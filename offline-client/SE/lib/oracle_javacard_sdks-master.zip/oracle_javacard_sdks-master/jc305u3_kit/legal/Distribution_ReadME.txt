DistributionREADME

Copyright (c) 1998, 2018, Oracle and/or its affiliates. All rights reserved.

DISTRIBUTION BY DEVELOPERS.  Subject to the terms and conditions of the Software License Agreement and the obligations, restrictions, and exceptions set forth below, You may reproduce and distribute the portions of Software identified below ("Redistributable"), provided that:

(a) You distribute Redistributable complete and unmodified and only bundled as part of Your Programs,

(b) Your Programs add significant and primary functionality to the Redistributable,

(c) You do not distribute additional software intended to replace any
component(s) of the Redistributable,

(d) You do not remove or alter any proprietary legends or notices contained in or on the Redistributable.

(e) You only distribute the Redistributable subject to a license agreement that protects Oracle's interests consistent with the terms contained in this
Agreement, and

(f) You agree to defend and indemnify Oracle and its licensors from and against any damages, costs, liabilities, settlement amounts and/or expenses  (including attorneys' fees) incurred in connection with any claim, lawsuit or action by any third party that arises or results from the use or distribution of any and all Programs and/or Redistributable.

The following files are Redistributables:

Java Card Development Kit 3.0.5
