from typing import Literal, Union
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Signature.pkcs1_15 import new as new_pkcs1_15
from Crypto.Signature.pss import new as new_pss
from ..common.bytes_io import to_bytes

class RasPkcsSigner:

    def __init__(self, n: Union[int, str, bytes, bytearray], d: Union[int, str, bytes, bytearray], e: Union[int, str, bytes, bytearray]=65537, scheme: Literal['PKCS#1 PSS', 'PKCS#1 v1.5']='PKCS#1 v1.5'):
        if isinstance(n, (str, bytes, bytearray)):
            n = int.from_bytes(to_bytes(n), 'big')
        if isinstance(e, (str, bytes, bytearray)):
            e = int.from_bytes(to_bytes(e), 'big')
        if isinstance(d, (str, bytes, bytearray)):
            d = int.from_bytes(to_bytes(d), 'big')
        self.private_key = RSA.construct((n, e, d))
        self.scheme = new_pkcs1_15(self.private_key) if scheme == 'PKCS#1 v1.5' else new_pss(self.private_key)

    def sign(self, data: Union[str, bytes]):
        return self.scheme.sign(SHA256.new(data))

class RasPkcsVerifier:

    def __init__(self, n: Union[int, str, bytes, bytearray], e: Union[int, str, bytes, bytearray]=65537, scheme: Literal['PKCS#1 PSS', 'PKCS#1 v1.5']='PKCS#1 v1.5'):
        if isinstance(n, (str, bytes, bytearray)):
            n = int.from_bytes(to_bytes(n), 'big')
        if isinstance(e, (str, bytes, bytearray)):
            e = int.from_bytes(to_bytes(e), 'big')
        self.public_key = RSA.construct((n, e))
        self.scheme = new_pkcs1_15(self.public_key) if scheme == 'PKCS#1 v1.5' else new_pss(self.public_key)

    def verify(self, data: Union[str, bytes], signature: Union[str, bytes]):
        h = SHA256.new(data)
        try:
            self.scheme.verify(h, signature)
            return True
        except (ValueError, TypeError):
            return False
__all__ = [RasPkcsSigner.__name__, RasPkcsVerifier.__name__]