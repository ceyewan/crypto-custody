from ctypes import create_string_buffer
from enum import IntEnum
from typing import Any, Dict, Literal, Tuple, Union, overload
from Crypto.Util.Padding import pad, unpad
from Crypto.Cipher import AES, _mode_ecb, _mode_cbc, _mode_cfb, _mode_ofb, _mode_ctr, _mode_openpgp, _mode_ccm, _mode_eax, _mode_siv, _mode_gcm, _mode_ocb
from Crypto.Hash import CMAC

def aes_ecb_cmac(key: bytes, data: bytes, mac_len: int=None):
    cmac = CMAC.new(key, data, AES, mac_len=mac_len)
    return cmac.digest()

class AES_MODE(IntEnum):
    ECB = AES.MODE_ECB
    CBC = AES.MODE_CBC
    CFB = AES.MODE_CFB
    OFB = AES.MODE_OFB
    CTR = AES.MODE_CTR
    OPENPGP = AES.MODE_OPENPGP
    CCM = AES.MODE_CCM
    EAX = AES.MODE_EAX
    SIV = AES.MODE_SIV
    GCM = AES.MODE_GCM
    OCB = AES.MODE_OCB

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.ECB]) -> _mode_ecb.EcbMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.CBC], *, iv: bytes=None) -> _mode_cbc.CbcMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.CFB], *, iv: bytes=None, segment_size: int=8) -> _mode_cfb.CfbMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.OFB], *, iv: bytes=None) -> _mode_ofb.OfbMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.SIV], *, nonce: bytes=None) -> _mode_siv.SivMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.EAX], *, nonce: bytes=None, mac_len: int=16) -> _mode_eax.EaxMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.GCM], *, nonce: bytes=None, mac_len: int=16) -> _mode_gcm.GcmMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.OCB], *, nonce: bytes=None, mac_len: int=16) -> _mode_ocb.OcbMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.CCM], *, nonce: bytes=None, mac_len: int=16, msg_len: int=None, assoc_len: int=None) -> _mode_ccm.CcmMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.CTR], *, nonce: bytes=None, initial_value: bytes=None) -> _mode_ctr.CtrMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.CTR], *, counter: Dict[str, Any]=None) -> _mode_ctr.CtrMode:
    pass

@overload
def new_aes(key: bytes, mode: Literal[AES_MODE.OPENPGP], *, iv: bytes=None) -> _mode_openpgp.OpenPgpMode:
    pass

@overload
def new_aes(key: bytes, mode: AES_MODE, **kwargs) -> Union[_mode_ecb.EcbMode, _mode_cfb.CfbMode, _mode_siv.SivMode, _mode_eax.EaxMode, _mode_gcm.GcmMode, _mode_ocb.OcbMode, _mode_ccm.CcmMode, _mode_ctr.CtrMode]:
    pass

def new_aes(*args, **kwargs) -> Union[_mode_ecb.EcbMode, _mode_cfb.CfbMode, _mode_siv.SivMode, _mode_eax.EaxMode, _mode_gcm.GcmMode, _mode_ocb.OcbMode, _mode_ccm.CcmMode, _mode_ctr.CtrMode]:
    kwargs = {k: v for (k, v) in kwargs.items() if v != None}
    return AES.new(*args, **kwargs)

class AesEcbCipher:

    def __init__(self, key: bytes, pad_style: Literal['pkcs7', 'iso7816', 'x923']='pkcs7') -> None:
        self.aes = new_aes(key, AES_MODE.ECB)
        self.pad_style = pad_style

    def encrypt(self, plain: bytes) -> bytes:
        if len(plain) % AES.block_size != 0:
            plain = pad(plain, AES.block_size, self.pad_style)
        return self.aes.encrypt(plain)

    def decrypt(self, cipher: bytes) -> bytes:
        plain = self.aes.decrypt(cipher)
        if len(plain) % AES.block_size != 0:
            plain = unpad(plain, AES.block_size, self.pad_style)
        return plain

    @staticmethod
    def enc(plain: bytes, key: bytes, pad_style: Literal['pkcs7', 'iso7816x923']='pkcs7') -> bytes:
        return AesEcbCipher(key, pad_style).encrypt(plain)

    @staticmethod
    def dec(cipher: bytes, key: bytes, pad_style: Literal['pkcs7', 'iso7816x923']='pkcs7') -> bytes:
        return AesEcbCipher(key, pad_style).decrypt(cipher)

def aes_cbc_encrypt(key: bytes, plain: bytes, iv: bytes=None) -> bytes:
    cipher = new_aes(key, AES_MODE.CBC, iv=iv or bytes(16))
    return cipher.encrypt(plain)
__all__ = [aes_ecb_cmac.__name__, AES_MODE.__name__, new_aes.__name__, AesEcbCipher.__name__, aes_cbc_encrypt.__name__]