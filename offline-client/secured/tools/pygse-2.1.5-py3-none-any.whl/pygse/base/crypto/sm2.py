import os
from typing import Dict, Union
from gmssl import sm2, sm3
from ..common.bytes_io import to_bytes

def sm2_calculate_e(public_key: Union[bytes, str], IDa: Union[bytes, str], data: Union[bytes, str], ecc_table: Dict=sm2.default_ecc_table) -> bytes:
    public_key = to_bytes(public_key)
    IDa = to_bytes(IDa)
    data = to_bytes(data)
    ecc_table = ecc_table or sm2.default_ecc_table
    a = bytes.fromhex(ecc_table['a'])
    b = bytes.fromhex(ecc_table['b'])
    gx = bytes.fromhex(ecc_table['g'][0:64])
    gy = bytes.fromhex(ecc_table['g'][64:128])
    ENTLa = len(IDa) * 8
    ENTLa_bytes = ENTLa.to_bytes(2, byteorder='big')
    msg_for_za = ENTLa_bytes + IDa + a + b + gx + gy + public_key
    ZA = sm3.sm3_hash(list(msg_for_za))
    combined_msg = bytes.fromhex(ZA) + data
    e = bytes.fromhex(sm3.sm3_hash(list(combined_msg)))
    return e

def sm2_sign(private_key: Union[bytes, str], data: Union[str, bytes], ecc_table: Dict=sm2.default_ecc_table) -> bytes:
    sm2_crypt = sm2.CryptSM2(public_key='', private_key=private_key if isinstance(private_key, str) else private_key.hex(), ecc_table=ecc_table)
    data = to_bytes(data)
    K = os.urandom(sm2_crypt.para_len >> 1).hex()
    signature = sm2_crypt.sign(data, K)
    return to_bytes(signature)

def sm2_verify(public_key: Union[bytes, str], e: Union[bytes, str], signature: Union[bytes, str], ecc_table: Dict=sm2.default_ecc_table) -> bool:
    try:
        public_key = public_key.hex() if isinstance(public_key, (bytes, bytearray)) else public_key
        e = to_bytes(e)
        signature = signature.hex() if isinstance(signature, (bytes, bytearray)) else signature
        sm2_crypt = sm2.CryptSM2(public_key=public_key, private_key=None, ecc_table=ecc_table)
        return sm2_crypt.verify(signature, e)
    except Exception as ex:
        print(f'An error occurred during verification: {ex}')
        return False
__all__ = [sm2_calculate_e.__name__, sm2_sign.__name__, sm2_verify.__name__]