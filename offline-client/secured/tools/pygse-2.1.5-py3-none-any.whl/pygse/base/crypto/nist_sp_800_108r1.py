from typing import Callable, List, Literal, overload
from Crypto.Util.number import long_to_bytes
from Crypto.Hash import CMAC
from Crypto.Cipher import AES
from .sm4 import sm4_ecb_cmac
from .aes import aes_ecb_cmac

@overload
def kdf_counter(master: bytes, key_len: int, prf: Callable[[bytes, bytes], bytes], label: bytes=b'', context: bytes=b'', num_keys: Literal[1]=1) -> bytes:
    pass

@overload
def kdf_counter(master: bytes, key_len: int, prf: Callable[[bytes, bytes], bytes], label: bytes=b'', context: bytes=b'', num_keys: int=...) -> List[bytes]:
    pass

def kdf_counter(master: bytes, key_len: int, prf: Callable[[bytes, bytes], bytes], label: bytes=b'', context: bytes=b'', num_keys: int=1):
    if num_keys is None:
        num_keys = 1
    key_len_enc = long_to_bytes(key_len * num_keys * 8, 2)
    output_len = key_len * num_keys
    i = 1
    dk = b''
    while len(dk) < output_len:
        info = label + b'\x00' + key_len_enc + long_to_bytes(i, 1) + context
        dk += prf(master, info)
        i += 1
        if i > 4294967295:
            raise ValueError('Overflow in SP800 108 counter')
    if num_keys == 1:
        return dk[:key_len]
    else:
        kol = [dk[idx:idx + key_len] for idx in range(0, output_len, key_len)]
        return kol

def prf(algorithm=Literal['aes', 'sm4']):
    if algorithm == 'aes':
        return aes_ecb_cmac
    elif algorithm == 'sm4':
        return sm4_ecb_cmac
    else:
        raise Exception(f'Bad argument of algorithm={algorithm}')

def cmac(key: bytes, data: bytes, algorithm=Literal['aes', 'sm4']):
    if algorithm == 'aes':
        return aes_ecb_cmac(key, data)
    elif algorithm == 'sm4':
        return sm4_ecb_cmac(key, data)
    else:
        raise Exception(f'Bad argument of algorithm={algorithm}')
__all__ = [kdf_counter.__name__, prf.__name__, cmac.__name__]