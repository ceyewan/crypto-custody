from typing import Union
from gmssl import sm4
from Crypto.Util.Padding import pad, unpad
from ..common.bytes_io import to_bytes

class CryptSM4(sm4.CryptSM4):

    def crypt_ecb(self, input_data: bytes):
        self.padding_mode = None if len(input_data) % 16 == 0 else sm4.PKCS7
        return super().crypt_ecb(input_data)

def sm4_cbc_encrypt(key: bytes, plain: bytes, iv: bytes=None):
    cipher = sm4.CryptSM4()
    cipher.set_key(key, sm4.SM4_ENCRYPT)
    if len(plain) % 16 != 0:
        plain = pad(plain, 16)
    return cipher.crypt_cbc(iv or bytes(16), plain)

def sm4_ecb_encrypt(sm4_key: Union[bytes, str], plain_data: bytes) -> bytes:
    sm4_crypt = CryptSM4()
    sm4_crypt.set_key(to_bytes(sm4_key), sm4.SM4_ENCRYPT)
    encrypted_data = sm4_crypt.crypt_ecb(to_bytes(plain_data))
    return encrypted_data

def int_to_bytes(n: int, length: int):
    return n.to_bytes(length, 'big')
BLOCK_SIZE = 16
Rb = int_to_bytes(135, BLOCK_SIZE)

def xor_bytes(b1: bytes, b2: bytes):
    return bytes((a ^ b for (a, b) in zip(b1, b2)))

def left_shift(b: bytes):
    n = int.from_bytes(b, 'big')
    n = n << 1 & (1 << BLOCK_SIZE * 8) - 1
    return int_to_bytes(n, BLOCK_SIZE)

def generate_subkeys(key: bytes):
    sm4_crypt = CryptSM4(padding_mode=None)
    sm4_crypt.set_key(key, sm4.SM4_ENCRYPT)
    L = sm4_crypt.crypt_ecb(bytes(BLOCK_SIZE))
    K1 = left_shift(L)
    if L[0] & 128:
        K1 = xor_bytes(K1, Rb)
    K2 = left_shift(K1)
    if K1[0] & 128:
        K2 = xor_bytes(K2, Rb)
    return (K1, K2)

def sm4_ecb_cmac(key: bytes, data: bytes):
    sm4_crypt = CryptSM4()
    sm4_crypt.set_key(key, sm4.SM4_ENCRYPT)
    (K1, K2) = generate_subkeys(key)
    n = (len(data) + BLOCK_SIZE - 1) // BLOCK_SIZE
    if n == 0:
        n = 1
    last_block = data[(n - 1) * BLOCK_SIZE:]
    if len(last_block) < BLOCK_SIZE:
        last_block += bytes([128])
        last_block = last_block.ljust(BLOCK_SIZE, b'\x00')
        last_block = xor_bytes(last_block, K2)
    else:
        last_block = xor_bytes(last_block, K1)
    X = bytes(BLOCK_SIZE)
    for i in range(n - 1):
        block = data[i * BLOCK_SIZE:(i + 1) * BLOCK_SIZE]
        X = sm4_crypt.crypt_ecb(xor_bytes(X, block))
    sm4_crypt.padding_mode = None if len(last_block) == 16 else sm4.PKCS7
    X = sm4_crypt.crypt_ecb(xor_bytes(X, last_block))
    return X
__all__ = [sm4_cbc_encrypt.__name__, sm4_ecb_encrypt.__name__, sm4_ecb_cmac.__name__]