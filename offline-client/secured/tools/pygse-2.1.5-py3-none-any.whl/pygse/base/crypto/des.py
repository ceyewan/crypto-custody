from Crypto.Cipher import DES3

def des3_cbc_encrypt(key: bytes, plain: bytes):
    cipher = DES3.new(key, DES3.MODE_ECB)
    return cipher.encrypt(plain)
__all__ = [des3_cbc_encrypt.__name__]