from asyncio import StreamReader, StreamWriter, Task, open_connection, create_task, get_running_loop, StreamReaderProtocol
from socket import socket, gethostbyname
from typing import Any, Literal, Tuple, Union, Awaitable
from ...common.event import AsyncEvent
from .async_io import AsyncBinaryIO

class SocketClientInitializer:

    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port

class SocketClientInitializer:

    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port

class SocketIO(AsyncBinaryIO):
    reader: StreamReader = None
    writer: StreamWriter = None
    host: str = None
    port: int = None
    sock: socket = None
    _reading_task: Task = None

    def __init__(self, sock: Union[str, Tuple[str, int], socket]):
        super().__init__()
        self.on_open = AsyncEvent()
        self.on_closed = AsyncEvent()
        if isinstance(sock, (str, tuple)):
            (host, port) = sock.split(':') if isinstance(sock, str) else sock
            self.host = host
            self.port = int(port)
            self.name = f'{host}:{port}'
        elif isinstance(sock, socket):
            self.sock = sock
            (self.host, self.port) = sock.getpeername()
            self.name = f'{self.host}:{self.port}'
        else:
            raise Exception(f'Bad argument of sock, expect: "IP:PORT", ("IP", PORT) or socket object.')

    @property
    def closed(self):
        return not self.writer or self.writer.is_closing() or (not self.reader)

    async def open(self):
        if not self.closed:
            return
        if self.sock:
            if not self.sock.fileno():
                raise Exception(f'Can not open stream with a closed sock.')
            self.sock.setblocking(False)
            loop = get_running_loop()
            self.reader = StreamReader(loop=loop)
            protocol = StreamReaderProtocol(self.reader, loop=loop)
            (transport, _) = await loop.create_connection(lambda : protocol, sock=self.sock)
            self.writer = StreamWriter(transport, protocol, self.reader, loop)
        elif self.host:
            (self.reader, self.writer) = await open_connection(gethostbyname(self.host), int(self.port))
        self.on_open.emit(self)

    async def close(self):
        if self._reading_task and (not self._reading_task.done()):
            self._reading_task.cancel()
        if self.writer:
            writer = self.writer
            self.writer = None
            if not writer.is_closing():
                writer.close()
                await writer.wait_closed()
            self.on_closed.emit(self)

    async def read(self, size: int=None):
        if self.closed:
            return b''
        self._reading_task = create_task(self.reader.read(size or -1))
        return await self._reading_task

    async def write(self, data: bytes):
        if self.closed:
            return None
        self.writer.write(data)
        return await self.writer.drain()
__all__ = [SocketIO.__name__]