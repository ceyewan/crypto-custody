import io
import asyncio
import os
from typing import Literal, Tuple, Union
from tornado.websocket import websocket_connect, WebSocketClientConnection
from ...common.event import AsyncEvent
from ...common.uri import URI
from .async_io import AsyncBinaryIO

class WebSocketIO(AsyncBinaryIO):
    ws: WebSocketClientConnection = None

    def __init__(self, url: Union[str, URI]):
        super().__init__()
        self.on_open = AsyncEvent()
        self.on_closed = AsyncEvent()
        self.url = URI(url) if isinstance(url, str) else url
        self.name = os.path.basename(self.url.path)
        self.__read_buffer = bytearray()

    @property
    def closed(self):
        return not self.ws or self.ws.close_code

    async def open(self):
        self.ws = await websocket_connect(self.url.to_url())
        asyncio.create_task(self._read_message())
        self.on_open.emit(self)

    async def close(self) -> None:
        if self.ws:
            if self.ws.close_code is None:
                self.ws.close()
            self.ws = None
            self.on_closed.emit(self)

    async def _read_message(self):
        while True:
            msg = await self.ws.read_message()
            if msg is None:
                break
            self._on_message(msg)
        asyncio.create_task(self.close())

    def _on_message(self, msg: Union[str, bytes]):
        if isinstance(msg, str):
            self.__read_buffer.extend(msg.encode())
        else:
            self.__read_buffer.extend(msg)

    async def read(self, size: int=None):
        if not size:
            data = self.__read_buffer.copy()
        else:
            data = self.__read_buffer[:size]
        if data:
            del self.__read_buffer[:len(data)]
        return bytes(data)

    async def write(self, data: bytes):
        return await self.ws.write_message(data)
__all__ = [WebSocketIO.__name__]