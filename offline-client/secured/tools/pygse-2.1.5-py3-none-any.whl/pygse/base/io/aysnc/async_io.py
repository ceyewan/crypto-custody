from typing import Protocol, runtime_checkable
from ...common.event import AsyncEvent

@runtime_checkable
class AsyncBinaryIO(Protocol):
    name: str
    closed: bool
    on_open: AsyncEvent['AsyncBinaryIO']
    on_closed: AsyncEvent['AsyncBinaryIO']

    async def open(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def write(self, data: bytes) -> int:
        pass

    async def read(self, size: int=None) -> bytes:
        pass
__all__ = [AsyncBinaryIO.__name__]