import asyncio
from typing import Literal, Union
from serial_asyncio import open_serial_connection
from enum import IntEnum
from ...common.event import AsyncEvent
from .async_io import AsyncBinaryIO

class StopBits(IntEnum):
    BITS_1 = 1
    BITS_1_5 = 1.5
    BITS_2 = 2

class SerialIO(AsyncBinaryIO):
    _reading_task: asyncio.Task = None

    def __init__(self, port: str, baudrate: int=460800, bytesize: Literal[5, 6, 7, 8]=8, parity: Literal['N', 'E', 'O', 'M', 'S']='N', stopbits: Union[StopBits, float]=1, timeout: float=None, xonxoff: bool=False, rtscts: bool=False, write_timeout: float=None, dsrdtr: bool=False, inter_byte_timeout: float=None, exclusive: float=None) -> None:
        super().__init__()
        self.on_open = AsyncEvent()
        self.on_closed = AsyncEvent()
        self.name = port
        self.kwargs = {k: v for (k, v) in {'baudrate': baudrate, 'bytesize': bytesize, 'parity': parity, 'stopbits': stopbits, 'timeout': timeout, 'xonxoff': xonxoff, 'rtscts': rtscts, 'write_timeout': write_timeout, 'dsrdtr': dsrdtr, 'inter_byte_timeout': inter_byte_timeout, 'exclusive': exclusive}.items() if v != None}
        self._read_lock: asyncio.Lock = asyncio.Lock()
        self._write_lock: asyncio.Lock = asyncio.Lock()
        self.loop = asyncio.get_event_loop()

    @property
    def closed(self):
        return not self.writer or self.writer.is_closing() or (not self.reader)

    async def open(self):
        (self.reader, self.writer) = await open_serial_connection(url=self.name, **self.kwargs)
        self.on_open.emit(self)

    async def close(self):
        if self._reading_task and (not self._reading_task.done()):
            self._reading_task.cancel()
        if self.writer:
            writer = self.writer
            self.writer = None
            if not writer.is_closing():
                await writer.drain()
                writer.close()
                await writer.wait_closed()
            self.on_closed.emit(self)

    async def read(self, size: int=None):
        if self.closed:
            return b''
        self._reading_task = asyncio.create_task(self.reader.read(size or -1))
        return await self._reading_task

    async def write(self, data: bytes):
        if self.closed:
            return None
        self.writer.write(data)
        await self.writer.drain()
        await asyncio.sleep(0)
__all__ = [StopBits.__name__, SerialIO.__name__]