from time import sleep
from typing import Dict, List, Literal, Union
from ..common.abstract_device import DeviceInfo, ISeDevice
from .ccid_session import CcidSession, NoCardException, ReaderCommands

class CcidDevice(ISeDevice):
    session: CcidSession = None

    async def open(self):
        return await self.connect()

    async def close(self):
        return await self.disconnect()

    async def connect(self):
        try:
            if not self.session:
                self.session = CcidSession(self.name)
            else:
                self.session.connect()
            self.logger.info(f'ATR: {hex(self.session.atr)}')
        except NoCardException:
            raise Exception('未检测到卡片，无法打开读卡器。是否忘了放置卡片？')
        except Exception as ex:
            raise

    async def disconnect(self):
        self.session.disconnect()

    async def reconnect(self):
        try:
            self.session.reconnect()
            self.logger.info(f'ATR: {hex(self.session.atr)}')
            return self.session.atr
        except NoCardException:
            self.logger.error(f'reconnect 失败。未检测到卡片，是否忘记放置卡片？')
            raise ex
        except Exception as ex:
            raise ex

    async def reset(self) -> bytes:
        self.logger.info('RESET')
        return await self.reconnect()

    async def restart(self) -> bytes:
        self.logger.info('RESTART')
        return self.reconnect()

    async def transmit(self, cmd: bytes, timeout: float=None) -> bytes:
        return self.session.transmit(cmd)

    async def transmit_a(self, cmd: bytes, timeout: float=None) -> bytes:
        rsp1 = self.session.transmit(ReaderCommands.SET_POOL_A)
        rsp2 = self.session.transmit(cmd)
        rsp3 = self.session.transmit(ReaderCommands.SET_POOL_DEFAULT)
        return rsp2

    async def transmit_b(self, cmd: bytes, timeout: float=None) -> bytes:
        rsp1 = self.session.transmit(ReaderCommands.SET_POOL_B)
        rsp2 = self.session.transmit(cmd)
        rsp3 = self.session.transmit(ReaderCommands.SET_POOL_DEFAULT)
        return rsp2

    async def transmit_f(self, cmd: bytes, timeout: float=None) -> bytes:
        return self.session.transmit(cmd)

    async def power_off_field(self) -> bytes:
        return self.session.transmit(ReaderCommands.POWER_OFF_FIELD)

    async def power_on_field(self) -> bytes:
        self.reconnect()
        return self.session.transmit(ReaderCommands.POWER_ON_FIELD)
__all__ = [CcidDevice.__name__]