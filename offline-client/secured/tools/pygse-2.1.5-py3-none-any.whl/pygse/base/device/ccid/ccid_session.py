from enum import Enum
import logging
from typing import List, Union
from smartcard import Session
from smartcard.CardConnection import CardConnection
from smartcard.Exceptions import NoCardException

class ReaderCommands(Enum):
    SET_POOL_DEFAULT = bytes.fromhex('FF CC 00 00 02 95 1B')
    SET_POOL_A = bytes.fromhex('FF CC 00 00 02 95 00')
    SET_POOL_B = bytes.fromhex('FF CC 00 00 02 95 01')
    POWER_OFF_FIELD = bytes.fromhex('FF CC 00 00 02 96 00')
    POWER_ON_FIELD = bytes.fromhex('FF CC 00 00 02 96 01')

class CcidSession(Session):

    def __init__(self, readerName=None, cardServiceClass=None):
        super().__init__(readerName, cardServiceClass)
        self.name = readerName
        self.logger = logging.getLogger(self.name)

    @property
    def atr(self) -> bytes:
        return bytes(self.getATR() or [])

    @property
    def connection(self) -> CardConnection:
        return self.cs.connection

    def connect(self):
        self.connection.connect()

    def disconnect(self):
        self.connection.disconnect()

    def reconnect(self):
        self.connection.disconnect()
        self.connection.connect()

    def transmit(self, data: Union[str, bytes, List[int]]) -> bytes:
        if isinstance(data, str):
            data = bytes.fromhex(data)
        if isinstance(data, list):
            data = bytes(data)
        self.logger.info(f'S: {hex(data)}')
        (data, sw1, sw2) = self.connection.transmit(list(data))
        data.extend([sw1, sw2])
        rsp = bytes(data)
        self.logger.info(f'R: {hex(rsp)}')
        return rsp