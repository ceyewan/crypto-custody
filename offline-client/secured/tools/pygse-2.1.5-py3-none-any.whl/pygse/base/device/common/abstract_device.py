from enum import Enum
import logging
import os
from typing import Dict, List, Type, TypeVar, Union, overload
from serial.tools.list_ports import comports
from smartcard.System import readers
from ...common import URI, input_select
T = TypeVar('T')

class DeviceType(Enum):
    ACL_SOCKET = 'socket'
    ACL_WEBSOCKET = 'ws'
    ACL_WEBSOCKET_SSL = 'wss'
    CCID = 'ccid'
    SERIAL = 'serial'

    @classmethod
    def _missing_(cls, value: str):
        enum_member = object.__new__(cls)
        enum_member._value_ = value
        enum_member._name_ = value
        enum_member.__objclass__ = cls
        cls._value2member_map_[value] = enum_member
        cls._member_map_[value] = enum_member
        return enum_member

class DeviceInfo:
    name: str
    path: str
    type: DeviceType
    uri: URI

    @overload
    def __init__(self, *, uri: Union[str, URI]) -> None:
        pass

    @overload
    def __init__(self, *, type: DeviceType=DeviceType.ACL_SOCKET, netloc: str, name: str='') -> None:
        pass

    @overload
    def __init__(self, *, type: DeviceType=DeviceType.ACL_WEBSOCKET, netloc: str, path: str, name: str='') -> None:
        pass

    @overload
    def __init__(self, *, type: DeviceType=DeviceType.ACL_WEBSOCKET_SSL, netloc: str, path: str, name: str='') -> None:
        pass

    @overload
    def __init__(self, *, type: DeviceType=DeviceType.SERIAL, path: str) -> None:
        pass

    @overload
    def __init__(self, *, type: DeviceType=DeviceType.CCID, name: str='') -> None:
        pass

    @overload
    def __init__(self, *, type: str, name: str='') -> None:
        pass

    def __init__(self, *, type: DeviceType=None, uri: Union[str, URI]='', netloc: str='', path: str='', name: str='') -> None:
        if isinstance(type, str):
            type = DeviceType(type)
        if not isinstance(uri, URI):
            uri = URI(uri, scheme=type.value if isinstance(type, DeviceType) else type, netloc=netloc, path=path)
        if name:
            uri.set_query_value('name', name)
        if uri.scheme == DeviceType.ACL_SOCKET:
            name = name or uri.netloc
        elif uri.scheme == DeviceType.ACL_WEBSOCKET:
            name = name or uri.to_str()
        elif uri.scheme == DeviceType.ACL_WEBSOCKET_SSL:
            name = name or uri.to_str()
        else:
            name = name or uri.path
        self.name = os.path.basename(name)
        self.path = path
        self.uri = uri
        self.type = DeviceType(uri.scheme)

    def get_parameter(self, key: str, cls: Type[T]=str) -> Union[T, None]:
        val = self.uri.get_query_value(key)
        if val == None:
            return None
        return cls(val) if cls else val

    @staticmethod
    def new_socket(netloc: str, name: str=''):
        return DeviceInfo(type=DeviceType.ACL_SOCKET, netloc=netloc, name=name)

    @staticmethod
    def new_websocket(netloc: str, path: str, name: str=''):
        return DeviceInfo(type=DeviceType.ACL_SOCKET, netloc=netloc, path=path, name=name)

    @staticmethod
    def new_serial(path: str, name: str=''):
        return DeviceInfo(type=DeviceType.SERIAL, path=path, name=name)

    @staticmethod
    def new_ccid(name: str=''):
        return DeviceInfo(type=DeviceType.CCID, path=name)

    @staticmethod
    def new_custom(type: str, name: str):
        return DeviceInfo(type=type, name=name)

def list_devices() -> List[DeviceInfo]:
    return [DeviceInfo.new_ccid(r.name) for r in readers()] + [DeviceInfo.new_serial(com.device or com.name) for com in comports()]

def input_select_local_device(devices: List[DeviceInfo]=None) -> DeviceInfo:

    def ls_dev():
        device_list = devices or list_devices()
        if not device_list:
            raise Exception('No Serial or Reader device connected to host system.')
        return device_list
    while True:
        (dev, _) = input_select('Choose a local device to connect', ls_dev, lambda d: d.name, 0)
        return dev

class IAbstractDevice:
    dev_info: DeviceInfo
    closed: bool = False

    def __init__(self, uri_or_info: Union[str, DeviceInfo]):
        self.dev_info = DeviceInfo(uri_or_info) if isinstance(uri_or_info, str) else uri_or_info
        self.logger = logging.getLogger(self.dev_info.name)

    @property
    def name(self):
        return self.dev_info.name

    async def open(self) -> None:
        pass

    async def close(self) -> None:
        pass

class ISeDevice(IAbstractDevice):
    atr: bytes = bytes()

    def __init__(self, uri_or_info: Union[str, DeviceInfo]):
        super().__init__(uri_or_info)

    async def connect(self) -> bytes:
        pass

    async def disconnect(self) -> bytes:
        pass

    async def reconnect(self) -> bytes:
        pass

    async def reset(self) -> bytes:
        return bytes()

    async def restart(self) -> bytes:
        return bytes()

    async def transmit(self, cmd: bytes, timeout: float=None) -> bytes:
        return bytes()

    async def get_notifications(self) -> List[bytes]:
        return []

    async def clear_notifications(self) -> None:
        pass

class IVirtualSe(ISeDevice):
    const_commands: Dict[bytes, bytes]

    def __init__(self, uri_or_info: Union[str, DeviceInfo]):
        super().__init__(uri_or_info)
        self.atr = bytes.fromhex('3BFF1100FF012020474F4F4449582076312E3000007B')
        self.const_commands = {}
        for (req, rsp) in [('00A4040000', '6F81858408A000000151000000A579736706072A864886FC6B01600B06092A864886FC6B020203630906072A864886FC6B03640B06092A864886FC6B040275640B06092A864886FC6B040378640B06092A864886FC6B040470650D060B2A864886FC6B0507020301660E060C2B060104012A026E010301009F6501FFBF0C099F08065732000000009000'), ('80CA9F7F00', '9F7F2A0000000000000000000000000000000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF90009000'), ('80A4040010A0000000868F0000000000000000000100', '9000'), ('80A4040010A0000000868F0000000000000000000200', '0100030000020001010100000000A5000000000000000000000000000000000000000035ACA5170A1E65000D34170D082C7F000000962000010000000000000000FEA55AF000009A85D69FA534000000039000')]:
            self.const_commands[bytes.fromhex(req)] = bytes.fromhex(rsp)

    async def connect(self) -> bytes:
        return self.atr

    async def disconnect(self) -> bytes:
        return self.atr

    async def reconnect(self) -> bytes:
        return self.atr

    async def reset(self) -> bytes:
        return self.atr

    async def restart(self) -> bytes:
        return self.atr

    async def transmit(self, cmd: bytes, timeout: float=None) -> bytes:
        self.logger.info(f'S: {hex(cmd)}')
        rsp = self.const_commands.get(cmd, None) or self.process_command(cmd) or rsp or b'h\x84'
        self.logger.info(f'R: {hex(rsp)}')
        return rsp

    async def get_notifications(self) -> List[bytes]:
        return []

    def process_command(self, cmd: bytes) -> bytes:
        return None
__all__ = [DeviceType.__name__, DeviceInfo.__name__, IAbstractDevice.__name__, ISeDevice.__name__, IVirtualSe.__name__, list_devices.__name__, input_select_local_device.__name__]