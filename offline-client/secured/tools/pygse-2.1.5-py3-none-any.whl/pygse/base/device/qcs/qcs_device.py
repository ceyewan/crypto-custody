import logging
import asyncio
from typing import Dict, List, Tuple, Union
from concurrent.futures import Future
from traceback import print_exc
from ...common import AsyncEvent, SafeNamespace
from ...device import DeviceInfo, ISeDevice
from ...io.aysnc import SerialIO
from .qcs_protocol import NFC_LOG_CONFIG_CMD, NFC_LOG_CONFIG_NTF, NFC_CONNECT_SE_CMD, NFC_SE_TYPE, NFC_TRANSACTION_NTF, QcsApiId, QcsMessageId, QcsMessageType, QcsPacket, NFC_TRANSMIT_APDU_CMD, NFC_TRANSMIT_APDU_RSP, QcsResponsePacket
from .qcs_packet_handler import QcsPacketHandler

class IRequestData(SafeNamespace):
    cmd: QcsPacket
    future: asyncio.Future
    timeout: float

    def __init__(self, cmd: QcsPacket, future: asyncio.Future, timeout: float=None, **kwargs):
        super().__init__(cmd=cmd, future=future, timeout=timeout, **kwargs)

class QcsDevice(ISeDevice):
    target_se: NFC_SE_TYPE = NFC_SE_TYPE.NFCC_ESE
    on_open: AsyncEvent['QcsDevice']
    on_close: AsyncEvent['QcsDevice']
    on_message: AsyncEvent[QcsPacket]
    stream: SerialIO = None
    packet_handler: QcsPacketHandler = None
    hci_ntf: List[bytes]

    def __init__(self, uri_or_info: Union[str, DeviceInfo]) -> None:
        super().__init__(uri_or_info)
        self._requesting_api = {}
        self._waiting_ntf_api = {}
        self.on_open = AsyncEvent()
        self.on_close = AsyncEvent()
        self.on_message = AsyncEvent()
        self.hci_ntf = []
        self.timeout = self.dev_info.get_parameter('timeout', int) or 10
        self.loop = asyncio.get_event_loop()
        self._serial_request_queue = asyncio.Queue()

    @property
    def name(self):
        return self.dev_info.name

    @property
    def closed(self):
        return not self.stream or self.stream.closed

    async def open(self):
        kwargs = dict(baudrate=self.dev_info.get_parameter('baudrate', int) or 460800, bytesize=self.dev_info.get_parameter('bytesize', int), parity=self.dev_info.get_parameter('parity'), stopbits=self.dev_info.get_parameter('stopbits', float), timeout=self.dev_info.get_parameter('timeout', float), xonxoff=self.dev_info.get_parameter('xonxoff', int), rtscts=self.dev_info.get_parameter('rtscts', int), write_timeout=self.dev_info.get_parameter('write_timeout', int), dsrdtr=self.dev_info.get_parameter('dsrdtr', int))
        kwargs = {k: v for (k, v) in kwargs.items() if v != None}
        self.stream = SerialIO(self.dev_info.path, **kwargs)
        retry_times = 5
        while retry_times > 0:
            try:
                await self.stream.open()
                await self.stream.write(NFC_LOG_CONFIG_CMD(1).to_bytes())
                await asyncio.sleep(0.2)
                while True:
                    rsp = await asyncio.wait_for(self.stream.read(2), timeout=5)
                    tag = int.from_bytes(rsp, 'big') if rsp else 0
                    if tag not in (26786, 18594):
                        raise Exception('Failed to open log!')
                    rsp = await asyncio.wait_for(self.stream.read(2), timeout=5)
                    if not rsp:
                        raise Exception('Failed to read payload length!')
                    length = int.from_bytes(rsp, 'big')
                    if tag == 18594 and length != 1 or (tag == 26786 and length > 200):
                        raise Exception(f'Bad payload length of 0x{tag:04X}!')
                    rsp = await asyncio.wait_for(self.stream.read(length), timeout=5)
                    if tag == 18594:
                        retry_times = -1
                        break
            except:
                retry_times -= 1
                await self.stream.close()
        if retry_times == 0:
            raise Exception(f'无法建立钱包协议通信！请检查{self.dev_info.name}输出是否正常。')
        self.stream.on_open.register(lambda s: self.on_open.emit(self))
        self.stream.on_closed.register(lambda s: self.__on_device_closed())
        self.packet_handler = QcsPacketHandler(self.stream, self.__on_device_message)
        self._serial_request_task = self.loop.create_task(self._process_requests())

    async def close(self):
        if self.packet_handler:
            await self.packet_handler.close()

    async def connect(self) -> bytes:
        rsp = await self.qcs_request(NFC_CONNECT_SE_CMD(0, self.target_se))
        return bytes([144, 0] if rsp.status == 0 else [112, rsp.status])

    async def disconnect(self) -> bytes:
        rsp = await self.qcs_request(NFC_CONNECT_SE_CMD(1, self.target_se))
        return bytes([144, 0] if rsp.status == 0 else [112, rsp.status])

    async def reconnect(self) -> bytes:
        rsp = await self.qcs_request(NFC_CONNECT_SE_CMD(2, self.target_se))
        return bytes([144, 0] if rsp.status == 0 else [112, rsp.status])

    async def reset(self):
        return await self.reconnect()

    async def restart(self):
        return await self.reconnect()

    def __on_device_closed(self):
        self.on_close(self)

    def __on_device_message(self, pkt: QcsPacket):
        if pkt.mt == QcsMessageType.RESPONSE:
            future = self._requesting_api.get(pkt.api_id, None)
            if future and (not future.done()):
                future.set_result(pkt)
        elif pkt.msg_id == QcsMessageId.DEVICE_ERROR_NTF:
            for (api, futures) in self._requesting_api.items():
                for future in futures:
                    if not future.done():
                        future.set_result(None)
        if pkt.msg_id == QcsMessageId.NFC_TRANSACTION_NTF:
            self.__on_nfc_ntf(pkt)
        elif pkt.msg_id == QcsMessageId.NFC_LOG_CONFIG_NTF:
            self.__on_log(pkt)
        if pkt.msg_id in self._waiting_ntf_api:
            future = self._waiting_ntf_api[pkt.msg_id]
            if not future.done():
                future.set_result(pkt)
        self.on_message(pkt)

    def __on_log(self, pkt: NFC_LOG_CONFIG_NTF):
        if ' = 6F19' in pkt.log or ' NFC received ntf gid:15' in pkt.log:
            return
        logging.debug(pkt.log.strip())

    def __on_nfc_ntf(self, pkt: NFC_TRANSACTION_NTF):
        if pkt.hci_packet_header != 145 or pkt.hci_message_header != 82 or (not pkt.hci_message):
            return
        hci_ntf = len(pkt.hci_message).to_bytes(2, 'big') + pkt.hci_message
        self.hci_ntf.append(hci_ntf)

    async def transmit(self, apdu: bytes, timeout: float=None) -> bytes:
        self.logger.info(f'S: {hex(apdu)}')
        rsp: NFC_TRANSMIT_APDU_RSP = await self.qcs_request(NFC_TRANSMIT_APDU_CMD(apdu), timeout)
        self.logger.info(f'R: {hex(rsp.apdu)}')
        return rsp.apdu

    async def get_notifications(self) -> List[bytes]:
        rsp = self.hci_ntf
        self.hci_ntf = []
        return rsp
    _requesting_api: Dict[QcsApiId, Future]
    _waiting_ntf_api: Dict[QcsApiId, Future]
    _serial_request_queue: 'asyncio.Queue[IRequestData]' = None

    async def _process_requests(self):
        while not self.closed:
            try:
                req = await self._serial_request_queue.get()
            except:
                continue
            try:
                future = self.loop.create_future()
                self._requesting_api[req.cmd.api_id] = future
                await self.packet_handler.send(req.cmd)
                rsp: Union[QcsResponsePacket, None] = await asyncio.wait_for(future, req.timeout or self.timeout)
                if not req.future.done():
                    req.future.set_result(rsp)
            except Exception as e:
                if not req.future.done():
                    req.future.set_exception(e)
            finally:
                if not future.done():
                    future.cancel()
                self._requesting_api.pop(req.cmd.api_id, None)
                self._serial_request_queue.task_done()

    async def qcs_request(self, cmd: QcsPacket, timeout: float=None) -> Union[QcsResponsePacket, None]:
        future = self.loop.create_future()
        await self._serial_request_queue.put(IRequestData(cmd, future, timeout))
        try:
            rsp: Union[QcsResponsePacket, None] = await asyncio.wait_for(future, (timeout or self.timeout) + 0.5)
            return rsp
        except asyncio.exceptions.TimeoutError as e:
            e.args = (f'Request Timeout! CMD={hex(cmd)}',) + e.args[1:]
            self.logger.error(e)
            raise
        except Exception as e:
            self.logger.error(e)
            raise
        finally:
            if not future.done():
                future.cancel()

    async def qcs_wait_for_ntf(self, msg_id: QcsMessageId, timeout: float=None) -> Union[QcsPacket, None]:
        future = self.loop.create_future()
        self._waiting_ntf_api[msg_id] = future
        try:
            rsp: Union[QcsResponsePacket, None] = await asyncio.wait_for(future, (timeout or self.timeout) + 0.5)
            return rsp
        except asyncio.exceptions.TimeoutError as e:
            e.args = (f'Timeout! while waiting {str(msg_id)}.',) + e.args[1:]
            raise
        except:
            raise
        finally:
            if not future.done():
                future.cancel()
            self._waiting_ntf_api.pop(msg_id, None)
__all__ = [QcsDevice.__name__]