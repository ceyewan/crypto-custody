import asyncio
import logging
from typing import Any, Awaitable, Callable, Union
from ...common.event import AsyncEvent
from ...io.aysnc import AsyncBinaryIO
from .qcs_protocol import QcsPacket

class QcsPacketHandler:
    on_message: AsyncEvent[QcsPacket]

    def __init__(self, stream: AsyncBinaryIO, on_message: Union[Callable[[QcsPacket], Any], Callable[[QcsPacket], Awaitable[Any]]]=None) -> None:
        self.logger = logging.getLogger(stream.name)
        self.stream = stream
        self.on_message = AsyncEvent()
        if on_message:
            self.on_message += on_message
        asyncio.create_task(self._read_data_thread())

    @property
    def closed(self):
        return self.stream.closed

    async def close(self):
        await self.stream.close()

    async def send(self, req: QcsPacket):
        buf = req.to_bytes()
        self.logger.debug(f'S: {hex(buf)}')
        await self.stream.write(buf)

    async def _read_data_thread(self):
        log_head = bytes([104, 162])
        reading_buffer = bytearray()
        want_read = 2
        reading_state = 0
        while not self.stream.closed:
            buf: bytes = None
            if reading_state == 0:
                reading_buffer.clear()
                want_read = 2
                reading_state = 1
            try:
                buf = await self.stream.read(want_read)
            except Exception as ex:
                self.logger.error(ex)
                break
            if not buf:
                await asyncio.sleep(0.1)
                break
            reading_buffer.extend(buf)
            want_read -= len(buf)
            if reading_state == 1:
                if want_read == 0:
                    ld = reading_buffer[1] >> 7
                    want_read = 2 if ld else 1
                    reading_state = 2
                    if reading_buffer[0] not in (40, 72, 104):
                        self.logger.error(f'Invalid QCS packet head: {hex(reading_buffer)}. The communication protocol has been corrupted!')
            elif reading_state == 2:
                if want_read == 0:
                    want_read = int.from_bytes(reading_buffer[2:], 'big')
                    reading_state = 3 if want_read else 0
            elif reading_state == 3:
                if want_read == 0:
                    try:
                        if not reading_buffer.startswith(log_head):
                            self.logger.debug(f'R: {hex(reading_buffer)}')
                        pkt = QcsPacket.try_from_bytes(reading_buffer)
                        if pkt:
                            self.on_message.emit(pkt)
                        else:
                            self.logger.error(f'Invalid packet: {hex(reading_buffer)}')
                    except Exception as ex:
                        self.logger.error(ex)
                    reading_state = 0
        await self.close()
        self.logger.debug('Stream closed.')
__all__ = [QcsPacketHandler.__name__]