from abc import abstractmethod
from enum import IntEnum
import logging
from typing import Dict, List, Literal, Tuple, Type, Union
from ...common import BytesIO

class QcsMessageType(IntEnum):
    COMMAND = 1
    RESPONSE = 2
    NOTIFICATION = 3

    @staticmethod
    def from_byte(b0: int):
        return QcsMessageType(b0 >> 5)

class QcsApiId(IntEnum):
    DEVICE_ERROR_NTF = 3
    NFC_RESET = 17
    NFC_TRANSMIT_APDU = 24
    NFC_REGISTER_NOTIFICATION = 26
    NFC_TRANSACTION_NTF = 27
    NFC_CHANGE_TRANSPARENT_MODE = 28
    NFC_LOG_CONFIG = 34
    DEVICE_SWITCH_CURRENT_MODE = 36
    NFC_CONNECT_SE = 38
    NFC_TRANSPARENT_MODE_TRANS = 45

    @staticmethod
    def from_byte(b1: int):
        return QcsApiId(b1 & 127)

class QcsMessageId(IntEnum):
    DEVICE_ERROR_NTF = 26627
    NFC_RESET_CMD = 10257
    NFC_RESET_RSP = 18449
    NFC_RESET_NTF = 26641
    NFC_TRANSMIT_APDU_CMD = 10264
    NFC_TRANSMIT_APDU_RSP = 18456
    NFC_REGISTER_NOTIFICATION_CMD = 10266
    NFC_REGISTER_NOTIFICATION_RSP = 18458
    NFC_TRANSACTION_NTF = 26651
    NFC_CHANGE_TRANSPARENT_MODE_CMD = 10268
    NFC_CHANGE_TRANSPARENT_MODE_RSP = 18460
    NFC_CHANGE_TRANSPARENT_MODE_NTF = 26652
    NFC_LOG_CONFIG_CMD = 10274
    NFC_LOG_CONFIG_RSP = 18466
    NFC_LOG_CONFIG_NTF = 26658
    DEVICE_SWITCH_CURRENT_MODE_CMD = 10276
    DEVICE_SWITCH_CURRENT_MODE_RSP = 18468
    NFC_CONNECT_SE_CMD = 10278
    NFC_CONNECT_SE_RSP = 18470
    DEVICE_SWITCH_NFCC_POWER_MODE_CMD = 10279
    DEVICE_SWITCH_NFCC_POWER_MODE_RSP = 18471
    NFC_TRANSPARENT_MODE_TRANS_CMD = 10285
    NFC_TRANSPARENT_MODE_TRANS_RSP = 18477
    NFC_TRANSPARENT_MODE_TRANS_NTF = 26669

    @property
    def mt(self) -> QcsMessageType:
        return self.value >> 13

    @property
    def api_type(self) -> int:
        return (self.value & 3840) >> 8

    @property
    def api_id(self) -> QcsApiId:
        return self.value & 127

    @classmethod
    def _missing_(cls, value):
        new_member = int.__new__(cls, value)
        new_member._name_ = f'UNDEFINED_{value:04X}'
        new_member._value_ = value
        return new_member

    @staticmethod
    def from_int(value: int):
        return QcsMessageId(value & 61311)

    @staticmethod
    def try_from_int(value: Union[int, bytes, bytearray]):
        try:
            if isinstance(value, (bytes, bytearray)):
                value = int.from_bytes(value[0:2], 'big')
            return QcsMessageId.from_int(value)
        except:
            pass
        return None

    @classmethod
    def from_stream(cls, stream: BytesIO, peek: bool=False):
        value = stream.read_int(2, 'big')
        if peek and value is not None:
            stream.seek(-2, 1)
        return cls.from_int(value)

class QcsPacket:
    __packet_factory: Dict[QcsMessageId, Type['QcsPacket']] = {}
    msg_id: QcsMessageId
    mt: QcsMessageType
    pbf: bool = False
    api_type: int = 8
    ld: bool = False
    api_id: QcsApiId = 0
    payload: bytes = None

    def __init__(self, msg_id: QcsMessageId) -> None:
        self.msg_id = msg_id
        self.mt = msg_id.mt
        self.api_type = msg_id.api_type
        self.api_id = msg_id.api_id

    def serialize(self, stream: BytesIO) -> BytesIO:
        b0 = self.mt << 5
        b0 |= bool(self.pbf) << 4
        b0 |= self.api_type & 15
        b1 = 128
        b1 |= self.api_id & 127
        stream.write_byte(b0)
        stream.write_byte(b1)
        pos0 = stream.tell()
        stream.write_int(0, 2)
        self.serialize_payload(stream)
        pos1 = stream.tell()
        length = pos1 - pos0 - 2
        stream.seek(pos0, 0)
        stream.write_int(length, 2, 'big')
        stream.seek(pos1, 0)
        return stream

    def deserialize(self, stream: BytesIO) -> 'QcsPacket':
        self.msg_id = QcsMessageId.from_stream(stream, True)
        self.mt = self.msg_id.mt
        self.api_type = self.msg_id.api_type
        self.api_id = self.msg_id.api_id
        b0 = stream.read_byte()
        self.pbf = b0 >> 4 & 1
        b1 = stream.read_byte()
        self.ld = b1 >> 7
        if self.ld:
            length = stream.read_int(2, 'big')
        else:
            length = stream.read_byte()
        if length:
            mark = stream.tell()
            self.payload = stream.peek(length)
            self.deserialize_payload(stream)
            stream.seek(mark + len(self.payload), 0)
        return self

    @abstractmethod
    def serialize_payload(self, stream: BytesIO):
        stream.write(self.payload)
        return stream

    @abstractmethod
    def deserialize_payload(self, stream: BytesIO):
        return self

    def to_bytes(self) -> bytes:
        stream = BytesIO()
        self.serialize(stream)
        return stream.getvalue()

    @staticmethod
    def from_bytes(packet: Union[str, bytes]) -> 'QcsPacket':
        stream = BytesIO(packet)
        id = QcsMessageId.from_stream(stream, True)
        cls = QcsPacket.__packet_factory.get(id, lambda : QcsPacket(id))
        return cls().deserialize(stream)

    @staticmethod
    def try_from_bytes(packet: Union[str, bytes]) -> 'QcsPacket':
        try:
            if QcsMessageId.try_from_int(packet) is not None:
                return QcsPacket.from_bytes(packet)
        except Exception as ex:
            logging.debug(ex)
            pass
        return None

    @staticmethod
    def register(id: QcsMessageId):

        def inner(cls):
            QcsPacket.__packet_factory[id] = cls
            QcsPacket.__packet_factory[id.value] = cls
            return cls
        return inner

    def __bytes__(self):
        return self.to_bytes()

class QcsResponsePacket(QcsPacket):
    status: int

    def __init__(self, msg_id: QcsMessageId, status: int=0) -> None:
        super().__init__(msg_id)
        self.mt = QcsMessageType.RESPONSE

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.status or 0)
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.status = stream.read_byte()

@QcsPacket.register(QcsMessageId.DEVICE_ERROR_NTF)
class DEVICE_ERROR_NTF(QcsPacket):
    status: int

    def __init__(self, status: int=0) -> None:
        super().__init__(QcsMessageId.DEVICE_ERROR_NTF)
        self.mt = QcsMessageType.NOTIFICATION
        self.status = status or 0

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.status or 0)
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.status = stream.read_byte()

@QcsPacket.register(QcsMessageId.NFC_RESET_CMD)
class NFC_RESET_CMD(QcsPacket):
    reset_type: int

    def __init__(self, reset_type: int=0) -> None:
        super().__init__(QcsMessageId.NFC_RESET_CMD)
        self.reset_type = reset_type

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.reset_type)
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.reset_type = stream.read_byte()

@QcsPacket.register(QcsMessageId.NFC_RESET_RSP)
class NFC_RESET_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_RESET_RSP)

@QcsPacket.register(QcsMessageId.NFC_RESET_NTF)
class NFC_RESET_NTF(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_RESET_NTF)

@QcsPacket.register(QcsMessageId.NFC_TRANSMIT_APDU_CMD)
class NFC_TRANSMIT_APDU_CMD(QcsPacket):
    target: int = 1
    apdu: bytes = 1

    def __init__(self, apdu: bytes=None, target: int=1) -> None:
        super().__init__(QcsMessageId.NFC_TRANSMIT_APDU_CMD)
        self.target = target
        self.apdu = apdu

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.target)
        stream.write(self.apdu)

    def deserialize_payload(self, stream: BytesIO):
        self.target = self.payload[0]
        self.apdu = self.payload[1:]

@QcsPacket.register(QcsMessageId.NFC_TRANSMIT_APDU_RSP)
class NFC_TRANSMIT_APDU_RSP(QcsResponsePacket):
    apdu: bytes = None

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_TRANSMIT_APDU_RSP)
        self.apdu = bytes()

    def serialize_payload(self, stream: BytesIO):
        stream.write(self.apdu)

    def deserialize_payload(self, stream: BytesIO):
        self.apdu = self.payload if len(self.payload) > 1 else bytes([112]) + self.payload[:1]

@QcsPacket.register(QcsMessageId.NFC_REGISTER_NOTIFICATION_CMD)
class NFC_REGISTER_NOTIFICATION_CMD(QcsPacket):
    register_items: List[Tuple[int, int]] = []

    def __init__(self, register_items: List[Tuple[int, int]]=[]) -> None:
        super().__init__(QcsMessageId.NFC_REGISTER_NOTIFICATION_CMD)
        self.register_items = register_items

    def serialize_payload(self, stream: BytesIO):
        for (t, en) in self.register_items:
            stream.write_byte(t)
            stream.write_byte(en)
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.register_items = self.payload[::2]

@QcsPacket.register(QcsMessageId.NFC_REGISTER_NOTIFICATION_RSP)
class NFC_REGISTER_NOTIFICATION_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_REGISTER_NOTIFICATION_RSP)

@QcsPacket.register(QcsMessageId.NFC_TRANSACTION_NTF)
class NFC_TRANSACTION_NTF(QcsPacket):
    hci_packet_header: int = 0
    hci_message_header: int = 0
    hci_message: bytes = None

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_TRANSACTION_NTF)

    def serialize_payload(self, stream: BytesIO):
        return stream

    def deserialize_payload(self, stream: BytesIO):
        nci_head = stream.read_int(2, 'big')
        nci_length = stream.read_byte()
        self.hci_packet_header = stream.read_byte()
        length = nci_length - 1
        if length > 0:
            self.hci_message = stream.read(length)
            self.hci_message_header = self.hci_message[0]

class NFC_TRANSPARENT_MODE(IntEnum):
    DISABLE = 0
    NCI = 1
    NCI_AND_NDP = 2

@QcsPacket.register(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_CMD)
class NFC_CHANGE_TRANSPARENT_MODE_CMD(QcsPacket):
    mode: NFC_TRANSPARENT_MODE = 0

    def __init__(self, mode: Union[NFC_TRANSPARENT_MODE, Literal[0, 1, 2]]=0) -> None:
        super().__init__(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_CMD)
        self.mode = mode

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(int(self.mode or 0))
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.mode = stream.read_byte()

@QcsPacket.register(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_RSP)
class NFC_CHANGE_TRANSPARENT_MODE_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_RSP)

@QcsPacket.register(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_NTF)
class NFC_CHANGE_TRANSPARENT_MODE_NTF(QcsPacket):
    mode: NFC_TRANSPARENT_MODE = 0
    status: int

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_NTF)

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(int(self.mode or 0))
        stream.write_byte(self.status)

    def deserialize_payload(self, stream: BytesIO):
        self.enable = stream.read_byte()
        self.status = stream.read_byte()

class LogOutputTarget(IntEnum):
    BLE = 0
    UART = 1
    HID = 2
    CDC = 3
    CCID = 4
    NONE = 5

@QcsPacket.register(QcsMessageId.NFC_LOG_CONFIG_CMD)
class NFC_LOG_CONFIG_CMD(QcsPacket):
    log_output_target: LogOutputTarget = LogOutputTarget.NONE

    def __init__(self, log_output_target: Union[LogOutputTarget, Literal[0, 1, 2, 3, 4, 5]]=LogOutputTarget.NONE) -> None:
        super().__init__(QcsMessageId.NFC_LOG_CONFIG_CMD)
        self.log_output_target = 5 if log_output_target is None else log_output_target

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(5 if self.log_output_target is None else int(self.log_output_target))

    def deserialize_payload(self, stream: BytesIO):
        self.log_output_target = LogOutputTarget(stream.read_byte())

@QcsPacket.register(QcsMessageId.NFC_LOG_CONFIG_RSP)
class NFC_LOG_CONFIG_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_LOG_CONFIG_RSP)

@QcsPacket.register(QcsMessageId.NFC_LOG_CONFIG_NTF)
class NFC_LOG_CONFIG_NTF(QcsPacket):
    log: str

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_LOG_CONFIG_NTF)

    def serialize_payload(self, stream: BytesIO):
        if self.log:
            stream.write(self.log.encode())

    def deserialize_payload(self, stream: BytesIO):
        self.log = self.payload.decode()

class DeviceWorkingMode(IntEnum):
    ESE_CE = 1
    UICC1_CE = 2
    UICC2_CE = 3
    DH_POS = 4
    DEVICE_POS = 5
    DH_CE = 6
    DEVICE_CE = 7

@QcsPacket.register(QcsMessageId.DEVICE_SWITCH_CURRENT_MODE_CMD)
class DEVICE_SWITCH_CURRENT_MODE_CMD(QcsPacket):
    device_working_mode: DeviceWorkingMode = DeviceWorkingMode.ESE_CE

    def __init__(self) -> None:
        super().__init__(QcsMessageId.DEVICE_SWITCH_CURRENT_MODE_CMD)

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.device_working_mode or 0)
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.device_working_mode = stream.read_byte()

@QcsPacket.register(QcsMessageId.DEVICE_SWITCH_CURRENT_MODE_RSP)
class DEVICE_SWITCH_CURRENT_MODE_RSP(QcsPacket):
    status: int

    def __init__(self) -> None:
        super().__init__(QcsMessageId.DEVICE_SWITCH_CURRENT_MODE_RSP)

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.status or 0)
        return stream

    def deserialize_payload(self, stream: BytesIO):
        self.status = stream.read_byte()

class NFC_SE_TYPE(IntEnum):
    ESE = 1
    NFCC_ESE = 2
    UICC1 = 3

class NFC_CONNECT_SE_ACTION(IntEnum):
    CONNECT = 0
    DISCONNECT = 1
    RECONNECT = 2

@QcsPacket.register(QcsMessageId.NFC_CONNECT_SE_CMD)
class NFC_CONNECT_SE_CMD(QcsPacket):
    target: NFC_SE_TYPE = 2
    action: NFC_CONNECT_SE_ACTION = 0

    def __init__(self, action: Union[NFC_CONNECT_SE_ACTION, Literal[0, 1, 2]]=0, target: Union[NFC_SE_TYPE, Literal[1, 2, 3]]=2) -> None:
        super().__init__(QcsMessageId.NFC_CONNECT_SE_CMD)
        self.target = target or 2
        self.action = action or 0

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(int(self.target or 1))
        stream.write_byte(int(self.action or 0))

    def deserialize_payload(self, stream: BytesIO):
        self.target = stream.read_byte()
        self.action = stream.read_byte()

@QcsPacket.register(QcsMessageId.NFC_CONNECT_SE_RSP)
class NFC_CONNECT_SE_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_CONNECT_SE_RSP)

@QcsPacket.register(QcsMessageId.DEVICE_SWITCH_NFCC_POWER_MODE_CMD)
class DEVICE_SWITCH_NFCC_POWER_MODE_CMD(QcsPacket):
    nfcc_power_mode: int

    def __init__(self, nfcc_power_mode: int=0) -> None:
        super().__init__(QcsMessageId.DEVICE_SWITCH_NFCC_POWER_MODE_CMD)
        self.nfcc_power_mode = nfcc_power_mode

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.nfcc_power_mode)

    def deserialize_payload(self, stream: BytesIO):
        self.nfcc_power_mode = stream.read_byte()

@QcsPacket.register(QcsMessageId.DEVICE_SWITCH_NFCC_POWER_MODE_RSP)
class DEVICE_SWITCH_NFCC_POWER_MODE_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.DEVICE_SWITCH_NFCC_POWER_MODE_RSP)

@QcsPacket.register(QcsMessageId.NFC_TRANSPARENT_MODE_TRANS_CMD)
class NFC_TRANSPARENT_MODE_TRANS_CMD(QcsPacket):
    nci: bytes

    def __init__(self, nci: bytes=None) -> None:
        super().__init__(QcsMessageId.NFC_TRANSPARENT_MODE_TRANS_CMD)
        self.nci = nci

    def serialize_payload(self, stream: BytesIO):
        stream.write(self.nci)

    def deserialize_payload(self, stream: BytesIO):
        self.nci = self.payload

@QcsPacket.register(QcsMessageId.NFC_TRANSPARENT_MODE_TRANS_RSP)
class NFC_TRANSPARENT_MODE_TRANS_RSP(QcsResponsePacket):

    def __init__(self) -> None:
        super().__init__(QcsMessageId.NFC_TRANSPARENT_MODE_TRANS_RSP)

@QcsPacket.register(QcsMessageId.NFC_TRANSPARENT_MODE_TRANS_NTF)
class NFC_TRANSPARENT_MODE_TRANS_NTF(QcsPacket):
    nci: bytes

    def __init__(self, nci: bytes=None) -> None:
        super().__init__(QcsMessageId.NFC_TRANSPARENT_MODE_TRANS_NTF)
        self.nci = nci

    def serialize_payload(self, stream: BytesIO):
        stream.write(self.nci)

    def deserialize_payload(self, stream: BytesIO):
        self.nci = self.payload
__all__ = [QcsMessageType.__name__, QcsApiId.__name__, QcsMessageId.__name__, QcsPacket.__name__, QcsResponsePacket.__name__, DeviceWorkingMode.__name__, NFC_RESET_CMD.__name__, NFC_RESET_RSP.__name__, NFC_RESET_NTF.__name__, NFC_TRANSMIT_APDU_CMD.__name__, NFC_TRANSMIT_APDU_RSP.__name__, NFC_REGISTER_NOTIFICATION_CMD.__name__, NFC_REGISTER_NOTIFICATION_RSP.__name__, NFC_TRANSACTION_NTF.__name__, NFC_TRANSPARENT_MODE.__name__, NFC_CHANGE_TRANSPARENT_MODE_CMD.__name__, NFC_CHANGE_TRANSPARENT_MODE_RSP.__name__, NFC_CHANGE_TRANSPARENT_MODE_NTF.__name__, NFC_LOG_CONFIG_CMD.__name__, NFC_LOG_CONFIG_RSP.__name__, NFC_LOG_CONFIG_NTF.__name__, DEVICE_SWITCH_CURRENT_MODE_CMD.__name__, DEVICE_SWITCH_CURRENT_MODE_RSP.__name__, NFC_SE_TYPE.__name__, NFC_CONNECT_SE_ACTION.__name__, NFC_CONNECT_SE_CMD.__name__, NFC_CONNECT_SE_RSP.__name__, NFC_TRANSPARENT_MODE_TRANS_CMD.__name__, NFC_TRANSPARENT_MODE_TRANS_RSP.__name__, NFC_TRANSPARENT_MODE_TRANS_NTF.__name__]