import logging
from threading import Semaphore
from typing import Callable, Coroutine
from ...io.aysnc import AsyncBinaryIO
from ..common import ISeDevice
from .acl_protocol import AclCommand, AclRequest, AclRequestType, AclResponse
from .acl_packet_handler import AclPacketHandler
DEFAULT_RESPONSE = AclResponse()

class AclPassiveDevice:
    _locker: Semaphore

    def __init__(self, device: ISeDevice):
        self.logger = logging.getLogger(device.name)
        self.device = device
        self._locker = Semaphore()

    def lock(self):
        return self._locker.acquire(False)

    def unlock(self):
        return self._locker.release()

    @property
    def name(self):
        return self.device.name

    async def handle_request(self, req: AclRequest) -> AclResponse:
        if req.request not in AclRequestType._value2member_map_:
            return AclResponse(req=req)
        cmd = AclRequestType(req.request)
        handler: Callable[[AclRequest], Coroutine[None, None, AclResponse]] = getattr(self, cmd.name.lower())
        if handler:
            try:
                rsp = await handler(req)
                rsp._req = req
                return rsp
            except Exception as ex:
                return AclResponse(err_terminal_code=-1, terminal_description=str(ex), err_server_description='KO', req=req)
        else:
            return AclResponse(req=req)

    async def req_heartbeat(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_connect(self, req: AclRequest) -> AclResponse:
        rsp = await self.device.connect()
        return AclResponse(rsp)

    async def req_diag(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_disconnect(self, req: AclRequest) -> AclResponse:
        rsp = await self.device.disconnect()
        return AclResponse(rsp)

    async def req_echo(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_init(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_restart(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_command(self, req: AclRequest) -> AclResponse:
        rsp = await self.device.transmit(req.data)
        return AclResponse(rsp)

    async def req_command_a(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_command_b(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_command_f(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_cold_reset(self, req: AclRequest) -> AclResponse:
        return AclResponse(await self.device.restart())

    async def req_warm_reset(self, req: AclRequest) -> AclResponse:
        return AclResponse(await self.device.reset())

    async def req_power_off_field(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_power_on_field(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_poll_a(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_poll_b(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_poll_f(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_poll_all_types(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_deactivate_interface(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_activate_interface(self, req: AclRequest) -> AclResponse:
        return DEFAULT_RESPONSE

    async def req_get_notifications(self, req: AclRequest) -> AclResponse:
        return AclResponse(await self.device.get_notifications())

    async def req_clear_notifications(self, req: AclRequest) -> AclResponse:
        return AclResponse(await self.device.clear_notifications())

class PassiveAclAdapter:
    remote_stream: AsyncBinaryIO = None
    remote_handler: AclPacketHandler = None

    def __init__(self, device: ISeDevice) -> None:
        self.passive_device = AclPassiveDevice(device)

    async def bind(self, remote_stream: AsyncBinaryIO):
        if self.remote_stream:
            await self.remote_stream.close()
        self.remote_stream = remote_stream
        self.remote_handler = AclPacketHandler(self.remote_stream, self.__on_remote_message)

    async def __on_remote_message(self, cmd: AclCommand):
        if self.passive_device.device.closed:
            await self.remote_handler.send(AclResponse(err_terminal_code=-1, terminal_description='Device closed!'))
            return
        rsp = await self.passive_device.handle_request(cmd)
        await self.remote_handler.send(rsp)
__all__ = ['AclPassiveDevice', 'PassiveAclAdapter']