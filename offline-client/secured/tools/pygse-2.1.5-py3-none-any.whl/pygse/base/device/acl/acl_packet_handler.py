import asyncio
import json
import logging
from time import sleep
from typing import Any, Awaitable, Callable, Union
from ...common.event import AsyncEvent
from ...io.aysnc import AsyncBinaryIO
from .acl_protocol import AclCommand, AclRequest, AclRequestType, AclResponse

class AclPacketHandler:
    __handshook: bool = False
    on_message: AsyncEvent[AclCommand]

    def __init__(self, stream: AsyncBinaryIO, on_message: Union[Callable[[AclCommand], Any], Callable[[AclCommand], Awaitable[Any]]]=None) -> None:
        self.logger = logging.getLogger(stream.name)
        self.stream = stream
        self.on_message = AsyncEvent()
        if on_message:
            self.on_message += on_message
        asyncio.create_task(self._read_data_thread())

    async def close(self):
        if not self.stream.closed:
            await self.stream.close()

    async def handshake(self, name: str):
        if self.__handshook:
            self.logger.warning('Client already handshook with server.')
            return
        self.logger.info(f'Handshake to ACL Server, using name={name}')
        await self.__send_packet(name)
        self.__handshook = True

    async def send(self, cmd: AclCommand):
        data = json.dumps(cmd)
        if isinstance(cmd, AclRequest):
            self.logger.info(f'S: {(hex(cmd.data) if cmd.data else cmd.request.name)}')
        elif isinstance(cmd, AclResponse):
            log = hex(cmd.response) if cmd.response else data
            if cmd._req.request == AclRequestType.REQ_HEARTBEAT:
                self.logger.debug(f'S: {log}')
            else:
                self.logger.info(f'S: {log}')
        await self.__send_packet(data)

    async def __send_packet(self, pkt: str):
        self.logger.debug(f'REQ: {pkt}')
        buf = pkt.encode()
        buf = len(buf).to_bytes(4, 'big') + buf
        return await self.stream.write(buf)

    async def _read_data_thread(self):
        want_read = 4
        reading_bytes = bytearray()
        read_state = 0
        while not self.stream.closed:
            buf = None
            if read_state == 0:
                reading_bytes.clear()
                want_read = 4
                read_state = 1
            try:
                buf = await self.stream.read(want_read)
            except Exception as ex:
                break
            if not buf:
                await asyncio.sleep(0.1)
                break
            reading_bytes.extend(buf)
            want_read -= len(buf)
            if read_state == 1:
                if want_read == 0:
                    want_read = int.from_bytes(reading_bytes, 'big')
                    if want_read:
                        reading_bytes.clear()
                        read_state = 2
                    else:
                        read_state = 0
            elif read_state == 2:
                if want_read == 0:
                    try:
                        payload = reading_bytes.decode()
                        self.logger.debug(f'RSP: {len(reading_bytes):08X}{hex(reading_bytes)}')
                        obj = json.loads(payload)
                        if 'request' in obj:
                            cmd = AclRequest(**obj)
                            if cmd.request == AclRequestType.REQ_HEARTBEAT:
                                self.logger.debug(f'REQ: {payload}')
                            else:
                                self.logger.info(f'REQ: {payload}')
                            self.on_message.emit(AclRequest(**obj))
                        else:
                            cmd = AclResponse(**obj)
                            if cmd.response:
                                self.logger.info(f'R: {hex(cmd.response)}')
                            self.on_message.emit(cmd)
                    except Exception as ex:
                        self.logger.error(ex)
                    finally:
                        read_state = 0
        await self.close()
        self.logger.debug('Stream closed.')
__all__ = [AclPacketHandler.__name__]