import asyncio
from concurrent.futures import Future, ThreadPoolExecutor
import threading
from typing import List, Union
from ...io.aysnc import SocketIO, WebSocketIO
from ...common import to_bytes
from ..common.abstract_device import DeviceInfo, DeviceType, ISeDevice
from .acl_protocol import *
from .acl_packet_handler import AclPacketHandler

class AclWebSocketIO(WebSocketIO):

    def __init__(self, url: str):
        super().__init__(url)

    def _on_message(self, msg: Union[str, bytes]):
        if msg == None:
            return
        if isinstance(msg, str):
            msg = msg.encode()
        msg = len(msg).to_bytes(4, 'big') + msg
        return super()._on_message(msg)

    async def write(self, data: bytes):
        return await super().write(data[4:])

class AclDevice1(ISeDevice):
    hci_ntf: List[bytes]
    __current_apdu_transmission_task: Future = None

    def __init__(self, uri_or_info: Union[str, DeviceInfo]) -> None:
        super().__init__(uri_or_info)
        self.loop = asyncio.get_event_loop()
        self.hci_ntf = []
        self.timeout = self.dev_info.get_parameter('timeout', int) or 10

    @property
    def name(self):
        return self.dev_info.name

    async def open(self):
        if self.dev_info.type == DeviceType.ACL_SOCKET:
            self.stream = SocketIO(self.dev_info.uri.netloc)
        elif self.dev_info.type == DeviceType.ACL_WEBSOCKET:
            self.stream = AclWebSocketIO(self.dev_info.uri)
        await self.stream.open()
        self.msg_handler = AclPacketHandler(self.stream, self.__on_device_message)

    async def close(self):
        await self.msg_handler.close()

    def __on_device_message(self, pkt: AclResponse):
        if self.__current_apdu_transmission_task and (not self.__current_apdu_transmission_task.done()):
            self.__current_apdu_transmission_task.set_result(pkt)

    async def transmit(self, cmd: bytes, timeout: float=None) -> bytes:
        future = asyncio.get_running_loop().create_future()
        try:
            await self.msg_handler.send(AclRequest(AclRequestType.REQ_COMMAND, cmd))
            self.__current_apdu_transmission_task = future
            rsp: AclResponse = await asyncio.wait_for(future, timeout or self.timeout)
            if rsp.err_server_code == 0 and rsp.err_terminal_code == 0:
                return to_bytes(rsp.response)
            else:
                raise Exception('; '.join([f'Server error: {str(rsp.err_server_code)}', f'Server err description: {rsp.err_server_description}Terminal error: {str(rsp.err_terminal_code)}', f'Terminal err description: {rsp.terminal_description}']))
        except (TimeoutError, asyncio.TimeoutError) as ex:
            future.cancel()
            raise
        except Exception:
            raise
        finally:
            self.__current_apdu_transmission_task = None

    async def transmit1(self, cmd: bytes, timeout: float=None) -> bytes:
        future = self.loop.create_future()

        async def run_in_loop():
            try:
                await self.msg_handler.send(AclRequest(AclRequestType.REQ_COMMAND, cmd))
                self.__current_apdu_transmission_task = future
                rsp: AclResponse = await asyncio.wait_for(future, timeout or self.timeout)
                if rsp.err_server_code == 0 and rsp.err_terminal_code == 0:
                    return to_bytes(rsp.response)
                else:
                    raise Exception('; '.join([f'Server error: {str(rsp.err_server_code)}', f'Server err description: {rsp.err_server_description}Terminal error: {str(rsp.err_terminal_code)}', f'Terminal err description: {rsp.terminal_description}']))
            except (TimeoutError, asyncio.TimeoutError) as ex:
                future.cancel()
                raise
            except Exception:
                raise
            finally:
                self.__current_apdu_transmission_task = None
        return await asyncio.wrap_future(asyncio.run_coroutine_threadsafe(run_in_loop(), self.loop))

    async def get_notifications(self) -> List[bytes]:
        rsp = self.hci_ntf
        self.hci_ntf = []
        return rsp

class AclDevice(ISeDevice):
    msg_handler: AclPacketHandler = None
    hci_ntf: List[bytes] = None
    __current_apdu_transmission_task: asyncio.Future = None
    loop: asyncio.AbstractEventLoop = None

    def __init__(self, uri_or_info: Union[str, DeviceInfo]) -> None:
        super().__init__(uri_or_info)
        self.hci_ntf = []
        self.timeout = self.dev_info.get_parameter('timeout', int) or 10

    def setup_event_loop(self):
        if self.loop and self.loop.is_running():
            return
        self.loop = asyncio.new_event_loop()
        loop_started = threading.Event()

        def start_loop(loop):
            asyncio.set_event_loop(loop)
            loop_started.set()
            loop.run_forever()
        self.loop_thread = threading.Thread(target=start_loop, name=f'asyncio_{self.name}', args=(self.loop,), daemon=True)
        self.loop_thread.start()
        loop_started.wait()

    def safe_stop_loop(self):
        tasks = [t for t in asyncio.all_tasks(self.loop) if t is not asyncio.current_task()]
        try:
            for task in tasks:
                task.cancel()
        except:
            pass
        try:
            asyncio.gather(*tasks, return_exceptions=True).result()
        except:
            pass
        self.loop.stop()

    def cleanup_event_loop(self):
        if self.loop and self.loop.is_running():
            self.loop.call_soon_threadsafe(self.safe_stop_loop)
            self.loop_thread.join()
            self.loop.close()

    async def run_in_loop(self, coro, *args):
        if not self.loop or not self.loop.is_running():
            raise Exception('Device is not connected!')
        fut = asyncio.run_coroutine_threadsafe(coro(*args), self.loop)
        return await asyncio.wrap_future(fut)

    def __del__(self):
        self.cleanup_event_loop()

    @property
    def name(self):
        return self.dev_info.name

    async def open(self):
        self.setup_event_loop()
        await self.run_in_loop(self._connect_inner)

    async def _connect_inner(self):
        if self.dev_info.type == DeviceType.ACL_SOCKET:
            self.stream = SocketIO(self.dev_info.uri.netloc)
        elif self.dev_info.type == DeviceType.ACL_WEBSOCKET:
            self.stream = AclWebSocketIO(self.dev_info.uri)
        await self.stream.open()
        self.msg_handler = AclPacketHandler(self.stream, self.__on_device_message)

    async def close(self):
        if self.msg_handler:
            await self.run_in_loop(self.msg_handler.close)
        self.cleanup_event_loop()

    async def transmit(self, cmd: bytes, timeout: float=None) -> bytes:
        result = await self.run_in_loop(self._transmit_inner, cmd, timeout)
        return result

    async def _transmit_inner(self, cmd: bytes, timeout: float=None) -> bytes:
        future = self.loop.create_future()
        try:
            await self.msg_handler.send(AclRequest(AclRequestType.REQ_COMMAND, cmd))
            self.__current_apdu_transmission_task = future
            rsp: AclResponse = await asyncio.wait_for(future, timeout or self.timeout)
            if rsp.err_server_code == 0 and rsp.err_terminal_code == 0:
                return to_bytes(rsp.response)
            else:
                raise Exception('; '.join([f'Server error: {str(rsp.err_server_code)}', f'Server err description: {rsp.err_server_description}Terminal error: {str(rsp.err_terminal_code)}', f'Terminal err description: {rsp.terminal_description}']))
        except (TimeoutError, asyncio.TimeoutError) as ex:
            future.cancel()
            raise
        except Exception:
            raise
        finally:
            self.__current_apdu_transmission_task = None

    def __on_device_message(self, pkt: AclResponse):
        if self.__current_apdu_transmission_task and (not self.__current_apdu_transmission_task.done()):
            self.__current_apdu_transmission_task.set_result(pkt)

    async def get_notifications(self) -> List[bytes]:
        rsp = self.hci_ntf
        self.hci_ntf = []
        return rsp
__all__ = [AclDevice.__name__]