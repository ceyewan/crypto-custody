from socket import create_connection, SocketIO
from .acl_protocol import *
from .acl_passive_device import *

class AclTransportLayer:
    __handshook: bool = False
    __on_request: Callable[[AclRequest], AclResponse]

    def __init__(self, stream: BinaryIO) -> None:
        self.stream = stream

    def disconnect(self):
        if not self.stream.closed:
            self.stream.close()

    def on_request(self, cb: Callable[[AclRequest], AclResponse]):
        self.__on_request = cb

    def handshake(self, name: str):
        if self.__handshook:
            logging.warning('Client already handshook with server.')
            return
        self.thread = Thread(target=self._read_data_thread)
        self.thread.start()
        logging.info(f'Handshake to ACL Server, using name={name}')
        self.__send_packet(name)
        self.__handshook = True

    def send(self, rsp: AclResponse):
        data = rsp.json()
        if rsp._req.request == AclRequestType.REQ_HEARTBEAT:
            logging.debug(f'ACL RSP: {data}')
        else:
            logging.info(f'ACL RSP: {data}')
        self.__send_packet(data)

    def __send_packet(self, pkt: str):
        buf = pkt.encode()
        self.stream.write(len(buf).to_bytes(4, 'big'))
        self.stream.write(buf)

    def _read_data_thread(self):
        logging.info(f'ACL Client TransportLayer thread started.')
        want_read = 4
        reading_bytes = bytearray()
        read_state = 0
        while not self.stream.closed:
            buf = None
            if read_state == 0:
                reading_bytes.clear()
                want_read = 4
                read_state = 1
            try:
                buf = self.stream.read(want_read)
            except Exception as ex:
                pass
            if not buf:
                sleep(0.1)
                continue
            reading_bytes.extend(buf)
            want_read -= len(buf)
            if read_state == 1:
                if want_read == 0:
                    want_read = int.from_bytes(reading_bytes, 'big')
                    if want_read:
                        reading_bytes.clear()
                        read_state = 2
                    else:
                        read_state = 0
            elif read_state == 2:
                if want_read == 0:
                    try:
                        payload = reading_bytes.decode()
                        req = AclRequest(payload)
                        if req.request == AclRequestType.REQ_HEARTBEAT:
                            logging.debug(f'ACL REQ: {payload}')
                        else:
                            logging.info(f'ACL REQ: {payload}')
                        self.__on_request(AclRequest(payload))
                    except Exception as ex:
                        logging.error(ex)
                    finally:
                        read_state = 0
        logging.info(f'ACL Client TransportLayer thread exited.')

class AclClient:
    name: str
    host: str
    device: IAclDevice
    __transport: AclTransportLayer

    def __init__(self, name: str, host: str, device: IAclDevice) -> None:
        if not name:
            raise Exception('parameter name is required!')
        if not host:
            raise Exception('parameter host is required!')
        if not device:
            raise Exception('parameter device is required!')
        self.name = name
        self.host = host
        self.device = device
        self.connect()

    def connect(self):
        logging.info(f'Connecting to ACL Server {self.host} ...')
        (hostname, port, *_) = self.host.split(':') + [80]
        sock = create_connection([hostname, int(port)], 5)
        sock.setblocking(False)
        self.__transport = AclTransportLayer(SocketIO(sock, 'rwb'))
        self.__transport.on_request(self.__on_request)
        self.__transport.handshake(f'{self.name} - {self.device.name}')

    def disconnect(self):
        self.__transport.disconnect()

    def __on_request(self, req: AclRequest):
        self.__transport.send(self.device.handle_request(req))