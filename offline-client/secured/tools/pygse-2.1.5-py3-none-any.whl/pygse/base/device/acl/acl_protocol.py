from enum import IntEnum
from typing import Union
from ...common import JsonEncodableObject, to_bytes

class AclErrorCode(IntEnum):
    SUCCESS = 0
    ERR_TIMEOUT = -1
    ERR_NETWORK = -2
    ERR_CLIENT_CLOSED = -3
    ERR_INVALID_STATE = -4
    ERR_INVALID_REQUEST = -5
    ERR_JSON_PARSING = -6
    ERR_INVALID_TERMINAL = -7

class AclRequestType(IntEnum):
    REQ_CONNECT = 0
    REQ_DIAG = 1
    REQ_DISCONNECT = 2
    REQ_ECHO = 3
    REQ_INIT = 4
    REQ_RESTART = 5
    REQ_COMMAND = 6
    REQ_COMMAND_A = 7
    REQ_COMMAND_B = 8
    REQ_COMMAND_F = 9
    REQ_COLD_RESET = 10
    REQ_WARM_RESET = 11
    REQ_POWER_OFF_FIELD = 12
    REQ_POWER_ON_FIELD = 13
    REQ_POLL_A = 14
    REQ_POLL_B = 15
    REQ_POLL_F = 16
    REQ_POLL_ALL_TYPES = 17
    REQ_DEACTIVATE_INTERFACE = 18
    REQ_ACTIVATE_INTERFACE = 19
    REQ_GET_NOTIFICATIONS = 20
    REQ_CLEAR_NOTIFICATIONS = 21
    REQ_HEARTBEAT = 99

class AclCommand(JsonEncodableObject):

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    def __json__(self):
        json = super().__json__()
        for (k, v) in json.items():
            if isinstance(v, bytes):
                json[k] = hex(v)
        return json

class AclRequest(AclCommand):
    request: AclRequestType
    data: bytes
    timeout: int

    def __init__(self, request: str=None, data: Union[str, bytes]=None, timeout: int=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.request = AclRequestType(request)
        self.data = to_bytes(data)
        self.timeout = timeout

class AclResponse(AclCommand):
    _req: AclRequest
    response: bytes
    err_server_code: AclErrorCode = AclErrorCode.SUCCESS
    err_server_description: str = 'OK'
    err_client_code: AclErrorCode = AclErrorCode.SUCCESS
    client_description: str = 'OK'
    err_terminal_code: AclErrorCode = AclErrorCode.SUCCESS
    terminal_description: str = 'OK'
    err_card_code: AclErrorCode = AclErrorCode.SUCCESS
    err_card_description: str = 'OK'

    def __init__(self, response: Union[str, bytes]='', err_server_code: AclErrorCode=AclErrorCode.SUCCESS, err_server_description: str='OK', err_client_code: AclErrorCode=AclErrorCode.SUCCESS, client_description: str='OK', err_terminal_code: AclErrorCode=AclErrorCode.SUCCESS, terminal_description: str='OK', err_card_code: AclErrorCode=AclErrorCode.SUCCESS, err_card_description: str='OK', req: AclRequest=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.response = to_bytes(response)
        self.err_server_code = err_server_code
        self.err_server_description = err_server_description
        self.err_client_code = err_client_code
        self.client_description = client_description
        self.err_terminal_code = err_terminal_code
        self.terminal_description = terminal_description
        self.err_card_code = err_card_code
        self.err_card_description = err_card_description
        self._req = req
__all__ = [AclErrorCode.__name__, AclRequestType.__name__, AclCommand.__name__, AclRequest.__name__, AclResponse.__name__]