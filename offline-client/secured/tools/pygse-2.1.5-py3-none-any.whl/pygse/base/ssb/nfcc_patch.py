import os
from typing import Dict, List, Union
from ..common import HexFile, BytesIO, read_file, read_json, crc32_mpeg2, CRC
from .ndp_protocol import *
from .patch_script import *

class NFCCPatchConfiguration:
    file: str = None
    mls_rom_hex: str
    mls_patch_table_hex: str
    mls_patch_code_hex: str
    patch_dsp_cos_patch_code: str
    patch_dsp_boot_patch_code: str
    dsp_config_file: str
    dsp_reg_excel_file: str
    ini_config_file: str
    flash_loader_script_file: str
    m0_patch_table_address: int
    m0_boot_patch_address: int
    m0_cos_patch_address: int
    m0_cos_patch_in_boot_area_address: int
    m0_cos_patch_in_share_ram_address: int
    m0_cos_patch_in_i2c_buf_address: int
    lifecycle: int
    mls_rom_version: int
    mls_boot_patch_version: int
    mls_cos_patch_version: int
    mls_flash_version: int
    package_segment_max: int
    flash_loader_segment_max: int
    mls_applet_instance_aid: bytes
    mls_applet_verify_key: bytes
    KEY_SE_AUT: bytes
    KEY_SE_ENC: bytes
    KEYID_AUT: bytes
    KEYID_ENC: bytes
    CNT: bytes
    crc_cal_enable: bool
    hardware_write_config_enable: bool

    def __init__(self, cfg: Union[Dict, str]) -> None:
        if isinstance(cfg, str):
            self.file = cfg
            cfg = read_json(cfg)
        self.__dict__.update(cfg)
        for (k, v) in self.__dict__.items():
            if 'address' in k:
                self.__dict__[k] = int(v, 16)
            if 'enable' in k:
                self.__dict__[k] = v == 'enable'
        self.mls_applet_instance_aid = bytes.fromhex(self.mls_applet_instance_aid)
        self.mls_applet_verify_key = bytes.fromhex(self.mls_applet_verify_key)
        self.KEY_SE_AUT = bytes.fromhex(self.KEY_SE_AUT)
        self.KEY_SE_ENC = bytes.fromhex(self.KEY_SE_ENC)
        self.KEYID_AUT = bytes.fromhex(self.KEYID_AUT)
        self.KEYID_ENC = bytes.fromhex(self.KEYID_ENC)
        self.CNT = bytes.fromhex(self.CNT)
        folder = os.path.dirname(os.path.realpath(self.file))

        def realpath(p: str):
            if os.path.isabs(p):
                return os.path.normpath(p)
            return os.path.normpath(os.path.join(folder, p))
        self.mls_rom_hex = realpath(self.mls_rom_hex)
        self.mls_patch_table_hex = realpath(self.mls_patch_table_hex)
        self.mls_patch_code_hex = realpath(self.mls_patch_code_hex)
        self.patch_dsp_cos_patch_code = realpath(self.patch_dsp_cos_patch_code)
        self.patch_dsp_boot_patch_code = realpath(self.patch_dsp_boot_patch_code)
        self.dsp_config_file = realpath(self.dsp_config_file)
        self.dsp_reg_excel_file = realpath(self.dsp_reg_excel_file)
        self.ini_config_file = realpath(self.ini_config_file)
        for f in (realpath(f'bat_file/{self.flash_loader_script_file}'), realpath(self.flash_loader_script_file)):
            if os.path.isfile(f):
                self.flash_loader_script_file = f
                break

class COSPatchPacket:
    raw: bytes
    header: bytes
    length: int
    payload: bytes

    def deserialize(self, input: BytesIO) -> 'COSPatchPacket':
        pos0 = input.tell()
        self.header = input.read(6)
        self.length = input.read_int(2)
        self.payload = input.read(self.length)
        pos1 = input.tell()
        input.seek(pos0, 0)
        self.raw = input.read(pos1 - pos0)
        return self

    @property
    def packet_length(self):
        return len(self.raw)

class COSPatchFile:
    packets: List[COSPatchPacket]

    def __init__(self, file: str) -> None:
        self.packets = []
        if file:
            self.load(file)

    def load(self, file: str):
        if not os.path.exists(file):
            raise Exception('File does not exists: {file}')
        self.packets.clear()
        input = BytesIO(read_file(file))
        while not input.at_end():
            self.packets.append(COSPatchPacket().deserialize(input))
        self.file = file

    def split(self, size: int=64 * 1024) -> List[bytes]:
        parts: List[bytearray] = []
        part: bytearray = None
        for p in self.packets:
            if not part or len(part) + p.packet_length > size:
                part = bytearray(p.raw)
                parts.append(part)
            else:
                part.extend(p.raw)
        return [bytes(p) for p in parts]

class PatchCommand:
    plain: Union[PATCH_PREPARE_CMD, PATCH_LOAD_CMD]
    encrypted: bytes

    def __init__(self, plain: Union[PATCH_PREPARE_CMD, PATCH_LOAD_CMD]) -> None:
        self.plain = plain

class SecurityPatchCommands:
    commands: List[PatchCommand] = None
    ivr: bytes = None
    ct0: bytes = None
    signature: bytes = None
    key_id_authentication: bytes
    key_id_encryption: bytes
    key_se_authentication: bytes
    key_se_encryption: bytes
    cnt: bytes
    init_aes_key: bytes = None
    init_aes_ivr: bytes = None

    def __init__(self, plain: List[Union[PATCH_PREPARE_CMD, PATCH_LOAD_CMD]], key_id_authentication: bytes, key_id_encryption: bytes, key_se_authentication: bytes, key_se_encryption: bytes, cnt: bytes, init_aes_key: bytes=None, init_aes_ivr: bytes=None) -> None:
        self.commands = list(map(lambda c: PatchCommand(c), plain))
        self.key_id_authentication = key_id_authentication
        self.key_id_encryption = key_id_encryption
        self.key_se_authentication = key_se_authentication
        self.key_se_encryption = key_se_encryption
        self.cnt = cnt
        if init_aes_key:
            self.init_aes_key = init_aes_key
        if init_aes_ivr:
            self.init_aes_ivr = init_aes_ivr
        self.__encrypt_plain_commands()

    def __encrypt_plain_commands(self) -> SET_AUTH_TO_ESE_CMD:
        key = self.init_aes_key or os.urandom(16)
        ivr = self.init_aes_ivr or os.urandom(12).ljust(16, bytes([255]))
        ivn = ivr[4:16]
        iv = int.from_bytes(ivn, 'big') + 256
        mac = bytes(16)
        aad = bytes(16)
        for cmd in reversed(self.commands):
            buf = right_padding(cmd.plain.to_bytes() + bytes([128]), 16) + mac
            iv -= 256
            (buf, mac) = AES.encrypt(input=buf, key=key, iv=iv.to_bytes(12, 'big'), aad=aad, mac=mac, alg=AES_ENCRYPT_MODE.GCM)
            cmd.encrypted = buf
        return self.__gen_secure_initialization(key, ivr, iv.to_bytes(12, 'big'), mac)

    def __gen_secure_initialization(self, key: bytes, ivr: bytes, iv: bytes, mac: bytes):
        encryption_data = right_padding(key + self.cnt + iv + mac + bytes([128]), 16)
        (ct0, _) = AES.encrypt(input=encryption_data, key=self.key_se_encryption, iv=ivr, alg=AES_ENCRYPT_MODE.CBC_128_NOPAD)
        if not ct0:
            raise Exception('CT0计算错误！')
        sign_data = right_padding(self.key_id_authentication + self.key_id_encryption + ct0 + ivr + bytes([128]), 16)
        (sign, _) = AES.encrypt(input=sign_data, key=self.key_se_authentication, iv=bytes(16), alg=AES_ENCRYPT_MODE.CBC_128_NOPAD)
        signature = sign[-16:]
        if not signature:
            raise Exception('Signature 计算错误！')
        self.ivr = ivr
        self.ct0 = ct0
        self.signature = signature

class PatchPart:
    patch_type: PatchType
    mls_rom_version: int
    mls_boot_patch_version: int
    mls_cos_patch_version: int
    address: int
    data: bytes
    crc: int

    def __init__(self, patch_type: PatchType, mls_rom_version: int, mls_boot_patch_version: int, mls_cos_patch_version: int, address: Union[int, None], data: bytes) -> None:
        self.patch_type = patch_type
        self.mls_rom_version = mls_rom_version
        self.mls_boot_patch_version = mls_boot_patch_version
        self.mls_cos_patch_version = mls_cos_patch_version
        self.address = address
        self.data = data
        self.crc = crc32_mpeg2(data)

    def make_plain_commands(self, patch_load_size: int=4000, alter_mls_rom_version: int=None, alter_mls_boot_patch_version: int=None, alter_mls_cos_patch_version: int=None) -> List[Union[PATCH_PREPARE_CMD, PATCH_LOAD_CMD]]:
        patch_load_size = patch_load_size or 4000
        mls_rom_version = self.mls_rom_version if alter_mls_rom_version == None else alter_mls_rom_version
        mls_boot_patch_version = self.mls_boot_patch_version if alter_mls_boot_patch_version == None else alter_mls_boot_patch_version
        mls_cos_patch_version = self.mls_cos_patch_version if alter_mls_cos_patch_version == None else alter_mls_cos_patch_version
        return [PATCH_PREPARE_CMD(self.patch_type, mls_rom_version, mls_boot_patch_version, mls_cos_patch_version, len(self.data), self.address), *PATCH_LOAD_CMD.make_cmd_list(self.patch_type, self.data, patch_load_size)]

class NFCCPatch:
    config: NFCCPatchConfiguration
    mls_rom_hex: HexFile = None
    mls_patch_table_hex: HexFile = None
    mls_patch_code_hex: HexFile = None
    dsp_cos_patch_hex: COSPatchFile = None
    dsp_boot_patch_hex: bytes = None
    m0_rom: PatchPart
    m0_patch_table: PatchPart
    m0_boot_patch: PatchPart
    m0_cos_patch: PatchPart
    m0_cos_patch_in_boot_area: PatchPart
    m0_cos_patch_in_share_ram: PatchPart
    m0_cos_patch_in_i2c_buf: PatchPart
    dsp_cos_patch: List[PatchPart]
    __gsn11_flash_loader: PatchScriptFile = None
    __loaded: bool = False

    def __init__(self, config: str) -> None:
        if config:
            self.config = NFCCPatchConfiguration(config)

    def reload_patch(self):
        self.__loaded = False
        self.load_patch()

    def load_patch(self):
        if self.__loaded:
            return True
        if os.path.isfile(self.config.mls_rom_hex):
            self.mls_rom_hex = HexFile(self.config.mls_rom_hex)
            self.m0_rom = self.mls_rom_hex.data()
            self.m0_rom = self.__make_patch_part(PatchType.M0_COS_PATCH, self.mls_rom_hex.data())
        if os.path.isfile(self.config.mls_patch_code_hex):
            self.mls_patch_code_hex = HexFile(self.config.mls_patch_code_hex)
            self.m0_boot_patch = self.__make_patch_part(PatchType.M0_COS_PATCH, self.mls_patch_code_hex.data(self.config.m0_boot_patch_address), self.config.m0_boot_patch_address)
            self.m0_cos_patch = self.__make_patch_part(PatchType.M0_COS_PATCH, self.mls_patch_code_hex.data(self.config.m0_cos_patch_address), self.config.m0_cos_patch_address)
            self.m0_cos_patch_in_boot_area = self.__make_patch_part(PatchType.M0_COS_PATCH, self.mls_patch_code_hex.data(self.config.m0_cos_patch_in_boot_area_address), self.config.m0_cos_patch_in_boot_area_address)
            self.m0_cos_patch_in_share_ram = self.__make_patch_part(PatchType.M0_COS_PATCH, self.mls_patch_code_hex.data(self.config.m0_cos_patch_in_share_ram_address), self.config.m0_cos_patch_in_share_ram_address)
            self.m0_cos_patch_in_i2c_buf = self.__make_patch_part(PatchType.M0_COS_PATCH, self.mls_patch_code_hex.data(self.config.m0_cos_patch_in_i2c_buf_address), self.config.m0_cos_patch_in_i2c_buf_address)
        if os.path.isfile(self.config.mls_patch_table_hex):
            self.mls_patch_table_hex = HexFile(self.config.mls_patch_table_hex)
            self.m0_patch_table = self.__make_patch_part(PatchType.PATCH_TABLE, self.mls_patch_table_hex.data(self.config.m0_patch_table_address))
        if os.path.isfile(self.config.patch_dsp_cos_patch_code):
            self.dsp_cos_patch_hex = COSPatchFile(self.config.patch_dsp_cos_patch_code)
            self.dsp_cos_patch = []
            for patch_data in self.dsp_cos_patch_hex.split():
                self.dsp_cos_patch.append(self.__make_patch_part(PatchType.DSP_COS_PATCH, patch_data))
        self.__loaded = self.mls_patch_code_hex and self.mls_patch_table_hex and self.dsp_cos_patch_hex
        return self.__loaded

    @property
    def gsn11_flash_loader(self) -> PatchScriptFile:
        if self.__gsn11_flash_loader:
            return self.__gsn11_flash_loader
        try:
            self.__gsn11_flash_loader = PatchScriptFile(self.config.flash_loader_script_file)
            return self.__gsn11_flash_loader
        except Exception as ex:
            return None

    def __make_patch_part(self, patch_type: PatchType, data: bytes, address: Union[int, None]=None) -> PatchPart:
        return PatchPart(patch_type, self.config.mls_rom_version, self.config.mls_boot_patch_version, self.config.mls_cos_patch_version, address, data)

    def __encrypt_plain_commands(self, patch_load_size: int, include_m0_patch_table: bool=True, alter_mls_rom_version: int=None, alter_mls_boot_patch_version: int=None, alter_mls_cos_patch_version: int=None):
        to_encrypt = self.m0_cos_patch.make_plain_commands(patch_load_size, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version) + self.m0_cos_patch_in_boot_area.make_plain_commands(patch_load_size, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version) + self.m0_cos_patch_in_share_ram.make_plain_commands(patch_load_size, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version) + self.m0_cos_patch_in_i2c_buf.make_plain_commands(patch_load_size, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version)
        if self.dsp_cos_patch_hex:
            to_encrypt.extend(sum(map(lambda p: p.make_plain_commands(patch_load_size, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version), self.dsp_cos_patch), []))
        if include_m0_patch_table:
            to_encrypt.extend(self.m0_patch_table.make_plain_commands(patch_load_size, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version))
        encrypted = SecurityPatchCommands(to_encrypt, self.config.KEYID_AUT, self.config.KEYID_ENC, self.config.KEY_SE_AUT, self.config.KEY_SE_ENC, self.config.CNT)
        return encrypted

    def to_patch_script_gsc(self, include_m0_patch_table: bool=True, alter_mls_rom_version: int=None, alter_mls_boot_patch_version: int=None, alter_mls_cos_patch_version: int=None) -> PatchScriptFile:
        self.load_patch()
        encrypted = self.__encrypt_plain_commands(self.config.package_segment_max, include_m0_patch_table, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version)
        secure_initialization_cmd = SECURE_INITIALIZATION_CMD(encrypted.ivr, encrypted.ct0, encrypted.signature)
        secure_protocol_cmd = list(map(lambda c: SECURE_PROTOCOL_CMD(c.encrypted, 1), encrypted.commands))
        last: SECURE_PROTOCOL_CMD = secure_protocol_cmd[-1]
        last.pbf = 0
        crc_check_cmd = [CRC_CHECK_CMD(0, len(self.m0_rom.data), self.m0_rom.crc), CRC_CHECK_CMD(self.m0_boot_patch.address, len(self.m0_boot_patch.data), self.m0_boot_patch.crc), CRC_CHECK_CMD(self.config.m0_patch_table_address, len(self.m0_patch_table.data), self.m0_patch_table.crc), CRC_CHECK_CMD(self.config.m0_cos_patch_address, len(self.m0_cos_patch.data), self.m0_cos_patch.crc), CRC_CHECK_CMD(self.config.m0_cos_patch_in_boot_area_address, len(self.m0_cos_patch_in_boot_area.data), self.m0_cos_patch_in_boot_area.crc), CRC_CHECK_CMD(self.config.m0_cos_patch_in_share_ram_address, len(self.m0_cos_patch_in_share_ram.data), self.m0_cos_patch_in_share_ram.crc), CRC_CHECK_CMD(self.config.m0_cos_patch_in_i2c_buf_address, len(self.m0_cos_patch_in_i2c_buf.data), self.m0_cos_patch_in_i2c_buf.crc)]
        if not include_m0_patch_table:
            crc_check_cmd.pop(2)
        mls_rom_version = self.config.mls_rom_version if alter_mls_rom_version == None else alter_mls_rom_version
        mls_boot_patch_version = self.config.mls_boot_patch_version if alter_mls_boot_patch_version == None else alter_mls_boot_patch_version
        mls_cos_patch_version = self.config.mls_cos_patch_version if alter_mls_cos_patch_version == None else alter_mls_cos_patch_version
        patch_target_interface = PatchTargetInterface(chip_type=PatchTargetChipType.GSC, script_commands=[secure_initialization_cmd, *secure_protocol_cmd, *crc_check_cmd])
        patch_target = PatchTarget(PatchTargetType.NFCC_PATCH, self.config.lifecycle, mls_rom_version, mls_boot_patch_version, mls_cos_patch_version, PatchTargetChipType.GSC, patch_target_interface)
        patch_file = PatchScriptFile(patch_target)
        return patch_file

    def to_patch_script_gsn(self, include_m0_patch_table: bool=True, alter_mls_rom_version: int=None, alter_mls_boot_patch_version: int=None, alter_mls_cos_patch_version: int=None) -> PatchScriptFile:
        self.load_patch()
        encrypted = self.__encrypt_plain_commands(self.config.flash_loader_segment_max, include_m0_patch_table, alter_mls_rom_version, alter_mls_boot_patch_version, alter_mls_cos_patch_version)
        select_mls_applet_cmd = SELECT_MLS_APPLET_CMD(self.config.mls_applet_instance_aid)
        set_info_to_ese_cmd0 = SET_INFO_TO_ESE_CMD(MLS_APPLET_AUTH_DATA(self.config.mls_applet_verify_key))
        set_info_to_ese_cmd1 = SET_INFO_TO_ESE_CMD(GET_INFO_FROM_ESE_RSP(0))
        set_auth_to_ese_cmd = SET_AUTH_TO_ESE_CMD(GET_AUTH_FROM_ESE_RSP(encrypted.ivr, encrypted.ct0, encrypted.signature))
        set_cipher_to_ese_cmd = list(map(lambda c: SET_CIPHER_TO_ESE_CMD(GET_CIPHER_FROM_ESE_RSP(c.encrypted, 1), 1), encrypted.commands))
        last: SET_CIPHER_TO_ESE_CMD = set_cipher_to_ese_cmd[-1]
        last.data.pbf = 0
        last.pbf = 0
        last.mls_flash_version = self.config.mls_flash_version
        to_crc: List[Union[SET_INFO_TO_ESE_CMD, SET_AUTH_TO_ESE_CMD, SET_CIPHER_TO_ESE_CMD]] = [set_info_to_ese_cmd1, set_auth_to_ese_cmd, *set_cipher_to_ese_cmd]
        stream = BytesIO()
        for cmd in to_crc:
            cmd.data.serialize(stream)
        if stream.tell() % 4 != 0:
            last.data_padding = bytes(4 - stream.tell() % 4)
        stream.write(last.data_padding)
        stream.write_int(self.config.mls_flash_version, 4, 'big')
        buf = stream.getvalue()
        reversed_buf = bytearray()
        for i in range(0, len(buf), 4):
            reversed_buf.extend(reversed(buf[i:i + 4]))
        crc = CRC(32, 79764919, 0, False, False, 0)
        last.flash_crc = crc.calc(reversed_buf)
        stream.write_int(last.flash_crc, 4, 'big')
        set_info_to_ese_cmd0.data.data = stream.getvalue()
        mls_rom_version = self.config.mls_rom_version if alter_mls_rom_version == None else alter_mls_rom_version
        mls_boot_patch_version = self.config.mls_boot_patch_version if alter_mls_boot_patch_version == None else alter_mls_boot_patch_version
        mls_cos_patch_version = self.config.mls_cos_patch_version if alter_mls_cos_patch_version == None else alter_mls_cos_patch_version
        patch_target_interface = PatchTargetInterface(chip_type=PatchTargetChipType.GSN, script_commands=[select_mls_applet_cmd, set_info_to_ese_cmd0, set_info_to_ese_cmd1, set_auth_to_ese_cmd, *set_cipher_to_ese_cmd])
        patch_target = PatchTarget(PatchTargetType.NFCC_PATCH, self.config.lifecycle, mls_rom_version, mls_boot_patch_version, mls_cos_patch_version, PatchTargetChipType.GSN, patch_target_interface)
        patch_file = PatchScriptFile(patch_target)
        return patch_file
__all__ = [NFCCPatchConfiguration.__name__, NFCCPatch.__name__]

def test():
    SecurityPatchCommands.init_aes_key = bytes.fromhex('fc0fa4dd7c657a442ac82786010144e1')
    SecurityPatchCommands.init_aes_ivr = bytes.fromhex('49e66df89ecf53b309e9e419ffffffff')
    MLS_APPLET_AUTH_DATA.factor = bytes.fromhex('7479cb20d6376234aaf3207fde36b26c')
    patch = NFCCPatch('E:\\Liugang\\Desktop\\DSP3650+MLS10153\\新建文件夹\\patch_scripts\\patch_builder_cfg.json')
    patch.to_patch_script_gsc().save('E:\\LiuGang\\Desktop\\DSP3650+MLS10153\\新建文件夹\\patch_scripts\\nfcc_cos_patch_table_code_script\\gsc10_mls_patch_06_41_0016_new.script')
    patch.to_patch_script_gsn().save('E:\\LiuGang\\Desktop\\DSP3650+MLS10153\\新建文件夹\\patch_scripts\\nfcc_cos_patch_table_code_script\\gsn11_mls_patch_06_41_0016_new.script')