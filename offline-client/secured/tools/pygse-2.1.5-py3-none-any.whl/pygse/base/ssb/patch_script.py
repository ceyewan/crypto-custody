import os
import io
from abc import abstractmethod
from enum import IntEnum
from typing import Dict, List, Literal, TextIO, Tuple, Type, Union, overload
from ..common import BytesIO, crc32_mpeg2

class PatchTargetTag(IntEnum):
    NFCC = 1
    SE = 2

class PatchCommandTag(IntEnum):
    POST_COMMAND = 513
    SEND_COMMAND = 514
    CMPE = 515
    CMPNE = 516
    CMPL = 517
    CMPLE = 518
    GOTO = 519
    NOP = 520
    FINAL = 521
    PROTOCOL_INIT = 522
    SEND_BPF_COMMAND = 523
    DELAY = 525

    @classmethod
    def from_stream(cls, stream: BytesIO, peek: bool=False):
        value = stream.peek_int(2, 'big') if peek else stream.read_int(2, 'big')
        return cls(value)

class PatchCommand:
    raw: bytes = None
    tag: PatchCommandTag
    length: int
    value: bytes = None

    def __init__(self, tag: PatchCommandTag) -> None:
        self.tag = tag

    def serialize(self, stream: BytesIO) -> BytesIO:
        pos_start = stream.tell()
        stream.write_int(int(self.tag), 2, 'big')
        if self.tag in (PatchCommandTag.NOP, PatchCommandTag.PROTOCOL_INIT):
            stream.write_byte(0)
            return
        elif self.tag in (PatchCommandTag.DELAY,):
            stream.write_int(0, 2)
            return
        pos_length = stream.tell()
        stream.write_int(0, 2, 'big')
        self.serialize_payload(stream)
        pos_end = stream.tell()
        length = pos_end - pos_length - 2
        stream.seek(pos_length, 0)
        stream.write_int(length, 2, 'big')
        if length:
            self.value = stream.read(length)
        stream.seek(pos_start, 0)
        self.raw = stream.read(pos_end - pos_start)
        return stream

    def deserialize(self, stream: BytesIO):
        pos_start = stream.tell()
        self.tag = PatchCommandTag(stream.read_int(2, 'big'))
        if self.tag in (PatchCommandTag.NOP, PatchCommandTag.PROTOCOL_INIT):
            self.length = 1
        elif self.tag in (PatchCommandTag.DELAY,):
            self.length = 2
        else:
            self.length = stream.read_int(2, 'big')
        pos_payload = stream.tell()
        if self.length:
            self.value = stream.read(self.length)
        pos_end = stream.tell()
        stream.seek(pos_start, 0)
        self.raw = stream.read(pos_end - pos_start)
        stream.seek(pos_payload, 0)
        self.deserialize_payload(stream)
        stream.seek(pos_end, 0)
        return self

    @abstractmethod
    def serialize_payload(self, stream: BytesIO):
        pass

    @abstractmethod
    def deserialize_payload(self, stream: BytesIO):
        pass

    def to_bytes(self) -> bytes:
        stream = BytesIO()
        self.serialize(stream)
        return stream.getvalue()

    @staticmethod
    def from_stream(stream: BytesIO) -> 'PatchCommand':
        pos = stream.tell()
        tag = PatchCommandTag.from_stream(stream, True)
        stream.seek(pos, 0)
        cls = PatchCommand.__packet_factory.get(tag, lambda : PatchCommand(tag))
        return cls().deserialize(stream)

    @staticmethod
    def from_bytes(packet: Union[str, bytes]) -> 'PatchCommand':
        if isinstance(packet, str):
            packet = bytes.fromhex(packet)
        stream = BytesIO(packet)
        return PatchCommand.from_stream(stream)

    @staticmethod
    def try_from_bytes(packet: Union[str, bytes]) -> 'PatchCommand':
        try:
            return PatchCommand.from_bytes(packet)
        except:
            pass
        return None
    __packet_factory: Dict[PatchCommandTag, Type['PatchCommand']] = {}

    @staticmethod
    def register(t: PatchCommandTag):

        def inner(cls):
            PatchCommand.__packet_factory[t] = cls
            PatchCommand.__packet_factory[t.value] = cls
            return cls
        return inner

    def __str__(self) -> str:
        return f'{self.tag.name} {hex(self.value)}'

@PatchCommand.register(PatchCommandTag.POST_COMMAND)
class POST_COMMAND(PatchCommand):
    cmd: bytes = None

    def __init__(self, cmd: bytes=None) -> None:
        super().__init__(PatchCommandTag.POST_COMMAND)
        self.cmd = cmd

    def serialize_payload(self, stream: BytesIO):
        if self.cmd:
            stream.write(self.cmd)

    def deserialize_payload(self, stream: BytesIO):
        self.cmd = stream.read(self.length)

    def __str__(self) -> str:
        return f'{self.tag.name} {hex(self.cmd)}'

@PatchCommand.register(PatchCommandTag.SEND_COMMAND)
class SEND_COMMAND(PatchCommand):
    cmd: bytes = None

    def __init__(self, cmd: bytes=None) -> None:
        super().__init__(PatchCommandTag.SEND_COMMAND)
        self.cmd = cmd

    def serialize_payload(self, stream: BytesIO):
        if self.cmd:
            stream.write(self.cmd)

    def deserialize_payload(self, stream: BytesIO):
        self.cmd = stream.read(self.length)

    def __str__(self) -> str:
        return f'{self.tag.name} {hex(self.cmd)}'

class CMP_CMD(PatchCommand):
    size: int = 0
    offset: int = 0
    data: bytes = None
    jump: int = 0

    def __init__(self, tag: Literal[PatchCommandTag.CMPE, PatchCommandTag.CMPNE, PatchCommandTag.CMPL, PatchCommandTag.CMPLE], jump: int=0, data: bytes=None, offset: int=0) -> None:
        super().__init__(tag)
        self.offset = offset
        self.jump = jump
        self.data = data or bytes()
        self.size = len(self.data)

    def serialize_payload(self, stream: BytesIO):
        if not self.data:
            raise Exception('data parameter is required!')
        if len(self.data) > 255:
            raise Exception('data parameter must be less than 256!')
        self.size = len(self.data) if self.data else 0
        stream.write_byte(self.size)
        stream.write_byte(self.offset, True)
        if self.size:
            stream.write(self.data)
        stream.write_int(self.jump, 2, 'big')

    def deserialize_payload(self, stream: BytesIO):
        self.size = stream.read_byte()
        self.offset = stream.read_byte(True)
        self.data = stream.read(self.size) or bytes()
        self.jump = stream.read_int(2, 'big')

    def compare(self, input: bytes) -> bool:
        input_value = int.from_bytes(input[self.offset:self.offset + self.size or None], 'big') if input else None
        expect_value = int.from_bytes(self.data, 'big') if self.data else None
        if self.tag == PatchCommandTag.CMPE:
            return input_value == expect_value
        if self.tag == PatchCommandTag.CMPNE:
            return input_value != expect_value
        if self.tag == PatchCommandTag.CMPL:
            return input_value < expect_value
        if self.tag == PatchCommandTag.CMPLE:
            return input_value <= expect_value
        raise Exception(f'Bad COMPARE COMMAND {hex(self.tag)}')

    def repr(self, input: bytes) -> str:
        return f'{self.__str__()}, input={hex(input[self.offset:self.offset + self.size or None])}'

    def __str__(self) -> str:
        return f"{self.tag.name} {hex(self.data)} with rsp[{self.offset}:{self.offset + self.size or ''}], jump={self.jump}"

@PatchCommand.register(PatchCommandTag.CMPE)
class CMPE(CMP_CMD):

    def __init__(self, jump: int=0, data: bytes=None, offset: int=0) -> None:
        super().__init__(PatchCommandTag.CMPE, jump, data, offset)

@PatchCommand.register(PatchCommandTag.CMPNE)
class CMPNE(CMP_CMD):

    def __init__(self, jump: int=0, data: bytes=None, offset: int=0) -> None:
        super().__init__(PatchCommandTag.CMPNE, jump, data, offset)

@PatchCommand.register(PatchCommandTag.CMPL)
class CMPL(CMP_CMD):

    def __init__(self, jump: int=0, data: bytes=None, offset: int=0) -> None:
        super().__init__(PatchCommandTag.CMPL, jump, data, offset)

@PatchCommand.register(PatchCommandTag.CMPLE)
class CMPLE(CMP_CMD):

    def __init__(self, jump: int=0, data: bytes=None, offset: int=0) -> None:
        super().__init__(PatchCommandTag.CMPLE, jump, data, offset)

@PatchCommand.register(PatchCommandTag.GOTO)
class GOTO(PatchCommand):
    offset: Union[int, None] = 0

    def __init__(self) -> None:
        super().__init__(PatchCommandTag.NOP)

    def serialize_payload(self, stream: BytesIO):
        stream.write_int(self.offset, 2, 'big')

    def deserialize_payload(self, stream: BytesIO):
        self.offset = stream.read_int(2, 'big')

    def __str__(self) -> str:
        return f'{self.tag.name} {self.offset}'

@PatchCommand.register(PatchCommandTag.NOP)
class NOP(PatchCommand):
    reserved: int = 0

    def __init__(self) -> None:
        super().__init__(PatchCommandTag.NOP)

    def serialize_payload(self, stream: BytesIO):
        stream.write(self.reserved)

    def deserialize_payload(self, stream: BytesIO):
        self.reserved = stream.read_byte()

    def __str__(self) -> str:
        return f'{self.tag.name} {self.reserved}'

@PatchCommand.register(PatchCommandTag.FINAL)
class FINAL(PatchCommand):
    size: int = 2
    offset: int = 0
    data: bytes = 0

    def __init__(self) -> None:
        super().__init__(PatchCommandTag.FINAL)

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.size)
        stream.write_byte(self.offset)
        stream.write(self.data)

    def deserialize_payload(self, stream: BytesIO):
        self.size = stream.read_byte()
        self.offset = stream.read_byte()
        self.data = stream.read(self.size)

    def compare(self, input: bytes) -> bool:
        if not input and (not self.data):
            return True
        if input and input.index(self.data, self.offset) == self.offset:
            return True
        return False

    def repr(self, input: bytes) -> str:
        return f"{self.tag.name} {self.data or ''} with rsp[{self.offset}:{self.offset + self.size or ''}]({(input[self.offset:self.offset + self.size or None] if input else '')})"

    def __str__(self) -> str:
        return f"{self.tag.name} {self.data or ''} with rsp[{self.offset}:{self.offset + self.size or ''}]"

@PatchCommand.register(PatchCommandTag.PROTOCOL_INIT)
class PROTOCOL_INIT(PatchCommand):

    def __init__(self) -> None:
        super().__init__(PatchCommandTag.PROTOCOL_INIT)

    def serialize_payload(self, stream: BytesIO):
        pass

    def deserialize_payload(self, stream: BytesIO):
        pass

    def __str__(self) -> str:
        return f'{self.tag.name}'

@PatchCommand.register(PatchCommandTag.SEND_BPF_COMMAND)
class SEND_BPF_COMMAND(PatchCommand):
    cmd: bytes = None

    def __init__(self, cmd: bytes=None) -> None:
        super().__init__(PatchCommandTag.SEND_BPF_COMMAND)
        self.cmd = cmd

    def serialize_payload(self, stream: BytesIO):
        if self.cmd:
            stream.write(self.cmd)

    def deserialize_payload(self, stream: BytesIO):
        self.cmd = stream.read(self.length)

    def __str__(self) -> str:
        return f'{self.tag.name} {hex(self.cmd)}'

@PatchCommand.register(PatchCommandTag.DELAY)
class DELAY_CMD(PatchCommand):
    delay: int = 0

    def __init__(self) -> None:
        super().__init__(PatchCommandTag.DELAY)

    def serialize_payload(self, stream: BytesIO):
        stream.write_int(self.reserved, 2, 'big')

    def deserialize_payload(self, stream: BytesIO):
        self.reserved = stream.read_int(2, 'big')

    def __str__(self) -> str:
        return f'{self.tag.name} {self.delay}ms'

class PatchInformationTag(IntEnum):
    COS_UPGRADE = 3
    USER_PREINSTALLED = 16
    GOODIX_PREINSTALLED = 32
    PREINSTALLED_UPGRADE_PACKAGES = 48

class PatchTargetChipType(IntEnum):
    GSN = 1
    GSC = 2

class PatchModule(IntEnum):
    LJS_COS = 0
    LJS_PATCH = 1
    ROOT2_PATCH = 3

class PatchInformationForGen1Cos:
    tag: PatchInformationTag
    patch_module: PatchModule
    ic_fw_version: int
    cos_rom_major_version: int
    cos_rom_minor_version: int
    patch_major_version: int
    patch_minor_version: int
    root2_version: int
    root2_crc: int
    key_version: int
    cid: int

    def __init__(self, patch_module: PatchModule=PatchModule.LJS_COS, ic_fw_version: int=0, cos_major_version: int=0, cos_minor_version: int=0, patch_major_version: int=0, patch_minor_version: int=0, root2_version: int=0, root2_crc: int=0, key_version: int=0, cid: int=0) -> None:
        self.patch_module = patch_module
        self.ic_fw_version = ic_fw_version
        self.cos_rom_major_version = cos_major_version
        self.cos_rom_minor_version = cos_minor_version
        self.patch_major_version = patch_major_version
        self.patch_minor_version = patch_minor_version
        self.root2_version = root2_version
        self.root2_crc = root2_crc
        self.key_version = key_version
        self.cid = cid

    @property
    def versions(self):
        return (self.ic_fw_version, self.cos_rom_major_version, self.cos_rom_minor_version, self.patch_major_version, self.patch_minor_version)

    @property
    def versions_str(self):
        return f'FW: {self.ic_fw_version:04X}, COS={self.cos_rom_major_version:02X}.{self.cos_rom_minor_version:02X}.{self.patch_major_version:02X}.{self.patch_minor_version:02X}, MODULE={self.patch_module.name}, CID=0x{self.cid:02X}, KV=0x{self.key_version:02X}'

    def deserialize(self, stream: BytesIO):
        self.tag = PatchInformationTag(stream.read_byte())
        self.length = stream.read_byte()
        self.patch_module = PatchModule(stream.read_byte())
        self.ic_fw_version = stream.read_int(2, 'big')
        self.cos_rom_major_version = stream.read_byte()
        self.cos_rom_minor_version = stream.read_byte()
        self.patch_major_version = stream.read_byte()
        self.patch_minor_version = stream.read_byte()
        self.root2_version = stream.read_int(2, 'big')
        self.root2_crc = stream.read_int(4, 'big')
        self.key_version = stream.read_byte()
        self.cid = stream.read_byte()
        return self

    def serialize(self, stream: BytesIO):
        stream.write_byte(self.tag)
        length_pos = stream.tell()
        stream.write_byte(0)
        stream.write_byte(int(self.patch_module))
        stream.write_int(self.ic_fw_version, 2, 'big')
        stream.write_byte(self.cos_rom_major_version)
        stream.write_byte(self.cos_rom_minor_version)
        stream.write_byte(self.patch_major_version)
        stream.write_byte(self.patch_minor_version)
        stream.write_int(self.root2_version, 2, 'big')
        stream.write_byte(self.root2_crc, 4, 'big')
        stream.write_byte(self.key_version)
        stream.write_byte(self.cid)
        stream.adjust_wrote_length(length_pos)

class PatchInformationForGen2Cos:
    tag: PatchInformationTag
    patch_module: PatchModule
    ic_fw_version: int
    cos_rom_version: int
    patch_major_version: int
    patch_minor_version: int
    config2_id: int
    cid: int
    reserved: int = 0
    sign: bytes = None

    def __init__(self, patch_module: PatchModule=PatchModule.LJS_COS, ic_fw_version: int=0, cos_rom_version: int=0, patch_major_version: int=0, patch_minor_version: int=0, config2_id: int=0, cid: int=0) -> None:
        self.patch_module = patch_module
        self.ic_fw_version = ic_fw_version
        self.cos_rom_version = cos_rom_version
        self.patch_major_version = patch_major_version
        self.patch_minor_version = patch_minor_version
        self.config2_id = config2_id
        self.cid = cid

    @property
    def versions(self):
        return (self.ic_fw_version, self.cos_rom_version, self.patch_major_version, self.patch_minor_version)

    @property
    def versions_str(self):
        return f'FW: {self.ic_fw_version:04X}, COS={self.cos_rom_version:02X}.{self.patch_major_version:02X}.{self.patch_minor_version:04X}, MODULE={self.patch_module.name}, CID=0x{self.cid:02X}, CFG2=0x{self.config2_id:02X}'

    def deserialize(self, stream: BytesIO):
        self.tag = PatchInformationTag(stream.read_byte())
        length = stream.read_byte()
        self.patch_module = PatchModule(stream.read_byte())
        self.ic_fw_version = stream.read_int(2, 'big')
        self.cos_rom_version = stream.read_byte()
        self.patch_major_version = stream.read_byte()
        self.patch_minor_version = stream.read_int(2, 'big')
        self.config2_id = stream.read_byte()
        self.cid = stream.read_byte()
        self.reserved = stream.read_byte()
        if length > 10:
            self.sign = stream.read(length - 10)
        return self

    def serialize(self, stream: BytesIO):
        stream.write_byte(self.tag)
        length_pos = stream.tell()
        stream.write_byte(0)
        stream.write_byte(int(self.patch_module))
        stream.write_int(self.ic_fw_version, 2, 'big')
        stream.write_byte(self.cos_rom_version)
        stream.write_byte(self.patch_major_version)
        stream.write_int(self.patch_minor_version, 2, 'big')
        stream.write_byte(self.config2_id)
        stream.write_byte(self.cid)
        stream.write_byte(self.reserved)
        stream.adjust_wrote_length(length_pos)

class PatchInformationForGoodixPreinstalledGen1:
    tag: PatchInformationTag
    applet_type: int
    applet_version: int
    applet_aid: bytes
    recovery_applet_version: int
    require_minimum_applet_version: int
    require_minimum_cos_rom_major_version: int
    require_minimum_cos_rom_minor_version: int

    def __init__(self, applet_type: int=0, applet_version: int=0, applet_aid: bytes=0, recovery_applet_version: int=0, require_minimum_applet_version: int=0, require_minimum_cos_rom_major_version: int=0, require_minimum_cos_rom_minor_version: int=0) -> None:
        self.applet_type = applet_type
        self.applet_version = applet_version
        self.applet_aid = applet_aid
        self.recovery_applet_version = recovery_applet_version
        self.require_minimum_applet_version = require_minimum_applet_version
        self.require_minimum_cos_rom_major_version = require_minimum_cos_rom_major_version
        self.require_minimum_cos_rom_minor_version = require_minimum_cos_rom_minor_version

    @property
    def require_cos_versions(self):
        return (self.require_minimum_cos_rom_major_version, self.require_minimum_cos_rom_minor_version)

    def deserialize(self, stream: BytesIO):
        self.tag = PatchInformationTag(stream.read_byte())
        self.length = stream.read_byte()
        data_start = stream.tell()
        self.applet_type = stream.read_int(2, 'big')
        self.applet_version = stream.read_int(2, 'big')
        applet_aid_len = stream.read_byte()
        self.applet_aid = stream.read(16).ljust(applet_aid_len, b'\x00')
        self.recovery_applet_version = stream.read_int(2, 'big')
        self.require_minimum_applet_version = stream.read_int(2, 'big')
        self.require_minimum_cos_rom_major_version = stream.read_byte()
        self.require_minimum_cos_rom_minor_version = stream.read_byte()
        data_read = stream.tell() - data_start
        if data_read < self.length:
            stream.seek(self.length - data_read, 1)
        return self

    def serialize(self, stream: BytesIO):
        stream.write_byte(self.tag)
        pos_length = stream.tell()
        stream.write_byte(0)
        stream.write_int(self.applet_type, 2, 'big')
        stream.write_int(self.applet_version, 2, 'big')
        stream.write_byte(len(self.applet_aid))
        stream.write(self.applet_aid.ljust(16, b'\x00'))
        stream.write_int(self.recovery_applet_version, 2, 'big')
        stream.write_int(self.require_minimum_applet_version, 2, 'big')
        stream.write_byte(self.require_minimum_cos_rom_major_version)
        stream.write_byte(self.require_minimum_cos_rom_minor_version)
        stream.adjust_wrote_length(pos_length)

    @property
    def versions_str(self):
        return f'AppType={self.applet_type:04X}, AppVersion={self.applet_version:04X}, AID={hex(self.applet_aid)}, RequireAppVersion={self.require_minimum_applet_version:04X}, RequireCosVersion={self.require_minimum_cos_rom_major_version:02X}.{self.require_minimum_cos_rom_minor_version:02X}'

class PatchInformationForGoodixPreinstalledGen2:
    tag: PatchInformationTag
    applet_type: int
    applet_version: int
    applet_aid: bytes
    recovery_applet_version: int
    require_minimum_applet_version: int
    require_minimum_cos_rom_version: int
    require_minimum_patch_major_version: int
    require_minimum_patch_minor_version: int

    def __init__(self, applet_type: int=0, applet_version: int=0, applet_aid: bytes=0, recovery_applet_version: int=0, require_minimum_applet_version: int=0, require_minimum_cos_rom_version: int=0, require_minimum_patch_major_version: int=0, require_minimum_patch_minor_version: int=0) -> None:
        self.applet_type = applet_type
        self.applet_version = applet_version
        self.applet_aid = applet_aid
        self.recovery_applet_version = recovery_applet_version
        self.require_minimum_applet_version = require_minimum_applet_version
        self.require_minimum_cos_rom_version = require_minimum_cos_rom_version
        self.require_minimum_patch_major_version = require_minimum_patch_major_version
        self.require_minimum_patch_minor_version = require_minimum_patch_minor_version

    @property
    def versions_str(self):
        return f'AppType={self.applet_type:04X}, AppVersion={self.applet_version:04X}, AID={hex(self.applet_aid)}, RequireAppVersion={self.require_minimum_applet_version:04X}, RequireCosVersion={self.require_minimum_cos_rom_version:02X}.{self.require_minimum_patch_major_version:02X}.{self.require_minimum_patch_minor_version:04X}'

    @property
    def require_cos_versions(self):
        return (self.require_minimum_cos_rom_version, self.require_minimum_patch_major_version, self.require_minimum_patch_minor_version)

    def deserialize(self, stream: BytesIO):
        self.tag = PatchInformationTag(stream.read_byte())
        self.length = stream.read_byte()
        data_start = stream.tell()
        self.applet_type = stream.read_int(2, 'big')
        self.applet_version = stream.read_int(2, 'big')
        applet_aid_len = stream.read_byte()
        self.applet_aid = stream.read(16).ljust(applet_aid_len, b'\x00')
        self.recovery_applet_version = stream.read_int(2, 'big')
        self.require_minimum_applet_version = stream.read_int(2, 'big')
        self.require_minimum_cos_rom_version = stream.read_byte()
        self.require_minimum_patch_major_version = stream.read_byte()
        self.require_minimum_patch_minor_version = stream.read_int(2, 'big')
        data_read = stream.tell() - data_start
        if data_read < self.length:
            stream.seek(self.length - data_read, 1)
        return self

    def serialize(self, stream: BytesIO):
        stream.write_byte(self.tag)
        pos_length = stream.tell()
        stream.write_byte(0)
        stream.write_int(self.applet_type, 2, 'big')
        stream.write_int(self.applet_version, 2, 'big')
        stream.write_byte(len(self.applet_aid))
        stream.write(self.applet_aid.ljust(16, b'\x00'))
        stream.write_int(self.recovery_applet_version, 2, 'big')
        stream.write_int(self.require_minimum_applet_version, 2, 'big')
        stream.write_byte(self.require_minimum_cos_rom_version)
        stream.write_byte(self.require_minimum_patch_major_version)
        stream.write_int(self.require_minimum_patch_minor_version, 2, 'big')
        stream.adjust_wrote_length(pos_length)

class PatchInformationForUserPreinstalled:
    tag: PatchInformationTag
    script_version: int

    def __init__(self, script_version: int=0) -> None:
        self.script_version = script_version

    @property
    def versions_str(self):
        return f'ScriptVersion={self.script_version:08X}'

    def deserialize(self, stream: BytesIO):
        self.tag = PatchInformationTag(stream.read_byte())
        self.length = stream.read_byte()
        self.script_version = stream.read_int(4, 'big')
        return self

    def serialize(self, stream: BytesIO):
        stream.write_byte(self.tag)
        pos_length = stream.tell()
        stream.write_byte(0)
        stream.write_int(self.script_version, 4, 'big')
        stream.adjust_wrote_length(pos_length)

class PatchInformation:

    @staticmethod
    def deserialize(stream: BytesIO) -> Union[PatchInformationForGen1Cos, PatchInformationForGen2Cos, PatchInformationForGoodixPreinstalledGen1, PatchInformationForGoodixPreinstalledGen2, PatchInformationForUserPreinstalled]:
        buf = stream.peek(7)
        tag = buf[0]
        length = buf[1]
        if tag == PatchInformationTag.COS_UPGRADE:
            if length != 10 and length != 74:
                raise Exception('Bad patch information length for COS_UPGRADE')
            if buf[-2] == 3 and buf[-1] >= 0:
                return PatchInformationForGen2Cos().deserialize(stream)
            else:
                return PatchInformationForGen1Cos().deserialize(stream)
        elif tag == PatchInformationTag.GOODIX_PREINSTALLED or tag == PatchInformationTag.PREINSTALLED_UPGRADE_PACKAGES:
            if length == 27 or length == 91:
                return PatchInformationForGoodixPreinstalledGen1().deserialize(stream)
            elif length == 29 or length == 93:
                return PatchInformationForGoodixPreinstalledGen2().deserialize(stream)
            else:
                raise Exception(f'Bad Information length=0x{length:02X}({length}) for GOODIX_PREINSTALLED, The bytes length requires 0x1B(27)/0x5B(91) for GEN1 and 0x1D(29)/0x5D(93) for GEN2.')
        elif tag == PatchInformationTag.USER_PREINSTALLED:
            return PatchInformationForUserPreinstalled().deserialize(stream)
        else:
            raise Exception(f'Bad Information tag=0x{tag:02X}')

class PatchInterfaceTag(IntEnum):
    I2C = 257
    SPI = 258
    ISO_7816 = 260

class PatchTargetInterface:
    tag: PatchInterfaceTag = PatchInterfaceTag.SPI
    length: int = 0
    commands: List[PatchCommand]

    def __init__(self, tag: PatchInterfaceTag=PatchInterfaceTag.I2C, script_commands: List[PatchCommand]=None) -> None:
        self.tag = tag
        self.commands = []
        if script_commands:
            self.set_script_commands(script_commands)

    def deserialize(self, stream: BytesIO) -> 'PatchTargetInterface':
        self.tag = PatchInterfaceTag(stream.read_int(2, 'big'))
        self.length = stream.read_int(4, 'big')
        end = stream.tell() + self.length
        self.commands.clear()
        while stream.tell() < end:
            b = stream.peek_int(2, 'big')
            if b == None:
                break
            if b in PatchCommandTag._value2member_map_:
                self.commands.append(PatchCommand.from_stream(stream))
            else:
                break
        return self

    def serialize(self, stream: BytesIO):
        stream.write_int(self.tag, 2, 'big')
        pos_length = stream.tell()
        stream.write_int(self.length, 4, 'big')
        for cmd in self.commands:
            cmd.serialize(stream)
        self.length = stream.adjust_wrote_length(pos_length, stream.tell(), 4, 'big')

class PatchTarget:
    tag: PatchTargetTag
    length: int
    info: Union[PatchInformationForGen1Cos, PatchInformationForGen2Cos, PatchInformationForGoodixPreinstalledGen1, PatchInformationForGoodixPreinstalledGen2, PatchInformationForUserPreinstalled]
    interface: PatchTargetInterface

    def __init__(self, tag: PatchTargetTag=None, info: Union[PatchInformationForGen1Cos, PatchInformationForGen2Cos, PatchInformationForGoodixPreinstalledGen1, PatchInformationForGoodixPreinstalledGen2, PatchInformationForUserPreinstalled]=None, interface: PatchTargetInterface=None) -> None:
        self.tag = tag
        self.info = info
        self.interface = interface

    def deserialize(self, stream: BytesIO) -> 'PatchTarget':
        self.tag = PatchTargetTag(stream.read_int(2, 'big'))
        self.length = stream.read_int(4, 'big')
        self.info = PatchInformation.deserialize(stream)
        self.interface = PatchTargetInterface().deserialize(stream)
        return self

    def serialize(self, stream: BytesIO):
        stream.write_int(self.tag, 2, 'big')
        pos_length = stream.tell()
        stream.write_int(0, 4)
        self.info.serialize(stream)
        self.interface.serialize(stream)
        self.length = stream.adjust_wrote_length(pos_length, stream.tell(), 4, 'big')

class PatchScriptFile:
    file: str = None
    head: bytes = bytes.fromhex('474F4F4449585F50415443485F534352495054')
    target: PatchTarget

    @overload
    def __init__(self, target: PatchTarget=None) -> None:
        pass

    @overload
    def __init__(self, targets: List[PatchTarget]=None) -> None:
        pass

    @overload
    def __init__(self, file: str=None) -> None:
        pass

    def __init__(self, init: Union[List[PatchTarget], str]=None) -> None:
        self.targets = []
        if isinstance(init, PatchTarget):
            self.targets = [init]
        elif isinstance(init, list):
            self.targets = init
        elif isinstance(init, str) and init and os.path.isfile(init):
            self.load(init)

    def load(self, file: str) -> 'PatchScriptFile':
        with open(file, 'r', encoding='utf8') as f:
            data = bytes.fromhex(f.read())
            if not data.startswith(self.head):
                raise Exception(f'Bad file format!')
            if int.from_bytes(data[-4:], 'big') != crc32_mpeg2(data[:-4]):
                raise Exception(f'CRC Check Error!')
            stream = BytesIO(data[:-4])
            try:
                self.deserialize(stream)
            except Exception as ex:
                ex.args = (', '.join([*ex.args, f'at position {stream.tell()}']),)
                raise ex
            self.file = file
        return self

    def deserialize(self, stream: BytesIO):
        if stream.read(len(self.head)) != self.head:
            raise Exception('Bad file head')
        b = stream.peek_int(2, 'big')
        if b in PatchTargetTag._value2member_map_:
            self.target = PatchTarget().deserialize(stream)
        else:
            raise Exception(f'Bad PatchTarget={b}, at {stream.tell()}')
        return self

    def serialize(self, stream: BytesIO):
        stream.write(self.head)
        self.target.serialize(stream)
        stream.write_padding(4)
        crc = crc32_mpeg2(stream.getvalue())
        stream.write_int(crc, 4, 'big')

    def to_bytes(self) -> bytes:
        stream = BytesIO()
        self.serialize(stream)
        return stream.getvalue()

    def save(self, file: Union[str, TextIO]):
        if isinstance(file, str):
            os.makedirs(os.path.dirname(os.path.realpath(file)), exist_ok=True)
            with open(file, 'w', encoding='utf8') as f:
                f.write(self.to_bytes().hex())
        else:
            file.write(self.to_bytes().hex())

def test():
    from ..common import read_json
    obj_cancel = read_json('..\\.debug\\V03.00.0003.4067_20240105-150112\\09-密文版本下载\\UpdateOS_LJS2_patch\\AutoTest\\TestScripts\\json\\common_json\\1117_092954_SVN6666_00_50F5A6EE_0300_1111\\goproof_json\\1117_092954_SVN6666_00_50F5A6EE_A4_CANCEL_0300_1111.json')
    obj_load = read_json('..\\.debug\\V03.00.0003.4067_20240105-150112\\09-密文版本下载\\UpdateOS_LJS2_patch\\AutoTest\\TestScripts\\json\\common_json\\1117_092954_SVN6666_00_50F5A6EE_0300_1111\\goproof_json\\1117_092954_SVN6666_00_50F5A6EE_A4_LOAD_0300_1111.json')
    ps = PatchScriptFile('../.debug/V03.00.0003.4067_20240105-150112/09-密文版本下载/UpdateOS_LJS2_patch/AutoTest/TestScripts/json/4067_989FECC8_0300_0003_0200_20240105_152209/dh_script/gsn22_ljs_update_dh_4067_989FECC8_0300_0003_0200_A4_NCUD_CANCEL_LOAD_20240105_152209_crc32.script')
    ps.target.info.patch_minor_version = 0
    ps.target.interface.commands[0].cmd = bytes.fromhex(obj_cancel[0][1])
    ps.target.interface.commands[1].cmd = bytes.fromhex(obj_cancel[1][1])
    for i in range(len(obj_load)):
        ps.target.interface.commands[4 + i].cmd = bytes.fromhex(obj_load[i][1])
    ps.target.interface.commands = ps.target.interface.commands[:4 + i + 1]
    ps.save('../doc/update_cos/1117_092954_SVN6666_00_50F5A6EE_A4_CANCEL_LOAD_0300_1111_crc32.script')
    ps1 = PatchScriptFile('../doc/update_cos/1117_092954_SVN6666_00_50F5A6EE_A4_CANCEL_LOAD_0300_1111_crc32.script')
    pass
__all__ = [PatchCommandTag.__name__, PatchCommand.__name__, POST_COMMAND.__name__, SEND_COMMAND.__name__, CMPE.__name__, CMPNE.__name__, CMPL.__name__, CMPLE.__name__, GOTO.__name__, NOP.__name__, PROTOCOL_INIT.__name__, SEND_BPF_COMMAND.__name__, DELAY_CMD.__name__, FINAL.__name__, PatchModule.__name__, PatchInformationTag.__name__, PatchInformationForGen1Cos.__name__, PatchInformationForGen2Cos.__name__, PatchInformationForGoodixPreinstalledGen1.__name__, PatchInformationForGoodixPreinstalledGen2.__name__, PatchInformationForUserPreinstalled.__name__, PatchInterfaceTag.__name__, PatchTargetInterface.__name__, PatchTargetTag.__name__, PatchTarget.__name__, PatchScriptFile.__name__]