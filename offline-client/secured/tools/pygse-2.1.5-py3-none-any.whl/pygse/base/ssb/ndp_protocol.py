import os
from typing import Dict, List, Literal, Tuple, Type, Union
from abc import abstractmethod
from enum import IntEnum
from ..common import BytesIO, crc32_mpeg2, right_padding

class NDPTag(IntEnum):
    GET_INFO_FROM_NFCC_CMD = 17
    GET_INFO_FROM_NFCC_RSP = 145
    SECURE_INITIALIZATION_CMD = 18
    SECURE_INITIALIZATION_RSP = 146
    SECURE_PROTOCOL_CMD = 19
    SECURE_PROTOCOL_RSP = 147
    BOOT_IDLE_EXIT_CMD = 20
    BOOT_IDLE_EXIT_RSP = 148
    SOFTWARE_WRITE_CMD = 21
    SOFTWARE_WRITE_RSP = 149
    SOFTWARE_READ_CMD = 22
    SOFTWARE_READ_RSP = 150
    CRC_CHECK_CMD = 24
    CRC_CHECK_RSP = 152
    PATCH_PREPARE_CMD = 33
    PATCH_PREPARE_RSP = 161
    PATCH_LOAD_CMD = 34
    PATCH_LOAD_RSP = 162
    OTP_WRITE_CMD = 35
    OTP_WRITE_RSP = 163
    OTP_READ_CMD = 36
    OTP_READ_RSP = 164
    ATP_NTF = 241
    NFCC_UPDATE_RESULT_NTF = 242
    HARDWARE_WRITE_CMD = 122
    HARDWARE_READ_CMD = 69
    HARDWARE_READ_RSP = 197
    GET_INFO_FROM_ESE_CMD = 49
    GET_INFO_FROM_ESE_RSP = 177
    GET_AUTH_FROM_ESE_CMD = 50
    GET_AUTH_FROM_ESE_RSP = 178
    GET_CIPHER_FROM_ESE_CMD = 51
    GET_CIPHER_FROM_ESE_RSP = 179
    NDFSE_EXIT_NTF = 244
    SELECT_MLS_APPLET_CMD = 80
    SELECT_MLS_APPLET_RSP = 208
    SET_INFO_TO_ESE_CMD = 81
    SET_INFO_TO_ESE_RSP = 209
    SET_AUTH_TO_ESE_CMD = 82
    SET_AUTH_TO_ESE_RSP = 210
    SET_CIPHER_TO_ESE_CMD = 83
    SET_CIPHER_TO_ESE_RSP = 211
    OTP_CRC_CHECK_CMD = 84
    OTP_CRC_CHECK_RSP = 212
    SET_GW_ENTER_ROOT2_CMD = 85
    SET_GW_ENTER_ROOT2_RSP = 213
    LOAD_LJS_TO_CMD = 86
    LOAD_LJS_TO_RSP = 214
    GET_LJS_VERSION_CMD = 87
    GET_LJS_VERSION_RSP = 215
    CLEAR_LJS_VERSION_CMD = 88
    CLEAR_LJS_VERSION_RSP = 216
    SET_GW_COLD_RESET_CMD = 89
    SET_GW_COLD_RESET_RSP = 217
    LJS_UPDATE_RESULT_NTF = 243

    @classmethod
    def from_stream(cls, stream: BytesIO, peek: bool=False):
        value = stream.peek_int() if peek else stream.read_byte()
        return cls(value)

class PatchType(IntEnum):
    PATCH_TABLE = 1
    M0_COS_PATCH = 2
    DSP_COS_PATCH = 3

class NDPPacket:
    raw: bytes
    tag: NDPTag
    pbf: int = 0
    payload_length: int = 0
    payload: bytes

    def __init__(self, tag: NDPTag) -> None:
        self.tag = tag

    def serialize(self, stream: BytesIO) -> BytesIO:
        pos_start = stream.tell()
        stream.write_byte(self.tag)
        pos_length = stream.tell()
        stream.write_int(0, 2)
        self.serialize_payload(stream)
        pos_end = stream.tell()
        self.length = stream.adjust_wrote_length(pos_length, pos_end, 2, 'big', lambda l: l | 32768 if self.pbf else l)
        stream.seek(pos_start, 0)
        self.raw = stream.read(pos_end - pos_start)
        return stream

    def deserialize(self, stream: BytesIO) -> 'NDPPacket':
        pos_start = stream.tell()
        self.tag = stream.read_byte()
        length = stream.read_int(2, 'big')
        self.pbf = length >> 15
        self.payload_length = length & 32767
        pos_payload = stream.tell()
        self.payload = stream.read(self.payload_length)
        pos_end = stream.tell()
        stream.seek(pos_start, 0)
        self.raw = stream.read(3 + self.payload_length)
        stream.seek(pos_payload, 0)
        self.deserialize_payload(stream)
        stream.seek(pos_end, 0)
        return self

    @abstractmethod
    def serialize_payload(self, stream: BytesIO):
        pass

    @abstractmethod
    def deserialize_payload(self, stream: BytesIO):
        pass

    def to_bytes(self) -> bytes:
        stream = BytesIO()
        self.serialize(stream)
        return stream.getvalue()

    @staticmethod
    def from_bytes(packet: Union[str, bytes]) -> 'NDPPacket':
        if isinstance(packet, str):
            packet = bytes.fromhex(packet)
        stream = BytesIO(packet)
        tag = NDPTag.from_stream(stream, True)
        cls = NDPPacket.__packet_factory.get(tag, lambda : NDPPacket(tag))
        return cls().deserialize(stream)

    @staticmethod
    def try_from_bytes(packet: Union[str, bytes]) -> 'NDPPacket':
        try:
            return NDPPacket.from_bytes(packet)
        except:
            pass
        return None
    __packet_factory: Dict[NDPTag, Type['NDPPacket']] = {}

    @staticmethod
    def register(t: NDPTag):

        def inner(cls):
            NDPPacket.__packet_factory[t] = cls
            NDPPacket.__packet_factory[t.value] = cls
            return cls
        return inner

@NDPPacket.register(NDPTag.SECURE_INITIALIZATION_CMD)
class SECURE_INITIALIZATION_CMD(NDPPacket):
    ivr: bytes
    ct0: bytes
    signature: bytes

    def __init__(self, ivr: bytes=None, ct0: bytes=None, signature: bytes=None) -> None:
        super().__init__(NDPTag.SECURE_INITIALIZATION_CMD)
        self.ivr = ivr
        self.ct0 = ct0
        self.signature = signature

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(0)
        stream.write(self.ivr)
        stream.write(self.ct0)
        stream.write(self.signature)

    def deserialize_payload(self, stream: BytesIO):
        stream.read_byte()
        self.ivr = stream.read(16)
        self.ct0 = stream.read(64)
        self.signature = stream.read(16)

@NDPPacket.register(NDPTag.SECURE_INITIALIZATION_RSP)
class SECURE_INITIALIZATION_RSP(NDPPacket):
    status: int = 0

    def __init__(self) -> None:
        super().__init__(NDPTag.SECURE_INITIALIZATION_RSP)

    def deserialize_payload(self, stream: BytesIO) -> 'NDPPacket':
        self.status = stream.read_byte()
        return self

@NDPPacket.register(NDPTag.SECURE_PROTOCOL_CMD)
class SECURE_PROTOCOL_CMD(NDPPacket):
    cipher_text: bytes

    def __init__(self, cipher_text: bytes=None, pbf: Literal[0, 1]=0) -> None:
        super().__init__(NDPTag.SECURE_PROTOCOL_CMD)
        self.cipher_text = cipher_text
        self.pbf = pbf

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(0)
        stream.write(self.cipher_text)

    def deserialize_payload(self, stream: BytesIO):
        stream.read_byte()
        self.cipher_text = stream.read(self.payload_length - 2)

@NDPPacket.register(NDPTag.SECURE_PROTOCOL_RSP)
class SECURE_PROTOCOL_RSP(NDPPacket):
    status: int = 0

    def __init__(self) -> None:
        super().__init__(NDPTag.SECURE_PROTOCOL_RSP)

    def deserialize_payload(self, stream: BytesIO) -> 'NDPPacket':
        self.status = stream.read_byte()
        return self

@NDPPacket.register(NDPTag.CRC_CHECK_CMD)
class CRC_CHECK_CMD(NDPPacket):
    address: int
    length: int
    crc: int

    def __init__(self, address: int=0, length: int=0, crc: int=None) -> None:
        super().__init__(NDPTag.CRC_CHECK_CMD)
        self.address = address
        self.length = length
        self.crc = crc

    def serialize_payload(self, stream: BytesIO):
        stream.write_int(self.address, 4, 'big')
        stream.write_int(self.length, 4, 'big')

    def deserialize_payload(self, stream: BytesIO):
        self.address = stream.read_int(4, 'big')
        self.length = stream.read_int(4, 'big')

@NDPPacket.register(NDPTag.CRC_CHECK_RSP)
class CRC_CHECK_RSP(NDPPacket):
    status: int = 0
    crc: int

    def __init__(self) -> None:
        super().__init__(NDPTag.CRC_CHECK_RSP)

    def serialize_payload(self, stream: BytesIO):
        stream.write_byte(self.status)
        stream.write_int(self.crc, 4, 'big')

    def deserialize_payload(self, stream: BytesIO) -> 'NDPPacket':
        self.status = stream.read_byte()
        self.crc = stream.read_int(4, 'big')
        return self

@NDPPacket.register(NDPTag.PATCH_PREPARE_CMD)
class PATCH_PREPARE_CMD(NDPPacket):
    patch_type: PatchType = PatchType.M0_COS_PATCH
    mls_rom_version: int
    mls_boot_patch_version: int
    mls_cos_patch_version: int
    patch_size: int
    patch_address: int

    def __init__(self, patch_type: PatchType=PatchType.M0_COS_PATCH, mls_rom_version: int=0, mls_boot_patch_version: int=0, mls_cos_patch_version: int=0, patch_size: int=0, patch_address: int=None) -> None:
        super().__init__(NDPTag.PATCH_PREPARE_CMD)
        self.patch_type = patch_type
        self.mls_rom_version = mls_rom_version
        self.mls_boot_patch_version = mls_boot_patch_version
        self.mls_cos_patch_version = mls_cos_patch_version
        self.patch_size = patch_size
        self.patch_address = patch_address

    def serialize_payload(self, stream: BytesIO) -> BytesIO:
        stream.write_byte(self.patch_type)
        stream.write_byte(self.mls_rom_version)
        stream.write_byte(self.mls_boot_patch_version)
        stream.write_int(self.mls_cos_patch_version, 2, 'big')
        stream.write_int(self.patch_size, 2, 'big')
        if self.patch_address != None:
            stream.write_int(self.patch_address, 4, 'big')

@NDPPacket.register(NDPTag.PATCH_PREPARE_RSP)
class PATCH_PREPARE_RSP(NDPPacket):
    status: int = 0

    def __init__(self) -> None:
        super().__init__(NDPTag.PATCH_PREPARE_RSP)

    def deserialize_payload(self, stream: BytesIO) -> 'NDPPacket':
        self.status = stream.read_byte()
        return self

@NDPPacket.register(NDPTag.PATCH_LOAD_CMD)
class PATCH_LOAD_CMD(NDPPacket):
    patch_data: bytes

    def __init__(self) -> None:
        super().__init__(NDPTag.PATCH_LOAD_CMD)

    def serialize_payload(self, stream: BytesIO) -> BytesIO:
        stream.write(self.patch_data)

    @staticmethod
    def make_cmd_list(patch_type: PatchType, patch_data: bytes, segment_size: int=4000) -> List['PATCH_LOAD_CMD']:
        stream = BytesIO(bytes([patch_type]) + len(patch_data).to_bytes(2, 'big') + patch_data)
        ret: List[PATCH_LOAD_CMD] = []
        while not stream.at_end():
            cmd = PATCH_LOAD_CMD()
            cmd.pbf = 1
            cmd.patch_data = stream.read(segment_size)
            ret.append(cmd)
        ret[-1].pbf = 0
        return ret

@NDPPacket.register(NDPTag.PATCH_LOAD_RSP)
class PATCH_LOAD_RSP(NDPPacket):
    status: int = 0

    def __init__(self) -> None:
        super().__init__(NDPTag.PATCH_LOAD_RSP)

    def deserialize_payload(self, stream: BytesIO) -> 'NDPPacket':
        self.status = stream.read_byte()
        return self

@NDPPacket.register(NDPTag.GET_INFO_FROM_ESE_CMD)
class GET_INFO_FROM_ESE_CMD(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.GET_INFO_FROM_ESE_CMD)

    def serialize_payload(self, stream: BytesIO):
        pass

@NDPPacket.register(NDPTag.GET_INFO_FROM_ESE_RSP)
class GET_INFO_FROM_ESE_RSP(NDPPacket):
    total: int = None
    tlvs: List[bytes] = None

    def __init__(self, total: int=None, tlvs: List[bytes]=None) -> None:
        super().__init__(NDPTag.GET_INFO_FROM_ESE_RSP)
        self.total = total
        self.tlvs = tlvs

    def deserialize_payload(self, stream: BytesIO):
        self.reserved = stream.read_int(2)
        self.package = stream.read(self.payload_length - 2)

    def serialize_payload(self, stream: BytesIO):
        stream.write_int(0, 2, 'big')
        pos_payload_start = stream.tell()
        if self.total != None:
            stream.write_int(self.total, 2, 'big')
        tlvs = self.tlvs or []
        stream.write_int(len(tlvs), 2, 'big')
        for tlv in tlvs:
            stream.write(tlv)
        pos_payload_end = stream.tell()
        stream.seek(pos_payload_start, 0)
        payload = right_padding(stream.read(pos_payload_end - pos_payload_start), 4)
        crc = crc32_mpeg2(payload)
        stream.write_int(crc, 4, 'big')

    @staticmethod
    def from_tlvs(tlvs: List[bytes]=None, num_of_tlv_per_packet: int=35) -> List['GET_INFO_FROM_ESE_CMD']:
        ret: List[GET_INFO_FROM_ESE_CMD] = []
        tlvs = tlvs or []
        for i in range(0, len(tlvs), num_of_tlv_per_packet):
            cmd = GET_INFO_FROM_ESE_CMD()
            cmd.pbf = 1
            cmd.tlvs = tlvs[i:i + num_of_tlv_per_packet]
            ret.append(cmd)
        if not ret:
            cmd = GET_INFO_FROM_ESE_CMD()
            cmd.total = 0
            ret.append(GET_INFO_FROM_ESE_CMD())
        ret[-1].pbf = 0
        return ret

@NDPPacket.register(NDPTag.GET_AUTH_FROM_ESE_CMD)
class GET_AUTH_FROM_ESE_CMD(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.GET_AUTH_FROM_ESE_CMD)

    def serialize_payload(self, stream: BytesIO):
        pass

@NDPPacket.register(NDPTag.GET_AUTH_FROM_ESE_RSP)
class GET_AUTH_FROM_ESE_RSP(NDPPacket):
    ivr: bytes
    ct0: bytes
    signature: bytes

    def __init__(self, ivr: bytes=None, ct0: bytes=None, signature: bytes=None) -> None:
        super().__init__(NDPTag.GET_AUTH_FROM_ESE_RSP)
        self.ivr = ivr
        self.ct0 = ct0
        self.signature = signature

    def serialize_payload(self, stream: BytesIO):
        stream.write_int(0, 2)
        stream.write(self.ivr)
        stream.write(self.ct0)
        stream.write(self.signature)

    def deserialize_payload(self, stream: BytesIO):
        stream.read_int(2)
        self.ivr = stream.read(16)
        self.ct0 = stream.read(64)
        self.signature = stream.read(16)

@NDPPacket.register(NDPTag.GET_CIPHER_FROM_ESE_CMD)
class GET_CIPHER_FROM_ESE_CMD(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.GET_CIPHER_FROM_ESE_CMD)

    def serialize_payload(self, stream: BytesIO):
        pass

@NDPPacket.register(NDPTag.GET_CIPHER_FROM_ESE_RSP)
class GET_CIPHER_FROM_ESE_RSP(NDPPacket):
    cipher_text: bytes

    def __init__(self, cipher_text: bytes=None, pbf: Literal[0, 1]=0) -> None:
        super().__init__(NDPTag.GET_CIPHER_FROM_ESE_RSP)
        self.cipher_text = cipher_text
        self.pbf = pbf

    def serialize_payload(self, stream: BytesIO):
        stream.write_int(0, 2)
        stream.write(self.cipher_text)

    def deserialize_payload(self, stream: BytesIO):
        stream.read_int(2)
        self.cipher_text = stream.read(self.payload_length - 2)

@NDPPacket.register(NDPTag.SELECT_MLS_APPLET_CMD)
class SELECT_MLS_APPLET_CMD(NDPPacket):
    mls_applet_aid: bytes

    def __init__(self, mls_applet_aid: bytes=None) -> None:
        super().__init__(NDPTag.SELECT_MLS_APPLET_CMD)
        self.mls_applet_aid = mls_applet_aid

    def serialize_payload(self, stream: BytesIO):
        stream.write(self.mls_applet_aid)

@NDPPacket.register(NDPTag.SELECT_MLS_APPLET_RSP)
class SELECT_MLS_APPLET_RSP(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.SELECT_MLS_APPLET_RSP)

    def deserialize_payload(self, stream: BytesIO):
        pass

class MLS_APPLET_AUTH_DATA:
    factor: bytes

    def __init__(self, mls_applet_verify_key: bytes=None, factor: bytes=None, data: bytes=None) -> None:
        self.mls_applet_verify_key = mls_applet_verify_key or bytes(16)
        if factor:
            self.factor = factor
        if data:
            self.data = data

    def serialize(self, stream: BytesIO):
        data = self.data or bytes()
        factor = self.factor or os.urandom(16)
        factor_kdf = factor + bytes([1])
        if len(factor) != 16:
            raise Exception('Length of factor must be 16.')
        mac_factor = cmac(factor, self.mls_applet_verify_key)
        key_session = cmac(factor_kdf, self.mls_applet_verify_key)
        remain16 = len(data) % 16
        if remain16 == 0:
            to_mac = data + bytes.fromhex('10101010101010101010101010101010')
        elif remain16 == 4:
            to_mac = data + bytes.fromhex('0C0C0C0C0C0C0C0C0C0C0C0C')
        elif remain16 == 8:
            to_mac = data + bytes.fromhex('0808080808080808')
        elif remain16 == 12:
            to_mac = data + bytes.fromhex('04040404')
        mac_data = cmac(to_mac, key_session)
        self.mac_factor = mac_factor
        self.mac_data = mac_data
        stream.write(factor)
        stream.write(mac_factor)
        stream.write(mac_data)
        return stream

    def deserialize(self, stream: BytesIO):
        self.factor = stream.read(16)
        self.mac_factor = stream.read(16)
        self.mac_data = stream.read(16)
        return self

@NDPPacket.register(NDPTag.SET_INFO_TO_ESE_CMD)
class SET_INFO_TO_ESE_CMD(NDPPacket):
    data: Union[MLS_APPLET_AUTH_DATA, GET_INFO_FROM_ESE_RSP]

    def __init__(self, data: Union[MLS_APPLET_AUTH_DATA, GET_INFO_FROM_ESE_RSP]=None) -> None:
        super().__init__(NDPTag.SET_INFO_TO_ESE_CMD)
        self.data = data

    def serialize_payload(self, stream: BytesIO):
        self.data.serialize(stream)

    def deserialize_payload(self, stream: BytesIO):
        if self.payload_length == 51:
            self.data = MLS_APPLET_AUTH_DATA().deserialize(stream)
        else:
            self.data = GET_INFO_FROM_ESE_RSP().deserialize(stream)

@NDPPacket.register(NDPTag.SET_INFO_TO_ESE_RSP)
class SET_INFO_TO_ESE_RSP(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.SET_INFO_TO_ESE_RSP)

    def deserialize_payload(self, stream: BytesIO):
        pass

@NDPPacket.register(NDPTag.SET_AUTH_TO_ESE_CMD)
class SET_AUTH_TO_ESE_CMD(NDPPacket):
    data: GET_AUTH_FROM_ESE_RSP

    def __init__(self, data: GET_AUTH_FROM_ESE_RSP=None) -> None:
        super().__init__(NDPTag.SET_AUTH_TO_ESE_CMD)
        self.data = data

    def serialize_payload(self, stream: BytesIO):
        self.data.serialize(stream)

@NDPPacket.register(NDPTag.SET_AUTH_TO_ESE_RSP)
class SET_AUTH_TO_ESE_RSP(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.SET_AUTH_TO_ESE_RSP)

    def deserialize_payload(self, stream: BytesIO):
        pass

@NDPPacket.register(NDPTag.SET_CIPHER_TO_ESE_CMD)
class SET_CIPHER_TO_ESE_CMD(NDPPacket):
    data: GET_CIPHER_FROM_ESE_RSP
    data_padding: bytes = None
    mls_flash_version: int = None
    flash_crc: int = None

    def __init__(self, data: GET_CIPHER_FROM_ESE_RSP=None, pbf: Literal[0, 1]=0) -> None:
        super().__init__(NDPTag.SET_CIPHER_TO_ESE_CMD)
        self.data = data
        self.pbf = pbf

    def serialize_payload(self, stream: BytesIO):
        self.data.serialize(stream)
        if self.data_padding:
            stream.write(self.data_padding)
        if self.mls_flash_version != None:
            stream.write_int(self.mls_flash_version, 4, 'big')
        if self.flash_crc != None:
            stream.write_int(self.flash_crc, 4, 'big')

    def deserialize_payload(self, stream: BytesIO):
        pos_start = stream.tell()
        stream.read(0, 2)
        self.data = GET_CIPHER_FROM_ESE_RSP().deserialize(stream)
        pos_end = stream.tell()
        data_length = pos_end - pos_start
        if data_length < self.payload_length:
            more = stream.read(stream, self.payload_length - data_length)
            self.flash_crc = int.from_bytes(more[-4:], 'big')
            self.mls_flash_version = int.from_bytes(more[-8:-4], 'big')
            self.data_padding = more[:-8]

@NDPPacket.register(NDPTag.SET_CIPHER_TO_ESE_RSP)
class SET_CIPHER_TO_ESE_RSP(NDPPacket):

    def __init__(self) -> None:
        super().__init__(NDPTag.SET_CIPHER_TO_ESE_RSP)

    def deserialize_payload(self, stream: BytesIO):
        pass