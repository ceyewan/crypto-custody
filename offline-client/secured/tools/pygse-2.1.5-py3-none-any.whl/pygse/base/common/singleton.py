from functools import wraps
from typing import Callable, Type, TypeVar
T = TypeVar('T')

def singleton(cls: Type[T]) -> Type[T]:
    cls.__instance = None

    @wraps(cls)
    def wrapper(*args, **kwargs):
        if cls.__instance is None:
            cls.__instance = cls(*args, **kwargs)
        return cls.__instance
    return wrapper
__all__ = [singleton.__name__]