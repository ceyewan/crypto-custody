from abc import abstractmethod
from typing import Any, Callable, Dict, Generic, List, Literal, Tuple, Type, TypeVar, Union, overload
from .tlv import Tlv
from .bytes_io import BytesIO

class Position:
    offset: int
    size: int

    def __init__(self, offset: int=0, size: int=0) -> None:
        self.offset = offset
        self.size = size

class PropertyValue:
    value: Any = None
    pos: List[Union[Position, Tlv]]

    def __init__(self) -> None:
        self.pos = []
T = TypeVar('T')

class Property:
    size: int = None
    cls: Type[Any] = None
    name: str = ''
    length: int = None
    doc: str = ''
    title: str = None
    order: Union[int, float] = 0
    fmt: Union[str, Callable[[Any, int], str]] = None
    default: T = None

    @overload
    def __init__(self, title: str, cls: Type[T], size: int, doc: str, default: T, order: Union[int, float], fmt: Union[str, Callable[[Any, int], str]]) -> None:
        pass

    def __init__(self, title, cls=bytes, **kwargs):
        kwargs.update(title=title, cls=cls)
        self.__dict__.update(kwargs)

    def __call__(self, f_get: Callable[[], T]):
        self.f_get = f_get
        self.__doc__ = f_get.__doc__
        return self

    def __get__(self, obj: object, type=None) -> T:
        if obj is None:
            return self
        if self.name in obj.__dict__:
            return obj.__dict__.get(self.name).value
        else:
            return self.default

    def __set__(self, obj: object, value, pos: Union[Position, Tlv, List[Position], List[Tlv]]=None) -> None:
        prop_value: PropertyValue = obj.__dict__.get(self.name, None)
        if not prop_value:
            prop_value = PropertyValue()
            obj.__dict__[self.name] = prop_value
        prop_value.value = value
        if pos:
            if isinstance(pos, list):
                prop_value.pos = pos
            else:
                prop_value.pos = [pos]

    def __append__(self, obj: object, value, pos: Union[Position, Tlv]=None) -> None:
        prop_value: PropertyValue = obj.__dict__.get(self.name, None)
        if not prop_value:
            prop_value = PropertyValue()
            prop_value.value = []
            obj.__dict__[self.name] = prop_value
        prop_value.value.append(value)
        prop_value.pos.append(pos)

    def __delete__(self, obj: object) -> None:
        obj.__dict__.pop(self.name, None)

    def __set_name__(self, owner, name):
        self.name = name
        self.title = self.title or name

class IntProperty(Property):
    bit_field: Tuple[int, int]
    byteorder: Literal['big', 'little'] = 'big'
    signed: bool = False

    def __init__(self, title: str, cls: Type[T]=int, size: int=1, doc: str=None, order: Union[int, float]=None, fmt: Union[str, Callable[[Any, int], str]]=None, bit_field: Union[int, Tuple[int, int]]=None, byteorder: Literal['big', 'little']='little', signed: bool=False) -> None:
        super().__init__(title=title, cls=cls, size=size, doc=doc, order=order, fmt=fmt, bit_field=bit_field, byteorder=byteorder, signed=signed)

    def __get__(self, obj: object, type=None) -> int:
        return super().__get__(obj, type)

    def __set__(self, obj: object, value, pos: Union[Position, Tlv]=None) -> None:
        return super().__set__(obj, value, pos)

class TlvProperty(Property):
    tag: int

    def __init__(self, tag: int, cls: Type[Any]=int, size: int=None, doc: str=None, order: Union[int, float]=None, fmt: Union[str, Callable[[Any, int], str]]=None, bit_field: Union[int, Tuple[int, int]]=None, byteorder: Literal['big', 'little']='little', signed: bool=False) -> None:
        super().__init__(title=f'0x{int(tag):02X}' if tag <= 255 else f'0x{int(tag):04X}', cls=cls, size=size, doc=doc, order=order, fmt=fmt, bit_field=bit_field, byteorder=byteorder, signed=signed)
        self.tag = tag

    def __set__(self, obj: object, value, pos: Union[Position, Tlv, List[Position], List[Tlv]]=None) -> None:
        return super().__set__(obj, value, pos)

    @classmethod
    def set_tlv(cls, self: 'TlvProperty', obj: object, node: Union[Tlv, List[Tlv]]=None) -> None:
        if node:
            if isinstance(node, list):
                cls.__set__(self, obj, [n.value for n in node], node)
            else:
                cls.__set__(self, obj, node.value, node)

class ListType:

    def __init__(self, cls: Type[Any]) -> None:
        self.cls = cls

class Object:

    def deserialize(self, stream: BytesIO):
        pass

    @abstractmethod
    def deserialize_from_tlv(self, stream: BytesIO, tlv: Tlv):
        pass

    def deserialize_tlv_property(self, prop: TlvProperty, stream: BytesIO, tlv: Union[Tlv, List[Tlv]]=None, size: int=None, cls: Type[Any]=None):
        if not tlv:
            return
        if not isinstance(prop, TlvProperty):
            raise Exception(f'Bad parameter of prop, TlvProperty required!')
        cls = cls or prop.cls or bytes
        if isinstance(cls, ListType):
            cls = cls.cls
            nodes = Tlv.find_all(tlv, prop.tag)
            if issubclass(cls, int):
                value = [cls(int.from_bytes(n.value, prop.byteorder, signed=prop.signed)) for n in nodes]
            elif issubclass(cls, bytes):
                value = [n.value for n in nodes]
            elif issubclass(cls, Object):
                value = []
                for n in nodes:
                    item = cls()
                    stream.seek(n.value_offset, 0)
                    item.deserialize_from_tlv(stream, n)
                    value.append(item)
            prop.__set__(self, value, nodes)
        else:
            node = Tlv.find_one(tlv, prop.tag)
            if node:
                if issubclass(cls, int):
                    value = cls(int.from_bytes(node.value, prop.byteorder, signed=prop.signed))
                elif issubclass(cls, bytes):
                    value = node.value
                elif issubclass(cls, Object):
                    value = cls()
                    stream.seek(n.value_offset, 0)
                    value.deserialize_from_tlv(node)
                prop.__set__(self, value, node)

    def deserialize_tlv(self, stream: BytesIO, tag_property_map: Dict[int, Property], size_limit: int=None):
        pos = stream.tell()
        while tag_property_map:
            tag = stream.read_tlv_tag()
            if tag not in tag_property_map:
                raise Exception(f'Bad Control Reference Template Tag 0x{tag:02X} at {stream.tell()}.')
            length = stream.read_tlv_length()
            self.deserialize_property(tag_property_map.pop(tag), stream, length)
            if size_limit and stream.tell() - pos >= size_limit:
                break

    def deserialize_property(self, prop: Union[Property, IntProperty], stream: BytesIO, size: int=None, cls: Type[Any]=None):
        is_list = False
        cls = cls or prop.cls or bytes
        if isinstance(cls, ListType):
            cls = cls.cls
            is_list = True
        (value, offset, size) = self._deserialize_primitive_value(prop, stream, cls, size)
        if is_list:
            prop.__append__(self, value, Position(offset, size))
        else:
            prop.__set__(self, value, Position(offset, size))

    def _deserialize_primitive_value(self, prop: Property, stream: BytesIO, cls, size: int=None) -> Tuple[Any, int, int]:
        offset = stream.tell()
        size = size or prop.size
        if issubclass(cls, int):
            value = cls(stream.read_int(size, prop.byteorder, prop.signed))
        elif issubclass(cls, bytes):
            value = stream.read(size)
        elif issubclass(cls, Object):
            value = cls()
            value.deserialize(stream)
        return (value, offset, stream.tell() - offset)

    def serialize(self, stream: BytesIO):
        pass

    def serialize_property(self, prop: Union[Property, IntProperty], stream: BytesIO, size: int=None):
        if isinstance(prop, TlvProperty):
            raise Exception('TLV自行解析，无法使用反射解析')
        cls = prop.cls or bytes
        size = prop.size or size
        value = prop.__get__(self)
        if value != None:
            cls = value.__class__
        if issubclass(cls, int):
            stream.write_int(cls(value), size or 1, prop.byteorder, prop.signed)
        elif issubclass(cls, bytes):
            stream.write(value if isinstance(value, bytes) else bytes())
        elif issubclass(cls, Object):
            if isinstance(value, Object):
                value.serialize(stream)

    def to_bytes(self) -> bytes:
        stream = BytesIO()
        self.serialize(stream)
        return stream.getvalue()

    def __bytes__(self):
        return self.to_bytes()

    def __buffer__(self, protocol):
        return memoryview(self.to_bytes())