from enum import Enum
from io import BytesIO
from typing import Dict, List, Literal, Union, Tuple
import zlib
__all__ = ['CRC', 'CommonCrcAlgorithms', 'create_crc', 'crc16_ccitt', 'crc16_ccitt_false', 'crc16_arc', 'crc16_ibm', 'crc32', 'crc32_mpeg2']

class CRC:
    __xor_table: List[int] = None
    __poly: int = 0

    def __init__(self, bits: Literal[8, 16, 32], poly: int, init: int, reflect_in: bool, reflect_out: bool, xor_out: int) -> None:
        self.bits = bits
        self.poly = poly
        self.init = init
        self.reflect_in = reflect_in
        self.reflect_out = reflect_out
        self.xor_out = xor_out
        self.__poly = self.revert_bit(self.poly, self.bits) if self.reflect_in else self.poly & (1 << self.bits) - 1

    @property
    def xor_table(self) -> List[int]:
        if self.bits <= 8 and (not self.__xor_table):
            self.__gen_xor_table()
        return self.__xor_table

    def __gen_xor_table(self):
        xor_bit = 1 << self.bits - 1
        table = []
        for i in range(1 << self.bits):
            crc = i
            for _ in range(8):
                if crc & xor_bit:
                    crc = crc << 1 ^ self.poly
                else:
                    crc <<= 1
            table.append(crc)
        self.__xor_table = table

    def calc(self, data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None) -> int:
        buf = data
        if isinstance(data, BytesIO):
            buf = data.getbuffer()
        start = start if start and start > 0 else 0
        length = length if length and length > 0 else len(buf)
        if self.bits == 32 and self.poly == 79764919:
            return self.__calc_zlib(data, start, length)
        xor_bit = 1 << self.bits - 1
        crc_mask = (1 << self.bits) - 1
        crc = self.init
        lshift = self.bits - 8
        for i in range(start, start + length):
            b = buf[i]
            if self.reflect_in:
                b = self.revert_bit8(b)
            crc ^= b << lshift
            if self.xor_table:
                crc = self.xor_table[crc & crc_mask]
            else:
                for _ in range(8):
                    if crc & xor_bit:
                        crc = crc << 1 ^ self.poly
                    else:
                        crc <<= 1
        crc &= crc_mask
        if self.reflect_out:
            crc = self.revert_bit(crc, self.bits)
        if self.xor_out:
            crc ^= self.xor_out
        return crc

    def __calc_zlib(self, data: Union[bytes, bytearray], start: int=None, length: int=None) -> int:
        if not self.reflect_in:
            data = bytes(map(lambda b: self.revert_bit8(b), data[start:start + length]))
        crc = zlib.crc32(data, self.revert_bit32(self.init) ^ 4294967295)
        crc &= 4294967295
        crc ^= 4294967295
        crc = self.revert_bit(crc, self.bits)
        if self.reflect_out:
            crc = self.revert_bit(crc, self.bits)
        if self.xor_out:
            crc ^= self.xor_out
        return crc

    def revert_bit8(self, x: int) -> int:
        x = x >> 4 & 15 | x << 4 & 240
        x = x >> 2 & 51 | x << 2 & 204
        x = x >> 1 & 85 | x << 1 & 170
        return x

    def revert_bit16(self, x: int) -> int:
        return self.revert_bit8(x) << 8 | self.revert_bit8(x >> 8)

    def revert_bit32(self, x: int) -> int:
        return self.revert_bit16(x) << 16 | self.revert_bit16(x >> 16)

    def revert_bit(self, x: int, bits: Literal[8, 16, 32]) -> int:
        if bits == 8:
            return self.revert_bit8(x)
        elif bits == 16:
            return self.revert_bit16(x)
        elif bits == 32:
            return self.revert_bit32(x)
        else:
            raise Exception('Invalid argument of bits')

class CommonCrcAlgorithms(Enum):
    CRC8 = 'CRC-8'
    CRC8_CDMA2000 = 'CRC-8/CDMA2000'
    CRC8_DARC = 'CRC-8/DARC'
    CRC8_DVB_S2 = 'CRC-8/DVB-S2'
    CRC8_EBU = 'CRC-8/EBU'
    CRC8_I_CODE = 'CRC-8/I-CODE'
    CRC8_ITU = 'CRC-8/ITU'
    CRC8_MAXIM = 'CRC-8/MAXIM'
    CRC8_ROHC = 'CRC-8/ROHC'
    CRC8_WCDMA = 'CRC-8/WCDMA'
    CRC16_AUG_CCITT = 'CRC-16/AUG-CCITT'
    CRC16_BUYPASS = 'CRC-16/BUYPASS'
    CRC16_CDMA2000 = 'CRC-16/CDMA2000'
    CRC16_CCITT = 'CRC-16/CCITT'
    CRC16_CCITT_TRUE = 'CRC-16/CCITT-TRUE'
    CRC16_CCITT_FALSE = 'CRC-16/CCITT-FALSE'
    CRC16_ARC = 'CRC-16/ARC'
    CRC16_DDS110 = 'CRC-16/DDS-110'
    CRC16_DECT_R = 'CRC-16/DECT-R'
    CRC16_DECT_X = 'CRC-16/DECT-X'
    CRC16_DNP = 'CRC-16/DNP'
    CRC16_EN13757 = 'CRC-16/EN-13757'
    CRC16_GENIBUS = 'CRC-16/GENIBUS'
    CRC16_IBM = 'CRC-16/IBM'
    CRC16_MAXIM = 'CRC-16/MAXIM'
    CRC16_MCRF4XX = 'CRC-16/MCRF4XX'
    CRC16_RIELLO = 'CRC-16/RIELLO'
    CRC16_T10_DIF = 'CRC-16/T10-DIF'
    CRC16_TELEDISK = 'CRC-16/TELEDISK'
    CRC16_TMS37157 = 'CRC-16/TMS37157'
    CRC16_USB = 'CRC-16/USB'
    CRC16A = 'CRC-A'
    CRC16_KERMIT = 'CRC-16/KERMIT'
    CRC16_MODBUS = 'CRC-16/MODBUS'
    CRC16_X25 = 'CRC-16/X-25'
    CRC16_XMODEM = 'CRC-16/XMODEM'
    CRC32 = 'CRC-32'
    CRC32_BZIP2 = 'CRC-32/BZIP2'
    CRC32C = 'CRC-32C'
    CRC32D = 'CRC-32D'
    CRC32_JAMCRC = 'CRC-32/JAMCRC'
    CRC32_MPEG2 = 'CRC-32/MPEG-2'
    CRC32_POSIX = 'CRC-32/POSIX'
    CRC32Q = 'CRC-32Q'
    CRC32_XFER = 'CRC-32/XFER'
__CRC_FACTORY: Dict[str, CRC] = {}

def create_crc(alg: Union[CommonCrcAlgorithms, str]) -> CRC:
    global __CRC_FACTORY
    key = (alg.value if isinstance(alg, CommonCrcAlgorithms) else alg).upper()
    crc = __CRC_FACTORY.get(key)
    if crc:
        return crc
    crc_args = dict([('CRC-8', (8, 7, 0, False, False, 0)), ('CRC-8/CDMA2000', (8, 155, 255, False, False, 0)), ('CRC-8/DARC', (8, 57, 0, True, True, 0)), ('CRC-8/DVB-S2', (8, 213, 0, False, False, 0)), ('CRC-8/EBU', (8, 29, 255, True, True, 0)), ('CRC-8/I-CODE', (8, 29, 253, False, False, 0)), ('CRC-8/ITU', (8, 7, 0, False, False, 85)), ('CRC-8/MAXIM', (8, 49, 0, True, True, 0)), ('CRC-8/ROHC', (8, 7, 255, True, True, 0)), ('CRC-8/WCDMA', (8, 155, 0, True, True, 0)), ('CRC-16/ARC', (16, 32773, 0, True, True, 0)), ('CRC-16/AUG-CCITT', (16, 4129, 7439, False, False, 0)), ('CRC-16/CCITT', (16, 4129, 0, True, True, 0)), ('CRC-16/CCITT-TRUE', (16, 4129, 0, True, True, 0)), ('CRC-16/CCITT-FALSE', (16, 4129, 65535, False, False, 0)), ('CRC-16/BUYPASS', (16, 32773, 0, False, False, 0)), ('CRC-16/CDMA2000', (16, 51303, 65535, False, False, 0)), ('CRC-16/DDS-110', (16, 32773, 32781, False, False, 0)), ('CRC-16/DECT-R', (16, 1417, 0, False, False, 1)), ('CRC-16/DECT-X', (16, 1417, 0, False, False, 0)), ('CRC-16/DNP', (16, 15717, 0, True, True, 65535)), ('CRC-16/EN-13757', (16, 15717, 0, False, False, 65535)), ('CRC-16/GENIBUS', (16, 4129, 65535, False, False, 65535)), ('CRC-16/IBM', (16, 32773, 0, True, True, 0)), ('CRC-16/MAXIM', (16, 32773, 0, True, True, 65535)), ('CRC-16/MCRF4XX', (16, 4129, 65535, True, True, 0)), ('CRC-16/RIELLO', (16, 4129, 45738, True, True, 0)), ('CRC-16/T10-DIF', (16, 35767, 0, False, False, 0)), ('CRC-16/TELEDISK', (16, 41111, 0, False, False, 0)), ('CRC-16/TMS37157', (16, 4129, 35308, True, True, 0)), ('CRC-16/USB', (16, 32773, 65535, True, True, 65535)), ('CRC-A', (16, 4129, 50886, True, True, 0)), ('CRC-16/KERMIT', (16, 4129, 0, True, True, 0)), ('CRC-16/MODBUS', (16, 32773, 65535, True, True, 0)), ('CRC-16/X-25', (16, 4129, 65535, True, True, 65535)), ('CRC-16/XMODEM', (16, 4129, 0, False, False, 0)), ('CRC-32', (32, 79764919, 4294967295, True, True, 4294967295)), ('CRC-32/BZIP2', (32, 79764919, 4294967295, False, False, 4294967295)), ('CRC-32C', (32, 517762881, 4294967295, True, True, 4294967295)), ('CRC-32D', (32, 2821953579, 4294967295, True, True, 4294967295)), ('CRC-32/JAMCRC', (32, 79764919, 4294967295, True, True, 0)), ('CRC-32/MPEG-2', (32, 79764919, 4294967295, False, False, 0)), ('CRC-32/POSIX', (32, 79764919, 0, False, False, 4294967295)), ('CRC-32Q', (32, 2168537515, 0, False, False, 0)), ('CRC-32/XFER', (32, 175, 0, False, False, 0))])
    if key in crc_args:
        crc = CRC(*crc_args[key])
        __CRC_FACTORY[key] = crc
        __CRC_FACTORY[CommonCrcAlgorithms(key)] = crc
    return crc

def crc16_ccitt(data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None):
    return create_crc(CommonCrcAlgorithms.CRC16_CCITT).calc(data, start, length)

def crc16_ccitt_false(data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None):
    return create_crc(CommonCrcAlgorithms.CRC16_CCITT_FALSE).calc(data, start, length)

def crc16_arc(data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None):
    return create_crc(CommonCrcAlgorithms.CRC16_ARC).calc(data, start, length)

def crc16_ibm(data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None):
    return create_crc(CommonCrcAlgorithms.CRC16_ARC).calc(data, start, length)

def crc32(data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None):
    return create_crc(CommonCrcAlgorithms.CRC32).calc(data, start, length)

def crc32_mpeg2(data: Union[BytesIO, bytes, bytearray], start: int=None, length: int=None):
    return create_crc(CommonCrcAlgorithms.CRC32_MPEG2).calc(data, start, length)

def test():
    data = '123456789'.encode('ascii')
    check_values: List[Tuple[str, int]] = [('CRC-8', 244), ('CRC-8/CDMA2000', 218), ('CRC-8/DARC', 21), ('CRC-8/DVB-S2', 188), ('CRC-8/EBU', 151), ('CRC-8/I-CODE', 126), ('CRC-8/ITU', 161), ('CRC-8/MAXIM', 161), ('CRC-8/ROHC', 208), ('CRC-8/WCDMA', 37), ('CRC-16/ARC', 47933), ('CRC-16/AUG-CCITT', 58828), ('CRC-16/CCITT', 8585), ('CRC-16/CCITT-TRUE', 8585), ('CRC-16/CCITT-FALSE', 10673), ('CRC-16/BUYPASS', 65256), ('CRC-16/CDMA2000', 19462), ('CRC-16/DDS-110', 40655), ('CRC-16/DECT-R', 126), ('CRC-16/DECT-X', 127), ('CRC-16/DNP', 60034), ('CRC-16/EN-13757', 49847), ('CRC-16/GENIBUS', 54862), ('CRC-16/IBM', 47933), ('CRC-16/MAXIM', 17602), ('CRC-16/MCRF4XX', 28561), ('CRC-16/RIELLO', 25552), ('CRC-16/T10-DIF', 53467), ('CRC-16/TELEDISK', 4019), ('CRC-16/TMS37157', 9905), ('CRC-16/USB', 46280), ('CRC-A', 48901), ('CRC-16/KERMIT', 8585), ('CRC-16/MODBUS', 19255), ('CRC-16/X-25', 36974), ('CRC-16/XMODEM', 12739), ('CRC-32', 3421780262), ('CRC-32/BZIP2', 4236843288), ('CRC-32C', 3808858755), ('CRC-32D', 2268157302), ('CRC-32/JAMCRC', 873187033), ('CRC-32/MPEG-2', 58124007), ('CRC-32/POSIX', 1985902208), ('CRC-32Q', 806403967), ('CRC-32/XFER', 3171672888)]
    from rich import print
    from rich.table import Table
    table = Table('Pass', 'Name', 'Calc', 'Check', title='CRC Check')
    for (name, check) in check_values:
        crc = create_crc(name)
        value = crc.calc(data)
        table.add_row('√' if value == check else '×', name, f'{value:X}'.ljust(crc.bits >> 2, '0'), f'{check:X}'.ljust(crc.bits >> 2, '0'))
    print(table)
if __name__ == '__main__':
    test()