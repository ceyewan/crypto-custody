import sys
import typing
if (sys.version_info.major, sys.version_info.minor) < (3, 8):
    if not hasattr(typing, 'Literal'):
        typing._SpecialForm.__getitem___ = typing._SpecialForm.__getitem__

        def __getitem__(self, parameters):
            if self._name == 'Literal':
                return typing._GenericAlias(self, parameters)
            return self.__getitem___(parameters)
        typing._SpecialForm.__getitem__ = __getitem__
        typing.Literal = typing._SpecialForm('Literal', doc="Special typing form to define literal types (a.k.a. value types).\n\n        This form can be used to indicate to type checkers that the corresponding\n        variable or function parameter has a value equivalent to the provided\n        literal (or one of several literals):\n\n        def validate_simple(data: Any) -> Literal[True]:  # always returns True\n            ...\n\n        MODE = Literal['r', 'rb', 'w', 'wb']\n        def open_helper(file: str, mode: MODE) -> str:\n            ...\n\n        open_helper('/some/path', 'r')  # Passes type check\n        open_helper('/other/path', 'typo')  # Error in type checker\n\n        Literal[...] cannot be subclassed. At runtime, an arbitrary value\n        is allowed as type argument to Literal[...], but type checkers may\n        impose restrictions.\n        ")
        typing.__all__.append('Literal')