import sys
import os
import logging
from string import Template
from typing import Literal, Mapping, Tuple, Union, Dict
try:
    import colorama
    colorama.init()
except ImportError:
    colorama = None
try:
    import curses
except ImportError:
    curses = None

class Foreground:
    BLACK = 0
    RED = 1
    GREEN = 2
    YELLOW = 3
    BLUE = 4
    MAGENTA = 5
    CYAN = 6
    WHITE = 7
    RESET = 9
__stderr_supports_color: bool = None

def _is_stderr_supports_color() -> bool:
    global __stderr_supports_color
    if __stderr_supports_color is not None:
        return __stderr_supports_color
    try:
        if hasattr(sys.stderr, 'isatty') and sys.stderr.isatty():
            if curses:
                curses.setupterm()
                if curses.tigetnum('colors') > 0:
                    __stderr_supports_color = True
                    return True
            elif colorama:
                if sys.stderr is getattr(colorama.initialise, 'wrapped_stderr', object()):
                    __stderr_supports_color = True
                    return True
    except Exception as ex:
        pass
    __stderr_supports_color = False
    return False

class LogFormatter(logging.Formatter):
    DEFAULT_FORMAT = {logging.CRITICAL: '[{levelname:1.1s} {asctime} {name}]: {message}', logging.ERROR: '[{levelname:1.1s} {asctime} {name}]: {message}', logging.WARNING: '[{levelname:1.1s} {asctime} {name}]: {message}', logging.INFO: '[{levelname:1.1s} {asctime} {name}]: {message:s}', logging.DEBUG: '[{levelname:1.1s} {asctime} {name} {module}:{lineno}]: {message}', logging.NOTSET: '[{levelname:1.1s} {asctime} {name}]: {message}'}
    COLOR_FORMAT = {logging.CRITICAL: '{color_begin}[{levelname:1.1s} {asctime} {name}]{color_end}: {message}', logging.ERROR: '{color_begin}[{levelname:1.1s} {asctime} {name}]{color_end}: {message}', logging.WARNING: '{color_begin}[{levelname:1.1s} {asctime} {name}]{color_end}: {message}', logging.INFO: '{color_begin}[{levelname:1.1s} {asctime} {name}]{color_end}: {message}', logging.DEBUG: '{color_begin}[{levelname:1.1s} {asctime} {name} {module}:{lineno}]{color_end}: {message}', logging.NOTSET: '{color_begin}[{levelname:1.1s} {asctime} {name}]{color_end}: {message}'}
    DEFAULT_COLORS = {logging.DEBUG: Foreground.BLUE, logging.INFO: Foreground.GREEN, logging.WARNING: Foreground.YELLOW, logging.ERROR: Foreground.RED, logging.CRITICAL: Foreground.MAGENTA}
    formats: Dict[int, Union[str, Template]]

    def __init__(self, fmt: Dict[int, str]=None, datefmt: str=None, style: Literal['{', '%', '$']='{', color: bool=True, colors: Dict[int, int]=DEFAULT_COLORS) -> None:
        logging.Formatter.__init__(self, datefmt=datefmt, style=style)
        self.default_msec_format = '%s.%03d'
        self.format_style = style
        self.formats = self.DEFAULT_FORMAT.copy()
        if isinstance(fmt, dict):
            self.formats.update(fmt)
        for level in logging._levelToName.keys():
            self.formats.setdefault(level, Template(self.DEFAULT_FORMAT[level]) if style == '$' else self.DEFAULT_FORMAT[level])
        if style == '$':
            for (k, v) in self.formats.items():
                if isinstance(v, str):
                    self.formats[k] = Template(v)
        self._fmt = self.formats.get(logging.INFO)
        self._colors = {}
        if color and _is_stderr_supports_color():
            if curses is not None:
                fg_color = curses.tigetstr('setaf') or curses.tigetstr('setf') or b''
                for (levelno, code) in colors.items():
                    self._colors[levelno] = str(curses.tparm(fg_color, code), 'ascii')
                self._normal = str(curses.tigetstr('sgr0'), 'ascii')
            else:
                for (levelno, code) in colors.items():
                    self._colors[levelno] = f'\x1b[3{code}m'
                self._normal = '\x1b[0m'
        else:
            self._normal = ''

    def usesTime(self) -> bool:
        return True

    def formatMessage(self, record: logging.LogRecord):
        fmt = self.formats.get(record.levelno, self._fmt)
        if not record.name and ' {name}' in fmt:
            fmt = fmt.replace(' {name}', '')
        if self.format_style == '{':
            return fmt.format(**record.__dict__)
        if self.format_style == '%':
            return fmt % record.__dict__
        if self.format_style == '$':
            return fmt.substitute(**record.__dict__)
        return self._style.format(record)

    def format(self, record: logging.LogRecord) -> str:
        if record.levelno in self._colors:
            record.color_begin = self._colors[record.levelno]
            record.color_end = self._normal
        else:
            record.color_begin = record.color_end = ''
        return super().format(record)

class StreamHandler(logging.StreamHandler):

    def __init__(self) -> None:
        super().__init__()
        self.setFormatter(LogFormatter(LogFormatter.COLOR_FORMAT))

    def emit(self, record: logging.LogRecord) -> None:
        self.__select_stream(record)
        return super().emit(record)

    def __select_stream(self, record: logging.LogRecord):
        if self.stream != sys.stdout and self.stream != sys.stderr:
            return
        self.setStream(sys.stderr if record.levelno in [logging.CRITICAL, logging.ERROR, logging.WARNING] else sys.stdout)

class FileHandler(logging.FileHandler):

    def __init__(self, filename: str, mode: str='a', encoding: str='utf-8', delay: bool=False) -> None:
        file = os.path.normpath(os.path.abspath(filename))
        if not os.path.exists(os.path.dirname(file)):
            os.makedirs(os.path.dirname(file), exist_ok=True)
        super().__init__(file, mode, encoding, delay)
        self.setFormatter(LogFormatter(LogFormatter.DEFAULT_FORMAT))

class Logger(logging.Logger):

    def __init__(self, name: str, level: Union[str, int]=logging.NOTSET) -> None:
        super().__init__(name, level)

    def _log(self, level: int, msg: object, args: Union[Tuple, Mapping[str, object]], exc_info: Exception=None, extra: Mapping[str, object]=None, stack_info: bool=None, stacklevel: int=1) -> None:
        if isinstance(msg, Exception) and self.getEffectiveLevel() == logging.DEBUG and (not hasattr(msg, 'printed')):
            exc_info = msg
            exc_info.printed = True
        return super()._log(level, msg, args, exc_info, extra, stack_info, stacklevel)

class RootLogger(Logger):

    def __init__(self, level=logging.INFO):
        Logger.__init__(self, '', level)

    def __reduce__(self):
        return (logging.getLogger, ())
__nameToLevel: Dict[str, int] = {'CRITICAL': logging.CRITICAL, 'FATAL': logging.FATAL, 'ERROR': logging.ERROR, 'WARN': logging.WARNING, 'WARNING': logging.WARNING, 'INFO': logging.INFO, 'DEBUG': logging.DEBUG, 'NOTSET': logging.NOTSET, 'C': logging.CRITICAL, 'F': logging.FATAL, 'E': logging.ERROR, 'W': logging.WARNING, 'I': logging.INFO, 'D': logging.DEBUG, 'N': logging.NOTSET}

def check_log_level(level: Union[str, int]):
    if isinstance(level, int):
        return level
    elif isinstance(level, str):
        level = level.upper()
        if level not in __nameToLevel:
            raise ValueError('Unknown level: %r' % level)
        rv = __nameToLevel[level]
    else:
        raise TypeError('Level not an integer or a valid string: %r' % level)
    return rv

def get_level_name(level: Union[str, int]):
    if isinstance(level, str):
        l = __nameToLevel.get(level.upper(), None)
        if l is not None:
            level = l
    result = logging._levelToName.get(level, None)
    if result is not None:
        return result
    return 'Level %s' % level
if not logging.root or not isinstance(logging.root, RootLogger):
    logging.root = RootLogger()
logging._defaultFormatter = LogFormatter()
logging._checkLevel = check_log_level
logging.FileHandler = FileHandler
logging.Logger.root = logging.root
logging.getLevelName = get_level_name
logging.setLoggerClass(Logger)
logging.basicConfig(handlers=[StreamHandler()])
Logger.manager.root = logging.root