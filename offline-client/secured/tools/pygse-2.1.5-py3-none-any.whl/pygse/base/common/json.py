from datetime import datetime
from enum import Enum
import json
import re
from typing import Any, Callable, List, Literal, Tuple, Union

class JSONEncoder(json.JSONEncoder):
    bytes_format: Literal['str', 'b-str']

    def __init__(self, *, skipkeys: bool=False, ensure_ascii: bool=True, check_circular: bool=True, allow_nan: bool=True, sort_keys: bool=False, indent: Union[int, str]=None, separators: Tuple[str, str]=None, default: Callable[[Any], Any]=None, bytes_format: Literal['str', 'b-str']='str', **kwargs) -> None:
        self.custom_default = default
        self.bytes_format = bytes_format
        default = None
        super().__init__(skipkeys=skipkeys, ensure_ascii=ensure_ascii, check_circular=check_circular, allow_nan=allow_nan, sort_keys=sort_keys, indent=indent, separators=separators, default=default)

    def default(self, o):
        if self.custom_default:
            try:
                return self.custom_default(o)
            except TypeError:
                pass
            except:
                raise
        if hasattr(o, '__json__') and callable(getattr(o, '__json__')):
            return o.__json__()
        if isinstance(o, (bytes, bytearray)):
            if self.bytes_format == 'b-str':
                return f"b'{o.hex().upper()}'"
            else:
                return o.hex().upper()
        if isinstance(o, datetime):
            return o.isoformat()
        if isinstance(o, Enum):
            return o.value
        raise TypeError

class JSONDecoder(json.JSONDecoder):
    hex_pattern = re.compile("^b'((?:[0-9a-fA-F]{2})+)'$")
    iso_datetime_pattern = re.compile('^(\\d{4})-(\\d{1,2})-(\\d{1,2})[T ](\\d{1,2}):(\\d{1,2}):(\\d{1,2})(?:\\.(\\d{1,9}))?$')

    def decode(self, s, _w=json.decoder.WHITESPACE.match):
        obj = super().decode(s, _w)
        return self._decode_object(obj)

    def _decode_object(self, obj):
        if isinstance(obj, dict):
            for (key, value) in obj.items():
                obj[key] = self._decode_object(value)
        elif isinstance(obj, list):
            for (i, value) in enumerate(obj):
                obj[i] = self._decode_object(value)
        elif isinstance(obj, str):
            return self._decode_special(obj)
        return obj

    def _decode_special(self, value: str):
        m = self.hex_pattern.match(value)
        if m:
            return bytes.fromhex(m[1])
        m = self.iso_datetime_pattern.match(value)
        if m:
            return datetime.fromisoformat(value)
        return value
json.dump.__kwdefaults__['cls'] = JSONEncoder
json.dump.__kwdefaults__['ensure_ascii'] = False
json.dumps.__kwdefaults__['cls'] = JSONEncoder
json.dumps.__kwdefaults__['ensure_ascii'] = False
json.load.__kwdefaults__['cls'] = JSONDecoder
json.loads.__kwdefaults__['cls'] = JSONDecoder

class JsonEncodableObject:

    def __init__(self, **kwargs) -> None:
        self.__dict__.update(kwargs)

    def __getattr__(self, attr):
        return None

    def __json__(self):
        d = self.__dict__
        return {k: d[k] for k in d.keys() if not k.startswith('_') and d[k] != None}

    def json(self, exclude: List[str]=None):
        obj = self.__json__()
        if exclude:
            for ex in exclude:
                if ex in obj:
                    del obj[ex]
        return obj
__all__ = [JsonEncodableObject.__name__]