import sys
import os
import builtins
from typing import Callable, Dict, Iterable, List, Type, TypeVar
from argparse import _SubParsersAction, ArgumentParser, Namespace
from .log import get_level_name

class CommandArguments:
    log_level: str = None
    log_file: str = None

    def __init__(self, init: Namespace) -> None:
        self.__dict__.update(init.__dict__)

    def __getattr__(self, attr):
        return None

def add_log_arguments(parser: ArgumentParser):
    parser.add_argument('--log-level', type=get_level_name, metavar='d|i|w|e|debug|info|warning|error')
    parser.add_argument('--log-file', type=str, metavar='LogFilePath')
    return parser

class SubCommandArguments(CommandArguments):
    cmd: str
    help: str

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if self.cmd:
            self.cmd = self.cmd.lower()

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        raise Exception('需要在派生类自己实现为parser添加参数的逻辑')
T_ARG = TypeVar('T_ARG', bound=SubCommandArguments)

class SystemExitException(Exception):

    def __init__(self, status: int, *args) -> None:
        super().__init__(*args)
        self.status = status

class InvalidCommandException(Exception):

    def __init__(self, *args) -> None:
        super().__init__(*args)

class ArgumentParserEx(ArgumentParser):

    def format_help(self) -> str:
        return super().format_help()

class CliSubArgumentsParser:
    registered_sub_parsers: Dict[str, Type[T_ARG]] = {}
    _parser: ArgumentParser = None

    def __init__(self) -> None:
        self.registered_sub_parsers = CliSubArgumentsParser.registered_sub_parsers.copy()

    def exit(self, status=0, message=None):
        if message:
            if status == 0:
                sys.stdout.write(message)
            else:
                sys.stderr.write(message)
        raise SystemExitException(status)

    def _init_parser(self):
        self._parser = ArgumentParser(__package__.split('.')[0], add_help=True)
        if (sys.version_info.major, sys.version_info.minor, sys.version_info.micro) <= (3, 8, 5):
            self._parser.exit = self.exit
        subparsers = self._parser.add_subparsers(dest='cmd', required=True)
        for (cmd, cls) in sorted(self.registered_sub_parsers.items(), key=lambda i: i[0]):
            help = cls.HELP if hasattr(cls, 'HELP') else None
            parser: ArgumentParser = subparsers.add_parser(cmd, help=help, add_help=True)
            if (sys.version_info.major, sys.version_info.minor, sys.version_info.micro) <= (3, 8, 5):
                parser.exit = self.exit
            cls.add_arguments(parser)
        for p in self.enum_sub_parsers(self._parser):
            add_log_arguments(p)
        return self._parser

    def enum_sub_parsers(self, parser: ArgumentParser) -> Iterable[ArgumentParser]:
        for action in parser._actions:
            if isinstance(action, _SubParsersAction):
                for sp in action.choices.values():
                    yield from self.enum_sub_parsers(sp)
                yield from action.choices.values()

    @property
    def parser(self):
        return self._parser if self._parser else self._init_parser()

    def parse_args(self, *args: str) -> T_ARG:
        args = args or sys.argv[1:]
        if len(args) == 1 and args[0].lower() in ('-v', '--version', 'v'):
            self.exit(0, f"{builtins.__product__} {builtins.__package_version__} from {os.path.realpath(__file__ + '/../../..')} {builtins.__build__} (Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro})\n")
        namespace = self.parser.parse_args(args)
        if namespace.cmd in self.registered_sub_parsers:
            cls = self.registered_sub_parsers[namespace.cmd]
            obj = cls(namespace)
            return obj
        raise InvalidCommandException(f'Bad command of "{namespace.cmd}"')

    @classmethod
    def register_sub_arg(self_cls, cmd: str, help: str=None, aliases: List[str]=None):

        def inner(cls):
            if cmd in self_cls.registered_sub_parsers:
                raise Exception(f'{cmd} already registered.')
            cls.HELP = help
            self_cls.registered_sub_parsers[cmd] = cls
            return cls
        return inner
__all__ = [add_log_arguments.__name__, CommandArguments.__name__, SubCommandArguments.__name__, CliSubArgumentsParser.__name__, SystemExitException.__name__, InvalidCommandException.__name__]