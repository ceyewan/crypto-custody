import os
import math
import hashlib
from enum import IntEnum
from random import randint
from typing import Union
from io import BytesIO

def rand_prime(bits: int):
    while True:
        num = randint(2 ** (bits - 1), 2 ** bits - 1) | 1
        for _ in range(50):
            if not miller_rabin(num):
                break
        else:
            return num

def miller_rabin(num: int):
    m = num - 1
    k = 0
    while m % 2 == 0:
        m = m // 2
        k = k + 1
    a = randint(2, num)
    b = power_mod(a, m, num)
    if b == 1:
        return True
    for _ in range(k):
        if b == num - 1:
            return True
        else:
            b = b * b % num
    return False

def power_mod(a: int, n: int, p: int):
    ans = 1
    a = a % p
    while n:
        if n & 1 == 1:
            ans = ans * a % p
        n >>= 1
        a = a * a % p
    return ans

def gcd(a: int, b: int):
    m = a % b
    while m:
        a1 = b
        b = a % b
        a = a1
        m = a % b
    return b

def inverse_element(x, n):
    r0 = n
    r1 = x % n
    if r1 == 1:
        y = 1
    else:
        s0 = 1
        s1 = 0
        t0 = 0
        t1 = 1
        while r0 % r1 != 0:
            q = r0 // r1
            r = r0 % r1
            r0 = r1
            r1 = r
            s = s0 - q * s1
            s0 = s1
            s1 = s
            t = t0 - q * t1
            t0 = t1
            t1 = t
            if r == 1:
                y = (t + n) % n
    return y

def build_key(e: int=65537):
    while True:
        p = rand_prime(1024)
        q = rand_prime(1024)
        n = p * q
        n1 = (p - 1) * (q - 1)
        if gcd(e, n1) != 1:
            continue
        d = inverse_element(e, n1)
        return (n, e, d)

def sign(m, n, d):
    s = [power_mod(ord(i), d, n) for i in m]
    return (m, s)

def verify(m, s, n, e):
    return m == ''.join([chr(power_mod(i, e, n)) for i in s])

class RSAPadding(IntEnum):
    NO_PAD = 0
    PKCS1 = 1
    PKCS1_OAEP = 2
    PKCS1_PSS = 3
    ISO9796 = 4

class RSAHashAlg(IntEnum):
    MD5 = 128
    SHA1 = 160
    SHA224 = 224
    SHA256 = 256
    SHA384 = 384
    SHA512 = 512

class RSA:
    e: int = None
    n: int = None
    d: int = None
    k: int = None
    hash_alg: RSAHashAlg = RSAHashAlg.SHA512
    hash_length: int = RSAHashAlg.SHA512 >> 8
    padding: RSAPadding = RSAPadding.NO_PAD

    def __init__(self, n: Union[bytes, bytearray, int]=None, d: Union[bytes, bytearray, int]=None, e: int=65537, padding: RSAPadding=RSAPadding.PKCS1_OAEP, hash_alg: RSAHashAlg=RSAHashAlg.SHA512) -> None:
        if n:
            self.n = n if isinstance(n, int) else int.from_bytes(n, 'big')
        if d:
            self.d = d if isinstance(n, int) else int.from_bytes(d, 'big')
        self.k = math.ceil((self.n or self.d).bit_length() / 8)
        self.e = e
        self.padding = padding
        self.hash_alg = hash_alg
        self.hash_length = hash_alg >> 3

    def encrypt(self, data: bytes, label: bytes=None) -> bytes:
        k = self.k
        mLen = len(data)
        hLen = self.hash_length
        segment_length = k - 2 * hLen - 2
        encoded = bytearray()
        stream = BytesIO(data)
        while stream.tell() != mLen:
            segment = stream.read(segment_length)
            if self.padding == RSAPadding.PKCS1_OAEP:
                segment = self.__pkcs1_oaep_padding_encode(segment, label)
            encoded.extend(bytes.fromhex(hex(pow(int.from_bytes(segment, 'big'), self.e, self.n))[2:].zfill(self.k * 2)))
        return bytes(encoded)

    def decrypt(self, data: bytes, label: bytes=None) -> bytes:
        k = self.k
        mLen = len(data)
        decoded = bytearray()
        stream = BytesIO(data)
        while stream.tell() != mLen:
            segment = stream.read(k)
            output = bytes.fromhex(hex(pow(int.from_bytes(segment, 'big'), self.d, self.n))[2:].zfill(self.k * 2))
            if self.padding == RSAPadding.PKCS1_OAEP:
                decoded.extend(self.__pkcs1_oaep_padding_decode(output, label))
            else:
                decoded.extend(output)
        return bytes(decoded)

    def __pkcs1_oaep_padding_encode(self, data: bytes, L: bytes=None) -> bytes:
        k = self.k
        mLen = len(data)
        hLen = self.hash_length
        if mLen > k - 2 * hLen - 2:
            raise Exception('message too long')
        PSLen = k - 2 * hLen - 2 - mLen
        DB = self.hash(L) + bytes([0]) * PSLen + bytes([1]) + data
        seed = os.urandom(hLen)
        dbMask = self.__mgf(seed, k - hLen - 1)
        maskedDB = self.__xor(DB, dbMask)
        seedMask = self.__mgf(maskedDB, hLen)
        maskedSeed = self.__xor(seed, seedMask)
        EM = bytes([0]) + maskedSeed + maskedDB
        return EM

    def __pkcs1_oaep_padding_decode(self, data: bytes, label: bytes=None) -> bytes:
        k = self.k
        hLen = self.hash_length
        mLen = len(data)
        if mLen != k:
            raise Exception('decryption error')
        if data[0] != 0:
            raise Exception('decryption error')
        maskedSeed = data[1:hLen + 1]
        maskedDB = data[-(k - hLen - 1):]
        seedMask = self.__mgf(maskedDB, hLen)
        seed = self.__xor(maskedSeed, seedMask)
        dbMask = self.__mgf(seed, k - hLen - 1)
        DB = self.__xor(maskedDB, dbMask)
        lHash = DB[0:hLen]
        if lHash != self.hash(label):
            raise Exception('decryption error')
        sep = DB.find(1, hLen)
        if sep < 0:
            raise Exception('decryption error')
        return DB[sep + 1:]

    def hash(self, data: bytes) -> bytes:
        return hashlib.new(self.hash_alg.name, data or bytes()).digest()

    def __mgf(self, mgf_seed: bytes, mask_length: int) -> bytes:
        T = bytearray()
        for i in range(0, math.ceil(mask_length / self.hash_length)):
            T.extend(self.hash(mgf_seed + i.to_bytes(4, 'big')))
        return bytes(T[:mask_length])

    def __xor(self, a: bytes, b: bytes) -> bytes:
        if a.__len__() < b.__len__():
            a = bytes([0]) * (b.__len__() - a.__len__()) + a
        return bytes((a[i] ^ b[i] for i in range(a.__len__())))
__all__ = [rand_prime.__name__, miller_rabin.__name__, power_mod.__name__, gcd.__name__, inverse_element.__name__, build_key.__name__, sign.__name__, verify.__name__, RSAPadding.__name__, RSAHashAlg.__name__, RSA.__name__]
if __name__ == '__main__':
    (n, e, d) = build_key()
    rsa = RSA(n, d, e)
    r = rsa.encrypt(b'123')
    d = rsa.decrypt(r)
    pass
try:
    from .protecting import protected
    RSA = protected(RSA)
except:
    pass