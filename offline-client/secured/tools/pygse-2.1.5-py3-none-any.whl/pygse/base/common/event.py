import asyncio
import inspect
from typing import Any, Awaitable, Callable, List, Tuple, TypeVar, Union, Generic
T = TypeVar('T')

class Event(Generic[T]):
    __registered_cb: List[Callable[[T], Any]]

    def __init__(self) -> None:
        self.__registered_cb = []

    def __iadd__(self, cb: Callable[[T], Any]) -> Callable:
        self.connect(cb)
        return self

    def __isub__(self, cb: Callable[[T], Any]):
        return self.disconnect(cb)

    def connect(self, cb: Callable[[T], Any]) -> Callable:
        self.__registered_cb.append(cb)
        return lambda : self.disconnect(cb)

    def disconnect(self, cb: Callable[[T], Any]):
        if cb in self.__registered_cb:
            self.__registered_cb.remove(cb)
        return self

    def clear(self):
        self.__registered_cb.clear()

    def __del__(self):
        self.__registered_cb.clear()

    def __call__(self, arg: T=None) -> Any:
        return self.emit(arg)

    def emit(self, arg: T=None):
        for cb in self.__registered_cb:
            cb(arg)
EventCallback = Union[Callable[[T], Any], Callable[[T], Awaitable[Any]]]

class AsyncEvent(Generic[T]):

    def __init__(self) -> None:
        self.__registered_cb: List[Tuple[EventCallback, asyncio.AbstractEventLoop]] = []

    def __iadd__(self, cb: EventCallback) -> 'AsyncEvent':
        self.register(cb)
        return self

    def __isub__(self, cb: EventCallback) -> 'AsyncEvent':
        self.deregister(cb)
        return self

    def register(self, cb: EventCallback) -> Callable:
        self.__registered_cb.append((cb, asyncio.get_running_loop()))
        return lambda : self.deregister(cb)

    def deregister(self, cb: EventCallback):
        for item in list(filter(lambda i: i[0] == cb, self.__registered_cb)):
            self.__registered_cb.remove(item)

    def clear(self):
        self.__registered_cb.clear()

    def __del__(self):
        self.__registered_cb.clear()

    def __call__(self, arg: T=None) -> None:
        self.emit(arg)

    def emit(self, arg: T=None) -> None:
        for (cb, loop) in self.__registered_cb:
            if loop.is_running():
                if inspect.iscoroutinefunction(cb):
                    asyncio.run_coroutine_threadsafe(cb(arg), loop)
                else:
                    loop.call_soon(cb, arg)
__all__ = [Event.__name__, AsyncEvent.__name__]