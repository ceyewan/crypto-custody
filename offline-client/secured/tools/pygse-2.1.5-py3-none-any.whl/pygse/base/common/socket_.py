import asyncio
import subprocess
import logging
from socket import socket, AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR, gethostbyname_ex, gethostname, getfqdn
import sys
from .event import AsyncEvent

def get_local_ip():
    hostname = gethostname()
    fqdn = getfqdn(hostname)
    (_, _, ip_list) = gethostbyname_ex(fqdn)
    for ip in ip_list:
        if not ip.startswith('127.'):
            return ip
    if sys.platform == 'linux':
        try:
            output = subprocess.check_output(['ip', 'addr'], encoding='utf8')
            for line in output.splitlines():
                line = line.strip()
                if line.startswith('inet ') and (not line.startswith('inet 127.')):
                    return line.split(' ')[1].split('/')[0]
        except:
            pass
    elif sys.platform == 'win32':
        try:
            output = subprocess.check_output(['ipconfig'], encoding='utf8')
            for line in output.splitlines():
                line = line.strip()
                if line.startswith('IPv4 '):
                    ip = line.split(':')[1].strip()
                    if not ip.startswith('127.'):
                        return ip if '(' not in ip else ip.split('(')[0]
        except:
            pass
    return None

class AsyncSocketServer:
    on_client_connected: AsyncEvent[socket]
    on_server_closed: AsyncEvent[socket]

    def __init__(self, name: str, port: int=0, host: str='0.0.0.0', loop: asyncio.AbstractEventLoop=None):
        self.name = name
        self.host = host
        self.port = port
        self.server = None
        self.on_client_connected = AsyncEvent()
        self.on_server_closed = AsyncEvent()
        self.event_loop = loop or asyncio.get_event_loop()
        self.logger = logging.getLogger(name or self.__class__.__name__)

    def init(self) -> 'AsyncSocketServer':
        server = socket(AF_INET, SOCK_STREAM)
        server.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.setblocking(False)
        server.listen()

        async def accept():
            while True:
                try:
                    (client_socket, client_address) = await self.event_loop.sock_accept(server)
                    self.logger.info(f'Accepted connection from {client_address} on {self.port}')
                    self.on_client_connected(client_socket)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    break
            self.on_server_closed(server)
            self.logger.info(f'Socket Server closed on {self.port}')
        self._accept_task = self.event_loop.create_task(accept())
        self.server = server
        self.logger.info(f'Socket Server is listening on {self.server.getsockname()[1]}')
        return self

    async def stop(self) -> None:
        if self._accept_task:
            self._accept_task.cancel()
            try:
                asyncio.wait_for()
                self._accept_task.result()
            except (asyncio.CancelledError, Exception) as e:
                self.logger.info(f'Accept task stopped with exception: {e}')
            self._accept_task = None
        if self.server:
            self.server.close()
            self.server = None

class AsyncSocketServer:
    on_client_connected: AsyncEvent[socket]
    on_server_closed: AsyncEvent[socket]

    def __init__(self, name: str, port: int=0, host: str='0.0.0.0', event_loop: asyncio.AbstractEventLoop=None):
        self.name = name
        self.host = host
        self.port = port
        self.server = None
        self.on_client_connected = AsyncEvent()
        self.on_server_closed = AsyncEvent()
        self.event_loop = event_loop or asyncio.get_event_loop()
        self.logger = logging.getLogger(name or self.__class__.__name__)

    async def _listen(self):
        server = socket(AF_INET, SOCK_STREAM)
        server.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.setblocking(False)
        server.listen()
        self.server = server
        self.logger.info(f'Socket Server is listening on {self.server.getsockname()[1]}')
        self._accept_task = self.event_loop.create_task(self._accept())

    async def _accept(self):
        while True:
            try:
                (client_socket, client_address) = await self.event_loop.sock_accept(self.server)
                self.logger.info(f'Accepted connection from {client_address} on {self.port}')
                self.on_client_connected(client_socket)
            except asyncio.CancelledError:
                break
            except Exception as e:
                break
        self.on_server_closed(self.server)
        self.logger.info(f'Socket Server closed on {self.port}')

    def start(self) -> 'AsyncSocketServer':
        asyncio.run_coroutine_threadsafe(self._listen(), self.event_loop)
        return self

    def stop(self):
        if self._accept_task:
            self._accept_task.cancel()
            self._accept_task = None
        if self.server:
            self.server.close()
            self.server = None
__all__ = [get_local_ip.__name__, AsyncSocketServer.__name__]