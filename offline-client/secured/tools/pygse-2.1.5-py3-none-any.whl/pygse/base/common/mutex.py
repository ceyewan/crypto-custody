import sys
if sys.platform == 'win32':
    from ..system.win32_api import Kernel32

    def mutex(name: str):
        return Kernel32.CreateMutex(name, False)

    def lock_mutex(handle: int):
        return Kernel32.WaitForSingleObject(handle, 1) == 0

    def release_mutex(handle: int):
        return Kernel32.ReleaseMutex(handle)

    class FileMutex:

        def __init__(self, name: str) -> None:
            self.handle = mutex(name)

        def lock(self):
            try:
                lock_mutex(self.handle)
            except:
                return False
            return True

        def release(self):
            try:
                release_mutex(self.handle)
            except:
                return False
            return True

        def close(self):
            pass
else:
    import fcntl

    class FileMutex:

        def __init__(self, name: str) -> None:
            self.fp = open(name, 'w')
            self.handle = self.fp.fileno()

        def lock(self):
            try:
                fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except:
                return False
            return True

        def release(self):
            try:
                fcntl.flock(self.handle, fcntl.LOCK_UN | fcntl.LOCK_NB)
            except:
                return False
            return True

        def close(self):
            if self.fp:
                self.fp.close()
                self.fp = None

class Mutex:
    mutex: FileMutex = None
    locked = False

    def __init__(self, name: str):
        self.name = name

    def acquire(self):
        try:
            if not self.mutex:
                self.mutex = FileMutex(self.name)
                if self.mutex.handle < 0:
                    return False
            self.locked = self.mutex.lock()
            return self.locked
        except:
            pass
        return False

    def release(self):
        try:
            if not self.mutex or not self.locked:
                return
            self.mutex.release()
        except:
            pass

    def __enter__(self):
        if not self.acquire():
            raise Exception(f'Can not lock {self.name}')
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()

    def __del__(self):
        try:
            self.release()
            if self.mutex:
                self.mutex.close()
        except:
            pass