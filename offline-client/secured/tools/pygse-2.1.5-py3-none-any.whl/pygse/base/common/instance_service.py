import inspect
import logging
from typing import Any, Dict, List, Tuple, Type, TypeVar, Union, overload
from threading import RLock
T = TypeVar('T')
ServiceId = Union[Type[T], str]

def as_service_id(id: ServiceId) -> str:
    return id if isinstance(id, str) else id.__name__

class IInstanceService:

    @overload
    def get(self, service_id: Type[T]) -> T:
        pass

    @overload
    def get(self, service_id: str) -> Any:
        pass

    def get(self, service_id: ServiceId) -> Any:
        pass

    def instance(self, cls: Type[T], *args, **kwargs) -> T:
        pass

class InstanceService(IInstanceService):
    __registered_services: Dict[Type[T], Tuple[Type[T], List, Dict]] = {}
    __service_instances: Dict[str, T] = None
    __instance_locker: RLock

    def __init__(self) -> None:
        super().__init__()
        self.__service_instances = {}
        self.__service_instances[IInstanceService.__name__] = self
        self.__instance_locker = RLock()

    def register_type(self, service_id: ServiceId, cls_implement: Type[T], *args, **kwargs):
        return InstanceService.global_register(service_id, cls_implement, *args, **kwargs)

    def register_instance(self, service_id: ServiceId, instance: T):
        self.register_type(service_id, instance.__class__)
        self.__service_instances[as_service_id(service_id)] = instance
        return instance

    @overload
    def get(self, service_id: Type[T]) -> T:
        pass

    @overload
    def get(self, service_id: str) -> Any:
        pass

    def get(self, service_id: ServiceId) -> T:
        id = as_service_id(service_id)
        if id in self.__service_instances:
            return self.__service_instances.get(id)
        if id not in self.registered_services:
            raise Exception(f'Service {service_id} is not registered!')
        else:
            with self.__instance_locker:
                if id in self.__service_instances:
                    return self.__service_instances.get(id)
                (ctor, args, kwargs) = self.registered_services[id]
                service = self.instance(ctor, *args, **kwargs)
                self.__service_instances[id] = service
                return service

    def instance(self, cls: Type[T], *args, **kwargs) -> T:
        signature = inspect.signature(cls.__init__)
        for (name, para) in signature.parameters.items():
            if name not in kwargs and isinstance(para.default, ServiceParam):
                kwargs[name] = self.get(para.default.service_id)
        return cls(*args, **kwargs)

    @property
    def registered_services(self):
        return InstanceService.__registered_services

    @staticmethod
    def global_register(service_id: ServiceId, service_implement: Type[T], *args, **kwargs):
        id = as_service_id(service_id)
        if id in InstanceService.__registered_services:
            logging.warn(f'{id} already registered by {InstanceService.__registered_services[id][0].__name__}')
        InstanceService.__registered_services[as_service_id(service_id)] = (service_implement, args, kwargs)
        return service_implement

class ServiceParam:

    def __init__(self, service_id: ServiceId) -> None:
        if not service_id:
            raise Exception('Argument of service_id is required!')
        self.service_id = service_id

def register_service(service_id: ServiceId, service_implement: Type[T], *args, **kwargs):
    return InstanceService.global_register(service_id, service_implement, *args, **kwargs)

def service(service_id: ServiceId, *args, **kwargs):

    def inner(cls):
        return InstanceService.global_register(service_id, cls, *args, **kwargs)
    return inner
__all__ = [IInstanceService.__name__, InstanceService.__name__, ServiceParam.__name__, register_service.__name__, service.__name__, 'ServiceId']
if __name__ == '__main__':

    class IService:

        def print(self):
            print('service')

    @service(IService)
    class Service(IService):

        def __init__(self) -> None:
            super().__init__()

    class IService1:
        s: IService

        def print(self):
            print('service1')

    @service(IService1)
    class Service1(IService1):

        def __init__(self, s: IService=ServiceParam(IService)) -> None:
            super().__init__()
            self.s = s
    instance = InstanceService()

    class MyClass:

        def __init__(self, name: str, service: IService1=ServiceParam(IService1)) -> None:
            self.service = service
            pass
    s = instance.instance(MyClass, 'name')
    s.service.print()
    s.service.s.print()