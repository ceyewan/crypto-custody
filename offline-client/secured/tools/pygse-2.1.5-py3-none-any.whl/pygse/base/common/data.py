from abc import abstractmethod
from typing import Any, Callable, Generic, List, Tuple, TypeVar, Union
from json import dumps
from .number import parse_int, parse_int_list
T = TypeVar('T')
TValue = TypeVar('TValue')
TInput = TypeVar('TInput')

class IValidator(Generic[T]):

    @abstractmethod
    def validate(self, value: T, quiet: bool=True) -> str:
        pass

class SimpleValidator(IValidator[T]):

    def __init__(self, validator: Callable[[T], str]) -> None:
        super().__init__()
        self.validator = validator

    def validate(self, value: T, quiet: bool=True) -> str:
        try:
            err = self.validator(value)
            if err:
                raise Exception(err)
            return None
        except Exception as ex:
            if not quiet:
                raise ex
            return str(ex)

class IntValidator(IValidator[int]):

    def __init__(self, min_value: int=None, max_value: int=None, allow_empty: bool=True) -> None:
        self.min_value = min_value
        self.max_value = max_value
        self.allow_empty = allow_empty

    def validate(self, value: int, quiet: bool=True) -> str:
        try:
            if value is None and self.allow_empty:
                return None
            if not isinstance(value, int):
                t = type(value)
                n = getattr(t, '__name__', str(t))
                raise Exception(f'Type of number {value} is "{n}". An integer value is expected.')
            if self.min_value != None and value < self.min_value:
                raise Exception(f'Number {value} is out of range. The minimum value is {self.min_value}.')
            if self.max_value != None and value > self.max_value:
                raise Exception(f'Number {value} is out of range. The maximum value is {self.max_value}.')
            return None
        except Exception as ex:
            if not quiet:
                raise ex
            return str(ex)
UINT8_VALIDATOR = IntValidator(0, 255)
UINT16_VALIDATOR = IntValidator(0, 65535)
UINT32_VALIDATOR = IntValidator(0, 4294967295)
UINT64_VALIDATOR = IntValidator(0, 18446744073709551615)

class IValueConverter(Generic[TValue, TInput]):

    @abstractmethod
    def from_input(self, current_value: TValue, input_value: TInput) -> TValue:
        pass

    def test_input(self, current_value: TValue, input_value: TInput) -> Tuple[TValue, Exception]:
        try:
            return (self.from_input(current_value, input_value), None)
        except Exception as ex:
            return (None, ex)

    @abstractmethod
    def to_input(self, current_value: TValue) -> TInput:
        pass

class IntConverter(IValueConverter[int, str]):

    def __init__(self, format_string: str='{:d}') -> None:
        super().__init__()
        self.format_string = format_string or '{:d}'

    def from_input(self, current_value: int, input_value: str, silent: bool=False) -> int:
        if isinstance(input_value, str) and (not input_value.strip()):
            raise Exception('Empty Value!')
        return parse_int(input_value)

    def to_input(self, value: int) -> str:
        if value is None:
            return ''
        return self.format_string.format(value)

class IntListConverter(IValueConverter[List[int], str]):

    def __init__(self) -> None:
        super().__init__()

    def from_input(self, current_value: List[int], input_value: str) -> int:
        if not input_value:
            return None
        return parse_int_list(input_value)

    def to_input(self, value: List[int]) -> str:
        if value is None:
            return ''
        return dumps(value)

class BytesConverter(IValueConverter[bytes, str]):

    def __init__(self) -> None:
        super().__init__()

    def from_input(self, current_value: int, input_value: str, silent: bool=False) -> int:
        return bytes.fromhex(input_value.strip())

    def to_input(self, value: bytes) -> str:
        if value is None:
            return ''
        return value.hex(' ').upper()

class BytesValidator(IValidator[bytes]):

    def __init__(self, min_size: int=None, max_size: int=None) -> None:
        self.min_size = min_size
        self.max_size = max_size

    def validate(self, value: bytes, quiet: bool=True) -> str:
        if value == None:
            return None
        try:
            if not isinstance(value, bytes):
                raise Exception(f'Wrong type of value. Expecting a bytes value.')
            if self.min_size != None and len(value) < self.min_size:
                raise Exception(f'Bad length of bytes({len(value)}). Must >= {self.min_size}.')
            if self.max_size != None and len(value) > self.max_size:
                raise Exception(f'Bad length of bytes({len(value)}). Must <= {self.max_size}.')
            return None
        except Exception as ex:
            if not quiet:
                raise ex
            return str(ex)

class IntListValidator(IValidator[List[int]]):

    def __init__(self, validators: List[IntValidator]) -> None:
        self.validators = validators

    def validate(self, value: List[int], quiet: bool=True) -> str:
        if not value:
            return None
        try:
            if not isinstance(value, list):
                raise Exception(f'Wrong type of value. Expecting a array with {len(self.validators)} elements.')
            if len(value) != len(self.validators):
                raise Exception(f'Length of array is not match, expect {len(self.validators)} elements, got {len(value)}.')
            ret = []
            for (i, v) in enumerate(value):
                r = self.validators[i].validate(v)
                if r:
                    ret.append(r)
            err = '\n'.join(ret)
            if err:
                raise Exception(err)
            return None
        except Exception as ex:
            if not quiet:
                raise ex
            return str(ex)
INT_CONVERTER = IntConverter()
INT_CONVERTER_HEX = IntConverter('0x{:X}')
INT_LIST_CONVERTER = IntListConverter()
BYTES_CONVERTER = BytesConverter()

class SimpleValueConverter(IValueConverter[TValue, TInput]):

    def __init__(self, prop: Union[property, str]) -> None:
        super().__init__()
        if isinstance(prop, property):
            self.prop_name = prop.fget.__name__
            self.prop = prop
        else:
            self.prop_name = prop
            self.prop = property(lambda o: getattr(o, self.prop_name), lambda o, v: setattr(o, self.prop_name, v))

    @abstractmethod
    def to_input(self, current_value: TValue) -> TInput:
        pass

    @abstractmethod
    def from_input(self, current_value: TValue, input_value: TInput) -> TValue:
        pass