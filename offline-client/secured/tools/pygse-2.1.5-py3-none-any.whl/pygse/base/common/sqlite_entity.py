import logging
import os
import sqlite3
from contextlib import contextmanager
from typing import Any, Callable, Dict, Generic, List, Tuple, Type, TypeVar, Literal, Protocol, Union, runtime_checkable
from datetime import datetime
from .collections import find
from uuid import uuid4
T = TypeVar('T')
SQLITE3_DATA_TYPE = Literal['INT', 'INTEGER', 'TINYINT', 'SMALLINT', 'MEDIUMINT', 'BIGINT', 'UNSIGNED BIG INT', 'INT2', 'INT8', 'TEXT', 'CLOB', 'BLOB', 'REAL', 'DOUBLE', 'DOUBLE PRECISION', 'FLOAT', 'NUMERIC', 'DECIMAL', 'BOOLEAN', 'DATE', 'DATETIME']

def table(name: str=None):

    def inner(cls):
        if name:
            cls.__table_name__ = name
        return cls
    return inner
FOREIGN_KEY_CHANGE_REACTIONS = Literal['NO ACTION', 'SET NULL', 'SET DEFAULT', 'SET DEFAULT', 'CASCADE', 'RESTRICT']
FOREIGN_KEY_MATCH_REACTIONS = Literal['SIMPLE', 'FULL', 'PARTIAL']

@runtime_checkable
class ITableClass(Protocol):
    __table_name__: str

@runtime_checkable
class IColumn(Protocol):
    column_name: str

class ForeignKey:
    local_column: str
    foreign_table: str
    foreign_column: str
    on_delete: FOREIGN_KEY_CHANGE_REACTIONS = None
    on_update: FOREIGN_KEY_CHANGE_REACTIONS = None
    match: FOREIGN_KEY_MATCH_REACTIONS = None

    def __init__(self, local_column: str, foreign_table: Union[str, Type[ITableClass]], foreign_column: Union[str, IColumn]='id', on_delete: FOREIGN_KEY_CHANGE_REACTIONS='CASCADE', on_update: FOREIGN_KEY_CHANGE_REACTIONS='CASCADE', match: FOREIGN_KEY_MATCH_REACTIONS=None) -> None:
        self.local_column = local_column
        self.foreign_table = foreign_table if isinstance(foreign_table, str) else foreign_table.__table_name__
        self.foreign_column = foreign_column if isinstance(foreign_column, str) else foreign_column.column_name
        self.on_delete = on_delete
        self.on_update = on_update
        self.match = match

    @property
    def foreign_key_spec(self):
        spec = [f'FOREIGN KEY ({self.local_column}) REFERENCES {self.foreign_table} ({self.foreign_column})']
        if self.on_delete:
            spec.append(f'ON DELETE {self.on_delete}')
        if self.on_update:
            spec.append(f'ON UPDATE {self.on_update}')
        if self.match:
            spec.append(f'MATCH {self.on_match}')
        return ' '.join(spec)

class navigation_property:
    local_column: str = None
    reference_table: Union[str, ITableClass] = None
    reference_column: Union[str, IColumn] = None
    relationship_type: Literal['1', '*'] = None

    def __init__(self, local_column: str=None, reference_table: Union[str, ITableClass]=None, reference_column: Union[str, IColumn]=None, relationship_type: Literal['1-1', '1-*']=None) -> None:
        self.local_column = local_column
        if reference_table:
            self.reference_table = reference_table if isinstance(reference_table, str) else reference_table.__table_name__
        if reference_column:
            self.reference_column = reference_column if isinstance(reference_column, str) else reference_column.column_name
        self.relationship_type = relationship_type

    def __call__(self, fget) -> 'column':
        self.fget = fget
        return self

    def __get__(self, obj, owner):
        if obj is None:
            return self
        return obj.__dict__.get(self.name, None)

    def __set__(self, obj: object, value) -> None:
        if obj is None:
            return value
        obj.__dict__[self.name] = value

    def __set_name__(self, owner: object, name: str):
        self.owner = owner
        self.name = name

    @staticmethod
    def enum_properties(cls) -> List['navigation_property']:
        return [prop for (name, prop) in cls.__dict__.items() if isinstance(prop, navigation_property)]

class column:
    type: SQLITE3_DATA_TYPE

    def __init__(self, type: SQLITE3_DATA_TYPE, primary_key: bool=None, autoincrement: bool=None, not_null: bool=None, default_value: Union[str, int, float]=None, index: Literal['ASC', 'DESC']=None, auto_update: str=None, column_name: str=None, foreign_key: ForeignKey=None):
        self.type = type
        self.primary_key = primary_key
        self.autoincrement = autoincrement
        self.not_null = not_null
        self.default_value = default_value
        self.index = index
        self.auto_update = auto_update
        self.column_name = column_name
        if autoincrement and type not in ['INT', 'INTEGER']:
            raise Exception('autoincrement requires an INTEGER type')
        self.foreign_key = foreign_key
        if self.foreign_key:
            self.foreign_key.local_column = column_name

    def __call__(self, fget) -> 'column':
        self.fget = fget
        return self

    def __get__(self, obj, owner):
        if obj is None:
            return self
        return obj.__dict__.get(self.name, None)

    def __set__(self, obj: object, value) -> None:
        if obj is None:
            return value
        obj.__dict__[self.name] = value

    def __set_name__(self, owner: object, name: str):
        self.owner = owner
        self.name = name
        self.column_name = self.column_name or name
        if self.foreign_key:
            self.foreign_key.local_column = self.column_name

    def __str__(self) -> str:
        return self.column_name

    @property
    def column_spec(self):
        spec = [self.column_name, self.type]
        if self.primary_key:
            spec.append('PRIMARY KEY')
        if self.autoincrement:
            spec.append('AUTOINCREMENT')
        if self.not_null:
            spec.append('NOT NULL')
        if self.default_value != None:
            if self.type == 'BLOB' or (self.type == 'CLOB' and isinstance(self.default_value, (bytes, bytearray))):
                spec.append(f"DEFAULT (x'{hex(self.default_value)}')")
            else:
                spec.append(f'DEFAULT ({self.default_value})')
        return ' '.join(spec)

    @property
    def index_spec(self):
        if self.index:
            return f'{self.column_name} {self.index}'
        else:
            return ''

    @property
    def auto_update_spec(self):
        if self.auto_update:
            return f'{self.column_name} = {self.auto_update}'
        else:
            return ''

    @staticmethod
    def enum_columns(cls) -> List['column']:
        return [prop for (name, prop) in cls.__dict__.items() if isinstance(prop, column)]

class identity(column):

    def __init__(self, column_name: Union[str, Callable[[], T]]=None, autoincrement: bool=True):
        super().__init__('INTEGER', True, autoincrement, True, None, 'ASC', None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner) -> T:
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class uuid(column):

    def __init__(self, column_name: Union[str, Callable[[], T]]=None, primary_key: bool=False, not_null: bool=True, index: Literal['ASC', 'DESC']=None):
        super().__init__('BLOB(16)', primary_key, None, not_null, None, index, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner) -> T:
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class text(column):

    def __init__(self, column_name: Union[str, Callable]=None, type: SQLITE3_DATA_TYPE='TEXT', primary_key: bool=None, not_null: bool=None, default_value: Union[str, int, float]=None, index: Literal['ASC', 'DESC']=None):
        super().__init__(type, primary_key, None, not_null, default_value, index, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class blob(column):

    def __init__(self, column_name: Union[str, Callable]=None, type: SQLITE3_DATA_TYPE='BLOB', primary_key: bool=None, not_null: bool=None, default_value: Union[str, int, float]=None, index: Literal['ASC', 'DESC']=None):
        super().__init__(type, primary_key, None, not_null, default_value, index, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class integer(column):

    def __init__(self, column_name: Union[str, Callable]=None, type: SQLITE3_DATA_TYPE='INTEGER', primary_key: bool=None, autoincrement: bool=None, not_null: bool=None, default_value: Union[str, int, float]=None, index: Literal['ASC', 'DESC']=None):
        super().__init__(type, primary_key, autoincrement, not_null, default_value, index, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class boolean(column):

    def __init__(self, column_name: Union[str, Callable]=None, type: SQLITE3_DATA_TYPE='BOOLEAN', not_null: bool=None, default_value: Union[str, int, float]=None):
        super().__init__(type, None, None, not_null, default_value, None, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class decimal(column):

    def __init__(self, column_name: Union[str, Callable]=None, type: SQLITE3_DATA_TYPE='DECIMAL', primary_key: bool=None, autoincrement: bool=None, not_null: bool=None, default_value: Union[str, int, float]=None, index: Literal['ASC', 'DESC']=None):
        super().__init__(type, primary_key, autoincrement, not_null, default_value, index, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class double(column):

    def __init__(self, column_name: Union[str, Callable]=None, type: SQLITE3_DATA_TYPE='FLOAT', not_null: bool=None, default_value: Union[str, int, float]=None, index: Literal['ASC', 'DESC']=None):
        super().__init__(type, None, None, not_null, default_value, index, None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

class date_time(column):

    def __init__(self, column_name: Union[str, Callable]=None, auto_update: bool=False, not_null: bool=None, default_value: Union[str, int, float]="DATETIME(CURRENT_TIMESTAMP, 'localtime')", index: Literal['ASC', 'DESC']=None):
        super().__init__('DATETIME', None, None, not_null, default_value, index, "DATETIME(CURRENT_TIMESTAMP, 'localtime')" if auto_update else None, column_name if isinstance(column_name, str) else None)

    def __get__(self, obj, owner):
        return super().__get__(obj, owner)

    def __set__(self, obj: object, value) -> None:
        return super().__set__(obj, value)

def add_foreign_key(local_table: ITableClass, local_column: column, local_navigation_property: navigation_property, foreign_table: ITableClass, foreign_column: column, foreign_navigation_property: navigation_property, on_delete: FOREIGN_KEY_CHANGE_REACTIONS='CASCADE', on_update: FOREIGN_KEY_CHANGE_REACTIONS='CASCADE', match: FOREIGN_KEY_MATCH_REACTIONS=None):
    local_column.foreign_key = ForeignKey(local_column.column_name, foreign_table, foreign_column, on_delete, on_update, match)
    if local_navigation_property:
        local_navigation_property.local_column = local_column.column_name
        local_navigation_property.reference_table = foreign_table.__table_name__
        local_navigation_property.reference_column = foreign_column.column_name
        local_navigation_property.relationship_type = '1'
    if foreign_navigation_property:
        foreign_navigation_property.local_column = foreign_column.column_name
        foreign_navigation_property.reference_table = local_table.__table_name__
        foreign_navigation_property.reference_column = local_column.column_name
        foreign_navigation_property.relationship_type = '*'

class DataTable(Generic[T]):
    columns_map: Dict[str, column]

    def __init__(self, connection: sqlite3.Connection, row_cls: Type[T], entity: 'Entity'):
        self.entity = entity
        self.connection = connection
        self.row_cls = row_cls
        self.columns = column.enum_columns(self.row_cls)
        if not self.columns:
            raise Exception(f'No columns spec in {self.row_cls}')
        self.columns_map: Dict[str, column] = dict([(c.column_name, c) for c in self.columns])
        self.primary_column = find(self.columns, lambda c: c.primary_key)
        if not self.primary_column:
            raise Exception('必须有一个主键列！')
        self.foreign_keys = [c.foreign_key for c in self.columns if c.foreign_key]
        self.navigation_properties = navigation_property.enum_properties(self.row_cls)
        self.table_name = getattr(self.row_cls, '__table_name__', self.row_cls.__name__)
        self.logger = logging.getLogger(__name__)

    def create_table(self):
        columns_spec = [c.column_spec for c in self.columns]
        indexes_spec = [c.index_spec for c in self.columns if c.index]
        auto_update_spec = [c.auto_update_spec for c in self.columns if c.auto_update]
        foreign_key_spec = [f.foreign_key_spec for f in self.foreign_keys]
        sql = [f"CREATE TABLE IF NOT EXISTS {self.table_name} ({', '.join(columns_spec + foreign_key_spec)})"]
        if indexes_spec:
            sql.append(f'''CREATE INDEX IF NOT EXISTS "{self.table_name}_index" ON {self.table_name} ({', '.join(indexes_spec)})''')
        if auto_update_spec and self.primary_column:
            update_on_columns = [c.column_name for c in self.columns if c.column_spec != auto_update_spec]
            if update_on_columns:
                sql.append(f'''\nCREATE TRIGGER IF NOT EXISTS "{self.table_name}_update_trigger"\nAFTER UPDATE OF {', '.join(update_on_columns)}\n             ON {self.table_name}\nFOR EACH ROW\nBEGIN\n    UPDATE {self.table_name} SET {', '.join(auto_update_spec)} WHERE {self.primary_column.column_name} = NEW.{self.primary_column.column_name};\nEND'''.strip())
        script = ';\n\n'.join(sql)
        self.logger.debug(f'create table: \n{script};')
        self.connection.executescript(script)

    def insert(self, objects: Union[T, List[T]]) -> int:
        if not objects:
            return
        obj = objects if isinstance(objects, list) else [objects]
        columns = [c for c in self.columns if not c.autoincrement]
        for o in obj:
            col = []
            param = []
            if isinstance(self.primary_column, uuid) and (not getattr(o, self.primary_column.name)):
                setattr(o, self.primary_column.name, uuid4().bytes)
            for c in columns:
                v = getattr(o, c.column_name)
                if v == None and c.default_value != None:
                    continue
                col.append(c.column_name)
                param.append(v)
            sql = f"INSERT INTO {self.table_name} ({', '.join(col)}) VALUES ({', '.join('?' * len(col))})"
            self.logger.debug(f'execute: {sql}')
            cursor = self.connection.execute(sql, param)
            if self.primary_column and isinstance(self.primary_column, identity) and cursor.lastrowid:
                setattr(o, self.primary_column.name, cursor.lastrowid)
        return cursor.lastrowid

    def select(self, where: str, parameters: Union[Tuple[Any], List[Any], Dict[str, Any]]=None, order_by: str=None, skip: int=None, take: int=None, fetch_navigation_property: Literal['FIRST', 'DESCENDANT']=None) -> List[T]:
        sql_parts = [f'SELECT * FROM {self.table_name}']
        if where:
            sql_parts.append(f'WHERE {where}')
        if order_by:
            sql_parts.append(f'ORDER BY {order_by}')
        if take:
            sql_parts.append(f'LIMIT {take}')
        if skip:
            sql_parts.append(f'OFFSET {skip}')
        sql = ' '.join(sql_parts)
        self.logger.debug(f'execute: {sql}')
        cursor = self.connection.execute(sql, parameters or [])
        rows: List[sqlite3.Row] = cursor.fetchall()
        columns = [self.columns_map[desc[0]] for desc in cursor.description]
        objs = []
        for row in rows:
            obj = self.row_cls()
            for (col, v) in zip(columns, row):
                if col.type == 'DATETIME' or col.type == 'DATE':
                    v = datetime.fromisoformat(v)
                setattr(obj, col.name, v)
            if fetch_navigation_property:
                for nav_prop in self.navigation_properties:
                    foreign_table = self.entity.get_table(nav_prop.reference_table)
                    if nav_prop.relationship_type == '*':
                        nav_value = foreign_table.select(f'{nav_prop.reference_column} = ?', [getattr(obj, self.columns_map[nav_prop.local_column].name, None)], fetch_navigation_property='DESCENDANT' if fetch_navigation_property == 'DESCENDANT' else None)
                    elif nav_prop.relationship_type == '1':
                        nav_value = foreign_table.select_one(f'{nav_prop.reference_column} = ?', [getattr(obj, self.columns_map[nav_prop.local_column].name, None)], fetch_navigation_property='DESCENDANT' if fetch_navigation_property == 'DESCENDANT' else None)
                    setattr(obj, nav_prop.name, nav_value)
            objs.append(obj)
        return objs

    def select_one(self, where: str, parameters: Tuple[Any]=[], order_by: str=None, fetch_navigation_property: Literal['FIRST', 'DESCENDANT']=None) -> Union[T, None]:
        ret = self.select(where, parameters, order_by, 0, 1, fetch_navigation_property)
        return ret[0] if ret else None

    def select_by_id(self, id: Union[bytes, int, str], fetch_navigation_property: Literal['FIRST', 'DESCENDANT']=None) -> Union[T, None]:
        return self.select_one(f'{self.primary_column} = ?', [id], fetch_navigation_property=fetch_navigation_property)

    def update(self, objects: Union[T, List[T]]):
        if not objects:
            return
        obj = objects if isinstance(objects, list) else [objects]
        columns = [c for c in self.columns if not c.primary_key and (not c.autoincrement)]
        updated = 0
        for o in obj:
            primary_value = getattr(o, self.primary_column.column_name)
            if primary_value == None:
                raise Exception(f'无法更新没有主键属性值的对象！')
            col = []
            param = []
            for c in columns:
                v = getattr(o, c.column_name)
                if v == None and c.default_value:
                    continue
                col.append(f'{c.column_name} = ?')
                param.append(v)
            sql = f"UPDATE {self.table_name} SET {', '.join(col)} WHERE {self.primary_column} = {primary_value}"
            self.logger.debug(f'execute: {sql}')
            cursor = self.connection.execute(sql, param)
            updated += cursor.rowcount
        return updated

    def update_many(self, columns: List[str], values: List[Any], where: str, parameters: Union[Tuple[Any], List[Any], Dict[str, Any]]=None) -> int:
        raise NotImplementedError()

    def delete(self, objects: Union[T, List[T], int, List[int]]) -> int:
        objects = objects if isinstance(objects, list) else [objects]
        ids = [o if isinstance(o, int) else getattr(o, self.primary_column.name) for o in objects]
        cursor = self.connection.cursor()
        sql = f"DELETE FROM {self.table_name} WHERE {self.primary_column} IN ({', '.join('?' * len(ids))})"
        self.logger.debug(f'execute: {sql}')
        cursor.execute(sql, ids)
        return cursor.rowcount

    def delete_many(self, where: str, parameters: Union[Tuple[Any], List[Any], Dict[str, Any]]=None) -> int:
        cursor = self.connection.cursor()
        sql = f'DELETE FROM {self.table_name} WHERE {where}'
        self.logger.debug(f'execute: {sql}')
        cursor.execute(sql, parameters)
        return cursor.rowcount

    def exists(self, id: Union[str, int]) -> bool:
        cursor = self.connection.cursor()
        sql = f'SELECT 1 FROM {self.table_name} WHERE {self.primary_column} = ?'
        self.logger.debug(f'execute: {sql}')
        cursor.execute(sql, (id,))
        row = cursor.fetchone()
        return row is not None

class Entity:
    tables: Dict[str, DataTable]

    def __init__(self, file: str, foreign_keys: Literal['ON', 'OFF']='ON', journal_mode: Literal['DELETE', 'TRUNCATE', 'PERSIST', 'MEMORY', 'WAL', 'OFF']='WAL', synchronous: Literal['ON', 'OFF']='OFF', cache_size: int=5000):
        self.tables = {}
        self.file = file
        if file != ':memory:':
            if not os.path.exists(os.path.dirname(file)):
                os.makedirs(os.path.dirname(file), exist_ok=True)
        self.connection = sqlite3.connect(self.file)
        for (cfg, value) in [('foreign_keys', foreign_keys), ('journal_mode', journal_mode), ('synchronous', synchronous), ('cache_size', cache_size)]:
            if value:
                self.connection.execute(f'PRAGMA {cfg}={value}')

    def register_table(self, cls: Type[T]) -> DataTable[T]:
        dt = DataTable(self.connection, cls, self)
        self.tables[getattr(cls, '__table_name__', cls.__name__)] = dt
        return dt

    def get_table(self, name: str) -> 'DataTable[T]':
        if name in self.tables:
            return self.tables[name]
        raise Exception(f'DataTable {name} is not registered!')

    def create_tables(self):
        table_deps: Dict[str, List[str]] = {n: [fk.foreign_table for fk in t.foreign_keys] for (n, t) in self.tables.items()}
        table_order = []
        while len(table_order) < len(table_deps):
            for (table, dependencies) in table_deps.items():
                if table in table_order:
                    continue
                if all((dep in table_order for dep in dependencies)):
                    table_order.append(table)
        for table in table_order:
            self.get_table(table).create_table()

    @contextmanager
    def transaction(self):
        conn = self.connection
        cursor = conn.cursor()
        try:
            conn.execute('BEGIN')
            yield cursor
            conn.commit()
        except Exception as e:
            print(f'Transaction failed: {e}')
            conn.rollback()
        finally:
            cursor.close()

@contextmanager
def transaction(conn: sqlite3.Connection):
    cursor = conn.cursor()
    try:
        yield cursor
        conn.commit()
    except sqlite3.Error:
        conn.rollback()
    finally:
        cursor.close()

@table('sample')
class Sample:

    @identity
    def id(self) -> int:
        pass

    @text
    def name(self) -> str:
        pass

    @integer
    def age(self) -> int:
        pass

    @double
    def star(self) -> float:
        pass

    @decimal
    def money(self) -> float:
        pass

    @date_time
    def born(self) -> datetime:
        pass

    @date_time(auto_update=True)
    def update_time(self) -> datetime:
        pass

    def __init__(self, name=None, age=None, born=None):
        self.name = name
        self.age = age
        self.born = born

class SampleEntity(Entity):

    def __init__(self):
        super().__init__(':memory:')
        self.samples = DataTable(self.connection, Sample)

def test_sample():
    from time import sleep
    entity = SampleEntity()
    sample = Sample('shit', 10)
    entity.samples.insert(sample)
    sample.age = 100
    sample.star = 100.0
    sample.money = 100.1
    sleep(1)
    entity.samples.update(sample)
    a = entity.samples.select_one(f'{Sample.age} = ?', [sample.age])
    print(a.__dict__)
    b = entity.samples.select_by_id(sample.id)
    print(b.__dict__)
__all__ = ['SQLITE3_DATA_TYPE', navigation_property.__name__, table.__name__, column.__name__, boolean.__name__, identity.__name__, uuid.__name__, text.__name__, integer.__name__, decimal.__name__, double.__name__, date_time.__name__, ForeignKey.__name__, DataTable.__name__, Entity.__name__, add_foreign_key.__name__]