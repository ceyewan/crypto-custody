from openpyxl import load_workbook, Workbook
from openpyxl.cell import Cell, MergedCell
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.worksheet.cell_range import CellRange

class SafeWorkbook:

    def __init__(self, book: Workbook) -> None:
        self.book = book

    def __enter__(self):
        return self.book

    def __exit__(self, exc_type, exc_value, traceback):
        self.book.close()

def open_workbook(filename: str, read_only=False, data_only=False, keep_links=True):
    return SafeWorkbook(load_workbook(filename, read_only=read_only, data_only=data_only, keep_links=keep_links))

def __pack():
    if not hasattr(MergedCell, 'value') or not isinstance(MergedCell.value, property):

        def get_cell_value(self_: MergedCell):
            if isinstance(self_, MergedCell):
                sheet: Worksheet = self_.parent
                my_range = CellRange(min_col=self_.column, min_row=self_.row, max_col=self_.column, max_row=self_.row)
                for r in sheet.merged_cells.ranges:
                    if r.issuperset(my_range):
                        return sheet.cell(r.min_row, r.min_col).value
            else:
                return self_.value
            return None

        def set_cell_value(self_: MergedCell, v):
            if isinstance(self_, MergedCell):
                sheet: Worksheet = self_.parent
                my_range = CellRange(min_col=self_.column, min_row=self_.row, max_col=self_.column, max_row=self_.row)
                for r in sheet.merged_cells.ranges:
                    if r.issuperset(my_range):
                        sheet.cell(r.min_row, r.min_col, v)
            else:
                self_.value = v
        MergedCell.value = property(get_cell_value, set_cell_value)
__pack()