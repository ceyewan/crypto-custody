import sys
import io
import json
from typing import Callable, Dict, Generic, Iterable, List, Literal, Protocol, SupportsBytes, SupportsIndex, Tuple, TypeVar, Union, overload, runtime_checkable
SEEK_SET = io.SEEK_SET
SEEK_CUR = io.SEEK_CUR
SEEK_END = io.SEEK_END
if sys.version_info >= (3, 12):
    from collections.abc import Buffer as Buffer
else:

    @runtime_checkable
    class Buffer(Protocol):

        def __buffer__(self, __flags: int) -> memoryview:
            ...

        def __bytes__(self) -> bytes:
            ...

def to_bytes(data: Union[int, str, bytes, bytearray, Union[Iterable[SupportsIndex], SupportsIndex, SupportsBytes, Buffer]]) -> bytes:
    if isinstance(data, bytes):
        return data
    if isinstance(data, str):
        return bytes.fromhex(data)
    if isinstance(data, int):
        return data.to_bytes(max((data.bit_length() + 7) // 8, 1), 'big')
    if data == None:
        return None
    return bytes(data) if data else bytes()

def to_aid(data: Union[int, str, bytes, bytearray, Union[Iterable[SupportsIndex], SupportsIndex, SupportsBytes, Buffer]]) -> bytes:
    if data == '.':
        return b'.'
    aid = to_bytes(data)
    if not aid or 5 <= len(aid) <= 16:
        return aid
    raise Exception(f'Invalid AID: {data}.')

def read_int(stream: io.BytesIO, length: int, byteorder: Literal['big', 'little']='little') -> int:
    return int.from_bytes(stream.read(length), byteorder)

def write_int(stream: io.BytesIO, value: int, length: int, byteorder: Literal['big', 'little']='little'):
    stream.write(value.to_bytes(length, byteorder))

def tlv_tag_to_bytes(tag: int):
    if tag < 128:
        return tag.to_bytes(1, byteorder='big')
    else:
        tag_bytes = []
        while tag > 0:
            tag_bytes.insert(0, tag & 127 | 128)
            tag >>= 7
        tag_bytes[-1] &= 127
        return bytes(tag_bytes)

def tlv_length_to_bytes(length: int):
    if length < 128:
        return length.to_bytes(1, byteorder='big')
    else:
        num_bytes = max((length.bit_length() + 7) // 8, 1)
        return (128 | num_bytes).to_bytes(1, byteorder='big') + length.to_bytes(num_bytes, byteorder='big')

def dgi_length_to_bytes(length: int):
    if length < 255:
        return bytes([length])
    else:
        num_bytes = max((length.bit_length() + 7) // 8, 2)
        return length.to_bytes(num_bytes, byteorder='big')

class BytesIO(io.BytesIO):

    @staticmethod
    def create(data: Union[str, bytes, 'BytesIO']) -> 'BytesIO':
        if isinstance(data, BytesIO):
            return data
        if isinstance(data, str):
            data = bytes.fromhex(data)
        return BytesIO(data)

    def __init__(self, initial_bytes: Union[bytes, bytearray, str]=None) -> None:
        super().__init__(bytes.fromhex(initial_bytes) if isinstance(initial_bytes, str) else initial_bytes)

    @property
    def length(self):
        return self.getbuffer().nbytes

    def read_byte(self, signed: bool=False) -> int:
        return self.read_int(1, 'big', signed)

    def read_int(self, length: int, byteorder: Literal['big', 'little']='little', signed: bool=False) -> int:
        data = self.read(length)
        if data:
            return int.from_bytes(data, byteorder, signed=signed)
        return None

    def write(self, buffer: Buffer) -> int:
        if buffer == None:
            return 0
        super().write(buffer)

    def write_int(self, value: int, length: int, byteorder: Literal['big', 'little']='little', signed: bool=False):
        self.write(value.to_bytes(length, byteorder, signed=signed))

    def write_byte(self, value: int, signed: bool=False):
        self.write_int(value, 1, 'big', signed)

    def write_lv(self, value: Union[bytes, int, str]):
        if value == None:
            self.write_byte(0)
            return
        value = to_bytes(value)
        self.write(tlv_length_to_bytes(len(value)))
        self.write(value)

    def write_tlv(self, encoded_tag: int, value: Union[bytes, int, str], unencoded_tag: int=None) -> None:
        if encoded_tag == None and unencoded_tag == None:
            raise Exception('A tag parameter must given!')
        if encoded_tag != None and unencoded_tag != None:
            raise Exception('Both encoded_tag and encoded_tag parameters are given!')
        self.write(to_bytes(encoded_tag) if encoded_tag else tlv_tag_to_bytes(unencoded_tag))
        if value == None:
            self.write_byte(0)
            return
        value = to_bytes(value)
        self.write(tlv_length_to_bytes(len(value)))
        self.write(value)

    def write_dgi(self, dgi_tag: int, value: Union[bytes, int]):
        self.write_int(dgi_tag, 2, 'big')
        value = to_bytes(value)
        self.write(dgi_length_to_bytes(len(value)))
        self.write(value)

    def read_dgi_tag(self, pos: int=None, whence: int=SEEK_CUR):
        if pos != None:
            self.seek(pos, whence)
        return self.read_int(2, 'big')

    def read_dgi_length(self, pos: int=None, whence: int=SEEK_CUR):
        if pos != None:
            self.seek(pos, whence)
        value = self.read_byte()
        if value < 255:
            return value
        else:
            return self.read_int(2, 'big')

    def peek_dgi_tag(self, pos: int=None, whence: int=SEEK_CUR) -> int:
        revert = self.tell()
        try:
            return self.read_dgi_tag(pos, whence)
        except:
            raise
        finally:
            self.seek(revert, io.SEEK_SET)

    def peek_dgi_length(self, pos: int=None, whence: int=SEEK_CUR) -> int:
        revert = self.tell()
        try:
            return self.read_dgi_length(pos, whence)
        except:
            raise
        finally:
            self.seek(revert, io.SEEK_SET)

    def read_tlv_tag(self, pos: int=None, whence: int=SEEK_CUR, tag_value_only: bool=False) -> int:
        if pos != None:
            self.seek(pos, whence)
        tag = b = self.read_byte()
        tag_value = b & 15
        if tag_value < 15:
            return tag_value if tag_value_only else tag
        b = self.read_byte()
        tag = (tag << 8) + b
        tag_value = b & 127
        while b & 128 == 128:
            b = self.read_byte()
            tag = (tag << 8) + b
            tag_value = (tag_value << 7) + (b & 127)
        return tag_value if tag_value_only else tag

    def read_tlv_length(self, pos: int=None, whence: int=SEEK_CUR) -> int:
        if pos != None:
            self.seek(pos, whence)
        length = self.read_byte()
        if length == 128:
            raise Exception('不定长的TLV暂时不支持')
        return length if length < 128 else self.read_int(length & 127, 'big')

    def peek_tlv_length(self, pos: int=None, whence: int=SEEK_CUR) -> int:
        revert = self.tell()
        try:
            return self.read_tlv_length(pos, whence)
        except:
            raise
        finally:
            self.seek(revert, io.SEEK_SET)

    def peek_tlv_tag(self, pos: int=None, whence: int=SEEK_CUR, tag_value_only: bool=False) -> int:
        revert = self.tell()
        try:
            return self.read_tlv_tag(pos, whence, tag_value_only)
        except:
            raise
        finally:
            self.seek(revert, io.SEEK_SET)

    def peek_int(self, length: int=1, byteorder: Literal['big', 'little']='little', pos: int=None, whence: int=SEEK_CUR, signed: bool=False) -> int:
        revert = self.tell()
        if pos is not None:
            self.seek(pos, whence)
        data = self.read_int(length, byteorder, signed)
        self.seek(revert, io.SEEK_SET)
        return data

    def peek(self, size: int=1, pos: int=None, whence: int=SEEK_CUR) -> bytes:
        revert = self.tell()
        if pos is not None:
            self.seek(pos, whence)
        data = self.read(size)
        self.seek(revert, io.SEEK_SET)
        return data

    def at_end(self):
        current = self.tell()
        end = self.seek(0, io.SEEK_END)
        self.seek(current, io.SEEK_SET)
        return current == end

    def insert(self, pos: int, data: bytes):
        self.seek(pos, 0)
        buf = self.read()
        self.seek(pos, 0)
        self.write(data)
        self.write(buf)

    def adjust_wrote_length(self, length_pos: int, end_pos: int=None, length_size: int=1, byteorder: Literal['big', 'little']='little', length_converter: Callable[[int], int]=None) -> int:
        current_pos = self.tell()
        end_pos = end_pos or current_pos
        length = end_pos - length_pos - length_size
        if length < 0:
            return length
        self.seek(length_pos, 0)
        self.write_int(length_converter(length) if length_converter else length, length_size, byteorder)
        self.seek(current_pos, 0)
        return length

    def write_padding(self, padding: int, fill_chars: Union[bytes, bytearray]=None):
        p = self.tell() % padding
        if p:
            fill = padding - p
            fill_chars = fill_chars or bytes(fill)
            if len(fill_chars) != fill:
                fill_chars = fill_chars.ljust(fill, fill_chars)
            return self.write(fill_chars)
        return 0

    def truncate(self, size: int=None) -> int:
        ret = super().truncate(size)
        if ret > self.length or self.tell() > ret:
            return self.seek(0, SEEK_END)
        return ret

    def clone(self) -> 'BytesIO':
        copy = BytesIO(self.getbuffer())
        copy.seek(self.tell())
        return copy

def right_padding(data: bytes, padding: int, fill_chars: Union[bytes, bytearray]=None) -> bytes:
    p = len(data) % padding
    if p:
        return data.ljust(len(data) + padding - p, fill_chars or bytes(1))
    return data

def left_padding(data: bytes, padding: int, fill_chars: Union[bytes, bytearray]=None) -> bytes:
    p = len(data) % padding
    if p:
        return data.rjust(len(data) + padding - p, fill_chars or bytes(1))
    return data

@overload
def read_file(file: str) -> bytes:
    pass

@overload
def read_file(file: str, encoding: str) -> str:
    pass

def read_file(file: str, encoding: str=None):
    with open(file, 'r', encoding=encoding) as f:
        return f.read()

def read_json(file: str, encoding: str='utf8'):
    with open(file, 'r', encoding=encoding) as f:
        return json.load(f)
__all__ = [to_bytes.__name__, to_aid.__name__, read_int.__name__, write_int.__name__, BytesIO.__name__, right_padding.__name__, left_padding.__name__, read_file.__name__, read_json.__name__]