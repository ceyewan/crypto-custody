import io
from typing import Literal, Union
from serial import Serial
from enum import IntEnum

class StopBits(IntEnum):
    BITS_1 = 1
    BITS_1_5 = 1.5
    BITS_2 = 2

class SerialIO(io.RawIOBase):

    def __init__(self, port: str, baudrate: int=460800, bytesize: Literal[5, 6, 7, 8]=8, parity: Literal['N', 'E', 'O', 'M', 'S']='N', stopbits: Union[StopBits, float]=1, timeout: float=None, xonxoff: bool=False, rtscts: bool=False, write_timeout: float=None, dsrdtr: bool=False, inter_byte_timeout: float=None, exclusive: float=None) -> None:
        super().__init__()
        self.name = port
        self.serial = Serial(port, baudrate, bytesize, parity, stopbits, timeout, xonxoff, rtscts, write_timeout, dsrdtr, inter_byte_timeout, exclusive)

    def readinto(self, b):
        data = self.serial.read(len(b))
        b[:len(data)] = data
        return len(data)

    def write(self, b):
        return self.serial.write(b)

    def close(self) -> None:
        self.serial.close()
        return super().close()
__all__ = [StopBits.__name__, SerialIO.__name__]