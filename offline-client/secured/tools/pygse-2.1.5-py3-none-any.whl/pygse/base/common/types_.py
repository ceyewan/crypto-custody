from types import FunctionType

def is_function(o) -> bool:
    return isinstance(o, FunctionType) or type(o).__name__ == 'cython_function_or_method'

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
    try:
        int(s)
        return True
    except ValueError:
        pass
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
    return False

class SafeNamespace:

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def __getattr__(self, name):
        return None
__all__ = ['is_function', 'is_number', 'SafeNamespace']