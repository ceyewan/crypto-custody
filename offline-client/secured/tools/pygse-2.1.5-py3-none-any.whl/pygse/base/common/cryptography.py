from ctypes import create_string_buffer
from goodix_tools.alg.Rsa import RSA_NE_Crypto, RSA_ND_Crypto
from goodix_tools.alg.Rsa_pad import ALG_SHA_512, ALG_RSA_PKCS1_OAEP, PKCS1_OAEP_EncodePadding, PKCS1_OAEP_DecodePadding
from .protecting import protected

def encrypt(bit_length: int, n: bytes, e: bytes, data: bytes) -> bytes:
    padData = PKCS1_OAEP_EncodePadding(bit_length, data, ALG_SHA_512)
    return RSA_NE_Crypto(n, e, padData)

def decrypt(bit_length: int, n: bytes, d: bytes, data: bytes) -> bytes:
    padData = RSA_ND_Crypto(n, d, data)
    return PKCS1_OAEP_DecodePadding(bit_length, padData, ALG_SHA_512)
encrypt = protected(encrypt)
decrypt = protected(decrypt)