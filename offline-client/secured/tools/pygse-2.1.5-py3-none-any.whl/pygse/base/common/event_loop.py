import asyncio
import functools
import threading
from typing import Coroutine

class CustomEventLoop:

    def __init__(self, name):
        self.name = name
        self.event_loop = asyncio.new_event_loop()
        loop_started_event = threading.Event()
        self.event_loop_thread = threading.Thread(target=self._loop_thread_proc, name=f'asyncio_{self.name}', args=(self.event_loop, loop_started_event), daemon=True)
        self.event_loop_thread.start()
        loop_started_event.wait()

    def _loop_thread_proc(self, loop: asyncio.AbstractEventLoop, loop_started_event: threading.Event):
        asyncio.set_event_loop(loop)
        loop_started_event.set()
        loop.run_forever()

    def _safe_stop_event_loop(self):
        if self.event_loop is None:
            return
        tasks = [t for t in asyncio.all_tasks(self.event_loop) if t is not asyncio.current_task(self.event_loop)]
        for task in tasks:
            task.cancel()
        try:
            asyncio.gather(*tasks, return_exceptions=True).result()
        except Exception:
            pass
        self.event_loop.stop()

    def close(self):
        if self.event_loop and self.event_loop.is_running():
            self.event_loop.call_soon_threadsafe(self._safe_stop_event_loop)
            self.event_loop_thread.join()
            self.event_loop.close()

    async def run_in_loop(self, coro: Coroutine, *args):
        if not self.event_loop or not self.event_loop.is_running():
            raise Exception(f'CustomEventLoop of {self.name} is not running!')
        fut = asyncio.run_coroutine_threadsafe(coro(*args), self.event_loop)
        return await asyncio.wrap_future(fut)

def custom_event_loop(cls):
    orig_init = cls.__init__

    def __init__(self, *args, **kwargs):
        self.event_loop = CustomEventLoop(self.__class__.__name__)
        orig_init(self, *args, **kwargs)
    cls.__init__ = __init__
    return cls

def thread_safe(func):

    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        if not hasattr(self, 'event_loop'):
            self.event_loop = CustomEventLoop(self.__class__.__name__)
        future_result = await self.event_loop.run_in_loop(func, self, *args, **kwargs)
        return future_result
    return wrapper
__all__ = [CustomEventLoop.__name__, thread_safe.__name__]