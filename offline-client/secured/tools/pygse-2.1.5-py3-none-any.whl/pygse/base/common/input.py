import logging
from typing import Callable, List, Literal, Tuple, Union
from typing import TypeVar

def input_text(prompt: str):
    return input(prompt).strip('\'" \t')

def input_int(prompt: str, empty_default: int=None) -> Union[int, None, Literal['nan']]:
    value = None
    try:
        txt = input_text(prompt).strip()
        if not txt:
            return empty_default
        value = int(txt)
    except Exception as ex:
        value = 'nan'
    return value
T = TypeVar('T')

def input_select(prompt: str, options: Union[List[T], Callable[[], List[T]]], option_label_provider: Callable[[T], str]=None, default_index: int=None) -> Tuple[T, int]:
    selected_index = -1
    while selected_index < 0:
        options_list = list(options() if callable(options) else options)
        default_idx = default_index if 0 <= default_index < len(options_list) else None
        tips = [prompt] + [f'  {i}. {(option_label_provider(v) if option_label_provider else v)}' for (i, v) in enumerate(options_list)]
        tips.append(f'  {len(options_list)}. Cancel')
        if default_idx is not None:
            tips.append(f'Input Option Number (Default {default_idx}):')
        else:
            tips.append('Input Option Number:')
        prompt_txt = '\n'.join(tips)
        selected_index = input_int(prompt_txt, default_idx)
        if selected_index == 'nan' or selected_index == None:
            selected_index = -1
        elif 0 <= selected_index < len(options_list):
            return (options_list[selected_index], selected_index)
        elif selected_index == len(options_list):
            return (None, -1)
        else:
            selected_index = -1
__all__ = [input_text.__name__, input_int.__name__, input_select.__name__]