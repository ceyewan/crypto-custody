from enum import IntEnum
import re
from typing import List, Literal, Union

def int_to_bytes(value: int, length: int=None, byteorder: Literal['little', 'big']='big', *, signed: bool=False) -> bytes:
    return value.to_bytes(length or (value.bit_length() + 7) // 8, byteorder, signed=signed)

class IntType(IntEnum):
    INT8 = 1
    INT16 = 2
    INT32 = 4
    INT64 = 8

class UIntType(IntEnum):
    UINT8 = 1
    UINT16 = 2
    UINT32 = 4
    UINT64 = 8

def parse_int(value: Union[str, int, float, bytes, bytearray]) -> int:
    if isinstance(value, int):
        return value
    elif isinstance(value, float):
        return int(value)
    elif isinstance(value, (bytes, bytearray)):
        return int.from_bytes(value)
    elif isinstance(value, str):
        value = value.strip()
    else:
        value = str(value).strip()
    if value:
        if re.match('^[\\+\\-]?\\d+$', value):
            return int(value)
        elif re.match('^[\\+\\-]?(0x)?[0-9a-f]+$', value, re.I):
            return int(value, 16)
        else:
            raise Exception(f'Invalid number of "{value}".\nThe number format like 123 or 0xABC is expected.')
    else:
        raise Exception('Empty value!')

def parse_int_list(value: str) -> List[int]:
    if not isinstance(value, str):
        raise Exception('Invalid argument type of value!')
    value = value.strip()
    if not value:
        raise Exception('Empty value!')
    if not value.startswith('[') or not value.endswith(']'):
        raise Exception('Bad format of array. An array should be quoted with "[]" and the elements are separated with ",".')
    value = value.strip('[]')
    ret = []
    for (i, p) in enumerate(map(lambda p: p.strip(), value.split(','))):
        try:
            ret.append(parse_int(p))
        except Exception as ex:
            suffix = 'st' if i == 0 else 'nd' if i == 1 else 'rd' if i == 2 else 'th'
            ex.args = ('\n'.join(ex.args + (f'At the {i + 1}{suffix} element.',)),)
            raise ex
    return ret
__all__ = [int_to_bytes.__name__, IntType.__name__, UIntType.__name__, parse_int.__name__, parse_int_list.__name__]