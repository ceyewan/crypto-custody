from enum import Enum
from itertools import zip_longest
from typing import Iterable, List, Literal, Union, overload
from rich import box
from rich.table import Table
from rich.console import Console, NULL_FILE
from rich.protocol import is_renderable
from rich.highlighter import ReprHighlighter

class TableGridType(Enum):
    ASCII = box.ASCII
    ASCII2 = box.ASCII2
    ASCII_DOUBLE_HEAD = box.ASCII_DOUBLE_HEAD
    SQUARE = box.SQUARE
    SQUARE_DOUBLE_HEAD = box.SQUARE_DOUBLE_HEAD
    MINIMAL = box.MINIMAL
    MINIMAL_HEAVY_HEAD = box.MINIMAL_HEAVY_HEAD
    MINIMAL_DOUBLE_HEAD = box.MINIMAL_DOUBLE_HEAD
    SIMPLE = box.SIMPLE
    SIMPLE_HEAD = box.SIMPLE_HEAD
    SIMPLE_HEAVY = box.SIMPLE_HEAVY
    HORIZONTALS = box.HORIZONTALS
    ROUNDED = box.ROUNDED
    HEAVY = box.HEAVY
    HEAVY_EDGE = box.HEAVY_EDGE
    HEAVY_HEAD = box.HEAVY_HEAD
    DOUBLE = box.DOUBLE
    DOUBLE_EDGE = box.DOUBLE_EDGE
    MARKDOWN = box.MARKDOWN
    SIMPLE_HEAD1 = box.Box('    \n    \n -- \n    \n    \n    \n    \n    \n')

class ReprHighlighter1(ReprHighlighter):
    base_style = 'repr.'
    highlights = ['(?P<tag_start><)(?P<tag_name>[-\\w.:|]*)(?P<tag_contents>[\\w\\W]*)(?P<tag_end>>)', '(?P<attrib_name>[\\w_]{1,50})=(?P<attrib_value>"?[\\w_]+"?)?', '(?P<brace>[][{}()])', '|'.join(['(?P<ipv4>[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})', '(?P<ipv6>([A-Fa-f0-9]{1,4}::?){1,7}[A-Fa-f0-9]{1,4})', '(?P<eui64>(?:[0-9A-Fa-f]{1,2}-){7}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{1,2}:){7}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{4}\\.){3}[0-9A-Fa-f]{4})', '(?P<eui48>(?:[0-9A-Fa-f]{1,2}-){5}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{1,2}:){5}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{4}\\.){2}[0-9A-Fa-f]{4})', '(?P<uuid>[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12})', '\\b(?P<bool_true>True)\\b|\\b(?P<bool_false>False)\\b|\\b(?P<none>None)\\b', '(?P<ellipsis>\\.\\.\\.)', '(?P<number_complex>(?<!\\w)(?:\\-?[0-9]+\\.?[0-9]*(?:e[-+]?\\d+?)?)(?:[-+](?:[0-9]+\\.?[0-9]*(?:e[-+]?\\d+)?))?j)', '(?P<number>(?<!\\w)\\-?[0-9]+\\.?[0-9]*(e[-+]?\\d+?)?\\b|0x[0-9a-fA-F]*|\\b([a-fA-F0-9]{2})+\\b)', '(?P<path>\\B(/[-\\w._+]+)*\\/)(?P<filename>[-\\w._+]*)?', '(?<![\\\\\\w])(?P<str>b?\'\'\'.*?(?<!\\\\)\'\'\'|b?\'.*?(?<!\\\\)\'|b?\\"\\"\\".*?(?<!\\\\)\\"\\"\\"|b?\\".*?(?<!\\\\)\\")', '(?P<url>(file|https|http|ws|wss)://[-0-9a-zA-Z$_+!`(),.?/;:&=%#~]*)'])]
HIGHLIGHT_CONSOLE = Console(highlighter=ReprHighlighter1())

@overload
def print_table(headers: Iterable[str], body: List[List[str]], title: str=None, justify: Literal['left', 'center', 'right', 'full']='left', footer: List[str]=None, grid: Union[TableGridType, box.Box]=None) -> str:
    pass

@overload
def print_table(headers: Iterable[str], body: List[List[str]], title: str=None, justify: Literal['left', 'center', 'right', 'full']='left', footer: List[str]=None, grid: Union[TableGridType, box.Box]=None, capture: Literal[True]=True) -> str:
    pass

def print_table(headers: Iterable[str], body: List[List[str]], title: str=None, justify: Literal['left', 'center', 'right', 'full']='left', footer: List[str]=None, grid: Union[TableGridType, box.Box]=None, capture: bool=None):
    grid = grid or TableGridType.SQUARE
    grid = grid if isinstance(grid, box.Box) else grid.value
    table = Table(title=title, box=grid, show_lines=True, show_footer=bool(footer), highlight=True)
    for (header, footer) in zip_longest(headers or [], footer or []):
        table.add_column(header or '', footer or '', overflow='fold', vertical='middle', justify=justify)
    for r in body:
        table.add_row(*[c if is_renderable(c) else str(c) for c in r])
    if capture:
        console = Console(record=True, file=NULL_FILE)
        console.print(table)
        return console.export_text()
    HIGHLIGHT_CONSOLE.print(table)
__all__ = [print_table.__name__, TableGridType.__name__]