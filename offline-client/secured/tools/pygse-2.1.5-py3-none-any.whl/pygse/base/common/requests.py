from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse
from json import dumps

async def post(url: str, json=None, data=None) -> HTTPResponse:
    http_client = AsyncHTTPClient()
    headers = None
    if json:
        headers = {'Content-Type': 'application/json'}
        body = json if isinstance(json, str) else dumps(json)
    else:
        body = data
    request = HTTPRequest(url, method='POST', headers=headers, body=body)
    return await http_client.fetch(request)
__all__ = [post.__name__]