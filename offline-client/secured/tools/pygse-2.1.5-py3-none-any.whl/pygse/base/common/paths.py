import os
import re
import sys

def join_path(path, *paths):
    return os.path.normpath(os.path.join(path, *paths))

def shell_escape(path: str):
    if not path or sys.platform == 'win32':
        return path
    special = re.escape('`!$^&*()={}[]|\\:;"\'<>,?')
    return re.sub(f'([{special}])', '\\\\\\1', path)
if __name__ == '__main__':
    input_path = '~`!@#$%^&*()_-+={}[]|\\:;"\'<>,.?.conf'
    output_path = '~\\`\\!@#\\$%\\^\\&\\*\\(\\)_-+\\=\\{\\}\\[\\]\\|\\\\\\:\\;\\"\\\'\\<\\>\\,.\\?.conf'
    assert shell_escape(input_path) == output_path, 'Fail'
    print('ok')
__all__ = [join_path.__name__, shell_escape.__name__]