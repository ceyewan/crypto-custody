def throw(msg: str):
    raise Exception(msg)

class UserCanceledException(Exception):
    pass