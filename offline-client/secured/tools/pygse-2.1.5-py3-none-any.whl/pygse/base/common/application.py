import sys
import logging
import signal
import asyncio
import asyncio.coroutines
from collections.abc import Callable
from functools import wraps
from threading import current_thread, Thread
from typing import Any, Callable, TypeVar, Coroutine
from .arguments_parser import SystemExitException
T = TypeVar('T')
Thread.__init__.__kwdefaults__['daemon'] = True

class Application:
    event_loop: asyncio.AbstractEventLoop = None

    def __init__(self, entry: Callable) -> None:
        current_thread().app = self
        self.entry = entry
        self.logger = logging.getLogger('APP')

    def run(self, *args: str):
        self.event_loop = asyncio.get_event_loop()
        if sys.platform != 'win32':
            for sig in (signal.SIGINT, signal.SIGTERM):
                signal.signal(sig, lambda sig, frame: exit(0))
        try:
            if asyncio.coroutines.iscoroutinefunction(self.entry):
                coro = self.entry
            else:

                @wraps(self.entry)
                async def wrapper(*args):
                    return self.entry(*args)
                coro = wrapper
            asyncio.run(coro(*args))
        except (TimeoutError, asyncio.TimeoutError) as e:
            self.logger.error(e)
            return -1
        except SystemExitException as e:
            return e.status
        except Exception as e:
            self.logger.error(e)
            return -1

    def run_coroutine_threadsafe(self, coro: Coroutine):
        return asyncio.run_coroutine_threadsafe(coro, self.event_loop)

    @staticmethod
    def current() -> 'Application':
        return current_thread().app

    @staticmethod
    def run_in_executor(worker: Callable[[Any], T], *args, done_callback: Callable[[T, Exception], Any]=None, executor=None):
        app = Application.current()
        if not app:
            raise Exception(f"This method must be invoked in either Application's event loop thread or Application's executor!")

        @wraps(worker)
        def wrapper(*args, **kwargs):
            current_thread().app = app
            try:
                return worker(*args, **kwargs)
            except Exception as ex:
                Application.current().logger.error(ex)
                raise ex
        future = app.event_loop.run_in_executor(executor, wrapper, *args)
        if done_callback:

            def cb(future: asyncio.Future):
                if future.exception():
                    done_callback(None, future.exception())
                else:
                    done_callback(future.result(), None)
            future.add_done_callback(cb)
        return future

    @staticmethod
    def call_soon(callback: Callable, *args):
        return Application.current().event_loop.call_soon_threadsafe(callback, *args)

    @staticmethod
    def call_later(delay: int, callback: Callable, *args):
        app = Application.current()
        if not app:
            raise Exception(f"This method must be invoked in either Application's event loop thread or Application's executor!")
        return app.event_loop.call_later(delay, callback, *args)
__all__ = [Application.__name__]