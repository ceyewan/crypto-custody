from typing import Any, Iterable, List, Union
from .bytes_io import BytesIO, SEEK_SET, SEEK_CUR

def build_len(size: int):
    out = bytearray()
    if size >= 128:
        num_bytes = 1
        l = size
        for _ in range(3):
            l = l >> 8
            if l == 0:
                break
            num_bytes += 1
        out.append(num_bytes | 128)
        for i in range(num_bytes, 0, -1):
            out.append(size >> 8 * (i - 1) & 255)
    else:
        out.append(size)
    return out

class BadTag(Exception):

    def __init__(self, msg: str):
        self.msg = str(msg)

    def __str__(self) -> str:
        return f'BadTag({self.msg})'

class BadLength(Exception):

    def __init__(self, msg: str):
        self.msg = str(msg)

    def __str__(self) -> str:
        return f'BadLength({self.msg})'

class BadParameter(Exception):

    def __init__(self, msg: str):
        self.msg = str(msg)

    def __str__(self) -> str:
        return f'BadParameter({self.msg})'

class UnexpectedEnd(Exception):

    def __init__(self, msg: str):
        self.msg = str(msg)

    def __str__(self) -> str:
        return f'UnexpectedEnd({self.msg})'

class Tag:
    UNIVERSAL = 0
    APPLICATION = 1
    CONTEXT_SPECIFIC = 2
    PRIVATE = 3

    @staticmethod
    def __leadingByte(tag: int) -> int:
        b = 0
        for i in range(3, -1, -1):
            b = tag >> i * 8 & 255
            if b != 0:
                break
        return b

    @staticmethod
    def isConstructed(tag: int) -> bool:
        return Tag.__leadingByte(tag) & 32 > 0

    @staticmethod
    def tagClass(tag: int) -> bool:
        return (Tag.__leadingByte(tag) & 192) >> 6

class TLVNode:
    value: Union[bytes, List['TLV']]
    offset: int
    length: int

    def __init__(self, value: Union[bytes, List['TLV']]=None, offset: int=0, length: int=0) -> None:
        self.value = value
        self.offset = offset
        self.length = length

class TLV:
    tag: TLVNode
    length: TLVNode
    value: TLVNode

    def __init__(self, tag: TLVNode=None, length: TLVNode=None, value: TLVNode=None) -> None:
        self.tag = tag or TLVNode()
        self.length = length or TLVNode()
        self.value = value or TLVNode()

    @property
    def offset(self):
        return self.tag.offset

    @property
    def size(self):
        return self.tag.length + self.length.length + self.value.length

    @property
    def end(self):
        return self.tag.offset + self.size

    def find_by_tag(self, tag: int) -> 'TLV':
        return find_by_tag(self, tag)

def find_by_tag(tlv: Union['TLV', List['TLV']], tag: int) -> Union['TLV', None]:
    if not tlv:
        return None
    if not isinstance(tlv, list):
        tlv = [tlv]
    for n in tlv:
        if n.tag.value == tag:
            return n
        if isinstance(n.value.value, list):
            n = find_by_tag(n.value.value, tag)
            if n:
                return n

def iter(tlv: Union['TLV', List['TLV']]) -> Iterable[TLV]:
    if not tlv:
        return None
    if not isinstance(tlv, list):
        tlv = [tlv]
    for n in tlv:
        yield n
        if isinstance(n.value.value, list):
            yield from iter(n.value.value)

class Parser:

    def __init__(self, data: BytesIO, length: int=None):
        self.data = data
        self.offset = data.tell()
        self.length = length
        self.pos = 0
        self.MultiOctetTagMask = 31
        self.MoreOctetMask = 128
        self.Start = 0
        self.TagStart = 1
        self.Tag = 2
        self.LenStart = 3
        self.Len = 4
        self.Data = 5
        self.End = 6

    def get_offset(self):
        return self.offset + self.pos

    def next_byte(self):
        if self.length and self.pos >= self.length:
            return None
        ret = self.data.read_byte()
        if ret is None:
            return None
        self.pos += 1
        return ret

    def next(self):
        node = TLV()
        tag = 0
        tag_len = 1
        size = 0
        size_len = 0
        data = bytearray()
        state = self.Start
        while state != self.End:
            byte = self.next_byte()
            if byte == None and state != self.Start:
                raise UnexpectedEnd('offset: {}'.format(self.get_offset()))
            if state == self.Start:
                if byte == 0:
                    continue
                state = self.TagStart
            if state == self.TagStart:
                if byte is None:
                    return None
                tag = byte
                node.tag.offset = self.data.tell() - 1
                node.tag.value = tag
                node.tag.length = tag_len
                if byte & self.MultiOctetTagMask == self.MultiOctetTagMask:
                    state = self.Tag
                else:
                    state = self.LenStart
            elif state == self.Tag:
                if tag_len >= 4:
                    raise BadTag('Tag is too long, offset {}'.format(self.get_offset()))
                tag_len += 1
                tag = tag << 8 | byte
                node.tag.value = tag
                node.tag.length = tag_len
                if byte & self.MoreOctetMask == self.MoreOctetMask:
                    state = self.Tag
                else:
                    state = self.LenStart
            elif state == self.LenStart:
                node.length.offset = self.data.tell() - 1
                if byte & self.MoreOctetMask == self.MoreOctetMask:
                    size_len = byte ^ self.MoreOctetMask
                    if size_len > 4:
                        raise BadLength('Tag length is too large, offset {}'.format(self.get_offset()))
                    state = self.Len
                else:
                    size = byte
                    if size > 0:
                        state = self.Data
                        node.value.offset = self.data.tell()
                    else:
                        state = self.End
                    node.length.value = size
                    node.length.length = 1
            elif state == self.Len:
                size = size << 8 | byte
                size_len -= 1
                if size_len == 0:
                    if size > 0:
                        state = self.Data
                        node.value.offset = self.data.tell()
                    else:
                        state = self.End
                    node.length.value = size
                    node.length.length = self.data.tell() - node.length.offset
            elif state == self.Data:
                data.append(byte)
                size -= 1
                if size <= 0:
                    state = self.End
                    node.value.value = bytes(data)
                    node.value.length = self.data.tell() - node.value.offset
        return node

    @staticmethod
    def parse(data: BytesIO, length: int=None, recursive: bool=True) -> List[TLV]:
        parser = Parser(data, length)
        res = list()
        while True:
            node: TLV = None
            try:
                pos = data.tell()
                node = parser.next()
            except Exception as ex:
                data.seek(pos, SEEK_SET)
            if node is None or node.value.value is None:
                break
            res.append(node)
            pos = data.tell()
            if (recursive == True or (recursive == None and Tag.isConstructed(node.tag.value))) and node.value.length > 2:
                data.seek(node.value.offset)
                child = Parser.parse(data, node.value.length, recursive)
                if child:
                    node.value.value = child
            data.seek(pos, SEEK_SET)
        return res

class Builder:

    @staticmethod
    def __build_tag(tag: int, path) -> bytearray:
        out = bytearray()
        tag_bytes = bytearray()
        for b in tag.to_bytes(4, byteorder='big'):
            if b == 0 and len(tag_bytes) == 0:
                continue
            tag_bytes.append(b)
        if len(tag_bytes) > 1 and tag_bytes[0] & 31 != 31:
            raise BadTag(str(tag), path)
        out.append(tag_bytes[0])
        next_expected = tag_bytes[0] & 31 == 31
        for i in tag_bytes[1:]:
            if not next_expected:
                raise BadTag(str(tag), path)
            next_expected = i & 128 == 128
            out.append(i)
        return out

    @staticmethod
    def __build_len(size: int) -> bytearray:
        out = bytearray()
        if size >= 128:
            num_bytes = 1
            l = size
            for _ in range(3):
                l = l >> 8
                if l == 0:
                    break
                num_bytes += 1
            out.append(num_bytes | 128)
            for i in range(num_bytes, 0, -1):
                out.append(size >> 8 * (i - 1) & 255)
        else:
            out.append(size)
        return out

    @staticmethod
    def build(data, path) -> bytes:
        out = bytearray()

        def items(data, path):
            if isinstance(data, dict):
                for (tag, value) in data.items():
                    yield (tag, value)
            elif isinstance(data, list):
                for i in data:
                    if type(i) is not tuple:
                        raise BadParameter('Not a tuple')
                    if len(i) != 2:
                        raise BadLength(str(len(i)), path)
                    yield i
            else:
                raise BadParameter(type(data).__name__)
        for (tag, value) in items(data, path):
            path.append(tag)
            if not isinstance(tag, int):
                raise BadTag(type(tag).__name__, path)
            if value is None:
                value = bytes()
            elif isinstance(value, dict) or isinstance(value, list):
                value = Builder.build(value, path)
            elif not isinstance(value, bytes):
                raise BadParameter(type(value).__name__)
            out += Builder.__build_tag(tag, path)
            out += Builder.__build_len(len(value))
            out += value
            path.pop()
        return bytes(out)

def parse(data: Union[str, bytes, BytesIO], length: int=None, recursive: bool=True) -> List[TLV]:
    return Parser.parse(BytesIO.create(data), length, recursive)

def build(data) -> bytes:
    path = list()
    return Builder.build(data, path)