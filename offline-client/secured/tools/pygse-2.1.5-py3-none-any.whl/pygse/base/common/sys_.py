import asyncio
from ctypes import Union
from io import StringIO
import sys
import re
import subprocess
from typing import Callable, Dict

def is_traced() -> bool:
    gettrace = getattr(sys, 'gettrace', lambda : None)
    return True if gettrace and gettrace() else False
IS_DEBUGGING = bool(getattr(sys, 'gettrace', lambda : None)())
sys.is_debugging = IS_DEBUGGING

class SystemInfo:
    __cache: 'SystemInfo' = None

    def __init__(self) -> None:
        pass

    def load(self):
        if self.__class__.__cache:
            return self.__class__.__cache
        systeminfo = subprocess.run('chcp 65001>nul & systeminfo', capture_output=True, shell=True, encoding='utf-8').stdout or ''
        systeminfo = re.sub('\\n\\s+', ' ', systeminfo.strip())
        lines = systeminfo.splitlines()
        info = dict(map(lambda p: (p[0], p[2]), map(lambda l: l.partition(':'), lines)))
        self.host_name = (info.get('Host Name') or info.get('主机名') or '').strip()
        self.os_name = (info.get('OS Name') or info.get('OS 名称') or '').strip()
        self.os_version = (info.get('OS Version') or info.get('OS 版本') or '').strip()
        self.os_manufacturer = (info.get('OS Manufacturer') or info.get('OS 制造商') or '').strip()
        self.os_configuration = (info.get('OS Configuration') or info.get('OS 配置') or '').strip()
        self.os_build_type = (info.get('OS Build Type') or info.get('OS 构建类型') or '').strip()
        self.registered_owner = (info.get('Registered Owner') or info.get('注册的所有人') or '').strip()
        self.registered_organization = (info.get('Registered Organization') or info.get('注册的组织') or '').strip()
        self.product_id = (info.get('Product ID') or info.get('产品 ID') or '').strip()
        self.original_install_date = (info.get('Original Install Date') or info.get('初始安装日期') or '').strip()
        self.system_boot_time = (info.get('System Boot Time') or info.get('系统启动时间') or '').strip()
        self.system_manufacturer = (info.get('System Manufacturer') or info.get('系统制造商') or '').strip()
        self.system_model = (info.get('System Model') or info.get('系统型号') or '').strip()
        self.system_type = (info.get('System Type') or info.get('系统类型') or '').strip()
        self.processors = (info.get('Processor(s)') or info.get('处理器') or '').strip()
        self.bios_version = (info.get('BIOS Version') or info.get('BIOS 版本') or '').strip()
        self.windows_directory = (info.get('Windows Directory') or info.get('Windows 目录:') or '').strip()
        self.system_directory = (info.get('System Directory') or info.get('系统目录') or '').strip()
        self.boot_device = (info.get('Boot Device') or info.get('启动设备') or '').strip()
        self.system_locale = (info.get('System Locale') or info.get('系统区域设置') or '').strip()
        self.input_locale = (info.get('Input Locale') or info.get('输入法区域设置') or '').strip()
        self.time_zone = (info.get('Time Zone') or info.get('时区') or '').strip()
        self.total_physical_memory = (info.get('Total Physical Memory') or info.get('物理内存总量') or '').strip()
        self.available_physical_memory = (info.get('Available Physical Memory') or info.get('可用的物理内存') or '').strip()
        self.virtual_memory = (info.get('Virtual Memory') or info.get('虚拟内存') or '').strip()
        self.virtual_memory = (info.get('Virtual Memory') or info.get('虚拟内存') or '').strip()
        self.virtual_memory = (info.get('Virtual Memory') or info.get('虚拟内存') or '').strip()
        self.page_file_locations = (info.get('Page File Location(s)') or info.get('页面文件位置') or '').strip()
        self.Domain = (info.get('Domain') or info.get('域') or '').strip()
        self.logon_server = (info.get('Logon Server') or info.get('登录服务器') or '').strip()
        self.Hotfixes = (info.get('Hotfix(s)') or info.get('修补程序') or '').strip()
        self.network_cards = (info.get('Network Card(s)') or info.get('网卡') or '').strip()
        self.hyper_v_requirements = (info.get('Hyper-V Requirements') or info.get('Hyper-V 要求') or '').strip()
        bios = subprocess.run('chcp 65001>nul & wmic bios get serialnumber', capture_output=True, shell=True, encoding='utf-8').stdout or ''
        self.bios_serial_number = (bios.strip().partition('\n')[2] or '').strip()
        self.__class__.__cache = self
        return self
__on_exit: Callable[[int], bool] = None

def on_exit(cb: Callable[[int], bool]):
    global __on_exit
    __on_exit = cb

def exit_ex(status: int=None):
    if __on_exit:
        if __on_exit(status):
            sys.exit(status)
    else:
        sys.exit(status)
__all__ = ['IS_DEBUGGING', on_exit.__name__, exit_ex.__name__]