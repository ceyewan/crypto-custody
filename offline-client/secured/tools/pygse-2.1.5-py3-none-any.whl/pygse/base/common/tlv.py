from enum import IntEnum
from typing import Any, Callable, List, Literal, Tuple, Tuple, Union
from .bytes_io import BytesIO, to_bytes

class BadTag(Exception):

    def __init__(self, offset: int) -> None:
        super().__init__(f'Bad tag at {offset}')

class BadLength(Exception):

    def __init__(self, offset: int, value: int=None) -> None:
        value = f'0x{value:X}' if value is not None else 'None'
        super().__init__(f'Bad length {value} at {offset}')

class BadValue(Exception):

    def __init__(self, offset: int) -> None:
        super().__init__(f'Bad value at {offset}')

class TagClass(IntEnum):
    Universal = 0
    Application = 1
    ContextSpecific = 2
    Private = 3

class ValueObjectType(IntEnum):
    Primitive = 0
    Constructed = 1

def tlv_tag_to_bytes(tag: int, tag_class: Union[TagClass, Literal[0, 1, 2, 3]]=0, value_object_type: Union[ValueObjectType, Literal[0, 1]]=0):
    tag_flags = int(tag_class or 0) << 6 | int(value_object_type or 0) << 5
    if tag < 31:
        return bytes([tag_flags | tag])
    tag_bytes = bytearray()
    while tag > 0:
        tag_bytes.append(tag & 127 | 128)
        tag >>= 7
    tag_bytes.append(tag_flags | 31)
    tag_bytes[0] &= 127
    return bytes(reversed(tag_bytes))

def tlv_length_to_bytes(length: int):
    if length < 128:
        return length.to_bytes(1, byteorder='big')
    else:
        num_bytes = (length.bit_length() + 7) // 8
        return (128 | num_bytes).to_bytes(1, byteorder='big') + length.to_bytes(num_bytes, byteorder='big')

class Tlv:
    is_tag_encoded: bool = None
    tag: int
    tag_offset: int
    tag_size: int
    length: int
    length_offset: int
    length_size: int
    value: Union[bytes, List['Tlv']]
    value_offset: int
    value_size: int

    def __init__(self, tag: Union[int, str]=0, value: Union[str, bytes, List[Union[str, bytes, 'Tlv']]]=None, length: int=0, is_tag_encoded: bool=None, tag_class: Union[TagClass, Literal[0, 1, 2, 3]]=None, value_object_type: Union[ValueObjectType, Literal[0, 1]]=None) -> None:
        self.tag = tag if isinstance(tag, int) else int(tag, 16)
        self.length = length
        self.value = value
        self.is_tag_encoded = is_tag_encoded
        self.tag_class = tag_class
        self.value_object_type = value_object_type

    def deserialize(self, stream: BytesIO, recursive: bool=True, max_tlv_size: int=None):
        offset = stream.tell()
        length = 1
        value = b = stream.read_byte()
        while b & 31 == 31:
            b = stream.read_byte()
            value = (value << 8) + b
            length += 1
            if length > 4:
                raise BadTag(stream.tell())
        self.tag = value
        self.tag_offset = offset
        self.tag_size = length
        offset = stream.tell()
        length = 1
        value = b = stream.read_byte()
        if b & 128 == 128:
            b = b & 127
            if b > 4 or b == 0:
                raise BadLength(stream.tell(), value)
            value = stream.read_int(b, 'big')
        self.length = value
        self.length_offset = offset
        self.length_size = stream.tell() - offset
        if self.length == 0:
            return
        if max_tlv_size and self.tag_size + self.length_size + self.length > max_tlv_size:
            raise Exception(f'TLV length of value does not match length. length={length.value} at {length.offset}. max_tlv_size={max_tlv_size}.')
        offset = stream.tell()
        length = self.length
        value = stream.read(length)
        if len(value) != self.length:
            raise Exception(f'TLV length of value does not match length. length={length.value} at {length.offset}, value at {value.offset}.')
        self.value = value
        self.value_offset = offset
        self.value_size = stream.tell() - offset
        if recursive and length >= 2:
            reverse_offset = stream.tell()
            try:
                stream.seek(offset, 0)
                value = Tlv.parse(stream, recursive, self.value_size)
                if reverse_offset == stream.tell():
                    self.value = value
            except:
                pass
            finally:
                stream.seek(reverse_offset, 0)

    def serialize(self, stream: BytesIO):
        stream.write(bytes(self))

    def __bytes__(self):
        value = b''
        if isinstance(self.value, list):
            value = b''.join([to_bytes(v) for v in self.value])
        elif isinstance(self.value, (bytes, bytearray, int, str, Tlv)):
            value = to_bytes(self.value)
        return (to_bytes(self.tag) if self.is_tag_encoded else tlv_tag_to_bytes(self.tag, self.tag_class, self.value_object_type)) + tlv_length_to_bytes(len(value)) + value

    @staticmethod
    def parse(data: Union[str, bytes, BytesIO], recursive: bool=True, max_tlv_size: int=None) -> List['Tlv']:
        stream = BytesIO.create(data)
        max_end = stream.tell() + (max_tlv_size or 18446744073709551615)
        ret = []
        while not stream.at_end() and stream.tell() < max_end:
            tlv = Tlv()
            tlv.deserialize(stream, recursive, max_tlv_size)
            ret.append(tlv)
        return ret

    def find_node(self, tag: int):
        if isinstance(self.value, list):
            for n in self.value:
                if n.tag == tag:
                    return n
        return None

    def find_nodes(self, tag: int):
        if isinstance(self.value, list):
            return [n for n in self.value if n.tag == tag]
        return None

    @staticmethod
    def try_parse(data: Union[str, bytes, BytesIO], recursive: bool=True, max_size: int=None) -> List['Tlv']:
        try:
            return Tlv.parse(data, recursive, max_size)
        except:
            pass
        return None

    @staticmethod
    def find_one(nodes: Union['Tlv', List['Tlv']], tag: int):
        if not nodes:
            return None
        if isinstance(nodes, Tlv):
            return nodes if nodes.tag == tag else None
        for n in nodes:
            if n.tag == tag:
                return n
        return None

    @staticmethod
    def find_all(nodes: Union['Tlv', List['Tlv']], tag: int):
        if not nodes:
            return None
        if isinstance(nodes, Tlv):
            return [nodes] if nodes.tag == tag else None
        return [n for n in nodes if n.tag == tag]

    @staticmethod
    def build(tag: int, value: Union[bytes, bytearray, int, 'Tlv', List[bytes], List[bytearray], List[int], List['Tlv']], is_tag_encoded: bool=None, tag_class: Union[TagClass, Literal[0, 1, 2, 3]]=None, value_object_type: Union[ValueObjectType, Literal[0, 1]]=None):
        return bytes(Tlv(tag, value, is_tag_encoded=is_tag_encoded, tag_class=tag_class, value_object_type=value_object_type))

    @staticmethod
    def build_from_tuple(*tag_value_tuple: Tuple[Union[int, str], Union[bytes, bytearray, int, 'Tlv', List[bytes], List[bytearray], List[int], List['Tlv'], Tuple[int, Any]]]):

        def _build(item: Union[bytes, bytearray, int, 'Tlv', List[bytes], List[bytearray], List[int], List['Tlv'], Tuple[int, Any]]):
            if isinstance(item, tuple):
                return Tlv.build_from_tuple(item)
            elif isinstance(item, list):
                return Tlv.build_from_tuple(*item)
            return item
        tag_value_tuple1 = map(lambda tv: tv if len(tv) > 1 else (tv[0], None), tag_value_tuple)
        return b''.join([bytes(Tlv(tag, _build(value), is_tag_encoded=True)) for (tag, value) in tag_value_tuple1])
__all__ = [BadTag.__name__, BadLength.__name__, BadValue.__name__, Tlv.__name__]