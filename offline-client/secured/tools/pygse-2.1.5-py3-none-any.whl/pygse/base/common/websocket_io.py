import io
import asyncio
import os
from typing import Literal, Tuple, Union
from tornado.websocket import websocket_connect, WebSocketClientConnection
from .uri import URI

class WebSocketIO(io.RawIOBase):
    ws: WebSocketClientConnection = None

    def __init__(self, url: Union[str, URI]):
        self.url = URI(url) if isinstance(url, str) else url
        self.__read_buffer = bytearray()
        self.loop = asyncio.get_event_loop()
        self.loop.sock_connect()
        asyncio.run_coroutine_threadsafe(self.connect(), self.loop)

    @property
    def name(self):
        return os.path.basename(self.url.path)

    async def connect(self):
        self.ws = await websocket_connect(self.url, on_message_callback=self._on_message)

    def readable(self):
        return self.ws and self.ws.close_code == None

    def writable(self):
        return self.ws and self.ws.close_code == None

    def _on_message(self, msg: Union[str, bytes]):
        if msg == None:
            return
        if isinstance(msg, str):
            self.__read_buffer.extend(msg.encode())
        else:
            self.__read_buffer.extend(msg)

    def read(self, size: int=-1):
        if size <= 0:
            data = self.__read_buffer.copy()
        else:
            data = self.__read_buffer[:size]
        if data:
            del self.__read_buffer[:len(data)]
        return bytes(data)

    def write(self, data):
        self.ws.write_message(data)

    def flush(self):
        pass

    def close(self):
        if self.ws:
            self.ws.close()
__all__ = [WebSocketIO.__name__]