import functools
import inspect
import builtins
from io import StringIO
from typing import Any, Callable, Dict, Generic, Iterator, Type, TypeVar, Union, overload

@overload
def range(start: float, stop: float, step: float=1) -> Iterator[float]:
    pass

@overload
def range(start: int, stop: int, step: int=1) -> Iterator[int]:
    pass

def range(start: Union[int, float], stop: Union[int, float], step: Union[int, float]=1):
    cur = start
    if start < stop:
        while cur < stop:
            yield cur
            cur += step
    else:
        while cur > stop:
            yield cur
            cur += step

def format_dict(dic: Dict[str, str]):
    o = StringIO()
    key_length = max(map(lambda k: len(k), dic.keys()))
    for (k, v) in dic.items():
        o.write(f'{k.rjust(key_length)}: ')
        v = v if isinstance(v, str) else str(v)
        if '\n' in v:
            indent = key_length - 4
            i = v.index(':')
            if i:
                indent = key_length - (i - 5)
            o.write('\n'.ljust(indent))
            o.write('\n'.ljust(indent).join(v.split('\n')).rstrip())
        else:
            o.write(v)
        o.write('\n')
    return o.getvalue()

def __wrapper(f):

    @functools.wraps(f)
    def inner(*args, **kwargs):
        if 'encoding' not in kwargs:
            kwargs['encoding'] = 'utf8'
            kwargs['errors'] = 'backslashreplace'
        return f(*args, **kwargs)
    return inner

def hex(old):

    @functools.wraps(old)
    def new(v):
        if isinstance(v, (bytes, bytearray)):
            return v.hex().upper()
        if isinstance(v, str):
            return v
        if v is None:
            return ''
        if isinstance(v, memoryview):
            return v.tobytes().hex().upper()
        if hasattr(v, '__buffer__'):
            return v.__buffer__().hex().upper()
        if hasattr(v, '__bytes__'):
            return bytes(v).hex().upper()
        return old(v)
    return new
builtins.hex = hex(builtins.hex)

def __wrap_format(old):

    @functools.wraps(old)
    def new(value: object, format_spec=''):
        if isinstance(value, (bytes, bytearray)):
            return value.hex().upper()
        return old(value, format_spec)
    return new
builtins.format = __wrap_format(builtins.format)
T = TypeVar('T')

class Property(Generic[T]):
    f_set: Callable[[Any, T], T] = None

    def __init__(self, f_get: Callable[[Any], T]) -> None:
        raise Exception(f'此类是为了解决注释标记，注释现在已经能够标记在变量后面，使用property或者直接定义即可')
        self.f_get = f_get
        self.__doc__ = f_get.__doc__ if f_get else None

    def __get__(self, obj: object, type=None) -> T:
        if obj is None:
            return self
        if self.name in obj.__dict__:
            return obj.__dict__.get(self.name, None)
        else:
            return self.f_get(obj)

    def __set__(self, obj: object, value: T) -> T:
        if obj is None:
            self.owner.__dict__[self.name] = value
        elif value != self.__get__(obj):
            if self.f_set:
                return self.f_set(obj, value)
            else:
                obj.__dict__[self.name] = value
        return value

    def __set_name__(self, owner: object, name):
        self.owner = owner
        self.name = name

    def setter(self, f_set: Callable[[T], T]) -> 'Property[T]':
        self.f_set = f_set
        return self

class ReadonlyProperty(Generic[T]):

    @overload
    def __init__(self, f_get: Callable[[Any], T]=None) -> None:
        pass

    @overload
    def __init__(self, default_value: T=None) -> None:
        pass

    def __init__(self, f_get_or_default=None) -> None:
        if inspect.isfunction(f_get_or_default):
            self.f_get = f_get_or_default
            self.default = None
        else:
            self.f_get = None
            self.default = f_get_or_default
        if hasattr(self.f_get, '__doc__'):
            self.__doc__ = self.f_get.__doc__

    def __get__(self, obj: object, type=None) -> T:
        if obj is None:
            return self
        if self.name in obj.__dict__:
            return obj.__dict__.get(self.name, None)
        elif self.f_get:
            return self.f_get(obj)
        else:
            return None

    def __set__(self, obj: object, value: T) -> None:
        if obj and self.__get__(obj) == value:
            return
        raise Exception('Can not set readonly property.')

    def set(self, obj: object, value: T) -> None:
        obj.__dict__[self.name] = value

    def __delete__(self, obj: object) -> None:
        obj.__dict__.pop(self.name, None)

    def __set_name__(self, owner, name):
        self.owner = owner
        self.name = f'__readonly_{name}'

class StaticProperty(Generic[T]):

    def __init__(self, f_default: Callable[[], T]) -> None:
        self.f_default = f_default or (lambda : None)
        self.__doc__ = f_default.__doc__ if f_default else None

    def __get__(self, obj: object, type=None) -> T:
        if self.name not in self.owner.__dict__:
            return self.f_default()
        return self.owner.__dict__.get(self.name)

    def __set__(self, obj: object, value: T) -> None:
        self.owner.__dict__[self.name] = value

    def __delete__(self, obj: object) -> None:
        self.owner.__dict__.pop(self.name, None)

    def __set_name__(self, owner: object, name):
        self.owner = owner
        self.name = f'__static_{name}'

def static_class(cls: Type[T]) -> Type[T]:

    class NotInstantiable(cls):

        def __new__(self, *args, **kwargs):
            raise TypeError('This class cannot be instantiated')
    NotInstantiable.__name__ = cls.__name__
    NotInstantiable.__doc__ = cls.__doc__
    return NotInstantiable
__all__ = [range.__name__, format_dict.__name__, static_class.__name__, ReadonlyProperty.__name__, StaticProperty.__name__]