from enum import IntEnum
from typing import List, Literal
from .bytes_io import BytesIO

class HexRecordType(IntEnum):
    DATA_RECORD = 0
    END_OF_FILE_RECORD = 1
    EXTENDED_SEGMENT_ADDRESS_RECORD = 2
    START_SEGMENT_ADDRESS_RECORD = 3
    EXTENDED_LINEAR_ADDRESS_RECORD = 4
    START_LINEAR_ADDRESS_RECORD = 5

class HexLine:
    payload_length: int
    offset: int
    record_type: HexRecordType
    payload: bytes
    crc: int
    address: int
    extended_address: int = None

    def __init__(self, line: str) -> None:
        if line:
            self.load(line)

    def load(self, line: str) -> 'HexLine':
        buf = bytes.fromhex(line.strip(':'))
        s = BytesIO(buf)
        self.payload_length = s.read_byte()
        self.offset = s.read_int(2, 'big')
        self.record_type = HexRecordType(s.read_byte())
        self.payload = s.read(self.payload_length)
        self.crc = s.read_byte()
        crc_verify = 256 - sum(buf[:-1]) & 255
        if self.crc != crc_verify:
            raise Exception(f'Bad CRC, expect 0x{crc_verify:02X}, got 0x{self.crc:02X}')
        if self.record_type == HexRecordType.EXTENDED_SEGMENT_ADDRESS_RECORD:
            self.extended_address = int.from_bytes(self.payload, 'big') << 8
        if self.record_type == HexRecordType.EXTENDED_LINEAR_ADDRESS_RECORD:
            self.extended_address = int.from_bytes(self.payload, 'big') << 16

class HexSegment:
    base_address: int
    lines: List[HexLine]
    __data: bytes = None

    def __init__(self, base_address: int) -> None:
        self.lines = []
        self.base_address = base_address

    def append_data(self, line: HexLine):
        line.address = self.base_address + line.offset
        self.lines.append(line)
        self.__data = None

    @property
    def start_address(self):
        return self.lines[0].address if self.lines else self.base_address

    @property
    def data(self):
        if self.__data == None:
            buf = bytearray()
            for l in self.lines:
                buf.extend(l.payload)
            self.__data = bytes(buf)
        return self.__data

class HexFile:
    file: str
    segments: List[HexSegment]

    def __init__(self, hex_file: str) -> None:
        self.segments = []
        if hex_file:
            self.load(hex_file)

    def load(self, hex_file: str) -> 'HexFile':
        with open(hex_file, 'r', encoding='utf8') as f:
            current_segment: HexSegment = None
            for (i, l) in enumerate(f.readlines()):
                if not l.startswith(':'):
                    continue
                try:
                    line = HexLine(l)
                except Exception as ex:
                    ex.args = ('\n'.join([*ex.args, f'At line {i + 1}']),)
                    raise ex
                if line.record_type == HexRecordType.DATA_RECORD:
                    current_segment.append_data(line)
                if line.record_type == HexRecordType.EXTENDED_SEGMENT_ADDRESS_RECORD:
                    current_segment = HexSegment(line.extended_address)
                    self.segments.append(current_segment)
                if line.record_type == HexRecordType.EXTENDED_LINEAR_ADDRESS_RECORD:
                    current_segment = HexSegment(line.extended_address)
                    self.segments.append(current_segment)
                if line.record_type == HexRecordType.END_OF_FILE_RECORD:
                    break
        self.file = hex_file
        return self

    def data(self, address: int=None) -> bytes:
        data = bytearray()
        for seg in self.segments:
            if address != None:
                if seg.start_address == address:
                    data.extend(seg.data)
            else:
                data.extend(seg.data)
        return bytes(data)
__all__ = [HexRecordType.__name__, HexLine.__name__, HexSegment.__name__, HexFile.__name__]