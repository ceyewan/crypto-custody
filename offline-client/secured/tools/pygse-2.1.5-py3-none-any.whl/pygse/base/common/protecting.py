import sys
import os
import builtins
builtins.__builtin__ = dict()
builtins.__calling__ = set()

def protected(fun):
    key = os.urandom(16)
    while key in builtins.__builtin__:
        key = os.urandom(16)
    fun._is_protected = True
    builtins.__builtin__[key] = fun
    return key

def pcall(key):

    class Wrapper:

        def __init__(self, key) -> None:
            self.__key = key

        def __enter__(self):
            self.__seed = os.urandom(16)
            mark: set = builtins.__calling__
            mark.add(bytes(map(lambda b: ~b & 255, self.__seed)))
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            seed = bytes(map(lambda b: ~b & 255, self.__seed))
            mark: set = builtins.__calling__
            if seed not in mark:
                sys.exit(-101)
            mark.remove(seed)

        def __call__(self, *args, **kwargs):
            try:
                seed = bytes(map(lambda b: ~b & 255, self.__seed))
                mark: set = builtins.__calling__
                if seed not in mark:
                    raise Exception()
            except:
                sys.exit(-101)
            if callable(self.__key):
                return builtins.__builtin__[self.__key](*args, **kwargs)
            elif self.__key in builtins.__builtin__:
                return builtins.__builtin__[self.__key](*args, **kwargs)
            else:
                return None
    return Wrapper(key)