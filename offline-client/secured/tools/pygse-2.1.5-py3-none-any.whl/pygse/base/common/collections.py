from typing import Any, Callable, Dict, List, Set, TypeVar, Iterable, Tuple
T = TypeVar('T')
T1 = TypeVar('T1')
T2 = TypeVar('T2')

def find(src_list: Iterable[T], predicate: Callable[[T], bool], default=None) -> T:
    for first in filter(predicate, src_list):
        return first
    return default

def first(src_list: Iterable[T], predicate: Callable[[T], bool]=None, default=None) -> T:
    for item in src_list:
        if predicate == None or (predicate and predicate(item)):
            return item
    return default

def first1(src_list: Iterable[T], predicate: Callable[[T], bool]=None, default=None) -> Tuple[int, T]:
    for (i, item) in enumerate(src_list):
        if predicate == None or (predicate and predicate(item)):
            return (i, item)
    return (-1, None)

def select(src_list: Iterable[T], predicate: Callable[[T], bool]) -> List[T]:
    return list(filter(predicate, src_list))

def filter_out(src_list: List[T], predicate: Callable[[T], bool]) -> List[T]:
    ret = list(filter(predicate, src_list))
    for i in ret:
        src_list.remove(i)
    return ret

def remove_one(src_list: List[T], predicate: Callable[[T], bool]) -> T:
    for item in src_list:
        if predicate(item):
            src_list.remove(item)
            return item
    return None

def some(iterable: Iterable[T], predicate: Callable[[T], bool]) -> bool:
    for item in iterable:
        if predicate(item):
            return True
    return False

def same(iterable: Iterable[T], getter: Callable[[T], Any]=None) -> bool:
    return len({getter(o) if getter else o for o in iterable}) <= 1

def every(iterable: Iterable[T], predicate: Callable[[T], bool]) -> bool:
    ret = False
    for item in iterable:
        if not predicate(item):
            return False
        ret = True
    return ret

def sumif(iterable: Iterable[T], predicate: Callable[[T], bool]):
    return sum((1 for item in iterable if predicate(item)))

def sync(target: List[T1], source: Iterable[T2], compare: Callable[[T1, T2], bool]=None, new_item: Callable[[T2], T1]=None, updater: Callable[[T1, T2], bool]=None) -> Tuple[List[T1], List[T1], List[T1], bool]:
    compare = compare or (lambda a, b: a == b)
    new_item = new_item or (lambda a: a)
    updater = updater or (lambda a, b: False)
    index_changed = False
    if not isinstance(source, (list, dict)):
        source = list(source)
    added = []
    removed = []
    updated = []
    for (i_src, src) in enumerate(source):
        (i_dst, dst) = first1(target, lambda t: compare(t, src))
        if dst is None:
            new = new_item(src)
            added.append(new)
            target.insert(i_src, new)
        else:
            if updater(dst, src):
                updated.append(dst)
            if i_src != i_dst:
                target.pop(i_dst)
                target.insert(i_src, dst)
                index_changed = True
    for t in target:
        if find(source, lambda s: compare(t, s)) is None:
            removed.append(t)
    for r in removed:
        target.remove(r)
    return (added, removed, updated, index_changed)

def groupby(iterable: Iterable[T1], keyfun: Callable[[T1], T2]=None) -> Dict[T2, List[T1]]:
    if keyfun is None:

        def keyfun(x):
            return x
    ret: Dict[T2, List[T1]] = {}
    for item in iterable:
        key = keyfun(item)
        ret.setdefault(key, []).append(item)
    return ret

def split(iterable: Iterable[T], count_per_group: int) -> List[List[T]]:
    if count_per_group < 1:
        raise Exception(f'Bad parameter count_per_group={count_per_group}')
    ret = []
    current = []
    for item in iterable:
        current.append(item)
        if len(current) == count_per_group:
            ret.append(current)
            current = []
    if current:
        ret.append(current)
    return ret

def distinct1(iterable: Iterable[T1], comparer: Callable[[T1, T1], bool]=None) -> List[T1]:
    if comparer is None:

        def comparer(a, b):
            return a == b

    class Wraper:

        def __init__(self, o: T1) -> None:
            self.obj = o

        def __eq__(self, __o: 'Wraper') -> bool:
            return comparer(self.obj, __o.obj)

        def __hash__(self) -> int:
            return hash(self.obj)
    distincted: Set[T2] = set()
    for item in iterable:
        distincted.add(Wraper(item))
    return list(distincted)

def distinct(iterable: Iterable[T1], keyfun: Callable[[T1], T2]=None) -> List[T1]:
    if keyfun is None:

        def keyfun(x):
            return x
    distincted: Dict[T2, T1] = {}
    for item in iterable:
        if keyfun(item) not in distincted:
            distincted[keyfun(item)] = item
    return list(distincted.values())

def peek_one(lst: List[T], predicate: Callable[[T], bool]):
    for (i, v) in enumerate(lst):
        if predicate(v):
            return lst.pop(i)
    return None
__all__ = [find.__name__, first.__name__, first1.__name__, select.__name__, filter_out.__name__, remove_one.__name__, some.__name__, same.__name__, every.__name__, sumif.__name__, sync.__name__, groupby.__name__, split.__name__, distinct1.__name__, distinct.__name__]