import ast
import inspect
import enum
import textwrap
from typing import Dict, Tuple, Union

class EnumInt(int):

    def __new__(cls, *args, **kwargs):
        isinstance = super(EnumInt, cls).__new__(cls, *args)
        return isinstance

    def __init__(self, *args) -> None:
        super().__init__()

def _new_int_enum(cls, value, doc: str=None):
    obj = int.__new__(cls, value)
    obj._value_ = value
    obj.__doc__ = doc
    return obj

def _missing_enum(cls, value):
    obj = _new_int_enum(cls, *(value if isinstance(value, tuple) else (value,)))
    obj._name_ = f'MISSING_0x{obj._value_:02X}' if obj._value_ <= 255 else f'MISSING_0x{obj._value_:04X}'
    obj.__objclass__ = cls
    obj.__init__(obj._value_)
    return obj

def get_member_docstring(cls, member_name):
    if hasattr(cls, '__member_doc__'):
        member_doc: Dict[str, str] = getattr(cls, '__member_doc__')
        return member_doc.get(member_name, None)
    source_code = inspect.getsource(cls)
    tree = ast.parse(source_code)
    member_doc = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == cls.__name__:
            for (i, body_node) in enumerate(node.body):
                if isinstance(body_node, ast.Assign) and len(body_node.targets) == 1 and isinstance(body_node.targets[0], ast.Name):
                    n = body_node.targets[0].id
                    if i + 1 < len(node.body) and isinstance(node.body[i + 1], ast.Expr) and isinstance(node.body[i + 1].value, ast.Str):
                        member_doc[n] = textwrap.dedent(node.body[i + 1].value.s).strip()
    setattr(cls, '__member_doc__', member_doc)
    return member_doc.get(member_name, None)

class IntEnum(enum.IntEnum):

    def __new__(cls, value, doc: str=None):
        return _new_int_enum(cls, value, doc)

    @classmethod
    def _missing_(cls, value):
        return _missing_enum(cls, cls.__get_missing_value__(value) or value if hasattr(cls, '__get_missing_value__') else value)

    def __str__(self):
        return f'{super().__str__()}(0x{self.value:02X})' if not self.__doc__ else f'{super().__str__()}(0x{self.value:02X}), {self.__doc__}'

class IntFlag(enum.IntFlag):

    def __new__(cls, value, doc: str=None):
        return _new_int_enum(cls, value, doc)

    def __str__(self):
        return f'{super().__str__()}, 0x{self.value:02X}'
__all__ = [IntEnum.__name__, IntFlag.__name__]