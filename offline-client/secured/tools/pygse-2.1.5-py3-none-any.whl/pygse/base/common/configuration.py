import os
import sys
import sqlite3
from typing import Dict
from datetime import datetime
from hashlib import sha256
from .mutex import Mutex

class ConfigurationItem:
    id: int
    key: str
    value: str
    update_time: datetime

    def __init__(self, key: str, value: str='', id: int=0, update_time: datetime=None):
        self.id = id
        self.key = key
        self.value = value
        self.update_time = update_time or datetime.now()

    @staticmethod
    def from_row(id: int, key: str, value: str, update_time: datetime):
        return ConfigurationItem(id=id, key=key, value=value, update_time=update_time)

class ConfigurationDatabase:
    is_open: bool = False
    conn: sqlite3.Connection = None
    __cache: Dict[str, ConfigurationItem]
    __db_locker: Mutex = None
    __lock_db: bool = False
    __locker_dir: str = None

    def __init__(self, db: str, lock_db: bool=False, locker_dir: str=None):
        self.__cache = {}
        self.__db = os.path.normpath(db)
        self.__lock_db = lock_db
        if lock_db and (not locker_dir):
            raise Exception('locker dir is required for locking db.')
        if locker_dir:
            self.__locker_dir = os.path.normpath(locker_dir)

    def open(self):
        if self.__db != ':memory:':
            os.makedirs(os.path.dirname(self.__db), exist_ok=True)
            if self.__lock_db:
                if sys.platform == 'win32':
                    lock_file = os.path.join(self.__locker_dir, sha256(self.__db.upper().encode('utf8')).digest().hex())
                else:
                    lock_file = os.path.join(self.__locker_dir, sha256(self.__db.encode('utf8')).digest().hex())
                os.makedirs(os.path.dirname(lock_file), exist_ok=True)
                db_locker = Mutex(lock_file)
                if not db_locker.acquire():
                    raise Exception(f'"{self.__db}" has been opened.')
                self.__db_locker = db_locker
        self.__init_db()
        self.is_open = True
        return self

    @property
    def name(self):
        return os.path.splitext(os.path.basename(self.__db))[0]

    @property
    def file(self):
        return self.__db

    def __init_db(self):
        init_script = "\n            -- 禁用外键约束\n            PRAGMA foreign_keys = off;\n            BEGIN TRANSACTION;\n\n            -- Table: Configuration\n            -- DROP TABLE IF EXISTS Configuration;\n\n            CREATE TABLE IF NOT EXISTS Configuration (\n                Id         INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,\n                [Key]      TEXT     NOT NULL,\n                Value      TEXT,\n                UpdateTime DATETIME NOT NULL DEFAULT (DATETIME('now', 'localtime')) \n            );\n\n\n            -- Index: IDX_Configuration_Key\n            -- DROP INDEX IF EXISTS IDX_Configuration_Key;\n\n            CREATE UNIQUE INDEX IF NOT EXISTS IDX_Configuration_Key ON Configuration ([Key]);\n\n\n            -- Trigger: AutoUpdateTime\n            -- DROP TRIGGER IF EXISTS AutoUpdateTime;\n            CREATE TRIGGER IF NOT EXISTS AutoUpdateTime AFTER UPDATE OF [Key], Value ON Configuration\n                FOR EACH ROW\n                BEGIN\n                    UPDATE Configuration SET UpdateTime = datetime('now', 'localtime') WHERE Id = new.Id;\n                END;\n\n\n            COMMIT TRANSACTION;\n            -- 启用外键约束\n            PRAGMA foreign_keys=ON;\n\n            --DELETE FROM Configuration WHERE UpdateTime < DATETIME('now', '-365 days');\n            "
        self.conn = sqlite3.connect(self.__db, check_same_thread=False)
        with self.conn:
            self.conn.executescript(init_script)

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
        if self.__db_locker:
            self.__db_locker.release()
            self.__db_locker = None
        self.is_open = False

    def __del__(self):
        self.close()

    def get_config(self, key: str):
        cfg = self.__cache.get(key.upper())
        if cfg:
            return cfg
        with self.conn:
            row = self.conn.execute('SELECT * FROM Configuration WHERE Key=? LIMIT 1', (key,)).fetchone()
            if row:
                cfg = ConfigurationItem.from_row(*row)
                self.__cache[cfg.key.upper()] = cfg
            else:
                cfg = ConfigurationItem(key)
            return cfg

    def set_config(self, cfg: ConfigurationItem):
        with self.conn:
            cursor = self.conn.execute('UPDATE Configuration SET Key=?, Value=? WHERE Key=?', (cfg.key, cfg.value, cfg.key))
            if cursor.rowcount == 0:
                cursor = self.conn.execute('INSERT INTO Configuration(Key, Value) VALUES (?, ?)', (cfg.key, cfg.value))
                cfg.id = cursor.lastrowid
            else:
                cfg.update_time = datetime.now()
            self.__cache[cfg.key.upper()] = cfg
            return cfg

    def backup(self, dst: 'ConfigurationDatabase'):
        with dst.conn:
            self.conn.backup(dst.conn)