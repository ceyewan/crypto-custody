from typing import List

class TextDecoder:
    state: int = 0
    current_line: bytearray

    def __init__(self, encoding: str='utf8') -> None:
        self.encoding = encoding
        self.current_line = bytearray()

    def reset(self):
        self.state = 0

    def decode(self, buf: bytes) -> List[str]:
        lines = []
        for b in buf:
            if b == 13:
                continue
            elif b == 10:
                lines.append(self.current_line.decode(self.encoding, 'replace'))
                self.current_line.clear()
            else:
                self.current_line.append(b)
__all__ = [TextDecoder.__name__]