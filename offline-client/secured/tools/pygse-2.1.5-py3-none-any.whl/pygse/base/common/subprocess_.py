import os
import sys
import re
import logging
from queue import SimpleQueue
from signal import SIGTERM
from subprocess import STDOUT, PIPE, Popen, CalledProcessError, call, check_output
from threading import Thread
from time import sleep
from typing import Any, Callable, List, Union

def get_shell_encoding() -> str:
    if sys.platform == 'win32':
        if hasattr(get_shell_encoding, 'ENCODING'):
            return get_shell_encoding.ENCODING
        ENCODING = 'GB2312'
        try:
            data = check_output('chcp', shell=True, text=True, stderr=STDOUT, errors='replace')
            m = re.search('(\\d+)$', data.strip())
            if m:
                code_pages = {936: 'GB18030', 65001: 'UTF-8'}
                ENCODING = code_pages.get(int(m[1]), 'GB18030')
                get_shell_encoding.ENCODING = ENCODING
        except:
            pass
        return ENCODING
    return 'UTF-8'

def getstatusoutput(cmd: List[str]):
    shell = sys.platform == 'win32'
    try:
        data = check_output(cmd, shell=shell, text=True, stderr=STDOUT, encoding=get_shell_encoding())
        exitcode = 0
    except CalledProcessError as ex:
        data = ex.output
        exitcode = ex.returncode
    if data[-1:] == '\n':
        data = data[:-1]
    return (exitcode, data)

class ChildProcess:
    output_lines: SimpleQueue = None
    process: Popen = None
    __read_thread: Thread = None
    __notify_thread: Thread = None

    def __init__(self, cmd: Union[str, List[str]], shell: bool=True, cb_on_lines_read: Callable[[List[str]], Any]=None, cb_on_stopped: Callable=None, logger: logging.Logger=None) -> None:
        self.cmd = cmd
        self.shell = shell
        self.cb_on_lines_read = cb_on_lines_read
        self.cb_on_stopped = cb_on_stopped
        self.logger = logger or logging.root

    @property
    def is_running(self):
        return self.process and self.process.poll() == None

    @property
    def pid(self):
        return self.process.pid if self.process else -1

    def start(self):
        if self.__read_thread:
            return
        self.__read_thread = Thread(target=self.__read_stdout_thread_proc, name='ChildProcess Reader Thread', daemon=True)
        self.__read_thread.start()

    def stop(self):
        if not self.process:
            return
        if sys.platform == 'win32':
            from subprocess import STARTF_USESHOWWINDOW, STARTUPINFO
            si = STARTUPINFO()
            si.dwFlags |= STARTF_USESHOWWINDOW
            call(['TASKKILL', '/F', '/PID', f'{self.process.pid}', '/T'], startupinfo=si)
        else:
            os.killpg(self.process.pid, SIGTERM)

    def __read_stdout_thread_proc(self):
        try:
            self.output_lines = SimpleQueue()
            self.process = Popen(self.cmd, stdout=PIPE, stderr=STDOUT, bufsize=1, shell=self.shell, close_fds=True, start_new_session=True, text=True, errors='replace')
            self.__notify_thread = Thread(target=self.__notify_thread_proc, name='ChildProcess Notify Thread', daemon=True)
            self.__notify_thread.start()
            while self.process.poll() == None:
                try:
                    for line in iter(self.process.stdout.readline, ''):
                        self.output_lines.put(line.rstrip('\n'))
                except Exception as ex:
                    self.logger.debug(ex)
        except Exception as ex:
            self.logger.debug(ex)
        self.process = None
        if self.cb_on_stopped:
            self.cb_on_stopped()

    def __notify_thread_proc(self):
        while self.process:
            if self.output_lines.empty():
                sleep(0.01)
                continue
            lines = []
            while not self.output_lines.empty():
                lines.append(self.output_lines.get())
            if lines:
                self.cb_on_lines_read(lines)
__all__ = [getstatusoutput.__name__, ChildProcess.__name__]