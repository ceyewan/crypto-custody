from typing import Dict, List, Union
from urllib.parse import urlparse, urlunparse, urljoin, parse_qs, unquote, quote, uses_netloc

class URI:
    scheme: str = ''
    netloc: str = ''
    path: str = ''
    params: str = ''
    fragment: str = ''
    __query: Dict[str, List[str]]

    def __init__(self, uri: str, *, scheme: str=None, netloc: str=None, path: str=None, params: str=None, query: str=None, fragment: str=None) -> None:
        if uri:
            parsed = urlparse(uri)
            self.scheme = parsed.scheme
            self.netloc = parsed.netloc
            self.path = unquote(parsed.path)
            self.params = parsed.params
            self.query = unquote(parsed.query)
            self.fragment = parsed.fragment
        self.scheme = (self.scheme or scheme or '').lower()
        self.netloc = self.netloc or netloc or ''
        self.path = self.path or path or ''
        self.params = self.params or params or ''
        self.query = self.query or query or ''
        self.fragment = self.fragment or fragment or ''

    @property
    def query(self) -> str:
        return self.__dict__.get('query', None) or ''

    @query.setter
    def query(self, value: str) -> str:
        self.__dict__['query'] = value
        self.__query = parse_qs(self.query)

    def get_query_value(self, key: str):
        v = self.__query.get(key, None)
        if not v:
            return None
        return v[-1] if v else None

    def get_query_value_all(self, key: str):
        v = self.__query.get(key, None)
        return v or []

    def set_query_value(self, key: str, value: Union[List[str], str, None]=None):
        if not value:
            self.__query.pop(key, None)
        else:
            self.__query[key] = value if isinstance(value, list) else [value]
        self.query = '&'.join(map(lambda kv: '&'.join(map(lambda i: f'{kv[0]}={quote(i)}', kv[1])), self.__query.items()))

    def to_url(self):
        if self.scheme and self.scheme not in uses_netloc:
            uses_netloc.append(self.scheme)
        return urlunparse((self.scheme, self.netloc, quote(self.path), self.params, quote(self.query), self.fragment))

    def to_str(self):
        if self.scheme and self.scheme not in uses_netloc:
            uses_netloc.append(self.scheme)
        return urlunparse((self.scheme, self.netloc, self.path, self.params, self.query, self.fragment))

    def __str__(self) -> str:
        return self.to_str()

    def __repr__(self) -> str:
        return self.to_str()

    @staticmethod
    def is_uri(string):
        try:
            result = urlparse(string)
            return all([result.scheme, result.netloc])
        except:
            return False

    @staticmethod
    def try_parse(s: str) -> 'URI':
        try:
            return URI(s)
        except:
            pass
        return None

def join_url(base, *args: str):
    url = base
    for arg in args:
        url = urljoin(url if base[-1] == '/' else url + '/', arg.strip('/'))
    return url
__all__ = [URI.__name__, join_url.__name__]