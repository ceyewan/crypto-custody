def register_all_services():
    import os
    import glob
    import importlib
    from typing import List
    root_path = os.path.dirname(__file__)
    root_package = __package__
    handler_files: List[str] = glob.glob(os.path.join(root_path, '**/*_service.py'), recursive=True)
    for handler_file in handler_files:
        p: str = os.path.relpath(os.path.splitext(handler_file)[0], root_path)
        module_name = p.replace(os.path.sep, '.')
        module = importlib.import_module(f'{root_package}.{module_name}')