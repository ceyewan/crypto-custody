import asyncio
import logging
from ....base.common import service
from ....base.ssb.patch_script import *
from ....global_platform.base import *
from ....global_platform.session import *
from ..common import IUpgradeCosService

@service(IUpgradeCosService)
class UpgradeCosService(IUpgradeCosService):

    def __init__(self) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)

    async def upgrade(self, device: SecurityDevice, script: str, force: bool=False) -> bool:
        file = PatchScriptFile(script)
        if not file.target:
            raise Exception('No patch target in script.')
        target = file.target
        if target.tag != PatchTargetTag.SE:
            raise Exception('Patch target MUST be SE.')
        if not target.interface or not target.interface.commands:
            raise Exception('No patch command in script file.')
        if target.info.tag == PatchInformationTag.COS_UPGRADE:
            self.logger.info(f'Upgrade COS: Tag={target.info.tag.name}(0x{target.info.tag:02X}), Module={target.info.patch_module.name}(0x{target.info.patch_module}).')
            return await self.__do_upgrade_cos(target.info, target.interface, device, force)
        elif target.info.tag == PatchInformationTag.GOODIX_PREINSTALLED or target.info.tag == PatchInformationTag.PREINSTALLED_UPGRADE_PACKAGES:
            self.logger.info(f'Upgrade Goodix Preinstalled: Tag={target.info.tag.name}(0x{target.info.tag:02X}).')
            return await self.__do_upgrade_goodix_preinstalled(target.info, target.interface, device, force)
        elif target.info.tag == PatchInformationTag.USER_PREINSTALLED:
            self.logger.info(f'Upgrade User Preinstalled: Tag={target.info.tag.name}(0x{target.info.tag:02X}).')
            return await self.__do_upgrade_user_preinstalled(target.info, target.interface, device, force)
        else:
            self.logger.error(f'Unknown patch information tag: {target.info.tag}')
            return False

    def __compare_version_to_update_gen1(self, info: PatchInformationForGen1Cos, cos_version: CosVersionGen1) -> bool:
        if cos_version.key_version != info.key_version:
            self.logger.error(f'The key version does not match! device=0x{cos_version.key_version:02X}, PatchScript=0x{info.key_version:02X}')
            return False
        if cos_version.cos_rom_major_version > 0 and cos_version.cos_rom_major_version < info.cos_rom_major_version and (info.cos_rom_minor_version == 0):
            return True
        elif cos_version.cos_rom_major_version == 0 and cos_version.cos_rom_minor_version <= 255 and (info.cos_rom_major_version == 1) and (info.cos_rom_minor_version == 0):
            return True
        elif cos_version.cos_rom_major_version == 0 and cos_version.cos_rom_minor_version < info.cos_rom_major_version and (info.cos_rom_major_version == 0) and (info.cos_rom_minor_version in (224, 192, 160, 128, 96)):
            return True
        elif info.cos_rom_major_version == cos_version.cos_rom_major_version and info.cos_rom_minor_version > cos_version.cos_rom_minor_version:
            if cos_version.cos_rom_major_version > 0:
                return True
            elif cos_version.cos_rom_minor_version >= 0 and info.cos_rom_minor_version <= 31 or (cos_version.cos_rom_minor_version >= 32 and info.cos_rom_minor_version <= 63) or (cos_version.cos_rom_minor_version >= 64 and info.cos_rom_minor_version <= 95) or (cos_version.cos_rom_minor_version >= 96 and info.cos_rom_minor_version <= 127) or (cos_version.cos_rom_minor_version >= 128 and info.cos_rom_minor_version <= 159) or (cos_version.cos_rom_minor_version >= 160 and info.cos_rom_minor_version <= 191) or (cos_version.cos_rom_minor_version >= 192 and info.cos_rom_minor_version <= 223) or (cos_version.cos_rom_minor_version >= 224 and info.cos_rom_minor_version <= 255):
                return True
        return False

    async def __compare_version_to_update_gen2(self, info: PatchInformationForGen2Cos, cos_version: CosVersionGen2) -> bool:
        if info.cos_rom_version == cos_version.cos_rom_version and info.patch_major_version > cos_version.patch_major_version and (info.patch_minor_version == 0):
            return True
        elif info.cos_rom_version == cos_version.cos_rom_version and info.patch_major_version == cos_version.patch_major_version and (info.patch_minor_version > cos_version.patch_minor_version):
            return True
        return False

    async def __do_upgrade_cos(self, info: Union[PatchInformationForGen1Cos, PatchInformationForGen2Cos], interface: PatchTargetInterface, device: SecurityDevice, force: bool=False):
        await device.reset()
        cos_version = await device.get_cos_version(True)
        if cos_version.ic_fw_version != info.ic_fw_version:
            self.logger.error(f'IC FW Version does not match! COS=0x{cos_version.ic_fw_version:04X}, PatchScript=0x{cos_version.ic_fw_version:04X}')
            return False
        if info.cid != 0 and cos_version.cid != info.cid:
            self.logger.error(f'CID does not match! COS.CID=0x{cos_version.cid:02X}, PatchScript.CID=0x{cos_version.cid:02X}')
            return False
        if isinstance(info, PatchInformationForGen1Cos):
            if not isinstance(cos_version, CosVersionGen1):
                self.logger.error(f'COS generation does not match! device!=GEN1, PatchScript=GEN1')
                return False
            if not force and (not self.__compare_version_to_update_gen1(info, cos_version)):
                self.logger.error(f'Can not upgrade {cos_version.versions_str} to {info.versions_str}. The Version does not meet the upgrading requirements.')
                return False
        elif isinstance(info, PatchInformationForGen2Cos):
            if not isinstance(cos_version, CosVersionGen2):
                self.logger.error(f'COS generation does not match! device!=GEN2, PatchScript=GEN2')
                return False
            if info.patch_module != PatchModule.LJS_PATCH:
                self.logger.error(f'LJS_PATCH(0x1) is required in patch information in patch script for GEN2 upgrade.')
                return False
            if not force and (not self.__compare_version_to_update_gen2(info, cos_version)):
                self.logger.error(f'Can not upgrade {cos_version.versions_str} to {info.versions_str}. The Version does not meet the upgrading requirements.')
                return False
        else:
            self.logger.error(f'Unsupported patch script info.')
            return False
        if info.patch_module in (PatchModule.LJS_COS, PatchModule.ROOT2_PATCH, PatchModule.LJS_PATCH):
            if not await device.enter_root2():
                self.logger.error(f'Can not enter root2.')
                return False
        self.logger.info(f'Upgrading {cos_version.versions_str} to {info.versions_str}')
        try:
            exec_ok = False
            exec_ok = await self.__do_execute_commands(interface.commands, device)
            if not exec_ok:
                return False
            else:
                await asyncio.sleep(0.02)
        except Exception as ex:
            self.logger.error(ex)
            return False
        finally:
            await device.reset()
            await asyncio.sleep(0.1)
            if not exec_ok:
                self.logger.error(f'Upgrade failed!')
        cos_version = await device.get_cos_version(True)
        if device.is_in_root2:
            for _ in range(3):
                if await device.exit_root2():
                    break
                await asyncio.sleep(1)
            else:
                self.logger.warning(f'Can not exit root2, try reset.')
                await device.reset()
            cos_version = await device.get_cos_version(True)
        if not cos_version:
            self.logger.error(f'Can not get COS version info after script commands executed! upgrade failed!')
            return False
        if device.is_in_root2:
            self.logger.error(f'Can not exit root2. Upgrade maybe failed')
            return False
        if cos_version.versions != info.versions:
            self.logger.error(f'Upgrade failed! Current COS version is "{cos_version.versions_str}", Patch Script is "{info.versions_str}".')
            return False
        self.logger.info(f'Upgrade successful! Current COS version is "{cos_version.versions_str}", Patch Script is "{info.versions_str}".')
        return True

    async def __do_upgrade_goodix_preinstalled(self, info: Union[PatchInformationForGoodixPreinstalledGen1, PatchInformationForGoodixPreinstalledGen2], interface: PatchTargetInterface, device: SecurityDevice, force: bool=False):
        cos_version = await device.get_cos_version(True)
        if device.is_in_root2:
            await device.exit_root2()
            cos_version = await device.get_cos_version(True)
        if device.is_in_root2:
            self.logger.error(f'Can not exit root2!')
            return False
        if isinstance(info, PatchInformationForGoodixPreinstalledGen1) and (not isinstance(cos_version, CosVersionGen1)):
            self.logger.error(f'The patch script is for GEN1, but COS is GEN2.')
            return False
        if isinstance(info, PatchInformationForGoodixPreinstalledGen2) and (not isinstance(cos_version, CosVersionGen2)):
            self.logger.error(f'The patch script is for GEN2, but COS is GEN1.')
            return False
        if isinstance(info, PatchInformationForGoodixPreinstalledGen1) and isinstance(cos_version, CosVersionGen1):
            if force or info.require_cos_versions == (0, 0, 0):
                pass
            elif info.require_cos_versions > (cos_version.cos_rom_major_version, cos_version.cos_rom_minor_version):
                self.logger.error(f'Applet in patch script require minimum cos version 0x{info.require_minimum_cos_rom_major_version:02X}.{info.require_minimum_cos_rom_minor_version:02X}, but the COS version on device is {cos_version.cos_rom_major_version:02X}.{cos_version.cos_rom_minor_version:02X}.')
                return False
        if isinstance(info, PatchInformationForGoodixPreinstalledGen2) and isinstance(cos_version, CosVersionGen2):
            if force or info.require_cos_versions == (0, 0, 0):
                pass
            elif info.require_cos_versions > (cos_version.cos_rom_version, cos_version.patch_major_version, cos_version.patch_minor_version):
                self.logger.error(f'Applet in patch script require minimum cos version 0x{info.require_minimum_cos_rom_version:02X}.{info.require_minimum_patch_major_version:02X}.{info.require_minimum_patch_minor_version:04X}, but the COS version on device is 0x{cos_version.cos_rom_version:02X}.{cos_version.patch_major_version:02X}.{cos_version.patch_minor_version:04X}.')
                return False
        if isinstance(info, PatchInformationForGoodixPreinstalledGen1):
            rsp = await device.select(GseConstants.SEM_AID)
            if not rsp.status_ok:
                self.logger.error(f'No BPF application({GseConstants.SEM_AID}) exists!')
                return False
        if info.applet_aid != GseConstants.GP_ISD_AID and (not force):
            if info.applet_aid not in GseConstants.GOODIX_PREINSTALLED_APPLETS:
                self.logger.error(f'Applet {hex(info.applet_aid)} is not a preinstalled applet!')
                return False
            if GseConstants.GOODIX_PREINSTALLED_APPLETS[info.applet_aid]:
                (app_info, status) = await device.get_goodix_preinstalled_applet_version(info.applet_aid)
                if status == StatusCode.SW9000:
                    if info.applet_version <= app_info.applet_version:
                        self.logger.error(f'Applet version in patch script is lower than the one installed on device. PatchScript.applet_version=0x{info.applet_version:04X}, installed=0x{app_info.applet_version:04X}')
                        return False
                    if info.require_minimum_applet_version and info.require_minimum_applet_version < app_info.applet_version:
                        self.logger.error(f'Applet version in patch script require minimum version 0x{info.require_minimum_applet_version:04X}, but the installed app on device is 0x{app_info.applet_version:04X}.')
                        return False
                elif status == StatusCode.SW6A82:
                    self.logger.info(f'Applet {hex(info.applet_aid)} in patch script is not installed.')
                else:
                    self.logger.error(f'Can not get version of {hex(info.applet_aid)}, code={status}!')
                    return False
        try:
            exec_ok = False
            exec_ok = await self.__do_execute_commands(interface.commands, device)
            if not exec_ok:
                return False
            else:
                await asyncio.sleep(0.02)
        except Exception as ex:
            self.logger.error(ex)
            return False
        finally:
            if not exec_ok:
                self.logger.error(f'Failed to upgrade the Goodix preinstalled applet {hex(info.applet_aid)}!')
        self.logger.info(f'The Goodix preinstalled applet {hex(info.applet_aid)} has been upgraded successfully!')
        return True

    async def __do_upgrade_user_preinstalled(self, info: PatchInformationForUserPreinstalled, interface: PatchTargetInterface, device: SecurityDevice, force: bool=False):
        (counter_before, status) = await device.get_user_preinstalled_counter()
        if status != StatusCode.SW9000:
            self.logger.error(f'Can not get user preinstalled counter! code={status}')
            return False
        try:
            exec_ok = False
            exec_ok = await self.__do_execute_commands(interface.commands, device)
            if not exec_ok:
                return False
            else:
                await asyncio.sleep(0.02)
        except Exception as ex:
            self.logger.error(ex)
            return False
        finally:
            if not exec_ok:
                self.logger.error(f'Failed to upgrade the user preinstalled version={info.script_version}!')
        (counter_after, status) = await device.get_user_preinstalled_counter()
        if status != StatusCode.SW9000:
            self.logger.error(f'Can not get user preinstalled counter after upgrade! code={status}')
            return False
        self.logger.info(f'The user preinstalled counter is {counter_after} after upgrade. Previous counter is {counter_before} before upgrade.')
        if device.is_in_root2:
            if not await device.exit_root2():
                self.logger.warning(f'Can not exit ROOT2 after upgrade user preinstalled.')
        self.logger.info(f'The user preinstalled version={info.script_version} has been upgraded successfully!')
        return True

    async def __do_execute_commands(self, commands: List[PatchCommand], device: SecurityDevice) -> bool:
        SELECT_NONE = bytes.fromhex('00A4040000')
        SELECT_ISD = bytes.fromhex('00A4040008A000000151000000')
        for cmd in commands:
            if isinstance(cmd, (POST_COMMAND, SEND_COMMAND, SEND_BPF_COMMAND)) and cmd.cmd == SELECT_NONE:
                cmd.cmd = SELECT_ISD
        rsp: ResponseAPDU = None
        i = 0
        total = len(commands)
        while i < total:
            cmd = commands[i]
            self.logger.debug(f'Execute[{i + 1}/{total}]: {cmd}')
            if isinstance(cmd, POST_COMMAND):
                rsp = await device.transmit(cmd.cmd)
            elif isinstance(cmd, SEND_COMMAND):
                rsp = await device.transmit(cmd.cmd)
                if not rsp.status_ok:
                    self.logger.error(f"Command failed at {i + 1}/{total}! RSP={(rsp if rsp else 'None')}")
                    return False
            elif isinstance(cmd, SEND_BPF_COMMAND):
                rsp = await device.transmit(cmd.cmd)
                if not rsp.status_ok:
                    self.logger.error(f"command failed at [{i + 1}/{total}]! RSP={(rsp if rsp else 'None')}")
                    return False
            elif isinstance(cmd, (CMPE, CMPNE, CMPL, CMPLE)):
                to_cmp = rsp.to_bytes()
                ok = cmd.compare(to_cmp)
                self.logger.debug(f'Execute[{i + 1}/{total}]: {cmd.repr(rsp)}, result={ok}')
                if ok:
                    i = cmd.jump
                    continue
            elif isinstance(cmd, GOTO):
                i = cmd.offset
                continue
            elif isinstance(cmd, PROTOCOL_INIT):
                await device.reset()
                pass
            elif isinstance(cmd, DELAY_CMD):
                await asyncio.sleep(cmd.delay)
            elif isinstance(cmd, NOP):
                pass
            elif isinstance(cmd, FINAL):
                return cmd.compare(rsp)
            i += 1
        return True
__all__ = [IUpgradeCosService.__name__, UpgradeCosService.__name__]