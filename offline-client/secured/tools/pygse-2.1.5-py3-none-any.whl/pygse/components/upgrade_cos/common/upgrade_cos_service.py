from abc import abstractmethod
from ....global_platform.base.security_device import SecurityDevice

class IUpgradeCosService:

    @abstractmethod
    async def upgrade(self, device: SecurityDevice, script: str, force: bool=False) -> bool:
        pass

    @abstractmethod
    def make_cos_upgrade_script(self) -> bool:
        pass
__all__ = [IUpgradeCosService.__name__]