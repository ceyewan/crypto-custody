import logging
from typing import Dict, List, Literal, Tuple, Union
from ....global_platform.base import ScpId, Key, KeySet, DesKeySet, AesKeySet, Sm4KeySet, DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet, KeySetAlgorithm, KeyType, StatusCode
from ....global_platform.kms.protocol import KmsClient
from ....base.common import service, ServiceParam
from ...configuration.common import IConfigurationService, CommonConfigurationKeys
from ..common import IRemoteKmsService

@service(IRemoteKmsService)
class RemoteKmsService(IRemoteKmsService):
    client: KmsClient = None

    def __init__(self, configuration_service: IConfigurationService=ServiceParam(IConfigurationService)) -> None:
        super().__init__()
        self.configuration_service = configuration_service
        configuration_service.register_on_changed(CommonConfigurationKeys.KMS_SERVER, self.__on_kms_address_changed)
        self.client = KmsClient(configuration_service.get_config(CommonConfigurationKeys.KMS_SERVER))
        self.logger = logging.getLogger(self.__class__.__name__)

    def __on_kms_address_changed(self, addr: str):
        if not self.client or self.client.kms_address != addr:
            self.client = KmsClient(addr)

    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Union[ScpId, int]=None, key_version_number: int=None) -> KeySet:
        try:
            if scp_id == ScpId.SCP02:
                algorithm = KeySetAlgorithm.DES
            elif scp_id == ScpId.SCP03:
                algorithm = KeySetAlgorithm.AES
            elif scp_id == ScpId.SCP04:
                algorithm = KeySetAlgorithm.SM4
            else:
                algorithm = None
            return await self.client.get_key_set(chip_id, security_domain, key_version_number, algorithm)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not get key set from {self.client.kms_address}')
            raise ex

    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: KeySetAlgorithm=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        try:
            return await self.client.new_key_set(chip_id, security_domain, key_version_number, algorithm, key_length, key_enc, key_mac, key_dek)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not new key set from {self.client.kms_address}')
            raise ex

    async def save_key_set(self, key_set: KeySet, override: bool=True):
        try:
            return await self.client.save_key_set(key_set.id, override)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not decrypt data with {self.client.kms_address}')
            raise ex

    async def delete_key_set_by_kvn(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int) -> int:
        try:
            return await self.client.delete_key_set_by_kvn(chip_id, security_domain, key_version_number)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not decrypt data with {self.client.kms_address}')
            raise ex

    async def derive_session_keys(self, key_set: Union[KeySet, DesKeySet, AesKeySet, Sm4KeySet], *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]:
        try:
            return await self.client.derive_session_keys(key_set.id, sequence_counter=sequence_counter, host_challenge=host_challenge, card_challenge=card_challenge, protocol_identifier=protocol_identifier, supported_protocol_configuration_list=supported_protocol_configuration_list)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not derive session keys from {self.client.kms_address}')
            raise ex

    async def encrypt_key_set(self, session_key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet], key_set: KeySet) -> KeySet:
        try:
            return await self.client.encrypt_key_set(session_key_set.id, key_set.id)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not encrypt data with {self.client.kms_address}')
            raise ex

    async def encrypt_key_set_aes(self, dek: Key, key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        try:
            return await self.client.encrypt_key_set_aes(dek.id, key_set.id)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not encrypt key set from {self.client.kms_address}')
            raise ex

    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        try:
            return await self.client.encrypt_key_set_des(dek, key_set.id)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not encrypt key set from {self.client.kms_address}')
            raise ex

    async def encrypt(self, key: Key, plain: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        try:
            return await self.client.encrypt(key.id, plain, algorithm, iv)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not encrypt data with {self.client.kms_address}')
            raise ex

    async def decrypt(self, key: Key, cipher: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        try:
            return await self.client.decrypt(key.id, cipher, algorithm, iv)
        except Exception as ex:
            self.logger.error(ex)
            self.logger.error(f'Can not decrypt data with {self.client.kms_address}')
            raise ex
__all__ = [RemoteKmsService.__name__]