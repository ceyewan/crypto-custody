import logging
from os import urandom
from typing import Dict, List, Literal, Tuple, Union
from Crypto.Cipher import AES
from ....base.crypto import aes_cbc_encrypt, des3_cbc_encrypt, sm4_cbc_encrypt
from ....base.common import service, ServiceParam, to_bytes, print_table, same, some
from ....global_platform.base import ScpId, KeyType, Key, KeySet, DesKeySet, AesKeySet, KeySetAlgorithm, DesKeyId, AesKeyId, Sm4KeyId, Sm4KeySet, DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet, calc_key_check_value
from ....global_platform.scp import scp02_derive_session_keys, scp03_derive_session_keys, scp04_derive_session_keys
from ...configuration.common import IConfigurationService, CommonConfigurationKeys
from ..common import ILocalKmsService

@service(ILocalKmsService)
class LocalKmsService(ILocalKmsService):
    key_sets: Dict[bytes, KeySet]

    def __init__(self, configuration_service: IConfigurationService=ServiceParam(IConfigurationService)) -> None:
        super().__init__()
        self.configuration_service = configuration_service
        self.logger = logging.getLogger(self.__class__.__name__)
        self.key_sets = {}

    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Union[ScpId, int]=None, key_version_number: int=None) -> KeySet:
        if scp_id == None and key_version_number != None:
            if key_version_number == self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_VERSION):
                scp_id = ScpId.SCP02
            elif key_version_number == self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_VERSION):
                scp_id = ScpId.SCP03
            elif key_version_number == self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_VERSION):
                scp_id = ScpId.SCP04
            elif key_version_number >= 32 and key_version_number <= 47:
                scp_id = ScpId.SCP02
            elif key_version_number >= 48 and key_version_number <= 63:
                scp_id = ScpId.SCP03
            elif key_version_number >= 80 and key_version_number <= 95:
                scp_id = ScpId.SCP04
        if scp_id == ScpId.SCP02:
            key_set = DesKeySet(chip_id, security_domain, key_version_number or self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_VERSION))
            key_set.id = bytes.fromhex('02020202020202020202020202020202')
            key_set.add_key(DesKeyId.KEY_ENC, self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_ENC))
            key_set.add_key(DesKeyId.KEY_MAC, self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_MAC))
            key_set.add_key(DesKeyId.KEY_DEK, self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_DEK))
        elif scp_id == ScpId.SCP03:
            key_set = AesKeySet(chip_id, security_domain, key_version_number or self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_VERSION))
            key_set.id = bytes.fromhex('03030303030303030303030303030303')
            key_set.add_key(AesKeyId.KEY_ENC, self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_ENC))
            key_set.add_key(AesKeyId.KEY_MAC, self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_MAC))
            key_set.add_key(AesKeyId.KEY_DEK, self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_DEK))
        elif scp_id == ScpId.SCP04:
            key_set = Sm4KeySet(chip_id, security_domain, key_version_number or self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_VERSION))
            key_set.id = bytes.fromhex('04040404040404040404040404040404')
            key_set.add_key(Sm4KeyId.KEY_ENC, self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_ENC))
            key_set.add_key(Sm4KeyId.KEY_MAC, self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_MAC))
            key_set.add_key(Sm4KeyId.KEY_DEK, self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_DEK))
        else:
            kvn = f'0x{key_version_number:02X}' if key_version_number != None else None
            raise Exception('\n'.join((f'Can not initialize key set with SCP={scp_id} and KVN={kvn}.', f'The SCP must be one of [02, 03, 04].', f'The key version number must be one of [0x{self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_VERSION):02X}, 0x{self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_VERSION):02X}, 0x{self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_VERSION):02X}].', f'Please check the key version number configuration using the command "pygse config ls". If the key version number is incorrect, update the configuration using "pygse config set aes.kvn/des.kvn/sm4.kvn {key_version_number:02X}".')))
        self.key_sets[key_set.id] = key_set
        return key_set

    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: KeySetAlgorithm=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        if key_length:
            if key_enc and len(key_enc) != key_length:
                raise Exception(f'The key_length={key_length} but len(key_enc)={len(key_enc)}.')
            if key_mac and len(key_mac) != key_length:
                raise Exception(f'The key_length={key_length} but len(key_mac)={len(key_mac)}.')
            if key_dek and len(key_dek) != key_length:
                raise Exception(f'The key_length={key_length} but len(key_dek)={len(key_dek)}.')
        else:
            lengths: List[int] = list(filter(lambda i: i, [len(key_enc) if key_enc else None, len(key_mac) if key_mac else None, len(key_dek) if key_dek else None]))
            if lengths:
                if not same(lengths):
                    raise Exception(f'The (len(key_enc), len(key_mac), len(key_dek)) are not the same.')
                key_length = lengths[0]
        if algorithm == KeySetAlgorithm.DES:
            key_length = key_length or 16
            assert key_length in (8, 16, 32), f'Invalid key_length={key_length}'
            key_set = DesKeySet(chip_id, security_domain, key_version_number or self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_VERSION))
            key_set.add_key(DesKeyId.KEY_ENC, key_enc or urandom(key_length))
            key_set.add_key(DesKeyId.KEY_MAC, key_mac or urandom(key_length))
            key_set.add_key(DesKeyId.KEY_DEK, key_dek or urandom(key_length))
        elif algorithm == KeySetAlgorithm.AES:
            key_length = key_length or 16
            assert key_length in (8, 16, 32), f'Invalid key_length={key_length}'
            key_set = AesKeySet(chip_id, security_domain, key_version_number or self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_VERSION))
            key_set.add_key(AesKeyId.KEY_ENC, key_enc or urandom(key_length))
            key_set.add_key(AesKeyId.KEY_MAC, key_mac or urandom(key_length))
            key_set.add_key(AesKeyId.KEY_DEK, key_dek or urandom(key_length))
        elif algorithm == KeySetAlgorithm.SM4:
            key_length = key_length or 16
            assert key_length in (16,), f'Invalid key_length={key_length}'
            key_set = Sm4KeySet(chip_id, security_domain, key_version_number or self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_VERSION))
            key_set.add_key(Sm4KeyId.KEY_ENC, key_enc or urandom(key_length))
            key_set.add_key(Sm4KeyId.KEY_MAC, key_mac or urandom(key_length))
            key_set.add_key(Sm4KeyId.KEY_DEK, key_dek or urandom(key_length))
        else:
            raise Exception(f'Unsupported Algorithm={algorithm} of Key Set.')
        return key_set

    async def save_key_set(self, key_set: KeySet) -> KeySet:
        if key_set.algorithm == KeySetAlgorithm.DES:
            scp02_enc = key_set.get_key(DesKeyId.KEY_ENC).key_value
            scp02_mac = key_set.get_key(DesKeyId.KEY_MAC).key_value
            scp02_dek = key_set.get_key(DesKeyId.KEY_DEK).key_value
            if scp02_dek and scp02_enc and scp02_mac:
                data = [[CommonConfigurationKeys.DES_KEY_ENC.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_ENC)), hex(scp02_enc)], [CommonConfigurationKeys.DES_KEY_MAC.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_MAC)), hex(scp02_mac)], [CommonConfigurationKeys.DES_KEY_DEK.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_DEK)), hex(scp02_dek)], [CommonConfigurationKeys.DES_KEY_VERSION.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_VERSION)), hex(key_set.key_version_number)]]
                self.configuration_service.set_config(CommonConfigurationKeys.DES_KEY_ENC, scp02_enc)
                self.configuration_service.set_config(CommonConfigurationKeys.DES_KEY_MAC, scp02_mac)
                self.configuration_service.set_config(CommonConfigurationKeys.DES_KEY_DEK, scp02_dek)
                self.configuration_service.set_config(CommonConfigurationKeys.DES_KEY_VERSION, key_set.key_version_number)
                print_table(['配置项', '旧值', '新值'], data, '已更新本地密钥配置')
            else:
                self.logger.error(f'无法保存不完整的密钥集！enc={hex(scp02_enc)}, mac={hex(scp02_mac)}, dek={hex(scp02_dek)}')
        elif key_set.algorithm == KeySetAlgorithm.AES:
            scp03_enc = key_set.get_key(AesKeyId.KEY_ENC).key_value
            scp03_mac = key_set.get_key(AesKeyId.KEY_MAC).key_value
            scp03_dek = key_set.get_key(AesKeyId.KEY_DEK).key_value
            if scp03_dek and scp03_enc and scp03_mac:
                data = [[CommonConfigurationKeys.AES_KEY_ENC.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_ENC)), hex(scp03_enc)], [CommonConfigurationKeys.AES_KEY_MAC.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_MAC)), hex(scp03_mac)], [CommonConfigurationKeys.AES_KEY_DEK.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_DEK)), hex(scp03_dek)], [CommonConfigurationKeys.AES_KEY_VERSION.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_VERSION)), hex(key_set.key_version_number)]]
                self.configuration_service.set_config(CommonConfigurationKeys.AES_KEY_ENC, scp03_enc)
                self.configuration_service.set_config(CommonConfigurationKeys.AES_KEY_MAC, scp03_mac)
                self.configuration_service.set_config(CommonConfigurationKeys.AES_KEY_DEK, scp03_dek)
                self.configuration_service.set_config(CommonConfigurationKeys.AES_KEY_VERSION, key_set.key_version_number)
                print_table(['配置项', '旧值', '新值'], data, '已更新本地密钥配置')
            else:
                self.logger.error(f'无法保存不完整的密钥集！enc={hex(scp03_enc)}, mac={hex(scp03_mac)}, dek={hex(scp03_dek)}')
        elif key_set.algorithm == KeySetAlgorithm.SM4:
            scp04_enc = key_set.get_key(Sm4KeyId.KEY_ENC).key_value
            scp04_mac = key_set.get_key(Sm4KeyId.KEY_MAC).key_value
            scp04_dek = key_set.get_key(Sm4KeyId.KEY_DEK).key_value
            if scp04_dek and scp04_enc and scp04_mac:
                data = [[CommonConfigurationKeys.SM4_KEY_ENC.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_ENC)), hex(scp04_enc)], [CommonConfigurationKeys.SM4_KEY_MAC.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_MAC)), hex(scp04_mac)], [CommonConfigurationKeys.SM4_KEY_DEK.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_DEK)), hex(scp04_dek)], [CommonConfigurationKeys.SM4_KEY_VERSION.key, hex(self.configuration_service.get_config(CommonConfigurationKeys.SM4_KEY_VERSION)), hex(key_set.key_version_number)]]
                self.configuration_service.set_config(CommonConfigurationKeys.SM4_KEY_ENC, scp04_enc)
                self.configuration_service.set_config(CommonConfigurationKeys.SM4_KEY_MAC, scp04_mac)
                self.configuration_service.set_config(CommonConfigurationKeys.SM4_KEY_DEK, scp04_dek)
                self.configuration_service.set_config(CommonConfigurationKeys.SM4_KEY_VERSION, key_set.key_version_number)
                print_table(['配置项', '旧值', '新值'], data, '已更新本地密钥配置')
            else:
                self.logger.error(f'无法保存不完整的密钥集！enc={hex(scp04_enc)}, mac={hex(scp04_mac)}, dek={hex(scp04_dek)}')
        return key_set

    async def delete_key_set_by_kvn(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int) -> int:
        return 0

    async def derive_session_keys(self, key_set: KeySet, *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet]:
        if key_set.algorithm == KeySetAlgorithm.DES:
            return scp02_derive_session_keys(key_set, sequence_counter)
        if key_set.algorithm == KeySetAlgorithm.AES:
            return scp03_derive_session_keys(key_set, host_challenge, card_challenge)
        if key_set.algorithm == KeySetAlgorithm.SM4:
            return scp04_derive_session_keys(key_set, host_challenge, card_challenge, protocol_identifier, supported_protocol_configuration_list)
        raise Exception(f'Unsupported Key Set with algorithm={key_set.algorithm}')

    async def encrypt_key_set(self, session_key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet], key_set: KeySet) -> KeySet:
        if some(key_set.keys.values(), lambda k: not k.key_value):
            raise Exception(f'the key value of the key component in the key set is required by local KMS.')
        dek = to_bytes(session_key_set.dek.key_value)
        encrypted = key_set.clone()
        if session_key_set.algorithm == KeySetAlgorithm.DES:
            for key in encrypted.keys.values():
                key.key_check_value = calc_key_check_value(key)
                key.key_value = des3_cbc_encrypt(dek, key.key_value)
        elif session_key_set.algorithm == KeySetAlgorithm.AES:
            for key in encrypted.keys.values():
                key.key_check_value = calc_key_check_value(key)
                key.key_value = aes_cbc_encrypt(dek, key.key_value)
        elif session_key_set.algorithm == KeySetAlgorithm.SM4:
            for key in encrypted.keys.values():
                key.key_check_value = calc_key_check_value(key)
                key.key_value = sm4_cbc_encrypt(dek, key.key_value)
        else:
            raise Exception(f'encrypt_key_set currently does not support session_key_set.algorithm={session_key_set.algorithm}')
        return encrypted

    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        dek = to_bytes(dek)
        if some(key_set.keys.values(), lambda k: not k.key_value):
            raise Exception(f'the key value of the key component in the key set is required by local KMS.')
        return [(key.key_type, des3_cbc_encrypt(dek, key.key_value), calc_key_check_value(key)) for key in sorted(key_set.keys.values(), key=lambda k: k.key_identifier)]

    async def encrypt_key_set_aes(self, dek: Key, key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        if not dek.key_value:
            raise Exception(f'dek.key_value is required by local KMS.')
        if some(key_set.keys.values(), lambda k: not k.key_value):
            raise Exception(f'the key value of the key component in the key set is required by local KMS.')
        return [(key.key_type, aes_cbc_encrypt(dek.key_value, key.key_value, iv=bytes(16)), calc_key_check_value(key)) for key in sorted(key_set.keys.values(), key=lambda k: k.key_identifier)]

    async def encrypt(self, dek: Key, plain: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        if not dek or not dek.key_value:
            raise Exception('Bad key!')
        cipher = None
        (enc_mode, mode, padding, *_) = algorithm.split('/') + [None, None, None]
        if enc_mode == 'AES':
            if mode == 'CBC':
                cipher = AES.new(dek.key_value, AES.MODE_CBC, iv=to_bytes(iv))
                return cipher.encrypt(plain)
        raise Exception('Unsupported encryption mode')

    async def decrypt(self, dek: Key, cipher: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        if not dek or not dek.key_value:
            raise Exception('Bad key!')
        cipher = None
        (enc_mode, mode, padding, *_) = algorithm.split('/') + [None, None, None]
        if enc_mode == 'AES':
            if mode == 'CBC':
                cipher = AES.new(dek.key_value, AES.MODE_CBC, iv=to_bytes(iv))
                return cipher.decode(cipher)
        raise Exception('Unsupported encryption mode')
__all__ = [LocalKmsService.__name__]