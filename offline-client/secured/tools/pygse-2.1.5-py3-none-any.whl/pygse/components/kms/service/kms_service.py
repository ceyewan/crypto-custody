from typing import Dict, List, Literal, Tuple, Union
from ....global_platform.base import Key, KeySet, AesKeySet, DesKeySet, Sm4KeySet, KeySetAlgorithm, KeyType, ScpId, DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet
from ....base.common import service, ServiceParam, IInstanceService
from ...configuration.common import IConfigurationService, CommonConfigurationKeys
from ..common import IKmsService, IRemoteKmsService, ILocalKmsService

@service(IKmsService)
class KmsService(IKmsService):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService), configuration_service: IConfigurationService=ServiceParam(IConfigurationService)) -> None:
        super().__init__()
        self.instance_service = instance_service
        self.configuration_service = configuration_service
    __inner_service: Union[IRemoteKmsService, ILocalKmsService] = None

    @property
    def service(self):
        if self.__inner_service:
            return self.__inner_service
        enable_remote: bool = self.configuration_service.get_config(CommonConfigurationKeys.KMS_ENABLE_REMOTE)
        if enable_remote:
            kms_server: bool = self.configuration_service.get_config(CommonConfigurationKeys.KMS_SERVER)
            if not kms_server:
                raise Exception(f'未配置KMS服务。请使用命令 "pygse config set {CommonConfigurationKeys.KMS_SERVER.key} [URL]" 配置KMS服务地址。')
            self.__inner_service = self.instance_service.get(IRemoteKmsService)
        else:
            self.__inner_service = self.instance_service.get(ILocalKmsService)
        return self.__inner_service

    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Union[ScpId, int]=None, key_version_number: int=None) -> KeySet:
        return await self.service.init_key_set(chip_id, security_domain, scp_id, key_version_number)

    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: KeySetAlgorithm=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        return await self.service.new_key_set(chip_id, security_domain, key_version_number, algorithm, key_length, key_enc, key_mac, key_dek)

    async def save_key_set(self, key_set: KeySet) -> KeySet:
        return await self.service.save_key_set(key_set)

    async def delete_key_set_by_kvn(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int) -> int:
        return await self.service.delete_key_set_by_kvn(chip_id, security_domain, key_version_number)

    async def derive_session_keys(self, key_set: Union[KeySet, DesKeySet, AesKeySet, Sm4KeySet], *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]:
        return await self.service.derive_session_keys(key_set, sequence_counter=sequence_counter, host_challenge=host_challenge, card_challenge=card_challenge, protocol_identifier=protocol_identifier, supported_protocol_configuration_list=supported_protocol_configuration_list)

    async def encrypt_key_set(self, session_key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet], key_set: KeySet) -> KeySet:
        return await self.service.encrypt_key_set(session_key_set, key_set)

    async def encrypt_key_set_aes(self, dek: Key, key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        return await self.service.encrypt_key_set_aes(dek, key_set)

    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        return await self.service.encrypt_key_set_des(dek, key_set)

    async def encrypt(self, key: Key, plain: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        return await self.service.encrypt(key, plain, algorithm, iv)

    async def decrypt(self, key: Key, cipher: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        return await self.service.decrypt(key, cipher, algorithm, iv)