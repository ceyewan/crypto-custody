from abc import abstractmethod
from typing import Dict, List, Literal, Tuple, Union, overload
from ....global_platform.base import Key, KeySetAlgorithm, KeySet, DesKeySet, AesKeySet, ScpId, KeyType, Sm4KeySet, DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet

class IKmsService:

    @overload
    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Literal[ScpId.SCP02, 2], key_version_number: int=None) -> DesKeySet:
        pass

    @overload
    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Literal[ScpId.SCP03, 3], key_version_number: int=None) -> AesKeySet:
        pass

    @overload
    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Literal[ScpId.SCP04, 4], key_version_number: int=None) -> Sm4KeySet:
        pass

    @overload
    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Union[ScpId, int]=None, key_version_number: int=None) -> KeySet:
        pass

    @abstractmethod
    async def init_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], scp_id: Union[ScpId, int]=None, key_version_number: int=None) -> KeySet:
        pass

    @abstractmethod
    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: KeySetAlgorithm=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        pass

    @overload
    async def derive_session_keys(self, key_set: DesKeySet, *, sequence_counter: Union[str, bytes]) -> DesSessionKeySet:
        pass

    @overload
    async def derive_session_keys(self, key_set: AesKeySet, *, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes]) -> AesSessionKeySet:
        pass

    @overload
    async def derive_session_keys(self, key_set: Sm4KeySet, *, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Sm4SessionKeySet:
        pass

    @abstractmethod
    async def derive_session_keys(self, key_set: Union[KeySet, DesKeySet, AesKeySet, Sm4KeySet], *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]:
        pass

    @abstractmethod
    async def encrypt_key_set(self, session_key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet], key_set: KeySet) -> KeySet:
        pass

    @abstractmethod
    async def encrypt_key_set_aes(self, dek: Key, key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        pass

    @abstractmethod
    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set: KeySet) -> List[Tuple[KeyType, bytes, bytes]]:
        pass

    async def save_key_set(self, key_set: KeySet):
        pass

    async def delete_key_set(self, key_set: KeySet):
        pass

    async def delete_key_set_by_kvn(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int) -> int:
        pass

    async def encrypt(self, key: Key, plain: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        pass

    async def decrypt(self, key: Key, cipher: Union[str, bytes], algorithm: str, iv: Union[str, bytes]=None) -> bytes:
        pass

class ILocalKmsService(IKmsService):
    pass

class IRemoteKmsService(IKmsService):
    pass
__all__ = [IKmsService.__name__, ILocalKmsService.__name__, IRemoteKmsService.__name__]