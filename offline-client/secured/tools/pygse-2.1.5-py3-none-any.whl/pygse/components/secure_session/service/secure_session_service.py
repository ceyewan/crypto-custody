import logging
from typing import Dict, Union
from ....base.common import IInstanceService, ServiceParam, service
from ....global_platform.base.security_device import SecurityDevice
from ....global_platform.base.apdu import *
from ....global_platform.scp.common import SecureLevel
from ....global_platform.session import SecureSession, SecureSession, SecureSessionOptions
from ...kms.common import IKmsService
from ..common import ISecureSessionService

@service(ISecureSessionService)
class SecureSessionService(ISecureSessionService):
    secure_sessions: Dict[str, SecureSession] = None

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService), kms_service: IKmsService=ServiceParam(IKmsService)) -> None:
        super().__init__()
        self.instance_service = instance_service
        self.kms_service = kms_service
        self.secure_sessions = {}
        self.logger = logging.getLogger(self.__class__.__name__)

    async def create(self, device: SecurityDevice, key_version_number: int=None, aid: Union[str, bytes]=None, sd: Union[str, bytes]=None, secure_level: SecureLevel=SecureLevel.C_MAC) -> SecureSession:
        current = self.get(device)
        if current:
            if current.scp_id == ScpId.SCP00 and key_version_number < 0:
                return current
            if not aid and (not key_version_number):
                return current
            if aid == current.options.aid and current.sd_key_set and (current.sd_key_set.key_version_number == key_version_number):
                return current
        session = SecureSession(device, self.kms_service, SecureSessionOptions(sd=sd, aid=aid, key_version_number=key_version_number, secure_level=secure_level))
        self.secure_sessions[device.name] = session
        return session

    def get(self, device: SecurityDevice) -> Union[SecureSession, None]:
        if not device:
            return None
        return self.secure_sessions.get(device.name, None)
__all__ = [ISecureSessionService.__name__, SecureSession.__name__]