from abc import abstractmethod
from typing import Union
from ....global_platform.base.security_device import SecurityDevice
from ....global_platform.scp.common import SecureLevel
from ....global_platform.session import SecureSession

class ISecureSessionService:

    @abstractmethod
    async def create(self, device: SecurityDevice, key_version_number: int=None, aid: Union[str, bytes]=None, sd: Union[str, bytes]=None, secure_level: SecureLevel=SecureLevel.C_MAC) -> SecureSession:
        pass

    @abstractmethod
    def get(self, device: SecurityDevice) -> SecureSession:
        pass
__all__ = [ISecureSessionService.__name__]