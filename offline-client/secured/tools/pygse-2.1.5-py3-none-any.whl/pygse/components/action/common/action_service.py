from abc import abstractmethod
from concurrent.futures import Future
import logging
from typing import Any, Dict, List, Type, Union, overload

class IAction:

    def __init__(self) -> None:
        self.logger = logging.getLogger(self.__class__.__name__)

    @abstractmethod
    async def run(self, *args, **kwargs) -> Any:
        pass

class ActionInfo:

    def __init__(self, id: str, action: Union[IAction, Type[IAction]], *args, **kwargs):
        self.id = id
        self.action = action
        self.args = args
        self.kwargs = kwargs
GLOBAL_REGISTERED_ACTIONS: Dict[str, ActionInfo] = {}

class IActionService:
    registered_actions: Dict[str, ActionInfo]

    def __init__(self) -> None:
        self.logger = logging.getLogger(self.__class__.__name__)
        self.registered_actions = GLOBAL_REGISTERED_ACTIONS.copy()

    @abstractmethod
    async def run(self, action: Union[str, IAction, Type[IAction]], *args, **kwargs) -> Future:
        pass

    @abstractmethod
    async def run_until_complete(self, action: Union[str, IAction, Type[IAction]], *args, **kwargs) -> Any:
        pass

    @overload
    def register(self, id: str, action: Union[IAction, Type[IAction]], *args, **kwargs):
        pass

def action(id: str, *args, **kwargs):

    def inner(cls):
        id_ = id.upper()
        if id_ in GLOBAL_REGISTERED_ACTIONS:
            logging.warning(f'Action {id} has already been registered! It will be overridden by the new registration!')
        GLOBAL_REGISTERED_ACTIONS[id_] = ActionInfo(id, cls, *args, **kwargs)
        return cls
    return inner
__all__ = [IAction.__name__, ActionInfo.__name__, IActionService.__name__, action.__name__]