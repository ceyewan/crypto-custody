import asyncio
from typing import Any, Type, Union
from ....base.common import service, ServiceParam, IInstanceService
from ..common import IAction, ActionInfo, IActionService, action

@service(IActionService)
class ActionService(IActionService):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, action: Union[str, IAction, Type[IAction]], *args, **kwargs) -> None:
        act = None
        if isinstance(action, str):
            registered = self.registered_actions.get(action.upper(), None)
            if not registered:
                return
            act = registered.action
            if not args and registered.args:
                args = registered.args
            if not kwargs and registered.kwargs:
                kwargs = registered.kwargs
        if isinstance(act, type) and issubclass(act, IAction):
            act = self.instance_service.instance(act)
        elif isinstance(act, IAction):
            pass
        else:
            raise Exception(f'Bad argument of action!')
        return asyncio.run_coroutine_threadsafe(act.run(*args, **kwargs), asyncio.get_event_loop())

    async def run_until_complete(self, action: Union[str, IAction, Type[IAction]], *args, **kwargs) -> Any:
        return await asyncio.wrap_future(await self.run(action, *args, **kwargs))

    def register(self, id: str, action: Union[IAction, Type[IAction]], *args, **kwargs):
        id_ = id.upper()
        if id_ in self.registered_actions:
            self.logger.warning(f'Action {id} has already been registered! It will be overridden by the new registration!')
        self.registered_actions[id_] = ActionInfo(id_, action, *args, **kwargs)
__all__ = [IAction.__name__, ActionInfo.__name__, IActionService.__name__, ActionService.__name__, action.__name__]