import json
import os
from typing import Any, Dict, List, Literal, Tuple, Union
from ....base.common import to_bytes, parse_int
from ....base.common import ReadonlyProperty, Application, service
from ..common import IConfigurationService, ConfigurationDescriptor

@service(IConfigurationService)
class ConfigurationService(IConfigurationService):
    runtime_storage: Dict[str, Any]
    user_storage: Dict[str, Any]

    def __init__(self) -> None:
        super().__init__()
        ReadonlyProperty.set(self.__class__.file, self, os.path.join(self.user_data_dir, 'settings.json'))
        self.runtime_storage = {}
        self.user_storage = {}
        self.load()
        ReadonlyProperty.set(self.__class__.app_data_dir, self, self.get_config('app_data_dir') or self.user_data_dir)
        os.makedirs(self.app_data_dir, exist_ok=True)

    def load(self):
        if not os.path.exists(self.file):
            self.logger.debug(f'{self.file} does not exits.')
            return
        with open(self.file, encoding='utf-8') as f:
            self.user_storage = json.load(f)
            self.logger.debug(f'Settings loaded from {self.file}.')

    def save(self):
        if not os.path.exists(os.path.dirname(self.file)):
            os.makedirs(os.path.dirname(self.file), exist_ok=True)
        with open(self.file, 'w', encoding='utf-8') as f:
            json.dump(self.user_storage, f)

    def get_config(self, key: Union[str, ConfigurationDescriptor], scope: Literal['runtime', 'user']=None) -> Any:
        key = key if isinstance(key, str) else key.key
        if scope == 'runtime':
            if key in self.runtime_storage:
                return self.runtime_storage.get(key, None)
            elif key in self.registered_configs:
                return self.registered_configs.get(key).default_value
        elif scope == 'runtime':
            if key in self.user_storage:
                return self.user_storage.get(key, None)
            elif key in self.registered_configs:
                return self.registered_configs.get(key).default_value
        else:
            if key in self.runtime_storage:
                return self.runtime_storage.get(key, None)
            if key in self.user_storage:
                return self.user_storage.get(key, None)
            elif key in self.registered_configs:
                return self.registered_configs.get(key).default_value
        return None

    def set_config(self, key: Union[str, ConfigurationDescriptor], value: Any, scope: Literal['runtime', 'user', 'all']=None):
        key = key if isinstance(key, str) else key.key
        storages: List[Tuple[Dict, str]] = []
        if scope == 'runtime':
            storages.append((self.runtime_storage, 'RUNTIME'))
        elif scope == 'all':
            storages.append((self.runtime_storage, 'RUNTIME'))
            storages.append((self.user_storage, 'USER'))
        else:
            storages.append((self.user_storage, 'USER'))
        desc = self.registered_configs.get(key, None)
        if desc and value != None:
            value = desc.parse_value(value)
        changed = False
        for (storage, scope) in storages:
            if value != None:
                if value != self.get_config(key, scope):
                    changed = True
                    storage.update({key: value})
                    self.logger.info(f'set {key}={(desc.format(value) if desc else format(value))}')
            else:
                if key in storage:
                    changed = True
                    storage.pop(key)
                self.logger.info(f'unset {key}')
        if changed:
            self.save()
            Application.call_soon(lambda : self.on_changed(key))
__all__ = [ConfigurationService.__name__]