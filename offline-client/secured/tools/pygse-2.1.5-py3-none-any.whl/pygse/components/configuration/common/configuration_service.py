from abc import abstractmethod
from enum import Enum
import logging
import os
import sys
import builtins
from typing import Any, Callable, Dict, List, Literal, Tuple, TypeVar, Union, overload
from ....base.common import ReadonlyProperty, AsyncEvent, to_bytes, parse_int
T = TypeVar('T')

class ConfigurationDescriptor:
    key: str = None
    type: Literal['int', 'str', 'bytes', 'json', 'bool'] = 'str'
    description: str = None
    default_value: str = None
    order: int = 0
    fmt: str = None

    def __init__(self, key: str=None, type: Literal['int', 'str', 'bytes', 'json', 'bool']='str', desc: str=None, default_value=None, order: int=None, fmt: str=None) -> None:
        self.key = key
        self.type = type
        self.description = desc
        self.default_value = self.parse_value(default_value)
        self.order = order or 0
        self.fmt = fmt

    def format(self, value):
        if value == None:
            return ''
        return self.fmt.format(value) if self.fmt else format(value)

    def parse_value(self, value):
        if value == None:
            return None
        if self.type == 'bool':
            if isinstance(value, str):
                if value.lower() == 'true':
                    value = True
                elif value.lower() == 'false':
                    value = False
                else:
                    value = bool(int(value))
            else:
                value = bool(value)
        elif self.type == 'bytes':
            value = to_bytes(value)
        elif self.type == 'int':
            value = parse_int(value)
        return value

class IConfigurationService:
    registered_configs: Dict[str, ConfigurationDescriptor] = {}

    def __init__(self) -> None:
        self.logger = logging.getLogger(self.__class__.__name__)
        if sys.platform == 'win32':
            user_data_dir = os.path.normpath(os.path.join(os.path.expanduser('~'), f'AppData/Roaming/Goodix/{builtins.__product__}'))
        else:
            user_data_dir = os.path.normpath(os.path.join(os.path.expanduser('~'), f'.goodix/{builtins.__product__}'))
        os.makedirs(user_data_dir, exist_ok=True)
        ReadonlyProperty.set(self.__class__.user_data_dir, self, user_data_dir)
        ReadonlyProperty.set(self.__class__.on_changed, self, AsyncEvent())
    file: str = ReadonlyProperty()
    user_data_dir: str = ReadonlyProperty()
    app_data_dir: str = ReadonlyProperty()
    on_changed: AsyncEvent[Tuple[str, Any]] = ReadonlyProperty()

    def register_on_changed(self, keys: Union[str, List[str]], cb: Callable[[Any], Any]):
        if not keys:
            return
        keys = keys if isinstance(keys, list) else [keys]

        def inner(key: str, value):
            if key not in keys:
                return
            cb(value)
        self.on_changed += inner

    @abstractmethod
    def get_config(self, key: Union[str, ConfigurationDescriptor], scope: Literal['runtime', 'user']=None) -> T:
        pass

    @abstractmethod
    def set_config(self, key: Union[str, ConfigurationDescriptor], value: Any, scope: Literal['runtime', 'user']=None):
        pass

@overload
def register_config(item: ConfigurationDescriptor):
    pass

@overload
def register_config(key: str=None, type: Literal['int', 'str', 'bytes', 'json', 'bool']='str', desc: str=None, default_value=None):
    pass

def register_config(key_or_item: Union[str, ConfigurationDescriptor]=None, type: Literal['int', 'str', 'bytes', 'json', 'bool']='str', desc: str=None, default_value=None):
    if isinstance(key_or_item, str):
        item = ConfigurationDescriptor(key_or_item, type, desc, default_value)
    else:
        item = key_or_item
    assert isinstance(item, ConfigurationDescriptor) and item.key, f'Bad Config key={item.key}!'
    if item.key in IConfigurationService.registered_configs:
        logging.warning(f'Config key={item.key} already registered!')
    IConfigurationService.registered_configs[item.key] = item
__all__ = [IConfigurationService.__name__, ConfigurationDescriptor.__name__, register_config.__name__]