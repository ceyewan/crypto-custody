from .configuration_service import ConfigurationDescriptor, register_config

class CommonConfigurationKeys:
    KMS_SERVER = ConfigurationDescriptor('kms.server', 'str', 'KMS服务URL地址。', '', 100)
    KMS_ENABLE_REMOTE = ConfigurationDescriptor('kms.enable-remote', 'bool', '配置是否使用远程KMS服务。默认使用本地KMS。', False, 101)
    DES_KEY_VERSION = ConfigurationDescriptor('des.kvn', 'int', 'DES(SCP02)的密钥版本号。', 32, 200, '0x{:02X}')
    DES_KEY_ENC = ConfigurationDescriptor('des.enc', 'str', 'DES KEY-ENC(SCP02)，当不使用远程KMS服务时，使用此密钥派生S-ENC会话密钥。', '404142434445464748494A4B4C4D4E4F', 201)
    DES_KEY_MAC = ConfigurationDescriptor('des.mac', 'str', 'DES KEY-MAC(SCP02)，当不使用远程KMS服务时，使用此密钥派生S-CMAC和R-MAC会话密钥。', '404142434445464748494A4B4C4D4E4F', 202)
    DES_KEY_DEK = ConfigurationDescriptor('des.dek', 'str', 'DES KEY-DEK(SCP02)，当不使用远程KMS服务时，使用此密钥派生S-DEK会话密钥。', '404142434445464748494A4B4C4D4E4F', 203)
    AES_KEY_VERSION = ConfigurationDescriptor('aes.kvn', 'int', 'AES(SCP03)的密钥版本号。', 48, 300, '0x{:02X}')
    AES_KEY_ENC = ConfigurationDescriptor('aes.enc', 'str', 'AES KEY-ENC(SCP03)密钥，当不使用远程KMS服务时，使用此密钥派生S-ENC会话密钥。', '404142434445464748494A4B4C4D4E4F', 301)
    AES_KEY_MAC = ConfigurationDescriptor('aes.mac', 'str', 'AES KEY-MAC(SCP03)密钥，当不使用远程KMS服务时，使用此密钥派生S-CMAC和R-MAC会话密钥。', '404142434445464748494A4B4C4D4E4F', 302)
    AES_KEY_DEK = ConfigurationDescriptor('aes.dek', 'str', 'AES KEY-DEK(SCP03)密钥，当不使用远程KMS服务时，使用此密钥对敏感信息加密。', '404142434445464748494A4B4C4D4E4F', 303)
    SM4_KEY_VERSION = ConfigurationDescriptor('sm4.kvn', 'int', 'SM4(SCP04)的密钥版本号。', 80, 500, '0x{:02X}')
    SM4_KEY_ENC = ConfigurationDescriptor('sm4.enc', 'str', 'SM4 KEY-ENC(SCP04)密钥，当不使用远程KMS服务时，使用此密钥派生S-ENC会话密钥。', '404142434445464748494A4B4C4D4E4F', 501)
    SM4_KEY_MAC = ConfigurationDescriptor('sm4.mac', 'str', 'SM4 KEY-MAC(SCP04)密钥，当不使用远程KMS服务时，使用此密钥派生S-CMAC和R-MAC会话密钥。', '404142434445464748494A4B4C4D4E4F', 502)
    SM4_KEY_DEK = ConfigurationDescriptor('sm4.dek', 'str', 'SM4 KEY-DEK(SCP04)密钥，当不使用远程KMS服务时，使用此密钥对敏感信息加密。', '404142434445464748494A4B4C4D4E4F', 503)

    @staticmethod
    def register_all():
        for item in CommonConfigurationKeys.__dict__.values():
            if isinstance(item, ConfigurationDescriptor):
                register_config(item)
CommonConfigurationKeys.register_all()
__all__ = [CommonConfigurationKeys.__name__]