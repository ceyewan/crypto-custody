import asyncio
import logging
from socket import socket
from ....base.common import service, IInstanceService, ServiceParam, print_table, AsyncSocketServer, get_local_ip, CustomEventLoop
from ....base.io.aysnc import SocketIO
from ....base.device import DeviceType, DeviceInfo, QcsDevice, AclPassiveDevice, QcsPacket, QcsResponsePacket, QcsApiId, QcsMessageType, QcsPacketHandler, AclPacketHandler, AclCommand, AclResponse
from ....base.device.qcs import QcsMessageId, NFC_CHANGE_TRANSPARENT_MODE_CMD, NFC_SE_TYPE, NFC_TRANSPARENT_MODE
from ..common.share_for_dh_service import IShareForDhService

class PassiveAclToQcsAdapter:
    remote_stream: SocketIO = None
    remote_handler: AclPacketHandler = None

    def __init__(self, device: QcsDevice) -> None:
        device.target_se = NFC_SE_TYPE.ESE
        self.passive_device = AclPassiveDevice(device)

    async def bind(self, client: socket):
        if self.remote_stream:
            await self.remote_handler.close()
        self.remote_stream = SocketIO(client)
        await self.remote_stream.open()
        self.remote_handler = AclPacketHandler(self.remote_stream, self.__on_remote_message)
        self.remote_handler.logger.name = f'SE({self.remote_handler.logger.name})'

    async def close(self):
        if self.remote_stream:
            await self.remote_stream.close()
            self.remote_stream = None

    async def __on_remote_message(self, cmd: AclCommand):
        if self.passive_device.device.closed:
            await self.remote_handler.send(AclResponse(err_terminal_code=-1, terminal_description='Device closed!'))
            return
        try:
            rsp = await self.passive_device.handle_request(cmd)
        except Exception as ex:
            pass
        if rsp:
            await self.remote_handler.send(rsp)

class PassiveNfccToQcsAdapter:
    remote_stream: SocketIO = None
    remote_handler: QcsPacketHandler = None

    def __init__(self, device: QcsDevice) -> None:
        self.passive_device = device
        device.on_message.register(self.__on_device_message)

    async def bind(self, client: socket):
        if self.remote_stream:
            await self.remote_handler.close()
        self.remote_stream = SocketIO(client)
        await self.remote_stream.open()
        self.remote_handler = QcsPacketHandler(self.remote_stream, self.__on_remote_message)
        self.remote_handler.logger.name = f'NFCC({self.remote_handler.logger.name})'

    async def close(self):
        if self.remote_stream:
            await self.remote_stream.close()
            self.remote_stream = None

    async def __on_remote_message(self, cmd: QcsPacket):
        if self.passive_device.closed:
            await self.remote_handler.send(QcsResponsePacket(cmd.msg_id, 255))
            return
        try:
            rsp = await self.passive_device.qcs_request(cmd)
        except Exception as ex:
            pass
        if rsp:
            await self.remote_handler.send(rsp)

    async def __on_device_message(self, pkg: QcsPacket):
        if not self.remote_handler:
            return
        if pkg.api_id in (QcsApiId.NFC_LOG_CONFIG, QcsApiId.NFC_TRANSMIT_APDU):
            return
        if pkg.mt == QcsMessageType.NOTIFICATION and (not self.remote_handler.closed):
            await self.remote_handler.send(pkg)

@service(IShareForDhService)
class ShareForDhService(IShareForDhService):
    device: QcsDevice = None
    se_channel: PassiveAclToQcsAdapter = None
    se_server: AsyncSocketServer = None
    nfcc_channel: PassiveNfccToQcsAdapter = None
    nfcc_server: AsyncSocketServer = None

    def __init__(self, instanceService: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)

    async def start_share(self, device: DeviceInfo, se_port: int=None, nfcc_port: int=None):
        if not device:
            raise Exception('没有共享的设备。')
        if device.type != DeviceType.SERIAL:
            raise Exception('为DH共享的设备目前只支持QCS串口。')
        self.device = QcsDevice(device)
        try:
            await self.device.open()
            await self.device.qcs_request(NFC_CHANGE_TRANSPARENT_MODE_CMD(NFC_TRANSPARENT_MODE.NCI_AND_NDP))
            await self.device.qcs_wait_for_ntf(QcsMessageId.NFC_CHANGE_TRANSPARENT_MODE_NTF, 5)
        except Exception:
            await self.device.close()
            raise

        async def on_device_closed(dev: QcsDevice):
            self.logger.info(f'{dev.name} closed!')
        self.device.on_close.register(on_device_closed)
        self.se_channel = PassiveAclToQcsAdapter(self.device)
        self.socket_server_event_loop = CustomEventLoop('SocketServerEventLoop')
        self.se_server = AsyncSocketServer('SE Server', se_port if se_port != None else 44944, event_loop=self.socket_server_event_loop.event_loop)
        self.se_server.on_client_connected.register(self.on_se_client_connected)
        self.se_server.start()
        self.nfcc_channel = PassiveNfccToQcsAdapter(self.device)
        self.nfcc_server = AsyncSocketServer('NFCC Server', nfcc_port if nfcc_port != None else 44945, event_loop=self.socket_server_event_loop.event_loop)
        self.nfcc_server.on_client_connected.register(self.on_nfcc_client_connected)
        self.nfcc_server.start()
        local_ip = get_local_ip()
        print_table(['通道', '远程访问地址', '本机安卓模拟器访问地址'], [['SE', f'{local_ip}:{self.se_server.port}', f'10.0.2.2:{self.se_server.port}'], ['NFCC', f'{local_ip}:{self.nfcc_server.port}', f'10.0.2.2:{self.nfcc_server.port}']], '访问地址', 'center')

    async def on_se_client_connected(self, sock: socket):
        await self.se_channel.bind(sock)

    async def on_nfcc_client_connected(self, sock: socket):
        await self.nfcc_channel.bind(sock)

    async def stop_share(self):
        self.logger.info(f'Stop sharing device for DH ...')
        if self.device:
            await self.device.close()
        self.se_server.stop()
        self.nfcc_server.stop()
        self.socket_server_event_loop.close()
        await self.se_channel.close()
        await self.nfcc_channel.close()
__all__ = [IShareForDhService.__name__, ShareForDhService.__name__]