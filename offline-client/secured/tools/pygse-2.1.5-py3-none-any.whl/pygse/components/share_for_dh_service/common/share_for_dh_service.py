from typing import Dict
from ....base.device.common.abstract_device import DeviceInfo
from ....base.device.acl.acl_passive_device import AclPassiveDevice
from ....global_platform.base.security_device import SecurityDevice

class IShareForDhService:

    async def start_share(self, device: DeviceInfo, se_port: int=None, nfcc_port: int=None):
        pass

    async def stop_share(self):
        pass
__all__ = [IShareForDhService.__name__]