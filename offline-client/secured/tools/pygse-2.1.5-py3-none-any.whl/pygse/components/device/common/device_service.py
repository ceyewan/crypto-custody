from abc import abstractmethod
from typing import List, Type, Union, overload
from ....global_platform.base.security_device import SecurityDevice
from ....base.device import DeviceInfo, ISeDevice

class IDeviceService:
    active_device: SecurityDevice

    def register_device(self, type: str, cls: Type[ISeDevice]):
        pass

    @abstractmethod
    async def list_devices(self) -> List[DeviceInfo]:
        pass

    @overload
    async def open(self, device: Union[str, DeviceInfo]) -> SecurityDevice:
        pass

    @overload
    async def close(self, device: Union[str, DeviceInfo, None]) -> DeviceInfo:
        pass

    @overload
    async def close_all(self):
        pass
__all__ = [IDeviceService.__name__]