import logging
from typing import Dict, Type, Union
from ....base.device import DeviceInfo, DeviceType, ISeDevice, QcsDevice, list_devices, CcidDevice, AclDevice
from ....base.common import service
from ....global_platform.base.security_device import SecurityDevice
from ..common import IDeviceService

@service(IDeviceService)
class DeviceService(IDeviceService):
    connected_devices: Dict[str, SecurityDevice]
    __active_device: SecurityDevice = None
    __registered_devices: Dict[str, Type[ISeDevice]]

    def __init__(self) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.connected_devices = {}
        self.__registered_devices = {DeviceType.CCID: CcidDevice, DeviceType.SERIAL: QcsDevice, DeviceType.ACL_SOCKET: AclDevice, DeviceType.ACL_WEBSOCKET: AclDevice, DeviceType.ACL_WEBSOCKET_SSL: AclDevice}

    @property
    def active_device(self):
        return self.__active_device

    @active_device.setter
    def active_device(self, dev: SecurityDevice):
        if dev.name not in self.connected_devices:
            raise Exception(f'Active device must connect first!')
        self.__active_device = dev

    def register_device(self, type: str, cls: Type[ISeDevice]):
        type = DeviceType(type)
        if type in self.__registered_devices:
            raise Exception(f'Device type {type} already registered.')
        self.__registered_devices[type] = cls

    async def list_devices(self) -> DeviceInfo:
        return list_devices()

    async def open(self, device: Union[str, DeviceInfo]) -> SecurityDevice:
        if isinstance(device, str):
            device = DeviceInfo(uri=device)
        if device.name in self.connected_devices:
            return self.connected_devices[device.name]
        dev_cls = self.__registered_devices.get(device.type, None)
        if not dev_cls:
            raise Exception(f'Device type {device.type} not registered.')
        dev = dev_cls(device)
        try:
            await dev.open()
            gp_device = SecurityDevice(dev)
            await gp_device.get_cplc()
            self.connected_devices[dev.dev_info.name] = gp_device
            if not self.active_device:
                self.__active_device = gp_device
            return gp_device
        except:
            self.logger.error(f'Can not open {dev.name}.')
            try:
                await dev.close()
            except Exception as ex:
                self.logger.debug(f'Can not close {dev.name}.', exc_info=ex)
            raise

    async def close(self, device: Union[str, DeviceInfo]) -> DeviceInfo:
        if not device:
            if not self.active_device:
                return None
            device = self.active_device.device.dev_info
        if isinstance(device, str):
            device = DeviceInfo(uri=device)
        if device.name in self.connected_devices:
            dev = self.connected_devices[device.name]
            await dev.close()
            self.connected_devices.pop(device.name)
            if self.active_device == dev:
                self.__active_device = list(self.connected_devices.values())[0] if self.connected_devices else None
            return dev.device.dev_info
        return None

    async def close_all(self):
        for dev in self.connected_devices.values():
            try:
                await dev.close()
            except Exception as ex:
                self.logger.error(ex)
        self.connected_devices.clear()
        self.__active_device = None
        return None
__all__ = [IDeviceService.__name__, DeviceService.__name__]