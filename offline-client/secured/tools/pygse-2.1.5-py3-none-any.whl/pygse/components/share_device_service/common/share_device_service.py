from typing import Dict
from ....base.device.acl.acl_passive_device import AclPassiveDevice
from ....global_platform.base.security_device import SecurityDevice

class IShareDeviceService:

    async def add_device(self, device: SecurityDevice):
        pass

    async def start_share(self, port: int=None):
        pass

    async def get_device_entries(self) -> Dict[str, AclPassiveDevice]:
        pass
__all__ = [IShareDeviceService.__name__]