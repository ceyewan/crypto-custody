import logging
import tornado.websocket
import tornado.web
import tornado.ioloop
import json
import asyncio
from socket import AF_UNSPEC, AddressFamily
from typing import Dict, Type
from urllib.parse import quote, urljoin
from ....base.device.acl.acl_protocol import AclRequest
from ....base.device.acl.acl_passive_device import AclPassiveDevice
from ....base.common import service, IInstanceService, ServiceParam, get_local_ip
from ....global_platform.base.security_device import SecurityDevice
from ..common.share_device_service import IShareDeviceService

class AclDeviceHandler(tornado.websocket.WebSocketHandler):
    device: AclPassiveDevice = None

    def initialize(self, *args, instanceService: IInstanceService, device: AclPassiveDevice, **kwargs) -> None:
        self.instanceService = instanceService
        self._device = device
        self.logger = logging.getLogger(self.__class__.__name__)
        return super().initialize(*args, **kwargs)

    async def prepare(self):
        if not self._device.lock():
            self.set_status(409, 'Device is busy!')
            self.finish('Device is busy!')
        self.device = self._device
        pass

    async def open(self, *args: str, **kwargs: str):
        self.remote_ip = self.request.remote_ip
        self.logger.info(f'{self.remote_ip} connected.')

    async def send_message(self, message):
        future = asyncio.Future()
        message['future'] = future
        self.write_message(json.dumps(message))
        await future
        return future.result()

    def on_message(self, message):
        asyncio.create_task(self.handle_request(json.loads(message)))

    async def handle_request(self, msg: Dict):
        rsp = await self.device.handle_request(AclRequest(**msg))
        await self.write_message(json.dumps(rsp))

    def on_close(self):
        if self.device:
            self.device.unlock()
        self.logger.info(f'{self.remote_ip} disconnected.')

class WebApplication(tornado.web.Application):

    def __init__(self, instanceService: IInstanceService=ServiceParam(IInstanceService)):
        settings = dict()
        super().__init__(**settings)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.instanceService = instanceService

    def add_rule(self, pattern: str, handler: Type[tornado.web.RequestHandler], kwargs: Dict=None, name: str=None) -> None:
        kwargs = kwargs or {}
        kwargs['instanceService'] = self.instanceService
        self.wildcard_router.add_rules([(pattern, handler, kwargs, name)])

    def listen(self, port: int, address: str=None, *, family: AddressFamily=AF_UNSPEC, backlog: int=tornado.netutil._DEFAULT_BACKLOG, flags: int=None, reuse_port: bool=False, **kwargs) -> tornado.web.HTTPServer:
        self.server = super().listen(port, address, family=family, backlog=backlog, flags=flags, reuse_port=reuse_port, **kwargs)
        for listen in self.binding_address:
            self.logger.info(f'Web server listening on {listen}')
        return self.server

    @property
    def binding_address(self):
        return [s.getsockname() for s in self.server._sockets.values()]

@service(IShareDeviceService)
class ShareDeviceService(IShareDeviceService):
    devices: Dict[str, AclPassiveDevice]

    def __init__(self, instanceService: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.devices = {}
        self.web_app = WebApplication(instanceService)

    async def add_device(self, device: SecurityDevice):
        self.devices[quote(f'/acl/{device.name}')] = AclPassiveDevice(device.device)

    async def start_share(self, port: int=None):
        if not self.devices:
            self.logger.warning('没有添加共享的设备。')
            return
        for (pattern, dev) in self.devices.items():
            self.web_app.add_rule(pattern, AclDeviceHandler, dict(device=dev), dev.name)
        self.web_app.listen(port or 0)

    async def get_device_entries(self) -> Dict[str, AclPassiveDevice]:
        local_ip = get_local_ip()
        port = self.web_app.binding_address[0][1]
        return {urljoin(f'ws://{local_ip}:{port}', p): d for (p, d) in self.devices.items()}
__all__ = [IShareDeviceService.__name__, ShareDeviceService.__name__]