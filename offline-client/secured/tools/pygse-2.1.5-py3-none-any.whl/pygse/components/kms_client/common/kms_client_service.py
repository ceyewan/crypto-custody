from abc import abstractmethod
from typing import Dict, Literal, Union

class IKmsClientService:

    @abstractmethod
    def derive_session_keys_scp02(self, chip_id: Union[str, bytes], key_version_number: int, sequence_counter: Union[str, bytes], security_domain: Union[str, bytes]=None) -> Dict[Literal['dek', 'enc', 'cmac', 'rmac'], bytes]:
        pass

    @abstractmethod
    def derive_session_keys_scp03(self, chip_id: Union[str, bytes], key_version_number: int, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], key_length: Literal[16, 24, 32]=None, security_domain: Union[str, bytes]=None) -> Dict[Literal['enc', 'cmac', 'rmac'], bytes]:
        pass

    @abstractmethod
    def get(self) -> bool:
        pass

    @abstractmethod
    def delete(self) -> bool:
        pass

    @abstractmethod
    def update(self) -> bool:
        pass

    @abstractmethod
    def query(self) -> bool:
        pass