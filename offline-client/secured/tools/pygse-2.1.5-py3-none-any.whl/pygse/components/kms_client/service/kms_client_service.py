import logging
from typing import Dict, Literal, Union
from ....global_platform.scp.scp03 import scp03_derive_session_keys
from ....global_platform.scp.scp02 import scp02_derive_session_keys
from ....global_platform.kms.protocol import KmsClient
from ....base.common import service, ServiceParam, to_bytes
from ...configuration.common import IConfigurationService, CommonConfigurationKeys
from ..common import IKmsClientService

class LocalKmsClient:

    def __init__(self, scp02_enc: Union[str, bytes], scp02_mac: Union[str, bytes], scp02_dek: Union[str, bytes], scp03_enc: Union[str, bytes], scp03_mac: Union[str, bytes], scp03_dek: Union[str, bytes]) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.scp02_enc = to_bytes(scp02_enc)
        self.scp02_mac = to_bytes(scp02_mac)
        self.scp02_dek = to_bytes(scp02_dek)
        self.scp03_enc = to_bytes(scp03_enc)
        self.scp03_mac = to_bytes(scp03_mac)
        self.scp03_dek = to_bytes(scp03_dek)

    def derive_session_keys_scp02(self, chip_id: Union[str, bytes], key_version_number: int, sequence_counter: Union[str, bytes], security_domain: Union[str, bytes]=None) -> Dict[Literal['dek', 'enc', 'cmac', 'rmac'], bytes]:
        if not self.scp02_enc or not self.scp02_mac or (not self.scp02_dek):
            self.logger.error(f'Bad SCP03 keys for {chip_id} in storage. enc={self.scp02_enc}, mac={self.scp02_mac}, dek={self.scp02_dek}')
        return scp02_derive_session_keys(self.scp02_enc, self.scp02_mac, self.scp02_dek, sequence_counter)

    def derive_session_keys_scp03(self, chip_id: Union[str, bytes], key_version_number: int, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], key_length: Literal[16, 24, 32]=None, security_domain: Union[str, bytes]=None) -> Dict[Literal['enc', 'cmac', 'rmac'], bytes]:
        if not self.scp03_enc or not self.scp03_mac or (not self.scp03_dek):
            self.logger.error(f'Bad SCP03 keys for {chip_id} in storage. enc={self.scp03_enc}, mac={self.scp03_mac}, dek={self.scp03_dek}')
        return scp03_derive_session_keys(self.scp03_enc, self.scp03_mac, host_challenge, card_challenge, key_length)

@service(IKmsClientService)
class KmsClientService(IKmsClientService):

    def __init__(self, configuration_service: IConfigurationService=ServiceParam(IConfigurationService)) -> None:
        super().__init__()
        self.configuration_service = configuration_service

    def __get_kms_client(self):
        kms_address: str = self.configuration_service.get_config(CommonConfigurationKeys.KMS_SERVER)
        if kms_address:
            kms_client = KmsClient(kms_address)
        else:
            kms_client = LocalKmsClient(scp02_enc=self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_ENC), scp02_mac=self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_MAC), scp02_dek=self.configuration_service.get_config(CommonConfigurationKeys.DES_KEY_DEK), scp03_enc=self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_ENC), scp03_mac=self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_MAC), scp03_dek=self.configuration_service.get_config(CommonConfigurationKeys.AES_KEY_DEK))
        return kms_client

    def derive_session_keys_scp02(self, chip_id: Union[str, bytes], key_version_number: int, sequence_counter: Union[str, bytes], security_domain: Union[str, bytes]=None) -> Dict[Literal['dek', 'enc', 'cmac', 'rmac'], bytes]:
        kms_client = self.__get_kms_client()
        return kms_client.derive_session_keys_scp02(chip_id, key_version_number, sequence_counter, security_domain)

    def derive_session_keys_scp03(self, chip_id: Union[str, bytes], key_version_number: int, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], key_length: Literal[16, 24, 32]=None, security_domain: Union[str, bytes]=None) -> Dict[Literal['enc', 'cmac', 'rmac'], bytes]:
        kms_client = self.__get_kms_client()
        return kms_client.derive_session_keys_scp03(chip_id, key_version_number, host_challenge, card_challenge, key_length, security_domain)