import builtins
from .base.common import *
from .base.device.common import *
from .global_platform.base import *
from .global_platform.session import *
from .app.cli.cli_args import parse_device
from .main import *
from .app import *
from .__version__ import *
version = version
product = 'PyGSE'
vendor = 'Shenzhen Goodix Technology Co., Ltd.'
builtins.vendor = vendor
builtins.product = product
builtins.__product__ = product
builtins.__package_version__ = version
builtins.__build__ = build
builtins.__commit__ = commit