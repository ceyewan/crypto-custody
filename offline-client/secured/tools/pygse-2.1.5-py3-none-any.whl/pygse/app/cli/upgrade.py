from ...base.common import IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from ...components.upgrade_cos.common import IUpgradeCosService
from .cli_args import register_cmd, parse_device, select_device, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'upgrade'

@register_cmd(ACTION_ID, '运行COS升级脚本、Goodix预置应用升级脚本、用户BPF升级脚本。')
class UpgradeCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    file: str
    force: bool = False

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, metavar='[NAME]', help='Target device name.')
        parser.add_argument('-f', '--force', action='store_true', help='Force to run script file, ignore version requirements.')
        parser.add_argument('file', nargs='?', metavar='[FILE]', help='Path to patch script file.')

@action(ACTION_ID)
class ListAppsAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: UpgradeCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        upgrade_service = self.instance_service.get(IUpgradeCosService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        await upgrade_service.upgrade(dev, arg.file, arg.force)
__all__ = []