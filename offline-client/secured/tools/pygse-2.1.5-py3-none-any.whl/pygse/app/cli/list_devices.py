from argparse import Namespace
from ...base.common import IInstanceService, ServiceParam, exit_ex
from ...base.device.common import list_devices
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, SubCommandArguments, ArgumentParser
ACTION_ID = 'ls-dev'

@register_cmd(ACTION_ID, 'List all supported local devices.')
class ListDevicesCommandArguments(SubCommandArguments):

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        pass

@action(ACTION_ID)
class DeleteKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ListDevicesCommandArguments, *args, **kwargs):
        devices = list_devices()
        if devices:
            i = 1
            print(f'List all supported local devices:')
            for dev in devices:
                print(f'{i}. {dev.name}({dev.type.name})')
                i += 1
        else:
            print(f'No supported local device found!')
__all__ = []