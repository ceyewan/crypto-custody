from argparse import Namespace
from ...base.common import to_bytes, print_table, IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, SubCommandArguments, ArgumentParser
ACTION_ID = 'ls-key'

@register_cmd(ACTION_ID, 'List all key sets in SE.')
class ListKeyCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    kvn: int

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='Security Domain AID of key to put in')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number for SCP to create security channel.')

@action(ACTION_ID)
class DeleteKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ListKeyCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        key_sets = await session.get_key_set()
        data = []
        for key_set in key_sets:
            for key in key_set.keys.values():
                data.append([f'0x{key_set.key_version_number:02X}', key.key_identifier, key.key_type.name, key.key_length])
        print_table(['版本号', 'ID', '类型', '长度'], data, '密钥集列表', 'center')
__all__ = []