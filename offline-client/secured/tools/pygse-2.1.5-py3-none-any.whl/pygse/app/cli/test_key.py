from argparse import Namespace
from ...base.common import to_bytes, IInstanceService, ServiceParam
from ...base.device.common import DeviceInfo
from ...components.kms.common.kms_service import IKmsService
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from ...global_platform.base import KeySetAlgorithm
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, parse_key_set_type, SubCommandArguments, ArgumentParser
ACTION_ID = 'test-key'

@register_cmd(ACTION_ID, 'Create a secure channel using a user-specified key to test if the key is correct.')
class PutKeyCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    kvn: int
    alg: KeySetAlgorithm
    kvn: int
    enc: bytes
    mac: bytes
    dek: bytes

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='Security Domain AID. Defaults to A000000151000000')
        parser.add_argument('--kvn', type=parse_key_version, required=True, help='The key version number of key set.')
        parser.add_argument('--alg', type=parse_key_set_type, required=True, metavar='AES|DES|RSA|ECC|HMAC', help='The key set algorithm type for the key set, for example, DES for SCP02 key set and AES for SCP03 key set.')
        parser.add_argument('--enc', type=to_bytes, required=True, help='The KEY-ENC for secure channel authentication & encryption')
        parser.add_argument('--mac', type=to_bytes, required=True, help='The KEY-MAC for secure channel verification & generation')
        parser.add_argument('--dek', type=to_bytes, required=True, help='The KEY-DEK for sensitive data encryption and decryption')

@action(ACTION_ID)
class PutKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: PutKeyCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        kms_service = self.instance_service.get(IKmsService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        key_set = await kms_service.new_key_set(dev.chip_id, arg.sd, arg.kvn, arg.alg, key_enc=arg.enc, key_mac=arg.mac, key_dek=arg.dek)
        session = await session_service.create(dev, key_set.key_version_number, arg.sd)
        session.sd_key_set = key_set
        await session.create_secure_channel()
        print(f"Successfully created security channel to {hex(arg.sd) or 'default ISD'}.")
__all__ = []