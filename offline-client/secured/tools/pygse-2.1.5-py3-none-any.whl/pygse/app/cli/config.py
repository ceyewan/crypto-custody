from typing import List, Literal, Union
from ...base.common import IInstanceService, ServiceParam, print_table, some
from ...components.configuration.common import IConfigurationService, CommonConfigurationKeys
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser, parse_key_version, parse_key
ACTION_ID = 'config'

@register_cmd('config', 'Set or list configurations.')
class ConfigureCommandArguments(SubCommandArguments):
    sub_cmd: Literal['set', 'unset', 'ls', 'aes', 'des', 'sm4']
    key: Union[str, List[str]]
    value: str
    kvn: int
    enc: bytes
    mac: bytes
    dek: bytes

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        sub = parser.add_subparsers(dest='sub_cmd')
        set = sub.add_parser('set', help='set configuration. e.g. config set key value')
        set.add_argument('key', help='Configuration key.')
        set.add_argument('value', help='Value of key.')
        unset = sub.add_parser('unset', help='unset configurations. e.g. config unset key')
        unset.add_argument('key', nargs='+', help='Configuration keys.')
        list = sub.add_parser('ls', help='list configurations. e.g. config list key')
        list.add_argument('key', nargs='*', help='仅输出包键名称包含此内容的配置项。默认全部输出。')
        set = sub.add_parser('des', help='configure DES key set. e.g. pygse config des 20 40...4F 40...4F 40...4F')
        set.add_argument('kvn', nargs='?', type=parse_key_version, help='Key version number. 20 21 22...')
        set.add_argument('enc', nargs='?', type=parse_key, help='KEY-ENC value of key set.')
        set.add_argument('mac', nargs='?', type=parse_key, help='KEY-MAC value of key set.')
        set.add_argument('dek', nargs='?', type=parse_key, help='KEY-DEK value of key set.')
        set = sub.add_parser('aes', help='configure AES key set. e.g. pygse config aes 30 40...4F 40...4F 40...4F')
        set.add_argument('kvn', nargs='?', type=parse_key_version, help='Key version number. 30 31 32...')
        set.add_argument('enc', nargs='?', type=parse_key, help='KEY-ENC value of key set.')
        set.add_argument('mac', nargs='?', type=parse_key, help='KEY-MAC value of key set.')
        set.add_argument('dek', nargs='?', type=parse_key, help='KEY-DEK value of key set.')
        set = sub.add_parser('sm4', help='configure SM4 key set. e.g. pygse config sm4 50 40...4F 40...4F 40...4F')
        set.add_argument('kvn', nargs='?', type=parse_key_version, help='Key version number. 50 51 52...')
        set.add_argument('enc', nargs='?', type=parse_key, help='KEY-ENC value of key set.')
        set.add_argument('mac', nargs='?', type=parse_key, help='KEY-MAC value of key set.')
        set.add_argument('dek', nargs='?', type=parse_key, help='KEY-DEK value of key set.')

@action(ACTION_ID)
class ConfigureAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ConfigureCommandArguments, *args, **kwargs):
        config_service = self.instance_service.get(IConfigurationService)
        if arg.sub_cmd == 'set':
            config_service.set_config(arg.key, arg.value)
            print('提示：使用命令 "pygse config ls [KEY]" 查看配置项。')
        elif arg.sub_cmd == 'unset':
            keys = arg.key if isinstance(arg.key, list) else [arg.key]
            for key in keys:
                if key in ('aes', 'des', 'sm4'):
                    for sub in ('kvn', 'enc', 'mac', 'dek'):
                        config_service.set_config(f'{key}.{sub}', None)
                else:
                    config_service.set_config(key, None)
        elif arg.sub_cmd == 'ls':
            data = [[item.key, item.type, item.description, item.format(config_service.get_config(item)), item.format(item.default_value)] for item in sorted(config_service.registered_configs.values(), key=lambda i: i.order)]
            for r in data:
                if r[-1] == r[-2]:
                    r[-2] = ''
            keys = arg.key if isinstance(arg.key, list) else [arg.key]
            if keys:
                data = [row for row in data if some(keys, lambda k: k in row[0])]
            if not data:
                print(f'没有找到包含“{arg.key}”的配置项！')
            else:
                print_table(['配置键值', '类型', '说明', '设置值', '默认值'], data, '当前用户配置')
                print('提示：使用命令 "pygse config set [KEY] [VALUE]" 进行配置。')
                print('\n'.join([f'例如：', f'  配置DES(SCP02)的默认KEY-ENC：pygse config set {CommonConfigurationKeys.DES_KEY_ENC.key} 404142434445464748494A4B4C4D4F', f'  快速配置AES(SCP03)的整个密钥集：pygse config set aes 30 404142434445464748494A4B4C4D4F']))
        elif arg.sub_cmd in ('aes', 'des', 'sm4'):
            if not arg.kvn:
                raise Exception(f'Key version number is required! see: pygse config {arg.sub_cmd} -h')
            if not arg.enc:
                raise Exception(f'KEY-ENC value is required! see: pygse config {arg.sub_cmd} -h')
            if not arg.mac:
                arg.mac = arg.enc
                self.logger.warning(f'KEY-MAC value is missing! Using KEY-ENC instead.')
            if not arg.dek:
                arg.dek = arg.mac
                self.logger.warning(f'KEY-DEK value is missing! Using KEY-MAC instead.')
            config_service.set_config(f'{arg.sub_cmd}.kvn', arg.kvn)
            config_service.set_config(f'{arg.sub_cmd}.enc', arg.enc)
            config_service.set_config(f'{arg.sub_cmd}.mac', arg.mac)
            config_service.set_config(f'{arg.sub_cmd}.dek', arg.dek)
__all__ = []