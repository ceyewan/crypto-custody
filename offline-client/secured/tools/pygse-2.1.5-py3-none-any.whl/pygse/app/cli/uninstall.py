from typing import List
from ...base.common import to_bytes, IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'uninstall'

@register_cmd(ACTION_ID, '卸载应用。')
class UninstallCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    aid: List[bytes]
    delete_related_objects: bool
    kvn: int

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='The Security Domain AID of applet installed in')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number for SCP.')
        parser.add_argument('-r', '--delete-related-objects', dest='delete_related_objects', action='store_true', help='Delete related objects. required for delete file.')
        parser.add_argument('aid', type=to_bytes, nargs='+', help='Executable Load File or Application AID.', metavar='AID')

@action(ACTION_ID)
class UninstallAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: UninstallCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        for aid in arg.aid:
            await session.delete_aid(aid, arg.delete_related_objects)
__all__ = []