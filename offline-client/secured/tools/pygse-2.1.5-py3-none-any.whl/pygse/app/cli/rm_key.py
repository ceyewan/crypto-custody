from argparse import Namespace
from typing import List
from ...base.common import to_bytes, IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...global_platform.base.apdu import StatusCode
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.kms.common.kms_service import IKmsService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, SubCommandArguments, ArgumentParser
ACTION_ID = 'rm-key'

@register_cmd(ACTION_ID, 'Remove key from Security Domain.')
class RemoveKeyCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    kvn: int
    keys: List[int]

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='Security Domain AID of key to put in')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number for SCP to create security channel.')
        parser.add_argument('keys', type=parse_key_version, nargs='+', help='Key Version Numbers.', metavar='KVN')

@action(ACTION_ID)
class RemoveKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: RemoveKeyCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        for kvn in arg.keys:
            await session.delete_key(kvn)
__all__ = []