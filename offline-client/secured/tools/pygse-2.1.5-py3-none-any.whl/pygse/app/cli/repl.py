import logging
import os
import re
import shlex
import sys
from typing import List, Type
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.styles import Style
from ...base.common import CliSubArgumentsParser, IInstanceService, ServiceParam, exit_ex, on_exit, to_bytes
from ...base.device import DeviceInfo
from ...global_platform.base.apdu import ScpId
from ...global_platform.session import SecureSession
from ...components.action.common.action_service import IActionService
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from .cli_args import set_default_device_provider, register_cmd, parse_device, select_device, parse_key_version, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'repl'

@register_cmd(ACTION_ID, '交互式命令行。')
class ReplCommandArguments(SubCommandArguments):
    dev: DeviceInfo

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')

@action(ACTION_ID)
class ReplAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        if arg.dev:
            dev = await device_service.open(arg.dev)
            if not dev:
                return
        repl_session = self.instance_service.instance(ReplSession)
        await repl_session.run()

class ReplOpenCommandArguments(SubCommandArguments):
    HELP = '打开设备。'
    dev: DeviceInfo

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device(False)
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('dev', type=lambda n: parse_device(n, True, False), nargs='?', help='Target device.')

class ReplOpenAction(IAction):
    ID = 'open'

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplOpenCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        if arg.dev:
            device = await device_service.open(arg.dev)
            if device:
                device_service.active_device = device

class ReplCloseCommandArguments(SubCommandArguments):
    HELP = '关闭设备。'
    dev: DeviceInfo

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('dev', type=parse_device, nargs='?', help='Target device.')

class ReplCloseAction(IAction):
    ID = 'close'

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplCloseCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        dev = await device_service.close(arg.dev)
        if dev:
            self.logger.info(f'"{dev.name}" was closed.')

class ReplExitCommandArguments(SubCommandArguments):
    HELP = '退出PyGSE交互式命令行。'
    dev: DeviceInfo

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        pass

class ReplExitAction(IAction):
    ID = 'exit'

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplExitCommandArguments, *args, **kwargs):
        print('bye!')
        sys.exit(0)

class ReplScpCommandArguments(SubCommandArguments):
    HELP = '创建安全通道。创建安全通道后，transmit指令会自动使用安全通道发送。'
    dev: DeviceInfo
    kvn: int
    aid: bytes
    sd: bytes

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('kvn', nargs='?', type=parse_key_version, help='Specify a Key Version Number for SCP to create security channel.')
        parser.add_argument('aid', nargs='?', type=to_bytes, help='AID of an Issuer Security Domain, a Supplementary Security Domain, or an Applet.')
        parser.add_argument('sd', nargs='?', type=to_bytes, help='AID of an Issuer Security Domain, a Supplementary Security Domain.')
        parser.add_argument('--dev', type=parse_device, help='Target device.')

class ReplScpAction(IAction):
    ID = 'scp'

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplScpCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session_service = self.instance_service.get(ISecureSessionService)
        session = await session_service.create(dev, arg.kvn, arg.aid, arg.sd)
        await session.create_secure_channel()

class ReplTransmitCommandArguments(SubCommandArguments):
    HELP = '发送APDU'
    dev: DeviceInfo
    apdu: List[bytes]

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('apdu', type=to_bytes, nargs='+', help='APDU commands.')

class ReplTransmitAction(IAction):
    ID = 'transmit'

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplTransmitCommandArguments, *args, **kwargs):
        if not arg.apdu:
            self.logger.warning(f'No APDU commands specified.')
            return
        if not arg.dev:
            self.logger.warning(f'No device specified.')
            return
        device_service = self.instance_service.get(IDeviceService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session_service = self.instance_service.get(ISecureSessionService)
        session = session_service.get(dev) or await session_service.create(dev)
        for apdu in arg.apdu:
            await session.transmit(apdu)

class ReplSelectCommandArguments(SubCommandArguments):
    HELP = '执行SELECT指令'
    dev: DeviceInfo
    aid: bytes
    sd: bytes

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('aid', nargs='?', type=to_bytes, help='AID of an Issuer Security Domain, a Supplementary Security Domain, or an Applet.')
        parser.add_argument('sd', nargs='?', type=to_bytes, help='AID of an Issuer Security Domain, a Supplementary Security Domain.')
        parser.add_argument('--dev', type=parse_device, help='Target device.')

class ReplSelectAction(IAction):
    ID = 'select'

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReplSelectCommandArguments, *args, **kwargs):
        if not arg.dev:
            self.logger.warning(f'No device specified.')
            return
        device_service = self.instance_service.get(IDeviceService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session_service = self.instance_service.get(ISecureSessionService)
        session = session_service.get(dev) or await session_service.create(dev, aid=arg.aid, sd=arg.sd)
        await session.select(arg.aid)

class CommandParserException(Exception):
    pass

class ReplInputCommandParser(CliSubArgumentsParser):

    def __init__(self) -> None:
        super().__init__()
        self.registered_sub_parsers.pop(ACTION_ID)

    def exit(self, status=0, message=None):
        if message:
            if status == 0:
                sys.stdout.write(message)
            else:
                sys.stderr.write(message)
        raise CommandParserException(*([message] if message else []))

    def exit_sub(self, status=0, message=None):
        if message:
            if status == 0:
                sys.stdout.write(message)
            else:
                sys.stderr.write(message)
        raise CommandParserException(*([message] if message else []))

    def error(self, message):
        self.parser.print_usage(sys.stderr)

    def _init_parser(self):
        parser = super()._init_parser()
        parser.prog = ''
        parser.exit = self.exit
        for sub in self.enum_sub_parsers(parser):
            sub.prog = ''
            sub.exit = self.exit_sub
        return parser

    def register_sub_parser(self, action_id: str, arg_type: Type[SubCommandArguments], help: str=None):
        if action_id in self.registered_sub_parsers:
            raise Exception(f'{action_id} already registered.')
        if help:
            arg_type.HELP = help
        self.registered_sub_parsers[action_id] = arg_type
        self._parser = None

class ArgparseCompleter(Completer):
    apdu_history: List[str]

    def __init__(self, parser: ArgumentParser):
        self.parser = parser
        self.apdu_history = ['00A4040000']

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor.lstrip()
        parts = text.split()
        sub_cmd = parts[0] if parts else ''
        commands: List[str] = self.parser._subparsers._group_actions[0].choices.keys()
        for command in commands:
            if not text or command.startswith(text):
                yield Completion(command + ' ', start_position=-len(sub_cmd))
        if sub_cmd in ['load', 'install', 'cap']:
            last_word = parts[-1]
            yield from self.listdir(last_word)
        if not sub_cmd or sub_cmd in ['t', 'transmit', 'select'] or re.match('^\\s*([0-9a-fA-F]+(\\s+[0-9a-fA-F]+)*)\\s*$', text):
            prefix = text[text.rfind(' ') + 1:].upper()
            yield from map(lambda j: Completion(j + ' ', start_position=-len(prefix)), filter(lambda i: i.startswith(prefix), self.apdu_history))

    def listdir(self, path: str):
        if os.path.exists(path):
            if os.path.isdir(path) and (path.endswith('/') or path.endswith('\\')):
                for entry in os.listdir(path):
                    yield Completion(entry)
        else:
            path1 = os.path.normpath(path)
            (parent, child) = os.path.split(path1)
            if sys.platform == 'win32':
                child = child.lower()
            if os.path.exists(parent):
                if os.path.isdir(parent):
                    for entry in os.listdir(parent):
                        if entry.lower().startswith(child):
                            yield Completion(entry, start_position=-len(child))

    def add_apdu_history(self, apdu: List[bytes]):
        for item in apdu:
            item = hex(item)
            try:
                self.apdu_history.remove(item)
            except ValueError:
                pass
            self.apdu_history.insert(0, item)

def try_to_bytes(s: str) -> List[bytes]:
    results = []
    parts = s.split()
    for part in parts:
        if not part:
            continue
        if len(s) % 2 != 0:
            return None
        try:
            results.append(bytes.fromhex(part))
        except ValueError:
            return None
    return results

class ReplSession:

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        self.cmd_parser = ReplInputCommandParser()
        self.instance_service = instance_service
        self.device_service = self.instance_service.get(IDeviceService)
        self.session_service = self.instance_service.get(ISecureSessionService)
        self.action_service = self.instance_service.get(IActionService)
        self.register_repl_cmd('q', ReplExitCommandArguments, ReplExitAction)
        self.register_repl_cmd(ReplExitAction.ID, ReplExitCommandArguments, ReplExitAction)
        self.register_repl_cmd(ReplOpenAction.ID, ReplOpenCommandArguments, ReplOpenAction)
        self.register_repl_cmd(ReplCloseAction.ID, ReplCloseCommandArguments, ReplCloseAction)
        self.register_repl_cmd('t', ReplTransmitCommandArguments, ReplTransmitAction)
        self.register_repl_cmd(ReplTransmitAction.ID, ReplTransmitCommandArguments, ReplTransmitAction)
        self.register_repl_cmd(ReplScpAction.ID, ReplScpCommandArguments, ReplScpAction)
        self.register_repl_cmd(ReplSelectAction.ID, ReplSelectCommandArguments, ReplSelectAction)
        on_exit(lambda code: 0)
        set_default_device_provider(lambda : self.device_service.active_device.device.dev_info if self.device_service.active_device else None)
        self.prompt_style = Style.from_dict({'': '#fa5', 'device': 'ansicyan', 'colon': 'darkorange', 'scp': 'magenta', 'dolor': '#00AA00'})
        self.completer = ArgparseCompleter(self.cmd_parser.parser)
        self.prompt_session = PromptSession(style=self.prompt_style, completer=self.completer)

    def register_repl_cmd(self, action_id: str, arg_type: Type[SubCommandArguments], action_type: Type[IAction]):
        self.cmd_parser.register_sub_parser(action_id, arg_type)
        self.action_service.register(action_id, action_type)

    @property
    def secure_session(self) -> SecureSession:
        return self.session_service.get(self.device_service.active_device)

    def __get_prompt(self):
        if self.secure_session and self.secure_session.secure_channel and (self.secure_session.secure_channel.scp_id > 0):
            return [('class:device', self.device_service.active_device.name if self.device_service else ''), ('class:colon', ':'), ('class:scp', self.secure_session.secure_channel.scp_id.name), ('class:dolor', '$ ')]
        return [('class:device', self.device_service.active_device.name if self.device_service.active_device else ''), ('class:dolor', '$ ')]

    async def run(self):
        ctrl_c_count = 0
        while True:
            try:
                input: str = await self.prompt_session.prompt_async(self.__get_prompt())
                input = input.strip()
                if not input:
                    continue
                ctrl_c_count = 0
            except KeyboardInterrupt:
                ctrl_c_count += 1
                if ctrl_c_count < 2:
                    print('To exit, press Ctrl+C again or Ctrl+D or type q or type exit.')
                    continue
                else:
                    print('bye!')
                    break
            except EOFError:
                print('bye!')
                break
            try:
                apdu = try_to_bytes(input)
                if apdu:
                    input = f"transmit {' '.join([hex(i) for i in apdu])}"
                arg: SubCommandArguments = self.cmd_parser.parse_args(*shlex.split(input.replace('\\', '\\\\')))
            except CommandParserException:
                continue
            except Exception as ex:
                logging.error(ex)
                continue
            try:
                await self.action_service.run_until_complete(arg.cmd, arg)
                if isinstance(arg, ReplTransmitCommandArguments):
                    self.completer.add_apdu_history(arg.apdu)
            except Exception as ex:
                logging.error(ex)
__all__ = []