from argparse import Namespace
from typing import Tuple
from ...base.common import to_bytes, IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.kms.common.kms_service import IKmsService
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from ...global_platform.base import DesKeyId, AesKeyId, KeySetAlgorithm
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, parse_key_set_type, SubCommandArguments, ArgumentParser
ACTION_ID = 'put-key'

@register_cmd(ACTION_ID, 'Put key into Security Domain.')
class PutKeyCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    kvn: int
    new_alg: KeySetAlgorithm
    new_kvn: int
    new_enc: bytes
    new_mac: bytes
    new_dek: bytes
    replace: bool = False

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if self.new_alg == KeySetAlgorithm.DES or self.new_alg == KeySetAlgorithm.AES:
            if not self.is_same_length(self.new_enc, self.new_mac, self.new_dek, (16, 24, 32)):
                raise Exception('The key length for ENC, MAC, and DEK must be one of the following: 16, 24, or 32 bytes.')
        if self.new_alg == KeySetAlgorithm.SM4:
            if not self.is_same_length(self.new_enc, self.new_mac, self.new_dek, (16,)):
                raise Exception('The key length for ENC, MAC, and DEK must be 16 bytes.')
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    def is_same_length(self, a: bytes, b: bytes, c: bytes, sizes: Tuple[int]):
        return len(a) == len(b) and len(b) == len(c) and (len(c) in sizes)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='Security Domain AID of key to put in')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number to create security channel.')
        parser.add_argument('--new-kvn', type=parse_key_version, required=True, help='The new key version number')
        parser.add_argument('--new-alg', type=parse_key_set_type, required=True, metavar='AES|DES|RSA|ECC|HMAC', help='The key set algorithm type for the new key set, for example, DES for SCP02 key set and AES for SCP03 key set.')
        parser.add_argument('--new-enc', type=to_bytes, required=True, help='The new KEY-ENC for secure channel authentication & encryption')
        parser.add_argument('--new-mac', type=to_bytes, required=True, help='The new KEY-MAC for secure channel verification & generation')
        parser.add_argument('--new-dek', type=to_bytes, required=True, help='The new KEY-DEK for sensitive data encryption and decryption')
        parser.add_argument('--replace', '-r', action='store_true', help='Remove the existing key set before putting new key set.')

@action(ACTION_ID)
class PutKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: PutKeyCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        kms_service = self.instance_service.get(IKmsService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        new_ket_set = await kms_service.new_key_set(dev.chip_id, arg.sd, arg.new_kvn, arg.new_alg, key_enc=arg.new_enc, key_mac=arg.new_mac, key_dek=arg.new_dek)
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        await session.put_key_set(new_ket_set, arg.replace)
        await kms_service.save_key_set(new_ket_set)
        print(f"Successfully put key set to {hex(arg.sd) or 'default ISD'}.")
__all__ = []