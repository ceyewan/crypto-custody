import logging
from typing import List
from ...base.common import to_bytes, to_aid, IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, parse_int, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'install'

@register_cmd(ACTION_ID, '安装应用(INSTALL for INSTALL and MAKE SELECTABLE)。')
class InstallForInstallCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    files: List[str]
    sd: bytes
    kvn: int
    app_aid: bytes
    load_parameters: bytes
    install_privileges: bytes
    install_parameters: bytes
    debug: bool
    payload_size: int

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='The Security Domain AID of applet installed in.')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number for SCP to create security channel.')
        parser.add_argument('--load-parameters', type=to_bytes, help='Specifies the load parameters field of INSTALL [for load]. This field is represented as a TLV-structured value. For example: EF04C6020102.')
        parser.add_argument('--install-parameters', type=to_bytes, help='Specifies the install parameters field of INSTALL for both [install] and [make selectable]. This field is represented as a TLV-structured value. For example: C900EF04C7020102.')
        parser.add_argument('--install-privileges', type=to_bytes, help='The install privileges field of INSTALL [for install] and [for make selectable]. 1 or 3 bytes of Privileges Coding.')
        parser.add_argument('--app-aid', type=to_aid, help='Specify a App AID for selectable app instance. Using --app-aid=. to using the Executable Module AID by default.')
        parser.add_argument('--debug', action='store_true', help='Include the debug data while loading cap file.')
        parser.add_argument('--payload-size', type=parse_int, help='Set the max payload size of load APDU。Default is 255.')
        parser.add_argument('files', nargs='+', help='cap files to install.', metavar='CAP FILE')

@action(ACTION_ID)
class InstallForInstallAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: InstallForInstallCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        if len(arg.files) > 1 and arg.app_aid and (arg.app_aid != b'.'):
            logging.warning(f'Argument --instance-aid is only valid for installing a single cap file.')
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        await session.install_cap(arg.files, for_make_selectable=True, app_aid=arg.app_aid, load_parameters=arg.load_parameters, install_parameters=arg.install_parameters, install_privileges=arg.install_privileges, include_debug=arg.debug, payload_size=arg.payload_size)
__all__ = []