import os
import builtins
import re
from datetime import datetime
from typing import List, Literal, Union
from rich.table import Table
from rich.box import SIMPLE_HEAD
from ...base.common import IInstanceService, ServiceParam, print_table, TableGridType
from ...components.configuration.common import IConfigurationService, CommonConfigurationKeys
from ...components.action.common import action, IAction
from ...global_platform.base.cap_file import CapFile
from .cli_args import register_cmd, parse_int, SubCommandArguments, ArgumentParser
ACTION_ID = 'cap'

@register_cmd(ACTION_ID, 'Cap文件工具。')
class CapCommandArguments(SubCommandArguments):
    sub_cmd: Literal['info', 'apdu']
    cap_file: str
    out_file: str
    payload_size: int
    debug: bool

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        sub = parser.add_subparsers(dest='sub_cmd')
        set = sub.add_parser('info', help='查看CAP文件信息。例如：cap info my-cap-file.cap')
        set.add_argument('cap_file', nargs='?', help='CAP文件。')
        apdu = sub.add_parser('apdu', help='将CAP文件转换为APDU指令序列。例如：cap apdu my-cap-file.cap')
        apdu.add_argument('cap_file', nargs='?', help='CAP文件。')
        apdu.add_argument('--out', '-o', dest='out_file', help='输出文件，如果未指定输出文件，将结果输出到命令行。')
        apdu.add_argument('--payload-size', type=parse_int, help='设定APDU数据段的最大长度。默认为255。')
        apdu.add_argument('--debug', action='store_true', help='转换内容时，是否包含CAP文件中的调试信息。')

@action(ACTION_ID)
class CapAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: CapCommandArguments, *args, **kwargs):
        if not os.path.exists(arg.cap_file):
            self.logger.error(f'File does not exists!')
            return
        cap_file = CapFile(arg.cap_file)
        header_component = [['Component Size', f'{cap_file.header.size}'], ['CAP File Format Version', f'{cap_file.header.cap_format_major_version}.{cap_file.header.cap_format_minor_version}'], ['CAP AID', hex(cap_file.header.cap_aid)], ['CAP Flags', f'{cap_file.header.flags.to_str()}']]
        if cap_file.is_extended:
            header_component.append(['CAP Version', f'{cap_file.header.cap_major_version}.{cap_file.header.cap_minor_version}'])
            header_component.append(['CAP Version', f'{cap_file.header.cap_major_version}.{cap_file.header.cap_minor_version}'])
        for (i, pkg) in enumerate(cap_file.header.packages):
            applet_table = Table(show_header=False, box=SIMPLE_HEAD)
            applet_table.add_column(justify='right')
            applet_table.add_column()
            applet_table.add_row('AID:', hex(pkg.aid))
            applet_table.add_row('Version:', f'{pkg.major_version}.{pkg.minor_version}')
            applet_table.add_row('Name:', pkg.name)
            header_component.append([f'Package {i + 1}', applet_table])
        applet_component = [['Component Size', f'{cap_file.applet.size}']]
        for (i, app) in enumerate(cap_file.applet.applets):
            applet_table = Table(show_header=False, box=SIMPLE_HEAD)
            applet_table.add_column(justify='right')
            applet_table.add_column()
            applet_table.add_row('AID:', hex(app.aid))
            applet_table.add_row('Install Method Offset:', f'{app.install_method_offset}')
            if app.install_method_component_block_index:
                applet_table.add_row('Install Method Component Block Index:', f'{app.install_method_component_block_index}')
            applet_component.append([f'Applet {i + 1}', applet_table])
        components = []
        total_size = 0
        for (type, component) in cap_file.components.items():
            components.append([type.name, str(component.size)])
            total_size += component.size
        components_footer = ['合计', f'{total_size}']
        if arg.sub_cmd == 'info':
            print_table(['属性', '值'], header_component, '文件头信息')
            print_table(['属性', '值'], applet_component, '应用信息')
            print_table(['组件', '大小'], components, '组件列表', footer=components_footer)
            print('提示：使用命令 "pygse cap apdu [CAP-FILE] --out=apdu.txt" 可转换CAP文件为APDU文本指令。')
        if arg.sub_cmd == 'apdu':
            grid = TableGridType.SIMPLE_HEAD1 if arg.out_file else None
            content = '\n'.join(map(lambda l: '# ' + l, '\n'.join([print_table(['属性', '值'], header_component, '文件头信息', grid=grid, capture=True), print_table(['属性', '值'], applet_component, '应用信息', grid=grid, capture=True), print_table(['组件', '大小'], components, '组件列表', footer=components_footer, grid=grid, capture=True)]).splitlines()))
            apdu = cap_file.to_apdu_s(arg.payload_size, arg.debug)
            content += f"\n#\n# 共{len(apdu)}条指令。{('' if arg.debug else '未')}包含调试信息。\n\n"
            content += '\n'.join(apdu)
            content = re.sub('#\\s{3,}\\n', '', content)
            if not arg.out_file:
                print(content)
            else:
                with open(arg.out_file, 'w+', encoding='utf8') as f:
                    file_header = '\n'.join([f'#==============================================================', f'#     Company: {builtins.vendor}', f'# Generate by: {builtins.product}@{builtins.__package_version__}', f"#   Date time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", f'#        File: {os.path.basename(arg.cap_file)}', f'#==============================================================\n#\n'])
                    f.write(file_header)
                    f.write(content)
                    self.logger.info(f'APDU saved to {os.path.normpath(os.path.realpath(arg.out_file))}')
__all__ = []