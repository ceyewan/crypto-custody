from ...base.common import IInstanceService, ServiceParam, print_table, exit_ex
from ...base.device.common import DeviceInfo
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from ...global_platform.base.apdu import CosVersionGen1, CosVersionGen2
from .cli_args import register_cmd, parse_device, select_device, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'info'

@register_cmd(ACTION_ID, 'Show SE information.')
class DeviceInformationCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    all: bool

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('-a', '--all', action='store_true', dest='all', help='Show all information.')

@action(ACTION_ID)
class DeviceInformationAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: DeviceInformationCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        cos_version_str = await dev.get_cos_version_str()
        try:
            cos_version = await dev.get_cos_version(True)
        except:
            cos_version = None
            self.logger.error(f'Can not get more COS version info!')
        if isinstance(cos_version, CosVersionGen1):
            data = [['COS Version', cos_version_str], ['CPLC', hex(dev.chip_id) if dev.chip_id else '']]
            if cos_version:
                data.extend([['IC FW Version', f'{cos_version.ic_fw_version:04X}'], ['COS ROM Major Version', f'{cos_version.cos_rom_major_version:02X}'], ['COS ROM Minor Version', f'{cos_version.cos_rom_minor_version:02X}'], ['Patch Major Version', f'{cos_version.patch_major_version:02X}'], ['Patch Minor Version', f'{cos_version.patch_minor_version:02X}']])
            if arg.all and cos_version:
                data.extend([['SE Root Minor Version', f'{cos_version.se_root_major_version:02X}'], ['SE Root Minor Version', f'{cos_version.se_root_minor_version:02X}'], ['MLS ROM Version', f'{cos_version.mls_rom_version:02X}'], ['MLS OPT Version', f'{cos_version.mls_opt_version:02X}'], ['MLS RAM Version', f'{cos_version.mls_ram_version:08X}'], ['COS Type', f'{int(cos_version.cos_type):02X}'], ['Key Version', f'{cos_version.key_version:02X}'], ['CID', f'{cos_version.cid:02X}'], ['CRC', f'{cos_version.crc:08X}']])
            print_table(['属性', '值'], data, title='版本信息')
        elif isinstance(cos_version, CosVersionGen2):
            data = [['COS Version', cos_version_str], ['CPLC', hex(dev.chip_id) if dev.chip_id else '']]
            if cos_version:
                data.extend([['IC FW Version', f'{cos_version.ic_fw_version:04X}'], ['COS ROM Version', f'{cos_version.cos_rom_version:02X}'], ['Patch Major Version', f'{cos_version.patch_major_version:02X}'], ['Patch Minor Version', f'{cos_version.patch_minor_version:04X}']])
            if arg.all and cos_version:
                data.extend([['COS Type', f'{int(cos_version.cos_type):02X}'], ['Key Version', f'{cos_version.key_version:02X}'], ['Config2 Id', f'{cos_version.config2_id:02X}'], ['CID', f'{cos_version.cid:02X}'], ['CRC', f'{cos_version.crc:08X}']])
            print_table(['属性', '值'], data, title='版本信息')
        else:
            print('Unknown COS Version!')
        if dev.cplc and arg.all:
            cplc = dev.cplc
            data = [['IC fabricator', f'0x{cplc.ic_fabricator:04X}'], ['IC type', f'0x{int(cplc.ic_type):04X}'], ['Operating system identifier', f'0x{cplc.operating_system_identifier:04X}'], ['Operating system release date', f'0x{cplc.operating_system_release_date:04X}'], ['Operating system release level', f'0x{cplc.operating_system_release_level:04X}'], ['IC fabrication date', f'0x{cplc.ic_fabrication_date:04X}'], ['IC serial number', f'0x{cplc.ic_serial_number:08X}'], ['IC batch identifier', f'0x{cplc.ic_batch_identifier:04X}'], ['IC module fabricator', f'0x{cplc.ic_module_fabricator:04X}'], ['IC module packaging date', f'0x{cplc.ic_module_packaging_date:04X}'], ['ICC manufacturer', f'0x{cplc.icc_manufacturer:04X}'], ['IC embedding date', f'0x{cplc.ic_embedding_date:04X}'], ['IC pre-personalizer', f'0x{cplc.ic_pre_personalizer:04X}'], ['IC pre-personalization date', f'0x{cplc.ic_pre_personalization_date:04X}'], ['IC pre-personalization equipment identifier', f'0x{cplc.ic_pre_personalization_equipment_identifier:08X}'], ['IC personalizer', f'0x{cplc.ic_personalizer:04X}'], ['IC personalization date', f'0x{cplc.ic_personalization_date:04X}'], ['IC personalization equipment identifier', f'0x{cplc.ic_personalization_equipment_identifier:08X}']]
            print_table(['属性', '值'], data, title='卡片生产生命周期')
__all__ = []