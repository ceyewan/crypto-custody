from typing import List
from ...base.common import to_bytes, IInstanceService, ServiceParam, print_table, exit_ex
from ...base.device.common import DeviceInfo
from ...components.configuration.common.configuration_service import IConfigurationService
from ...components.kms.common.kms_service import IKmsService
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from ...global_platform.base.apdu import GetStatusP1, GlobalPlatformRegistryRelatedData
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'ls'

@register_cmd(ACTION_ID, 'List installed applets in SE.')
class ListAppsCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    all: bool
    kvn: int

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number for SCP to create security channel.')
        parser.add_argument('--sd', type=to_bytes, help='Security Domain AID')
        parser.add_argument('-a', '--all', action='store_true', dest='all', help='Show all information.')

@action(ACTION_ID)
class ListAppsAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ListAppsCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        if arg.all:
            isd_data = await session.get_status(GetStatusP1.ISSUER_SECURITY_DOMAIN)
            app_data = await session.get_status(GetStatusP1.APPLICATIONS_WITH_SECURITY_DOMAINS)
            file_data = await session.get_status(GetStatusP1.EXECUTABLE_LOAD_FILES_AND_EXECUTABLE_MODULES)
            self.print_isd_list(isd_data)
            print('')
            self.print_app_list(app_data)
            print('')
            self.print_file_list(file_data)
        else:
            app_data = await session.get_status(GetStatusP1.APPLICATIONS_WITH_SECURITY_DOMAINS)
            self.print_app_list(app_data)
            print('提示：使用"ls -a"可查看所有的安全域、应用和文件信息')
        tips = ['查看生命周期状态编码表：pygse help life-cycle-state-coding [HEX CODE]', '        查看权限编码表：pygse help privileges-coding [HEX CODE]', '查看隐式选择参数编码表：pygse help implicit-selection-parameter-coding [HEX CODE]', ' 例如，解析3字节权限码：pygse help privileges-coding 9EFE80', '', '    卸载应用或文件：pygse uninstall [APP AID | PKG AID]', '卸载文件及关联应用：pygse uninstall [PKG AID] -r']
        print('\n'.join(tips))

    def print_isd_list(self, data: List[GlobalPlatformRegistryRelatedData]):
        body = []
        if not data:
            body.append(['-', '-', '-', '-', '-', '-', '-'])
        else:
            for (i, item) in enumerate(sorted(data, key=lambda d: d.aid)):
                body.append([f'{i + 1}', hex(item.aid), hex(item.associated_security_domain_aid), hex(item.application_executable_load_file_aid), hex(item.life_cycle_state), hex(item.privileges), ' '.join([f'{i:02X}' for i in item.implicit_selection_parameters or []])])
        print_table(['序号', 'AID', '关联安全域AID', '载入文件AID', '生命周期状态', '权限', '隐式选择参数'], body, '发行者安全域列表')

    def print_app_list(self, data: List[GlobalPlatformRegistryRelatedData]):
        body = []
        if not data:
            body.append(['-', '-', '-', '-', '-', '-'])
        else:
            for (i, item) in enumerate(sorted(data, key=lambda d: d.aid)):
                body.append([f'{i + 1}', hex(item.aid), hex(item.associated_security_domain_aid), hex(item.application_executable_load_file_aid), hex(item.life_cycle_state), hex(item.privileges)])
        print_table(['序号', '应用AID', '关联安全域AID', '应用文件AID', '生命周期状态', '权限'], body, '应用列表')

    def print_file_list(self, data: List[GlobalPlatformRegistryRelatedData]):
        body = []
        if not data:
            body.append(['-', '-', '-', '-', '-', '-'])
        else:
            for (i, item) in enumerate(sorted(data, key=lambda d: d.aid)):
                body.append([f'{i + 1}', hex(item.aid), hex(item.associated_security_domain_aid), f'{item.executable_load_file_version_number[0]}.{item.executable_load_file_version_number[1]}' if len(item.executable_load_file_version_number) == 2 else hex(item.executable_load_file_version_number), hex(item.life_cycle_state), '\n'.join([hex(i) for i in item.executable_module_aid or []])])
        print_table(['序号', '文件AID', '关联安全域AID', '文件版本号', '生命周期状态', '可执行模块'], body, '载入文件列表')
__all__ = []