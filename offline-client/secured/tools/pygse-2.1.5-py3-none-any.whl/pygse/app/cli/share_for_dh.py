import logging
from ...base.common import IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.action.common import action, IAction
from ...components.share_for_dh_service.common import IShareForDhService
from .cli_args import register_cmd, parse_device, select_device, wait_for_input_exit, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'share-for-dh'

@register_cmd(ACTION_ID, 'Share NFCC and SE for Android DH over socket.')
class ShareForDhCommandArguments(SubCommandArguments):
    se_port: int
    nfcc_port: int
    dev: DeviceInfo

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            dev = select_device()
            if not dev:
                exit_ex(-1)
            self.dev = dev

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--se-port', type=int, help='Listen port for SE channel.', default=44944)
        parser.add_argument('--nfcc-port', type=int, help='Listen port for NFCC channel.', default=44945)
        parser.add_argument('dev', nargs='?', type=parse_device, help='Local devices to be shared.')

@action(ACTION_ID)
class ShareForDhAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ShareForDhCommandArguments, *args, **kwargs):
        if not arg.log_level:
            logging.root.setLevel(logging.DEBUG)
        share_service = self.instance_service.get(IShareForDhService)
        await share_service.start_share(arg.dev, arg.se_port, arg.nfcc_port)
        await wait_for_input_exit()
        await share_service.stop_share()
__all__ = []