import os
import sys
from typing import List, Literal, Union
from colorama import Fore, Style
from ...base.common import to_bytes, IInstanceService, ServiceParam, print_table
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser
ACTION_ID = 'help'

@register_cmd(ACTION_ID, 'Things to help you.')
class HelpCommandArguments(SubCommandArguments):
    sub_cmd: Literal['life-cycle-state-coding', 'privileges-coding', 'implicit-selection-parameter-coding']
    code: bytes

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        sub = parser.add_subparsers(dest='sub_cmd')
        user_manual = sub.add_parser('user-manual', help='Open user manual. This is default operation if sub-command is omit.')
        life_cycle_state_coding = sub.add_parser('life-cycle-state-coding', help='Show "Life Cycle State Coding" table.')
        life_cycle_state_coding.add_argument('code', nargs='?', type=to_bytes, help='HEX Coding to display.')
        privileges_coding = sub.add_parser('privileges-coding', help='Show "Privileges Coding" table.')
        privileges_coding.add_argument('code', nargs='?', type=to_bytes, help='HEX Coding to display.')
        implicit_selection_parameter_coding = sub.add_parser('implicit-selection-parameter-coding', help='Show "Implicit Selection Parameter Coding" table.')
        implicit_selection_parameter_coding.add_argument('code', nargs='?', type=to_bytes, help='HEX Coding to display.')

@action(ACTION_ID)
class HelpAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: HelpCommandArguments):
        if arg.sub_cmd == 'implicit-selection-parameter-coding':
            self.print_implicit_selection_parameter_coding(arg.code)
        elif arg.sub_cmd == 'life-cycle-state-coding':
            self.print_life_cycle_state_coding(arg.code)
        elif arg.sub_cmd == 'privileges-coding':
            self.print_privileges_coding(arg.code)
        else:
            user_manual = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../PyGSE用户手册.pdf'))
            self.open(user_manual)

    def open(self, file: str):
        if not os.path.exists(file):
            print(f'{file} does not exits!')
            return
        print(f'Open {file} ...')
        try:
            if sys.platform == 'win32':
                os.startfile(file)
            else:
                import subprocess
                subprocess.Popen(['xdg-open', file])
        except:
            print(f'Can not open {file}. Please open it manually.')

    def mark_coding(self, coding: List[List[Union[int, str]]], code: int=None) -> List[List[Union[int, str]]]:
        if code == None or not isinstance(code, int):
            return coding
        for row in coding:
            value = int(''.join([f'{i}' if isinstance(i, int) else '0' for i in row[:8]]), 2)
            mask = int(''.join(['1' if isinstance(i, int) else '0' for i in row[:8]]), 2)
            if mask and mask & code == value:
                row[-1] = f'{row[-1]}' + Fore.RED + '*' + Style.RESET_ALL
        return coding

    def print_life_cycle_state_coding(self, code: bytes=None):
        b0 = code[0] if code else None
        b1 = code[1] if code and len(code) > 1 else None
        headers = ['b8', 'b7', 'b6', 'b5', 'b4', 'b3', 'b2', 'b1', 'Meaning']
        print_table(headers, self.mark_coding([[0, 0, 0, 0, 0, 0, 0, 1, 'LOADED']], b0), 'Executable Load File Life Cycle Coding' + (f'({b0:02X})' if b0 != None else ''))
        print('')
        print_table(headers, self.mark_coding([[0, 0, 0, 0, 0, 0, 1, 1, 'INSTALLED'], [0, 0, 0, 0, 0, 1, 1, 1, 'SELECTABLE'], [0, 'X', 'X', 'X', 'X', 1, 1, 1, 'Application Specific State'], [1, '-', '-', '-', '-', '-', 1, 1, 'LOCKED']], b0), 'Application Life Cycle Coding' + (f'({b0:02X})' if b0 != None else ''))
        print('')
        print_table(headers, self.mark_coding([[0, 0, 0, 0, 0, 0, 1, 1, 'INSTALLED'], [0, 0, 0, 0, 0, 1, 1, 1, 'SELECTABLE'], [0, 0, 0, 0, 1, 1, 1, 1, 'PERSONALIZED'], [1, 0, 0, 0, '-', '-', 1, 1, 'LOCKED']], b0), 'Security Domain Life Cycle Coding' + (f'({Fore.RED}{b0:02X}{Style.RESET_ALL})' if b0 != None else ''))
        print('')
        print_table(headers, self.mark_coding([[0, '–', '–', '–', '–', '–', '–', 1, 'ACTIVATED'], [0, '–', '–', '–', '–', '–', '–', 0, 'DEACTIVATED'], [1, '–', '–', '–', '–', '–', '–', 0, 'NON_ACTIVATABLE'], ['–', 'X', 'X', 'X', 'X', 'X', 'X', '–', 'RFU (Reserved for future use)']], b1), 'Contactless Activation State Byte Coding' + (f'({Fore.RED}{b1:02X}{Style.RESET_ALL})' if b1 != None else ''))
        print('Tips: Contactless Activation State Byte Coding refers to the coding of the 2nd byte in the Life Cycle State data.')

    def print_privileges_coding(self, code: bytes=None):
        b0 = code[0] if code else None
        b1 = code[1] if code and len(code) > 1 else None
        b2 = code[2] if code and len(code) > 2 else None
        header = ['b8', 'b7', 'b6', 'b5', 'b4', 'b3', 'b2', 'b1', 'Meaning', 'Privilege Number']
        print_table(header, self.mark_coding([[1, '-', '-', '-', '-', '-', '-', '-', 'Security Domain', 0], [1, 1, '-', '-', '-', '-', '-', 0, 'DAP Verification', 1], [1, '-', 1, '-', '-', '-', '-', '-', 'Delegated Management', 2], ['-', '-', '-', 1, '-', '-', '-', '-', 'Card Lock', 3], ['-', '-', '-', '-', 1, '-', '-', '-', 'Card Terminate', 4], ['-', '-', '-', '-', '-', 1, '-', '-', 'Card Reset', 5], ['-', '-', '-', '-', '-', '-', 1, '-', 'CVM Management', 6], [1, 1, '-', '-', '-', '-', '-', 1, 'Mandated DAP Verification', 7]], b0), 'Privileges ' + (f'(Byte 1 - {Fore.RED}{b0:02X}{Style.RESET_ALL})' if b0 != None else '(Byte 1)'))
        print('')
        print_table(header, self.mark_coding([[1, '-', '-', '-', '-', '-', '-', '-', 'Trusted Path', 8], ['-', 1, '-', '-', '-', '-', '-', '-', 'Authorized Management', 9], ['-', '-', 1, '-', '-', '-', '-', '-', 'Token Management ', 10], ['-', '-', '-', 1, '-', '-', '-', '-', 'Global Delete ', 11], ['-', '-', '-', '-', 1, '-', '-', '-', 'Global Lock ', 12], ['-', '-', '-', '-', '-', 1, '-', '-', 'Global Registry ', 13], ['-', '-', '-', '-', '-', '-', 1, '-', 'Final Application ', 14], ['-', '-', '-', '-', '-', '-', '-', 1, 'Global Service ', 15]], b1), 'Privileges ' + (f'(Byte 2 - {Fore.RED}{b1:02X}{Style.RESET_ALL})' if b1 != None else '(Byte 2)'))
        print('')
        print_table(header, self.mark_coding([[1, '-', '-', '-', '-', '-', '-', '-', 'Receipt Generation', 16], ['-', 1, '-', '-', '-', '-', '-', '-', 'Ciphered Load File Data Block', 17], ['-', '-', 1, '-', '-', '-', '-', '-', 'Contactless Activation', 18], ['-', '-', '-', 1, '-', '-', '-', '-', 'Contactless Self-Activation', 19], ['-', '-', '-', '-', 'X', 'X', 'X', 'X', 'RFU', '-']], b2), 'Privileges ' + (f'((Byte 3 - {Fore.RED}{b2:02X}{Style.RESET_ALL})' if b2 != None else '(Byte 3)'))

    def print_implicit_selection_parameter_coding(self, code: bytes=None):
        b0 = code[0] if code else None
        header = ['b8', 'b7', 'b6', 'b5', 'b4', 'b3', 'b2', 'b1', 'Meaning']
        coding = self.mark_coding([[1, '-', '-', '-', '-', '-', '-', '-', 'Contactless I/O'], ['-', 1, '-', '-', '-', '-', '-', '-', 'Contact I/O'], ['-', '-', 'X', '-', '-', '-', '-', '-', 'RFU'], ['-', '-', '-', 'X', 'X', 'X', 'X', 'X', 'Logical channel number (0 to 19)']], b0)
        if b0 != None:
            channel = b0 & 31
            coding[-1][-1] += f'. Channel={channel}'
        print_table(header, coding, 'Implicit Selection Parameter' + (f'({Fore.RED}{b0:02X}{Style.RESET_ALL})' if b0 != None else ''))
__all__ = []