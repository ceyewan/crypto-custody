import asyncio
import logging
import os
import io
import re
import sys
import signal
from typing import Callable, List
from concurrent.futures import ThreadPoolExecutor
from argparse import ArgumentParser, Namespace
from ...global_platform.base import ScpId, KeySetAlgorithm
from ...base.common import SubCommandArguments, CliSubArgumentsParser, URI, exit_ex
from ...base.device import DeviceInfo, DeviceType, input_select_local_device, list_devices
__default_device_provider: Callable[[], DeviceInfo] = None

def set_default_device_provider(getter: Callable[[], DeviceInfo]):
    global __default_device_provider
    __default_device_provider = getter

def parse_device(name: str, select: bool=True, use_default: bool=True) -> DeviceInfo:
    name = name or ''
    if name and '://' not in name and re.match('^(\\w+\\.)*\\w+:\\d+($|\\?.*)', name):
        name = DeviceType.ACL_SOCKET.value + '://' + name
    uri = URI.try_parse(name)
    if uri.scheme:
        if uri.scheme not in DeviceType._value2member_map_:
            raise Exception(f'Unknown device type!\n{DeviceInfo.__doc__}')
        if uri.scheme in (DeviceType.CCID.value, DeviceType.SERIAL.value) and (not uri.path) and uri.netloc:
            uri.path = uri.netloc
            uri.netloc = ''
        return DeviceInfo(uri=uri)
    default_device = __default_device_provider() if use_default and __default_device_provider else None
    local_name = uri.path or uri.netloc or (default_device.name if default_device else None)
    devices = list_devices()
    for dev in devices:
        if dev.name == local_name:
            dev.uri.query = uri.query
            return dev
    if uri.path:
        print(f'Can not find local device "{uri.path}"!')
    if not select:
        exit_ex(-1)
    dev = select_device(use_default)
    if not dev:
        exit_ex(-1)
    return dev

def select_device(use_default: bool=True):
    if sys.stdin.isatty():
        default_device = __default_device_provider() if use_default and __default_device_provider else None
        if default_device:
            return default_device
        return input_select_local_device()

def check_patch_script_file(file: str):
    if not os.path.isfile(file):
        raise Exception(f'File not exists: {file}')
    return os.path.normpath(file)

def parse_scp(scp_str: str):
    if scp_str.lower() in ('0', '00'):
        return ScpId.SCP00
    elif scp_str.lower() in ('2', '02', 'scp02'):
        return ScpId.SCP02
    elif scp_str.lower() in ('3', '03', 'scp03'):
        return ScpId.SCP03
    elif scp_str.lower() in ('4', '04', 'scp04'):
        return ScpId.SCP04
    else:
        raise Exception(f'Bad scp {scp_str}. Using 0 for no SCP, 2、02、SCP02 for SCP02, 3、03、SCP03 for SCP03，4、04、SCP04 for SCP04.')

def parse_key_set_type(type_str: str):
    type_str = type_str.upper()
    if type_str == 'AES':
        return KeySetAlgorithm.AES
    if type_str == 'DES':
        return KeySetAlgorithm.DES
    if type_str == 'SM4':
        return KeySetAlgorithm.SM4
    if type_str == 'RSA':
        return KeySetAlgorithm.RSA
    if type_str == 'ECC':
        return KeySetAlgorithm.ECC
    if type_str == 'HMAC':
        return KeySetAlgorithm.HMAC
    else:
        raise Exception(f'Bad Key Set Type {type_str}. Using AES DES SM4 RSA ECC HMAC.')

def parse_key_version(hex_str: str):
    kv = int(hex_str, 16)
    if kv < 0 or kv >= 255:
        raise Exception(f'Bad Key Version {hex_str}, A hex numbers between 00-FE is required！')
    return kv

def parse_int(int_str: str) -> int:
    int_str = int_str.strip()
    patterns = {'^0b[01]+$': 2, '^0o[0-7]+$': 8, '^0x[0-9a-f]+$': 16, '^[0-9]+$': 10, '^[0-9a-f]+$': 16}
    for (pattern, base) in patterns.items():
        if re.fullmatch(pattern, int_str, re.I):
            return int(int_str, base)
    raise ValueError(f'Invalid input number: {int_str}')

def parse_cid(v: str):
    v = bytes.fromhex(v)
    assert len(v) == 16, '芯片ID应该是16字节HEX字符串'
    return v

def parse_isd(v: str):
    v = bytes.fromhex(v)
    assert len(v) >= 3 and len(v) < 16, '芯片ID应该是3-16字节HEX字符串'
    return v

def parse_key(v: str):
    v = bytes.fromhex(v)
    assert len(v) in (8, 16, 32), '密钥应该是8、16、32字节HEX字符串'
    return v

def register_cmd(cmd: str, help: str=None, aliases: List[str]=None):
    return CliSubArgumentsParser.register_sub_arg(cmd, help, aliases)

def parse_arguments(*args: str) -> SubCommandArguments:
    return CliSubArgumentsParser().parse_args(*args)

def load_cli_actions():
    for (root, dirs, files) in os.walk(os.path.dirname(__file__)):
        for file in files:
            if file.endswith('.py') and (not file.startswith('_')):
                module_name = os.path.splitext(file)[0]
                module = __import__(f'{__package__}.{module_name}')

def question(prompt: str, answers: str='yn') -> str:
    answer = ''
    while len(answer) != 1 or answer not in answers:
        answer = input(prompt + f"({'/'.join(answers)}):").lower()
    return answer
EOF = ''
EOT = '\x04'

async def async_input(loop: asyncio.AbstractEventLoop=None):
    if sys.platform == 'win32':
        loop = loop or asyncio.get_running_loop()
        with ThreadPoolExecutor() as executor:
            try:
                return await loop.run_in_executor(executor, input)
            except EOFError:
                return EOF
            except Exception as ex:
                return ''
    else:
        loop = loop or asyncio.get_event_loop()
        if hasattr(loop, 'stdin_reader'):
            reader: asyncio.StreamReader = loop.stdin_reader
        else:
            reader: asyncio.StreamReader = asyncio.StreamReader(loop=loop)
            await loop.connect_read_pipe(lambda : asyncio.StreamReaderProtocol(reader), sys.stdin)
            loop.stdin_reader = reader
        try:
            if reader.at_eof():
                return EOT
            data = await reader.readline()
            if not data:
                return ''
            return data.decode().strip()
        except asyncio.CancelledError:
            pass
        except Exception as ex:
            pass
        return EOT if reader.at_eof() else ''

async def wait_for_input_exit():
    if sys.platform == 'win32':
        exit_tip = '\nTo exit, press Ctrl+C twice or type q or type exit.'
    else:
        exit_tip = '\nTo exit, press Ctrl+C twice or Ctrl+D or type q or type exit.'
    print(exit_tip)
    sigint_future: asyncio.Future = None

    def handle_global_exception(loop, context):
        logging.error(context.get('exception') or context or 'handle_global_exception')
        if sigint_future and (not sigint_future.done()):
            sigint_future.set_result(signal.SIGINT)
    loop = asyncio.get_event_loop()
    loop.set_exception_handler(handle_global_exception)

    def signal_handler(signum, *args, **kwargs):
        if sigint_future and (not sigint_future.done()):
            sigint_future.set_result(signum)
    if sys.platform == 'win32':
        signal.signal(signal.SIGINT, signal_handler)
    else:
        loop.add_signal_handler(signal.SIGINT, signal_handler, signal.SIGINT)
    ctrl_c_count = 0
    while True:
        try:
            input_task = asyncio.create_task(async_input(), name='async_input')
            sigint_future = asyncio.Future()
            (_, pending) = await asyncio.wait([sigint_future, input_task], return_when=asyncio.FIRST_COMPLETED)
            if sigint_future.done():
                if sigint_future.result() == signal.SIGINT:
                    ctrl_c_count += 1
                    if ctrl_c_count == 2:
                        print()
                        break
                    else:
                        print(exit_tip)
                else:
                    break
            if input_task.done():
                cmd = input_task.result()
                if cmd.lower() in ('q', 'exit', EOT):
                    break
                if cmd:
                    ctrl_c_count = 0
        except Exception as e:
            logging.error(e)
            break
        finally:
            for t in pending:
                t.cancel()
__all__ = [Namespace.__name__, ArgumentParser.__name__, SubCommandArguments.__name__, register_cmd.__name__, parse_arguments.__name__, parse_device.__name__, parse_scp.__name__, parse_key_version.__name__, parse_cid.__name__, parse_isd.__name__, parse_key.__name__, parse_key_set_type.__name__, parse_int.__name__, load_cli_actions.__name__, set_default_device_provider.__name__, question.__name__, wait_for_input_exit.__name__]