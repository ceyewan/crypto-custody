import tornado
from typing import List
from ...base.common import IInstanceService, ServiceParam, print_table, exit_ex
from ...base.device.common import DeviceInfo
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from ...components.share_device_service.common import IShareDeviceService
from .cli_args import register_cmd, parse_device, select_device, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'share'

@register_cmd(ACTION_ID, 'Share a device as an ACL device over WebSocket.')
class ShareDeviceCommandArguments(SubCommandArguments):
    dev: List[DeviceInfo]
    port: int

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            dev = select_device()
            if not dev:
                exit_ex(-1)
            self.dev = [dev]

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--port', type=int, help='Listen port.')
        parser.add_argument('dev', nargs='*', type=parse_device, help='Local devices to be shared.')

@action(ACTION_ID)
class ShareDeviceAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ShareDeviceCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        share_device_service = self.instance_service.get(IShareDeviceService)
        entries = {}
        try:
            for d in arg.dev:
                dev = await device_service.open(d)
                if not dev:
                    return
                await share_device_service.add_device(dev)
            await share_device_service.start_share(arg.port)
            entries = await share_device_service.get_device_entries()
            print_table(['设备', '设备地址'], [[d.name, p] for (p, d) in entries.items()], '已共享设备')
            shutdown_event = tornado.locks.Event()
            await shutdown_event.wait()
        except:
            raise
__all__ = []