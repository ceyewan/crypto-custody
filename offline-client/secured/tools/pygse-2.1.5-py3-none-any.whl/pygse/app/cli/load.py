from typing import List
from ...base.common import to_bytes, IInstanceService, ServiceParam, exit_ex
from ...base.device.common import DeviceInfo
from ...components.secure_session.common.secure_session_service import ISecureSessionService
from ...components.device.common.device_service import IDeviceService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, parse_device, select_device, parse_key_version, parse_int, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'load'

@register_cmd(ACTION_ID, '安装应用(INSTALL for LOAD)。')
class InstallForLoadCommandArguments(SubCommandArguments):
    dev: DeviceInfo
    sd: bytes
    kvn: int
    load_parameters: bytes
    debug: bool
    payload_size: int
    files: List[str]

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not self.dev:
            self.dev = select_device()
            if not self.dev:
                exit_ex(-1)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--dev', type=parse_device, help='Target device.')
        parser.add_argument('--sd', type=to_bytes, help='The Security Domain AID of applet installed in.')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify a Key Version Number for SCP to create security channel.')
        parser.add_argument('--load-parameters', type=to_bytes, help='Specifies the load parameters field of INSTALL [for load]. This field is represented as a TLV-structured value. For example: EF04C6020102.')
        parser.add_argument('--debug', action='store_true', help='Include the debug data while loading cap file.')
        parser.add_argument('--payload-size', type=parse_int, help='Set the max payload size of load APDU。Default is 255.')
        parser.add_argument('files', nargs='+', help='cap files to install.', metavar='CAP FILE')

@action(ACTION_ID)
class InstallForLoadAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: InstallForLoadCommandArguments, *args, **kwargs):
        device_service = self.instance_service.get(IDeviceService)
        session_service = self.instance_service.get(ISecureSessionService)
        dev = await device_service.open(arg.dev)
        if not dev:
            return
        session = await session_service.create(dev, arg.kvn, sd=arg.sd)
        await session.install_cap(arg.files, for_make_selectable=False, load_parameters=arg.load_parameters, include_debug=arg.debug, payload_size=arg.payload_size)
__all__ = []