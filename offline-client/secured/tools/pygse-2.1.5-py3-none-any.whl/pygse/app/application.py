import logging
from ..components.action.common import IActionService
from ..base.common import InstanceService, Application
from ..components import register_all_services
from ..components.device.common import IDeviceService
from ..components.secure_session.common import ISecureSessionService
from .cli import parse_arguments

class PyGseServiceFactory(InstanceService):

    def __init__(self) -> None:
        register_all_services()
        super().__init__()

    @property
    def device_service(self) -> IDeviceService:
        return self.get(IDeviceService)

    @property
    def session_service(self) -> ISecureSessionService:
        return self.get(ISecureSessionService)

class CliApplication(Application):

    def __init__(self) -> None:
        super().__init__(self.__main)

    async def __main(self, *argv: str):
        arg = parse_arguments(*argv)
        if arg.log_level:
            logging.root.setLevel(arg.log_level)
        if arg.log_file:
            logging.root.addHandler(logging.FileHandler(arg.log_file, 'w'))
        self.instance_service = PyGseServiceFactory()
        action_service = self.instance_service.get(IActionService)
        try:
            await action_service.run_until_complete(arg.cmd, arg)
        except:
            raise
        finally:
            await self.instance_service.device_service.close_all()
__all__ = [PyGseServiceFactory.__name__, CliApplication.__name__]