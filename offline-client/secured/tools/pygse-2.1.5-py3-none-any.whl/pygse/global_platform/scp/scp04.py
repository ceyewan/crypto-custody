from typing import Callable, Dict, List, Literal, Tuple, Union
from Crypto.Hash import CMAC
from Crypto.Cipher import AES
from Crypto.Util.number import long_to_bytes
from Crypto.Util.py3compat import iter_range
from ...base.common import IntEnum, BytesIO, to_bytes
from ...base.crypto import kdf_counter, sm4_ecb_cmac
from ..base.apdu import CommandAPDU, ResponseAPDU, ScpId
from ..base import Sm4KeyId, Sm4KeySet, Sm4SessionKeySet, CommandAPDU, ResponseAPDU, ScpId, Instruction
from .common import ISecureChannel, SecureLevel

class Scp04SecureLevel(IntEnum):
    CDEC_RENC_CMAC_RMAC = 51
    CDEC_CMAC_RMAC = 19
    CMAC_RMAC = 17
    RMAC = 16
    CDEC_CMAC = 3
    CMAC = 1
    NONE = 0

class Scp04ProtocolConfigurationIdentifier(IntEnum):
    AES_CBC = 1
    SM4 = 2
    AES_GCM = 3

class Scp04ProtocolConfiguration:
    protocol_identifier: int
    data_derivation: int
    mac: int
    rekeying: int
    cipher: int
    sensitive_data_encryption: int
    random: int

    def __init__(self, protocol_identifier: int=0, data_derivation: int=0, mac: int=0, rekeying: int=0, cipher: int=0, sensitive_data_encryption: int=0, random: int=0) -> None:
        self.protocol_identifier = protocol_identifier
        self.data_derivation = data_derivation
        self.mac = mac
        self.rekeying = rekeying
        self.cipher = cipher
        self.sensitive_data_encryption = sensitive_data_encryption
        self.random = random

class Scp04ProtocolConfigurations:
    AES_CBC: 'Scp04ProtocolConfiguration' = Scp04ProtocolConfiguration(protocol_identifier=1, data_derivation=16, mac=32, rekeying=48, cipher=64, sensitive_data_encryption=80, random=96)
    SM4: 'Scp04ProtocolConfiguration' = Scp04ProtocolConfiguration(protocol_identifier=2, data_derivation=16, mac=33, rekeying=48, cipher=65, sensitive_data_encryption=81, random=96)
    AES_GCM: 'Scp04ProtocolConfiguration' = Scp04ProtocolConfiguration(protocol_identifier=3, data_derivation=16, mac=66, rekeying=48, cipher=66, sensitive_data_encryption=80, random=96)

class Scp04DerivationConstants(IntEnum):
    CARD_CRYPTOGRAM = 0
    HOST_CRYPTOGRAM = 1
    CARD_CHALLENGE = 2
    S_ENC = 4
    S_MAC = 6
    S_RMAC = 7

def scp04_kdf(key: Union[str, bytes], constant: Scp04DerivationConstants, context: Union[str, bytes], derived_key_length: Literal[8, 16, 24, 32]=16):
    label = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, int(constant)])
    return kdf_counter(master=to_bytes(key), key_len=derived_key_length, prf=sm4_ecb_cmac, label=label, context=to_bytes(context), num_keys=1)

def scp04_derive_session_keys(key_set: Sm4KeySet, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2], derived_key_length: Literal[16, 24, 32]=None) -> Sm4SessionKeySet:
    key_enc = key_set.get_key(Sm4KeyId.KEY_ENC).key_value
    key_mac = key_set.get_key(Sm4KeyId.KEY_MAC).key_value
    derived_key_length = derived_key_length or len(key_enc)
    if derived_key_length not in (16, 24, 32):
        raise Exception(f'Bad parameter of derived_key_length={derived_key_length}')
    context = to_bytes(host_challenge) + to_bytes(card_challenge) + bytes([protocol_identifier]) + bytes(supported_protocol_configuration_list or [2])
    constant = bytes(11)
    s_enc = kdf_counter(key_enc, derived_key_length, sm4_ecb_cmac, constant + b'\x04', context)
    s_mac = kdf_counter(key_mac, derived_key_length, sm4_ecb_cmac, constant + b'\x06', context)
    s_rmac = kdf_counter(key_mac, derived_key_length, sm4_ecb_cmac, constant + b'\x07', context)
    return Sm4SessionKeySet(s_enc, s_mac, s_rmac, key_set.get_key(Sm4KeyId.KEY_DEK), key_set.chip_id, key_set.security_domain, key_set.key_version_number)

def buffer_increment(buf, offset=0):
    new_buf = bytearray(buf)
    buf_len = len(buf)
    if buf_len < 1:
        return buf
    i = offset + buf_len - 1
    while i > 0:
        if buf[i] != 255:
            new_buf[i] = buf[i] + 1
            break
        else:
            new_buf[i] = 0
        i -= 1
    return new_buf

def pad80(buf: bytes, block_size: int):
    pad_len = block_size - len(buf) % block_size
    new_buf = buf + bytes([128]) + bytes(pad_len - 1)
    return new_buf

def scp03_aes_key_check(key: bytes):
    data = BytesIO()
    data.write_byte(3)
    plain_text = bytes([1] * len(key))
    cipher = AES.new(key, AES.MODE_CBC, iv=bytes([0] * len(key)))
    enc_data = cipher.encrypt(plain_text)
    data.write(enc_data[0:3])
    return data.getvalue()

class Scp04SecurityChannel(ISecureChannel):
    session_key_set: Sm4SessionKeySet
    chaining_mac: bytes
    encryption_counter: bytes

    def __init__(self, aid: bytes, session_key_set: Sm4SessionKeySet, secure_level: SecureLevel=SecureLevel.NONE, logic_channel_number: int=0):
        super().__init__(aid, session_key_set, ScpId.SCP04, secure_level, logic_channel_number)
        self.s_enc = session_key_set.enc.key_value
        self.s_mac = session_key_set.mac.key_value
        self.s_rmac = session_key_set.rmac.key_value
        self.cmac_length = 16
        self.chaining_mac = bytes(16)
        self.encryption_counter = bytes(16)

    def encrypt(self, plain: CommandAPDU) -> CommandAPDU:
        encrypted = CommandAPDU().deserialize(BytesIO(plain.to_bytes()))
        if self.secure_level != SecureLevel.NONE:
            encrypted.cla |= 132 if self.logic_channel_number <= 3 else 224
        if SecureLevel.C_DEC in self.secure_level:
            self.encryption_counter = buffer_increment(self.encryption_counter)
            if len(encrypted.data) > 0:
                cipher = AES.new(self.s_enc, AES.MODE_CBC, iv=bytes([0] * len(self.s_enc)))
                iv = cipher.encrypt(self.encryption_counter)
                cipher = AES.new(self.s_enc, AES.MODE_CBC, iv=iv)
                aes_input = pad80(encrypted.data, AES.block_size)
                encrypted.data = cipher.encrypt(aes_input)
        if SecureLevel.C_MAC in self.secure_level:
            cmac_input = bytearray(encrypted.to_bytes(True))
            cmac_input[4] += 16
            cmac_input = self.chaining_mac + cmac_input
            self.chaining_mac = sm4_ecb_cmac(self.s_mac, cmac_input)
            encrypted.data += self.chaining_mac
        return encrypted

    def decrypt(self, rsp: ResponseAPDU) -> ResponseAPDU:
        return rsp

def __test_scp04_derive_session_keys():
    test_result = []
    key_set = Sm4KeySet()
    key_set.add_key(Sm4KeyId.KEY_ENC, '11111111111111111111111111111111')
    key_set.add_key(Sm4KeyId.KEY_MAC, '22222222222222222222222222222222')
    key_set.add_key(Sm4KeyId.KEY_DEK, '33333333333333333333333333333333')

    def verify(label: str, a: bytes, b: str):
        a = hex(a)
        b = b.upper()
        return [label, a, b, '√' if a == b else '×']
    session_key_set = scp04_derive_session_keys(key_set, '5352C68347A447566D4C1990D5463248', '5DE7FCB1A2A521E656EE17EB8231F2EE')
    test_result.append(verify('S-ENC', session_key_set.enc.key_value, 'e0a3489181cc50d96fa069d7c1648494'))
    test_result.append(verify('S-MAC', session_key_set.mac.key_value, '94abb559035245061c26195507126ef9'))
    test_result.append(verify('S-RMAC', session_key_set.rmac.key_value, '57ab4bc93d90ad5b0824c2b60ded041c'))
    host_cryptogram = scp04_kdf(session_key_set.mac.key_value, Scp04DerivationConstants.HOST_CRYPTOGRAM, '5352C68347A447566D4C1990D5463248' + '5DE7FCB1A2A521E656EE17EB8231F2EE', 16)
    test_result.append(verify('Host Cryptogram', host_cryptogram, '5577590adadcbe9fe0f5c807dae055cd'))
    secure_channel = Scp04SecurityChannel(session_key_set, SecureLevel.C_MAC)
    from ...base.common import Tlv
    plain = CommandAPDU(cla=132, ins=Instruction.EXTERNAL_AUTHENTICATE, p1=SecureLevel.C_MAC, p2=0, data=Tlv.build(141, host_cryptogram, True))
    encrypted = secure_channel.encrypt(plain)
    test_result.append(verify('Chaining MAC', secure_channel.chaining_mac, 'f44bab1808bb3b107e7e66daac513a06'))
    test_result.append(verify('EXTERNAL AUTHENTICATE Plain', plain.to_bytes(), '84820100128D105577590ADADCBE9FE0F5C807DAE055CD'))
    test_result.append(verify('EXTERNAL AUTHENTICATE Encrypted', encrypted.to_bytes(), '84820100228D105577590ADADCBE9FE0F5C807DAE055CDf44bab1808bb3b107e7e66daac513a06'))
    from ...base.common import print_table
    print_table(['验证项', '当前值', '期望值', '结果'], test_result)
    print('')
__all__ = [Scp04SecureLevel.__name__, Scp04ProtocolConfiguration.__name__, Scp04ProtocolConfigurations.__name__, Scp04DerivationConstants.__name__, scp04_kdf.__name__, scp04_derive_session_keys.__name__, Scp04SecurityChannel.__name__]