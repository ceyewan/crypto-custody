from abc import abstractmethod
from enum import IntEnum, IntFlag
from typing import Union
from ..base.key import AesSessionKeySet, DesSessionKeySet, KeySet, Sm4SessionKeySet
from ..base.apdu import ScpId, CommandAPDU, ResponseAPDU

class SecureLevel(IntFlag):
    NONE = 0
    C_MAC = 1
    C_DEC = 2
    R_MAC = 16
    R_ENC = 32

class ISecureChannel:
    scp_id: ScpId = None
    secure_level: SecureLevel = SecureLevel.NONE
    logic_channel_number: int = 0
    cmac_length: int = 8
    aid: bytes = None
    session_key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet, KeySet] = None

    def __init__(self, aid: bytes, session_key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet, KeySet]=None, scp_id: ScpId=ScpId.SCP00, secure_level: SecureLevel=SecureLevel.NONE, logic_channel_number: int=0) -> None:
        self.aid = aid
        self.session_key_set = session_key_set
        self.scp_id = scp_id
        self.secure_level = secure_level or SecureLevel.NONE
        self.logic_channel_number = logic_channel_number

    @abstractmethod
    def encrypt(self, plain: CommandAPDU) -> CommandAPDU:
        pass

    @abstractmethod
    def decrypt(self, encrypted: ResponseAPDU) -> ResponseAPDU:
        pass