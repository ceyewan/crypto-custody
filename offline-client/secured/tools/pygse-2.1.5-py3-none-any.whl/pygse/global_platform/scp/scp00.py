from ..base import CommandAPDU, ResponseAPDU, ScpId
from .common import ISecureChannel, SecureLevel

class Scp00SecurityChannel(ISecureChannel):

    def __init__(self, aid: bytes):
        super().__init__(aid)
        self.cmac_length = 0

    def encrypt(self, plain: CommandAPDU) -> CommandAPDU:
        return plain

    def decrypt(self, rsp: ResponseAPDU) -> ResponseAPDU:
        return rsp
__all__ = [Scp00SecurityChannel.__name__]