from typing import Dict, Literal, Tuple, Union
from Crypto.Cipher import DES, DES3
from Crypto.Util.Padding import pad, unpad
from ...base.common import IntEnum, IntFlag, BytesIO, to_bytes
from ..base import DesKeyId, DesKeySet, DesSessionKeySet, CommandAPDU, ResponseAPDU, ScpId
from .common import ISecureChannel, SecureLevel

def scp02_3des_cbc_nulliv(key, input):
    cipher = DES3.new(key, DES3.MODE_CBC, bytes([0] * 8))
    return cipher.encrypt(input)

def pad80(buf: bytes, block_size: int):
    pad_len = block_size - len(buf) % block_size
    new_buf = buf + bytes([128]) + bytes(pad_len - 1)
    return new_buf

def scp02_mac_des_3des(key, input, iv):
    des_key = key[0:8]
    des3_key = key + key[0:8]
    cipher_des = DES.new(des_key, DES.MODE_CBC, iv)
    cipher_des3 = DES3.new(des3_key, DES3.MODE_CBC, iv)
    if len(input) > 8:
        temp = cipher_des.encrypt(input[:-8])
        cipher_des3 = DES3.new(des3_key, DES3.MODE_CBC, temp[-8:])
    temp = cipher_des3.encrypt(input[-8:])
    return temp[-8:]

def scp02_mac_3des(key, input, iv=bytes([0] * 8)):
    des3_key = key + key[0:8]
    cipher = DES3.new(des3_key, DES3.MODE_CBC, iv)
    temp = cipher.encrypt(input)
    return temp[-8:]

def scp02_mac_3des_nulliv(key: bytes, input: bytes):
    pass

def scp02_3des_key_check(key):
    data = BytesIO()
    data.write_byte(3)
    plain_text = bytes([0] * 8)
    cipher = DES3.new(key, DES3.MODE_ECB)
    enc_data = cipher.encrypt(plain_text)
    data.write(enc_data[0:3])
    return data.getvalue()

def scp02_3des_ecb(key: bytes, plain: bytes, iv=None):
    cipher = DES3.new(key, DES3.MODE_ECB)
    enc_data = cipher.encrypt(plain)
    return enc_data

def scp02_encrypt_key(dek: bytes, input: bytes) -> Tuple[bytes, bytes]:
    cipher1 = DES3.new(dek, DES3.MODE_ECB)
    encrypted_key = cipher1.encrypt(input)
    cipher2 = DES3.new(input, DES3.MODE_ECB)
    key_check = cipher2.encrypt(bytes(8))[0:3]
    return (encrypted_key, key_check)

class Scp02DeriveConstants(IntEnum):
    C_MAC_CONSTANT = (257, "C-MAC session keys using the Secure Channel base key or MAC key(S-MAC) and the session keys derivation data with a constant of '0101'")
    R_MAC_CONSTANT = (258, "R-MAC session keys using the Secure Channel base key or MAC key(S-MAC) and the session keys derivation data with a constant of '0102'")
    S_ENC_CONSTANT = (386, "Generating the Secure Channel encryption session keys using the Secure Channel base key orencryption key (S-ENC) and the session keys derivation data with a constant of '0182'")
    DEK_CONSTANT = (385, "Generating the Secure Channel data encryption session keys using the Secure Channel base key or data encryption key (DEK) and the session keys derivation data with a constant of '0181'.")

class Scp02SecurityChannel(ISecureChannel):
    session_key_set: DesSessionKeySet
    chaining_mac: bytes = bytes()

    def __init__(self, aid: bytes, session_key_set: DesSessionKeySet, secure_level: SecureLevel=SecureLevel.NONE):
        super().__init__(aid, session_key_set, ScpId.SCP02, secure_level)
        self.s_mac = session_key_set.cmac.key_value
        self.cmac_length = 8

    def encrypt(self, plain: CommandAPDU) -> CommandAPDU:
        encrypted = CommandAPDU().deserialize(BytesIO(plain.to_bytes()))
        if self.secure_level != SecureLevel.NONE:
            encrypted.cla |= 132 if self.logic_channel_number <= 3 else 224
        if SecureLevel.C_MAC in self.secure_level:
            cmac_input = bytearray(encrypted.to_bytes(True))
            cmac_input[4] += 8
            cmac_input = self.chaining_mac + cmac_input
            self.chaining_mac = scp02_mac_des_3des(self.s_mac, pad80(cmac_input, 8), bytes(8))
            encrypted.data += self.chaining_mac
        return encrypted

    def decrypt(self, rsp: ResponseAPDU) -> ResponseAPDU:
        return rsp

def scp02_derive_session_keys(key_set: DesKeySet, sequence_counter: bytes) -> DesSessionKeySet:
    enc = DES3.new(key_set.get_key(DesKeyId.KEY_ENC).key_value, DES3.MODE_CBC, bytes(8)).encrypt(b'\x01\x82' + sequence_counter + bytes(12))
    cmac = DES3.new(key_set.get_key(DesKeyId.KEY_MAC).key_value, DES3.MODE_CBC, bytes(8)).encrypt(b'\x01\x01' + sequence_counter + bytes(12))
    rmac = DES3.new(key_set.get_key(DesKeyId.KEY_MAC).key_value, DES3.MODE_CBC, bytes(8)).encrypt(b'\x01\x02' + sequence_counter + bytes(12))
    dek = DES3.new(key_set.get_key(DesKeyId.KEY_DEK).key_value, DES3.MODE_CBC, bytes(8)).encrypt(b'\x01\x81' + sequence_counter + bytes(12))
    return DesSessionKeySet(enc, cmac, rmac, dek, key_set.chip_id, key_set.security_domain, key_set.key_version_number)