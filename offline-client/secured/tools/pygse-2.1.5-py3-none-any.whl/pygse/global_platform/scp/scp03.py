from typing import Callable, Dict, Literal, Tuple, Union
from Crypto.Hash import CMAC
from Crypto.Cipher import AES
from Crypto.Util.number import long_to_bytes
from ...base.common import IntEnum, IntFlag, BytesIO, to_bytes
from ...base.crypto import new_aes, AES_MODE, kdf_counter, aes_ecb_cmac
from ..base import AesKeyId, AesKeySet, AesSessionKeySet, CommandAPDU, ResponseAPDU, ScpId, Instruction, Scp03SecurityMode
from .common import ISecureChannel, SecureLevel

class Scp03DerivationConstants(IntEnum):
    CARD_CRYPTOGRAM = 0
    HOST_CRYPTOGRAM = 1
    CARD_CHALLENGE = 2
    S_ENC = 4
    S_MAC = 6
    S_RMAC = 7

def scp03_kdf(key: Union[str, bytes], constant: Scp03DerivationConstants, context: Union[str, bytes], derived_key_length: Literal[8, 16, 24, 32]):
    label = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, int(constant)])
    return kdf_counter(master=to_bytes(key), key_len=derived_key_length, prf=aes_ecb_cmac, label=label, context=to_bytes(context), num_keys=1)

def scp03_derive_session_keys(key_set: AesKeySet, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], derived_key_length: Literal[16, 24, 32]=None) -> AesSessionKeySet:
    key_enc = key_set.get_key(AesKeyId.KEY_ENC).key_value
    key_mac = key_set.get_key(AesKeyId.KEY_MAC).key_value
    derived_key_length = derived_key_length or len(key_enc)
    if derived_key_length not in (16, 24, 32):
        raise Exception(f'Bad out_key_length={derived_key_length}')
    context = to_bytes(host_challenge) + to_bytes(card_challenge)
    constant = bytes(11)
    s_enc = kdf_counter(key_enc, derived_key_length, aes_ecb_cmac, constant + b'\x04', context)
    s_mac = kdf_counter(key_mac, derived_key_length, aes_ecb_cmac, constant + b'\x06', context)
    s_rmac = kdf_counter(key_mac, derived_key_length, aes_ecb_cmac, constant + b'\x07', context)
    return AesSessionKeySet(s_enc, s_mac, s_rmac, key_set.get_key(AesKeyId.KEY_DEK), key_set.chip_id, key_set.security_domain, key_set.key_version_number)

def buffer_increment(buf, offset=0):
    new_buf = bytearray(buf)
    buf_len = len(buf)
    if buf_len < 1:
        return buf
    i = offset + buf_len - 1
    while i > 0:
        if buf[i] != 255:
            new_buf[i] = buf[i] + 1
            break
        else:
            new_buf[i] = 0
        i -= 1
    return new_buf

def pad80(buf: bytes, block_size: int):
    pad_len = block_size - len(buf) % block_size
    new_buf = buf + bytes([128]) + bytes(pad_len - 1)
    return new_buf

def scp03_aes_key_check(key: bytes):
    data = BytesIO()
    data.write_byte(3)
    plain_text = bytes([1] * len(key))
    cipher = AES.new(key, AES.MODE_CBC, iv=bytes([0] * len(key)))
    enc_data = cipher.encrypt(plain_text)
    data.write(enc_data[0:3])
    return data.getvalue()

def scp03_encrypt_key(dek: bytes, input: bytes) -> Tuple[bytes, bytes]:
    iv = bytes(16)
    cipher1 = new_aes(dek, AES_MODE.CBC, iv=iv)
    encrypted_key = cipher1.encrypt(input)
    cipher2 = new_aes(input, AES_MODE.CBC, iv=iv)
    key_check = cipher2.encrypt(bytes([1] * 16))[0:3]
    return (encrypted_key, key_check)

class Scp03SecurityChannel(ISecureChannel):
    session_key_set: AesSessionKeySet
    chaining_mac: bytes
    encryption_counter: bytes
    security_mode: Scp03SecurityMode

    def __init__(self, aid: bytes, session_key_set: AesSessionKeySet, secure_level: SecureLevel=SecureLevel.NONE, security_mode: Scp03SecurityMode=Scp03SecurityMode.S8, logic_channel_number: int=0):
        super().__init__(aid, session_key_set, ScpId.SCP03, secure_level, logic_channel_number)
        self.s_enc = session_key_set.enc.key_value
        self.s_mac = session_key_set.mac.key_value
        self.s_rmac = session_key_set.rmac.key_value
        self.security_mode = security_mode or Scp03SecurityMode.S8
        self.cmac_length = 8 if self.security_mode == Scp03SecurityMode.S8 else 16
        self.chaining_mac = bytes(16)
        self.encryption_counter = bytes(16)

    def encrypt(self, plain: CommandAPDU) -> CommandAPDU:
        encrypted = CommandAPDU().deserialize(BytesIO(plain.to_bytes()))
        if self.secure_level != SecureLevel.NONE:
            encrypted.cla |= 132 if self.logic_channel_number <= 3 else 224
        if SecureLevel.C_DEC in self.secure_level:
            self.encryption_counter = buffer_increment(self.encryption_counter)
            if len(encrypted.data) > 0:
                cipher = AES.new(self.s_enc, AES.MODE_CBC, iv=bytes([0] * len(self.s_enc)))
                iv = cipher.encrypt(self.encryption_counter)
                cipher = AES.new(self.s_enc, AES.MODE_CBC, iv=iv)
                aes_input = pad80(encrypted.data, AES.block_size)
                encrypted.data = cipher.encrypt(aes_input)
        if SecureLevel.C_MAC in self.secure_level:
            cmac_input = bytearray(encrypted.to_bytes(True))
            cmac_input[4] += self.cmac_length
            cmac_input = self.chaining_mac + cmac_input
            self.chaining_mac = aes_ecb_cmac(self.s_mac, cmac_input)
            encrypted.data += self.chaining_mac[0:self.cmac_length] if self.cmac_length == 8 else self.chaining_mac
        return encrypted

    def decrypt(self, rsp: ResponseAPDU) -> ResponseAPDU:
        return rsp

def __test_scp03_derive_session_keys():
    test_result = []
    key_set = AesKeySet()
    key_set.add_key(AesKeyId.KEY_ENC, '101112131415161718191A1B1C1D1E1F')
    key_set.add_key(AesKeyId.KEY_MAC, '101112131415161718191A1B1C1D1E1F')
    key_set.add_key(AesKeyId.KEY_DEK, '101112131415161718191A1B1C1D1E1F')

    def verify(label: str, a: bytes, b: str):
        a = hex(a)
        b = b.upper()
        return [label, a, b, '√' if a == b else '×']
    host_challenge = to_bytes('629D07CF88AD5EBC')
    card_challenge = to_bytes('5C905AA52CC8B8F5')
    session_key_set = scp03_derive_session_keys(key_set, host_challenge, card_challenge)
    test_result.append(verify('S-ENC', session_key_set.enc.key_value, '24263355ef925593b68e12b358b90173'))
    test_result.append(verify('S-MAC', session_key_set.mac.key_value, 'cc0cd48a5472a2f331c67f257537b98e'))
    test_result.append(verify('S-RMAC', session_key_set.rmac.key_value, 'ce507542669940b169acf430efd69c2d'))
    host_cryptogram = scp03_kdf(session_key_set.mac.key_value, Scp03DerivationConstants.HOST_CRYPTOGRAM, host_challenge + card_challenge, len(card_challenge))
    test_result.append(verify('Host Cryptogram', host_cryptogram, 'd9aaa9840ede366a'))
    secure_channel = Scp03SecurityChannel(session_key_set, SecureLevel.C_MAC)
    plain = CommandAPDU(cla=132, ins=Instruction.EXTERNAL_AUTHENTICATE, p1=SecureLevel.C_MAC, p2=0, data=host_cryptogram)
    encrypted = secure_channel.encrypt(plain)
    test_result.append(verify('Chaining MAC', secure_channel.chaining_mac, 'd957c3cbfba19b82d624f72803e181d8'))
    test_result.append(verify('EXTERNAL AUTHENTICATE Plain', plain.to_bytes(), '8482010008d9aaa9840ede366a'))
    test_result.append(verify('EXTERNAL AUTHENTICATE Encrypted', encrypted.to_bytes(), '8482010010d9aaa9840ede366ad957c3cbfba19b82'))
    from ...base.common import print_table
    print_table(['验证项', '当前值', '期望值', '结果'], test_result)
    print('')
__all__ = [Scp03DerivationConstants.__name__, scp03_kdf.__name__, scp03_derive_session_keys.__name__, Scp03SecurityChannel.__name__]