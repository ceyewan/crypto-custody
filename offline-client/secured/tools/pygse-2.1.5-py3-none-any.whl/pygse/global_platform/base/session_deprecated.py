from abc import abstractmethod
from typing import List, Literal, Union, overload
from .key import KeySet
from .apdu import CommandAPDU, ResponseAPDU, ScpId
from .cap_file import CapFile