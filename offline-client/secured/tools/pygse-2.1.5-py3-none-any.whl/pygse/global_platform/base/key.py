from datetime import datetime
from enum import IntEnum, IntFlag
from os import urandom
from typing import Dict, List, Literal, Union, overload
from ...base.crypto import aes_cbc_encrypt, des3_cbc_encrypt, sm4_cbc_encrypt
from ...base.common import to_bytes
from .apdu import KeyType, KeyUsageQualifier, PutKeyData, KeyComponent

class KeySetAlgorithm(IntEnum):
    AES = 1
    DES = 2
    SM4 = 3
    HMAC = 4
    RSA = 5
    ECC = 6

    def __str__(self):
        return f'{self.name}({self.value})'

class DesKeyId(IntEnum):
    KEY_ENC = 1
    KEY_MAC = 2
    KEY_DEK = 3

class DesSessionKeyId(IntEnum):
    S_ENC = 1
    S_CMAC = 2
    S_RMAC = 3
    S_DEK = 4

class AesKeyId(IntEnum):
    KEY_ENC = 1
    KEY_MAC = 2
    KEY_DEK = 3

class AesSessionKeyId(IntEnum):
    S_ENC = 1
    S_MAC = 2
    S_RMAC = 3
    DEK = 4

class Sm4KeyId(IntEnum):
    KEY_ENC = 1
    KEY_MAC = 2
    KEY_DEK = 3

class Sm4SessionKeyId(IntEnum):
    S_ENC = 1
    S_MAC = 2
    S_RMAC = 3
    DEK = 4

class RsaKeyId(IntEnum):
    RSA_PUBLIC_KEY_PUBLIC_EXPONENT_E = 1
    RSA_PUBLIC_KEY_MODULUS_N_CLEAR_TEXT = 2
    RSA_PRIVATE_KEY_MODULUS_N = 3
    RSA_PRIVATE_KEY_PRIVATE_EXPONENT_D = 4
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_P = 5
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_Q = 6
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_PQ = 7
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_DP1 = 8
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_DQ1 = 9

class EccKeyId(IntEnum):
    ECC_PUBLIC_KEY = 1
    ECC_PRIVATE_KEY = 2
    ECC_P = 3
    ECC_A = 4
    ECC_B = 5
    ECC_G = 6
    ECC_N = 7
    ECC_K = 8
    ECC_KEY_REFERENCE = 9

class HmacKeyId(IntEnum):
    HMAC_SHA1 = 1
    HMAC_SHA1_160 = 2
KeyIdentifier = Union[int, DesKeyId, AesKeyId, Sm4KeyId, RsaKeyId, EccKeyId, HmacKeyId, DesSessionKeyId, AesSessionKeyId, Sm4SessionKeyId]

class Key:

    def __init__(self, key_set_id: bytes=None, key_identifier: KeyIdentifier=None, key_type: Union[int, KeyType]=None, key_usage_qualifier: KeyUsageQualifier=None, key_access: int=None, key_value: bytes=None, key_length: int=None):
        self.id = urandom(16)
        self.key_set_id = key_set_id
        self.key_identifier = key_identifier
        self.key_type = KeyType(key_type) if key_type else None
        self.key_usage_qualifier = key_usage_qualifier
        self.key_access = key_access
        self.key_value = to_bytes(key_value)
        self.key_length = len(self.key_value) if self.key_value else key_length
    id: bytes
    key_set_id: bytes
    key_identifier: KeyIdentifier
    key_type: KeyType
    key_usage_qualifier: KeyUsageQualifier
    key_access: int
    key_value: bytes
    key_check_value: bytes
    key_length: int
    update_time: datetime
    create_time: datetime

    def clone(self):
        obj = self.__class__()
        obj.__dict__.update(self.__dict__)
        return obj

    def to_json(self, ignore_value: bool=False):
        ret = self.__dict__.copy()
        for (k, v) in ret.items():
            if isinstance(v, (IntEnum, IntFlag)):
                ret[k] = int(v)
        if ignore_value:
            ret.pop('key_value')
        return ret

    @classmethod
    def from_json(cls, data: Dict):
        key = cls()
        key.__dict__.update(data)
        return key

class KeySet:

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=None, algorithm: KeySetAlgorithm=None):
        self.id = urandom(16)
        self.chip_id = chip_id
        self.security_domain = security_domain
        self.key_version_number = key_version_number
        self.algorithm = algorithm
        self.create_time = datetime.now()
        self.keys = {}
    id: bytes = None
    chip_id: bytes = None
    security_domain: bytes = None
    algorithm: KeySetAlgorithm = None
    key_version_number: int = None
    update_time: datetime = None
    create_time: datetime = None
    keys: Dict[KeyIdentifier, Key] = None

    @overload
    def add_key(self, key_identifier: DesKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: AesKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: Sm4KeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: RsaKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: EccKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: HmacKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: DesSessionKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: AesSessionKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: Sm4SessionKeyId, key_value: Union[str, bytes]) -> Key:
        pass

    @overload
    def add_key(self, key_identifier: int, key_value: Union[str, bytes], key_type: KeyType) -> Key:
        pass

    def add_key(self, key_identifier: KeyIdentifier, key_value: Union[str, bytes], key_type: KeyType=None) -> Key:
        key_usage_qualifier: KeyUsageQualifier = 0
        if isinstance(key_identifier, DesKeyId):
            key_type = KeyType.DES
            if key_identifier == DesKeyId.KEY_ENC:
                key_usage_qualifier = KeyUsageQualifier.C_ENC_AND_R_ENC
            if key_identifier == DesKeyId.KEY_MAC:
                key_usage_qualifier = KeyUsageQualifier.C_MAC_R_MAC
            if key_identifier == DesKeyId.KEY_DEK:
                key_usage_qualifier = KeyUsageQualifier.C_DEK_AND_R_DEK
        elif isinstance(key_identifier, AesKeyId):
            key_type = KeyType.AES
            if key_identifier == AesKeyId.KEY_ENC:
                key_usage_qualifier = KeyUsageQualifier.C_ENC_AND_R_ENC
            if key_identifier == AesKeyId.KEY_MAC:
                key_usage_qualifier = KeyUsageQualifier.C_MAC_R_MAC
            if key_identifier == AesKeyId.KEY_DEK:
                key_usage_qualifier = KeyUsageQualifier.C_DEK_AND_R_DEK
        elif isinstance(key_identifier, Sm4KeyId):
            key_type = KeyType.SM4
            if key_identifier == Sm4KeyId.KEY_ENC:
                key_usage_qualifier = KeyUsageQualifier.C_ENC_AND_R_ENC
            if key_identifier == Sm4KeyId.KEY_MAC:
                key_usage_qualifier = KeyUsageQualifier.C_MAC_R_MAC
            if key_identifier == Sm4KeyId.KEY_DEK:
                key_usage_qualifier = KeyUsageQualifier.C_DEK_AND_R_DEK
        elif isinstance(key_identifier, DesSessionKeyId):
            key_type = KeyType.DES
            if key_identifier == DesSessionKeyId.S_ENC:
                key_usage_qualifier = KeyUsageQualifier.C_ENC_AND_R_ENC
            if key_identifier == DesSessionKeyId.S_CMAC:
                key_usage_qualifier = KeyUsageQualifier.C_MAC
            if key_identifier == DesSessionKeyId.S_RMAC:
                key_usage_qualifier = KeyUsageQualifier.R_MAC
            if key_identifier == DesSessionKeyId.S_DEK:
                key_usage_qualifier = KeyUsageQualifier.C_DEK_AND_R_DEK
        elif isinstance(key_identifier, AesSessionKeyId):
            key_type = KeyType.AES
            if key_identifier == AesSessionKeyId.S_ENC:
                key_usage_qualifier = KeyUsageQualifier.C_ENC_AND_R_ENC
            if key_identifier == AesSessionKeyId.S_MAC:
                key_usage_qualifier = KeyUsageQualifier.C_MAC
            if key_identifier == AesSessionKeyId.S_RMAC:
                key_usage_qualifier = KeyUsageQualifier.R_MAC
            if key_identifier == AesSessionKeyId.DEK:
                key_usage_qualifier = KeyUsageQualifier.C_DEK_AND_R_DEK
        elif isinstance(key_identifier, Sm4SessionKeyId):
            key_type = KeyType.SM4
            if key_identifier == Sm4SessionKeyId.S_ENC:
                key_usage_qualifier = KeyUsageQualifier.C_ENC_AND_R_ENC
            if key_identifier == Sm4SessionKeyId.S_MAC:
                key_usage_qualifier = KeyUsageQualifier.C_MAC
            if key_identifier == Sm4SessionKeyId.S_RMAC:
                key_usage_qualifier = KeyUsageQualifier.R_MAC
            if key_identifier == Sm4SessionKeyId.DEK:
                key_usage_qualifier = KeyUsageQualifier.C_DEK_AND_R_DEK
        elif isinstance(key_identifier, RsaKeyId):
            key_type = KeyType(160 + key_identifier - 1)
        elif isinstance(key_identifier, EccKeyId):
            key_type = KeyType.ECC_KEY_REFERENCE if key_identifier == EccKeyId.ECC_KEY_REFERENCE else KeyType(176 + key_identifier - 1)
        elif isinstance(key_identifier, HmacKeyId):
            key_type = KeyType(144 + key_identifier - 1)
        elif isinstance(key_identifier, int):
            if key_identifier < 1 or key_identifier >= 255:
                raise Exception(f'key_identifier required a value between 1-254!')
            if not key_type:
                raise Exception(f'key_type required!')
            key_type = KeyType(key_type)
        else:
            raise Exception(f'The type of key_identifier must be one of DesKeyId, AesKeyId, RsaKeyId, EccKeyId, int!')
        key = Key(self.id, key_identifier, key_type, key_usage_qualifier, 0, key_value)
        self.keys[key.key_identifier] = key
        return key

    @overload
    def get_key(self, key_identifier: DesKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: AesKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: Sm4KeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: RsaKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: EccKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: HmacKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: DesSessionKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: AesSessionKeyId) -> Key:
        pass

    @overload
    def get_key(self, key_identifier: Sm4SessionKeyId) -> Key:
        pass

    def get_key(self, key_identifier: KeyIdentifier) -> Key:
        return self.keys.get(key_identifier, None)

    def clone(self):
        obj = self.__class__()
        obj.__dict__.update(self.__dict__)
        obj.keys = self.keys.copy()
        for id in sorted(obj.keys.keys()):
            obj.keys[id] = self.keys[id].clone()
        return obj

    def to_json(self, ignore_key_value: bool=False):
        ret = self.__dict__.copy()
        for (k, v) in ret.items():
            if isinstance(v, (IntEnum, IntFlag)):
                ret[k] = int(v)
        ret['keys'] = list(map(lambda k: k.to_json(ignore_key_value), self.keys.values()))
        return ret

    @classmethod
    def from_json(cls, data: Dict):
        key_set = cls()
        key_set.__dict__.update(data)
        if 'keys' in data:
            key_set.keys = {}
            for key in map(lambda k: Key.from_json(k), data['keys']):
                key_set.keys[key.key_identifier] = key
        return key_set

class DesKeySet(KeySet):

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=32):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.DES)

class AesKeySet(KeySet):

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=48):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.AES)

class Sm4KeySet(KeySet):

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=80):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.SM4)

class RsaKeySet(KeySet):

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=64):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.RSA)

class EccKeySet(KeySet):

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=80):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.ECC)

class HmacKeySet(KeySet):

    def __init__(self, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=96):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.HMAC)

class DesSessionKeySet(KeySet):

    def __init__(self, s_enc: bytes=None, s_cmac: bytes=None, s_rmac: bytes=None, s_dek: bytes=None, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=0):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.DES)
        if s_enc:
            self.add_key(DesSessionKeyId.S_ENC, s_enc)
        if s_cmac:
            self.add_key(DesSessionKeyId.S_CMAC, s_cmac)
        if s_rmac:
            self.add_key(DesSessionKeyId.S_RMAC, s_rmac)
        if s_dek:
            self.add_key(DesSessionKeyId.S_DEK, s_dek)

    @property
    def enc(self):
        return self.get_key(DesSessionKeyId.S_ENC)

    @property
    def cmac(self):
        return self.get_key(DesSessionKeyId.S_CMAC)

    @property
    def rmac(self):
        return self.get_key(DesSessionKeyId.S_RMAC)

    @property
    def dek(self):
        return self.get_key(DesSessionKeyId.S_DEK)

class AesSessionKeySet(KeySet):

    def __init__(self, s_enc: bytes=None, s_mac: bytes=None, s_rmac: bytes=None, dek: Union[bytes, Key]=None, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=0):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.AES)
        if s_enc:
            self.add_key(AesSessionKeyId.S_ENC, s_enc)
        if s_mac:
            self.add_key(AesSessionKeyId.S_MAC, s_mac)
        if s_rmac:
            self.add_key(AesSessionKeyId.S_RMAC, s_rmac)
        if dek:
            if isinstance(dek, Key):
                k = self.add_key(AesSessionKeyId.DEK, dek.key_value)
                k.id = dek.id
            else:
                self.add_key(AesSessionKeyId.DEK, dek)

    @property
    def enc(self) -> Key:
        return self.get_key(AesSessionKeyId.S_ENC)

    @property
    def mac(self) -> Key:
        return self.get_key(AesSessionKeyId.S_MAC)

    @property
    def rmac(self) -> Key:
        return self.get_key(AesSessionKeyId.S_RMAC)

    @property
    def dek(self) -> Key:
        return self.get_key(AesSessionKeyId.DEK)

class Sm4SessionKeySet(KeySet):

    def __init__(self, s_enc: bytes=None, s_mac: bytes=None, s_rmac: bytes=None, dek: Union[bytes, Key]=None, chip_id: bytes=None, security_domain: bytes=None, key_version_number: int=0):
        super().__init__(chip_id, security_domain, key_version_number, KeySetAlgorithm.SM4)
        if s_enc:
            self.add_key(Sm4SessionKeyId.S_ENC, s_enc)
        if s_mac:
            self.add_key(Sm4SessionKeyId.S_MAC, s_mac)
        if s_rmac:
            self.add_key(Sm4SessionKeyId.S_RMAC, s_rmac)
        if dek:
            if isinstance(dek, Key):
                k = self.add_key(Sm4SessionKeyId.DEK, dek.key_value)
                k.id = dek.id
            else:
                self.add_key(Sm4SessionKeyId.DEK, dek)

    @property
    def enc(self) -> Key:
        return self.get_key(Sm4SessionKeyId.S_ENC)

    @property
    def mac(self) -> Key:
        return self.get_key(Sm4SessionKeyId.S_MAC)

    @property
    def rmac(self) -> Key:
        return self.get_key(Sm4SessionKeyId.S_RMAC)

    @property
    def dek(self) -> Key:
        return self.get_key(Sm4SessionKeyId.DEK)

def calc_key_check_value(key: Key) -> bytes:
    if key.key_type == KeyType.DES:
        return des3_cbc_encrypt(key.key_value, bytes(8))[0:3]
    if key.key_type == KeyType.AES:
        return aes_cbc_encrypt(key.key_value, bytes([1] * 16), iv=bytes(16))[0:3]
    if key.key_type == KeyType.SM4:
        return sm4_cbc_encrypt(key.key_value, bytes([2] * 16), iv=bytes(16))[0:3]
    raise Exception(f'Unsupported KeyType={key.key_type} while generate the Key Check Value(KCV)')
__all__ = [KeySetAlgorithm.__name__, DesKeyId.__name__, AesKeyId.__name__, Sm4KeyId.__name__, RsaKeyId.__name__, EccKeyId.__name__, HmacKeyId.__name__, Key.__name__, KeySet.__name__, DesKeySet.__name__, AesKeySet.__name__, Sm4KeySet.__name__, RsaKeySet.__name__, EccKeySet.__name__, HmacKeySet.__name__, DesSessionKeySet.__name__, AesSessionKeySet.__name__, Sm4SessionKeySet.__name__, calc_key_check_value.__name__]