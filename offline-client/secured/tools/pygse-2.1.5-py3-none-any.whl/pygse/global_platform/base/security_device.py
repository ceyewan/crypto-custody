import logging
from typing import Literal, Tuple, Type, TypeVar, Union
from ...base.common import ReadonlyProperty, BytesIO, to_bytes
from ...base.device import ISeDevice
from .constants import GseConstants
from .apdu import *
T_RSP = TypeVar('T_RSP', bound=ResponseAPDU)

class SecurityDevice:
    cplc: CardProductionLifeCycle = None
    version_info: Union[CosVersionGen1, CosVersionGen2] = None
    logic_channel_number: int = 0

    def __init__(self, device: ISeDevice, logic_channel_number: int=None) -> None:
        self.logic_logic_channel_number = logic_channel_number
        self.device = device
        self.logger = logging.getLogger(device.name)

    @property
    def chip_id(self):
        return self.cplc.chip_id if self.cplc else None

    @property
    def name(self):
        return self.device.name

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        await self.close()

    async def close(self):
        return await self.device.close()

    async def disconnect(self):
        return await self.device.disconnect()

    async def reset(self):
        return await self.device.reset()

    async def transmit(self, apdu: Union[CommandAPDU, str, bytes], rsp_cls: Type[T_RSP]=ResponseAPDU) -> T_RSP:
        if self.logic_channel_number:
            if isinstance(apdu, CommandAPDU):
                apdu.logic_channel_number = self.logic_channel_number
            else:
                apdu = CommandAPDU().deserialize(BytesIO(apdu))
                apdu.logic_channel_number = self.logic_channel_number
        rsp_cls = rsp_cls or ResponseAPDU
        bytes_apdu = to_bytes(apdu)
        timeout = 41 if bytes_apdu[1] in (Instruction.INITIALIZE_UPDATE, Instruction.EXTERNAL_AUTHENTICATE) else None
        return rsp_cls(await self.device.transmit(bytes_apdu, timeout))

    async def select(self, aid: Union[str, bytes]=None, p1: int=4, p2: Literal[0, 2]=0) -> ResponseAPDU:
        req = CommandAPDU(ins=Instruction.SELECT, p1=p1, p2=p2, data=to_bytes(aid), logic_channel_number=self.logic_channel_number)
        return await self.transmit(req)

    async def get_data(self, tag: Union[int, GetDataTag], data: bytes=None) -> ResponseAPDU:
        req = CommandAPDU(cla=128, ins=Instruction.GET_DATA_CA, p1=tag >> 8, p2=tag & 255, data=data, logic_channel_number=self.logic_channel_number)
        return await self.transmit(req)

    async def get_cplc(self) -> CardProductionLifeCycle:
        if self.cplc:
            return self.cplc
        await self.reset()
        rsp = await self.select()
        if not rsp.status_ok:
            self.logger.warning(f'This can not select default ISD on this device, rsp={rsp}.')
            return None
        rsp = await self.get_data(GetDataTag.CARD_PRODUCTION_LIFE_CYCLE)
        if not rsp.status_ok or not rsp.data or (not rsp.data.startswith(bytes([159, 127]))):
            raise Exception(f'Can not GET CPLC, rsp={rsp}')
        s = BytesIO(rsp.data)
        s.seek(3)
        self.cplc = CardProductionLifeCycle().deserialize(s)
        return self.cplc

    @Property
    def is_in_root2(self) -> bool:
        pass

    async def enter_root2(self) -> bool:
        await self.reset()
        if self.is_in_root2:
            return True
        self.logger.info(f'Enter ROOT2...')
        rsp = await self.select(GseConstants.ROOT2_AID)
        self.is_in_root2 = rsp.status_ok
        return rsp.status_ok

    async def exit_root2(self) -> bool:
        if self.is_in_root2:
            self.logger.info(f'Exit ROOT2...')
            rsp = await self.transmit(GseConstants.EXIT_ROOT2)
            if rsp.status_ok:
                self.is_in_root2 = False
            else:
                await self.get_cos_version(True)
        return not self.is_in_root2

    async def get_cos_version(self, ignore_gotten: bool=False) -> Union[CosVersionGen1, CosVersionGen2]:
        if not ignore_gotten and self.version_info:
            return self.version_info
        rsp = await self.select(GseConstants.GET_COS_VERSION_AID)
        if not rsp.status_ok:
            raise Exception(f'Can not select {hex(GseConstants.GET_COS_VERSION_AID)}, rsp={rsp}')
        self.version_info = CosVersion.new(rsp.data)
        self.is_in_root2 = self.version_info.cos_type == CosType.ROOT2
        return self.version_info

    async def get_cos_version_str(self) -> str:
        rsp = await self.select()
        if not rsp.status_ok:
            raise Exception(f'Can not select default ISD, rsp={rsp}')
        rsp = await self.transmit(GseConstants.GET_VERSION_STR)
        if not rsp.status_ok:
            raise Exception(f'Can not get version string, rsp={rsp}')
        return rsp.data.decode() if rsp.data else ''

    async def get_goodix_preinstalled_applet_version(self, aid: Union[str, bytes]) -> Tuple[GoodixPreinstalledAppletVersionInformation, StatusCode]:
        rsp = await self.select()
        if not rsp.status_ok:
            return (None, rsp.status_code)
        rsp = await self.select(aid)
        if rsp.status_ok:
            rsp = await self.transmit(GseConstants.GET_PREINSTALLED_APPLET_VERSION)
            if not rsp.status_ok:
                return (None, rsp.status_code)
            return (GoodixPreinstalledAppletVersionInformation(rsp.data), rsp.status_code)
        return (None, rsp.status_code)

    async def get_user_preinstalled_counter(self) -> Tuple[int, StatusCode]:
        cos_version = await self.get_cos_version(True)
        if isinstance(cos_version, CosVersionGen1):
            if self.is_in_root2:
                await self.exit_root2()
                cos_version = await self.get_cos_version(True)
            if self.is_in_root2:
                raise Exception(f'Can not exit root2!')
            rsp = await self.select(GseConstants.SEM_AID)
            if not rsp.status_ok:
                raise Exception(f'No BPF application({GseConstants.SEM_AID}) exists!')
        else:
            ok = await self.enter_root2()
            if not ok:
                raise Exception(f'Can not enter ROOT2!')
        rsp = await self.transmit(GseConstants.GET_BPF_COUNTER)
        if rsp.status_ok:
            if len(rsp.data) == 11:
                return (int.from_bytes(rsp.data[-6:-2], 'big'), rsp.status_code)
            if len(rsp.data) == 19:
                return (int.from_bytes(rsp.data[-8:-4], 'big'), rsp.status_code)
        return (4294967295, rsp.status_code)
__all__ = [SecurityDevice.__name__]