from typing import Dict
from ...base.common import static_class, StaticProperty

@static_class
class GseConstants:

    @StaticProperty
    def GP_ISD_AID():
        return bytes.fromhex('A000000151000000')

    @StaticProperty
    def GET_COS_VERSION_AID():
        return bytes.fromhex('A0000000868F00000000000000000002')

    @StaticProperty
    def SEM_AID():
        return bytes.fromhex('A00000015153454D5300000001')

    @StaticProperty
    def ROOT2_AID():
        return bytes.fromhex('A0000000868F00000000000000000001')

    @StaticProperty
    def EXIT_ROOT2():
        return bytes.fromhex('80F10000')

    @StaticProperty
    def GOODIX_PREINSTALLED_APPLETS() -> Dict[bytes, bool]:
        return dict([(bytes.fromhex('A00000484447534E3131100010180002'), False), (bytes.fromhex('A00000484447534E31311000101A0002'), False), (bytes.fromhex('A00000015153504341534400'), False), (bytes.fromhex('A0000003330053440121561126241000'), False), (bytes.fromhex('A0000000005343434101'), False), (bytes.fromhex('A00000484447534E3131100010030000'), True), (bytes.fromhex('A00000015143525300'), True), (bytes.fromhex('325041592E5359532E4444463031'), True), (bytes.fromhex('A00000015141434C00'), True), (bytes.fromhex('A00000015141434C08'), True), (bytes.fromhex('A000000809434343444B417631'), True), (bytes.fromhex('A00000484447534E3131400040020002'), True), (bytes.fromhex('A00000015153454D5300000001'), True), (bytes.fromhex('A000000476575652434F4D4D30'), True), (bytes.fromhex('A000000476575652434F524530010101'), False), (bytes.fromhex('A000000062'), True)])

    @StaticProperty
    def GET_PREINSTALLED_APPLET_VERSION() -> bytes:
        return bytes.fromhex('80CAFF8010476F6F6469784170706C657420566572')

    @StaticProperty
    def GET_BPF_COUNTER() -> bytes:
        return bytes.fromhex('80A300000000')

    @StaticProperty
    def GET_VERSION_STR() -> bytes:
        return bytes.fromhex('80CAFF01020002')