from .apdu import StatusCode, ResponseAPDU

class GPException(Exception):

    def __init__(self, sw: StatusCode, message: str=''):
        self.sw = sw or 0
        self.message = message

    def __str__(self):
        return f'SW: {str(self.sw)}. Error: {self.message}'

    @staticmethod
    def check(rsp: ResponseAPDU, message: str=''):
        if not rsp.status_ok:
            raise GPException(rsp.status_code, message)
__all__ = [GPException.__name__]