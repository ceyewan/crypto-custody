from typing import Dict, Iterable, SupportsBytes, SupportsIndex, SupportsInt, overload, Protocol, ByteString, runtime_checkable
from ...base.common import Int, IntEnum, IntFlag

class Instruction(IntEnum):
    DEACTIVATE_FILE = Int(4)
    ERASE_RECORDS = Int(12)
    ERASE_BINARY_0E = Int(14)
    ERASE_BINARY_0F = Int(15)
    PERFORM_SCQL_OPERATION = Int(16)
    PERFORM_TRANSACTION_OPERATION = Int(18)
    PERFORM_USER_OPERATION = Int(20)
    VERIFY_20 = Int(32)
    VERIFY_21 = Int(33)
    MANAGE_SECURITY_ENVIRONMENT = Int(34)
    CHANGE_REFERENCE_DATA = Int(36)
    DISABLE_VERIFICATION_REQUIREMENT = Int(38)
    ENABLE_VERIFICATION_REQUIREMENT = Int(40)
    PERFORM_SECURITY_OPERATION = Int(42)
    RESET_RETRY_COUNTER = Int(44)
    ACTIVATE_FILE = Int(68)
    GENERATE_ASYMMETRIC_KEY_PAIR = Int(70)
    INITIALIZE_UPDATE = Int(80)
    MANAGE_CHANNEL = Int(112)
    END_RMAC_SESSION = Int(120)
    BEGIN_RMAC_SESSION = Int(122)
    EXTERNAL_AUTHENTICATE = Int(130)
    GET_CHALLENGE = Int(132)
    GENERAL_AUTHENTICATE_86 = Int(134)
    GENERAL_AUTHENTICATE_87 = Int(135)
    INTERNAL_AUTHENTICATE = Int(136)
    SECURE_INITIALIZATION = Int(160)
    SECURE_PROTOCOL = Int(161)
    SECURE_UPDATE_KEY = Int(162)
    SECURE_GET_INFO = Int(163)
    SELECT = Int(164)
    READ_BINARY_B0 = Int(176)
    READ_BINARY_B1 = Int(177)
    READ_RECORDS_B2 = Int(178)
    READ_RECORDS_B3 = Int(179)
    GET_RESPONSE = Int(192)
    ENVELOPE_C2 = Int(194)
    ENVELOPE_C3 = Int(195)
    GET_DATA_CA = Int(202, doc="GET_DATA. If CLA = '00' - '0F', '40' - '4F', or '60' - '6F', even or odd instruction code 'CA' or 'CB'.\nIf CLA = '80' - '8F', 'C0' - 'CF', or 'E0' - 'EF', even instruction code 'CA'")
    GET_DATA_CB = Int(203, doc="GET_DATA. If CLA = '00' - '0F', '40' - '4F', or '60' - '6F', even or odd instruction code 'CA' or 'CB'.\nIf CLA = '80' - '8F', 'C0' - 'CF', or 'E0' - 'EF', even instruction code 'CA'")
    WRITE_BINARY_D0 = Int(208)
    WRITE_BINARY_D1 = Int(209)
    WRITE_RECORD = Int(210)
    UPDATE_BINARY_D6 = Int(214)
    UPDATE_BINARY_D7 = Int(215)
    PUT_KEY = Int(216)
    PUT_DATA_DA = Int(218)
    PUT_DATA_DB = Int(219)
    UPDATE_RECORD_DC = Int(220)
    UPDATE_RECORD_DD = Int(221)
    CREATE_FILE = Int(224)
    GOODIX_PRIVATE = Int(225)
    STORE_DATA = Int(226)
    DELETE = Int(228)
    INSTALL = Int(230)
    LOAD = Int(232)
    SET_STATUS = Int(240)
    GET_STATUS = Int(242)

    @property
    def doc(self):
        return self.value.__doc__

    def __new__(cls, value):
        obj = int.__new__(cls, value)
        obj._value_ = value
        return obj

    def __str__(self):
        return f'{super().__str__()}(0x{self.value:02X})' if not self.doc else f'{super().__str__()}(0x{self.value:02X}), {self.doc}'

class KeyType(IntEnum):
    DES_MODE = (128, 'DES - mode (ECB/CBC) implicitly known')
    PRESHARED_KEY = (133, 'Pre-Shared Key for Transport Layer Security')
    AES_KEY = (136, 'AES (16, 24, or 32 long keys)')
    HMAC_SHA1 = (144, 'HMAC-SHA1 - length of HMAC is implicitly known')
    HMAC_SHA1_160 = (145, 'HMAC-SHA1-160 - length of HMAC is 160 bits')
    RSA_PUBLIC_KEY_PUBLIC_EXPONENT_E = (160, 'RSA Public Key - public exponent e component (clear text)')
    RSA_PUBLIC_KEY_MODULUS_N_CLEAR_TEXT = (161, 'RSA Public Key - modulus N component (clear text)')
    RSA_PRIVATE_KEY_MODULUS_N = (162, 'RSA Private Key - modulus N component')
    RSA_PRIVATE_KEY_PRIVATE_EXPONENT_D = (163, 'RSA Private Key - private exponent d component')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_P = (164, 'RSA Private Key - Chinese Remainder P component')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_Q = (165, 'RSA Private Key - Chinese Remainder Q component')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_PQ = (166, 'RSA Private Key - Chinese Remainder PQ component (q-1 mod p)')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_DP1 = (167, 'RSA Private Key - Chinese Remainder DP1 component (d mod (p-1))')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_DQ1 = (168, 'RSA Private Key - Chinese Remainder DQ1 component (d mod (q-1))')
    ECC_PUBLIC_KEY = (176, 'ECC public key')
    ECC_PRIVATE_KEY = (177, 'ECC private key')
    ECC_P = (178, 'ECC field parameter P (field specification)')
    ECC_A = (179, 'ECC field parameter A (first coefficient)')
    ECC_B = (180, 'ECC field parameter B (second coefficient)')
    ECC_G = (181, 'ECC field parameter G (generator)')
    ECC_N = (182, 'ECC field parameter N (order of generator)')
    ECC_K = (183, 'ECC field parameter k (cofactor of order of generator)')
    ECC_KEY_REFERENCE = (240, 'ECC key parameters reference')

    @staticmethod
    def __get_missing_value__(value: int):
        if 0 <= value and value <= 127:
            return Int(value, doc='Reserved for private use')
        if 129 <= value and value <= 132:
            (Int(value, doc='Reserved for historical reasons'),)
        if 134 <= value and value <= 135:
            (Int(value, doc='RFU (symmetric algorithms'),)
        if 137 <= value and value <= 143:
            (Int(value, doc='RFU (symmetric algorithms'),)
        if 146 <= value and value <= 159:
            (Int(value, doc='RFU (symmetric algorithms'),)
        if 169 <= value and value <= 175:
            (Int(value, doc='RFU (asymmetric algorithms'),)
        if 184 <= value and value <= 239:
            (Int(value, doc='RFU (asymmetric algorithms'),)
        if 241 <= value and value <= 254:
            (Int(value, doc='RFU (asymmetric algorithms'),)
        if 65280 <= value and value <= 65535:
            (Int(value, doc='Extended format (usage defined for specific APDU commands; e.g. PUT KEY'),)

class ExecutableLoadFileLifeCycleCoding(IntEnum):
    LOGICALLY_DELETED_WITH_REFERENCES = (0, 'LOGICALLY DELETED WITH REFERENCES')
    LOADED = (1, 'LOADED')

class ApplicationLifeCycleCoding(IntEnum):
    INSTALLED = (3, 'INSTALLED')
    SELECTABLE = (7, 'SELECTABLE')
    LOCKED = (135, 'LOCKED')

    @staticmethod
    def __get_missing_value__(value: int):
        if value & 131 == 131:
            return Int(value, doc='LOCKED')
        if value & 135 == 7:
            return Int(value, doc='Application Specific State')
        return Int(value, doc='RFU')

class SecurityDomainLifeCycleCoding(IntEnum):
    INSTALLED = (3, 'INSTALLED')
    SELECTABLE = (7, 'SELECTABLE')
    PERSONALIZED = (15, 'PERSONALIZED')
    LOCKED = (131, 'LOCKED')

    @staticmethod
    def __get_missing_value__(value: int):
        if value & 131 == 131:
            return Int(value, doc='LOCKED')
        return Int(value, doc='RFU')

class CardLifeCycleCoding(IntEnum):
    OP_READY = (1, 'OP_READY')
    INITIALIZED = (7, 'INITIALIZED')
    SECURED = (15, 'SECURED')
    CARD_LOCKED = (127, 'CARD_LOCKED')
    TERMINATED = (255, 'TERMINATED')

class CLASpecType(IntEnum):
    ISO_IEC_7816 = (0, 'Command defined in ISO/IEC 7816')
    GLOBAL_PLATFORM = (1, 'GlobalPlatform command')

class CLAInterIndustryType(IntEnum):
    FIRST = (0, 'First Inter-industry Class Byte Coding')
    FURTHER = (1, 'Further Inter-industry Class Byte Coding')

class CLASecureTypeForFirstInterIndustry(IntEnum):
    NO_SECURE_MESSAGING = (0, 'No secure messaging')
    GLOBAL_PLATFORM = (1, 'Secure messaging - GlobalPlatform proprietary')
    ISO_IEC_7816_NO_CMAC = (2, 'Secure messaging - ISO/IEC 7816 standard, command header not processed (no C-MAC)')
    ISO_IEC_7816_CMAC = (3, 'Secure messaging - ISO/IEC 7816 standard, command header authenticated (C-MAC)')

class CLASecureTypeForFurtherInterIndustry(IntEnum):
    NO_SECURE_MESSAGING = (0, 'No secure messaging')
    ISO_IEC_7816_OR_GLOBAL_PLATFORM = (1, 'Secure messaging - ISO/IEC 7816 or GlobalPlatform proprietary')

class StatusCode(IntEnum):
    SW9000 = (36864, 'The command executed successfully.')
    SW6200 = (25088, 'Logical Channel already closed; No information given')
    SW6281 = (25217, 'Part of returned data may be corrupted')
    SW6282 = (25218, 'End of file, record or DO reached before reading Ne bytes, or unsuccessful search.')
    SW6283 = (25219, 'Card Life Cycle State is CARD_LOCKED; Selected file deactivated')
    SW6284 = (25220, 'File or data control information not formatted according to 7.4')
    SW6285 = (25221, 'Selected file or DO in termination state')
    SW6286 = (25222, 'No input data available from a sensor on the card')
    SW6287 = (25223, 'At least one of the referenced records is not processed for some reason, e.g. record deactivated, security status not satisfied or conditions of use not satisfied')
    SW6300 = (25344, 'No information given')
    SW6310 = (25360, 'More data available')
    SW6340 = (25408, 'Unsuccessful comparison')
    SW6381 = (25473, 'File or DO filled up by the last write')
    SW6400 = (25600, 'No specific diagnosis; No information given')
    SW6401 = (25601, 'Immediate response required by the card')
    SW6402 = (25602, "to '80' Triggering by the card (see 12.6.2)")
    SW6481 = (25729, 'Logical channel shared access denied')
    SW6482 = (25730, 'Logical channel opening denied')
    SW6500 = (25856, 'No information given')
    SW6581 = (25985, 'Memory failure')
    SW6600 = (26112, 'No information given, any other value is RFU')
    SW6700 = (26368, 'Wrong length in Lc; No information given')
    SW6701 = (26369, 'Command APDU format not compliant with this standard (see 5.1)')
    SW6702 = (26370, 'The value of Lc is not the one expected.')
    SW6800 = (26624, 'No information given')
    SW6881 = (26753, 'Logical channel not supported')
    SW6882 = (26754, 'Secure messaging not supported')
    SW6883 = (26755, 'Last command of the chain expected')
    SW6884 = (26756, 'Command chaining not supported')
    SW6900 = (26880, 'No information given')
    SW6981 = (27009, 'Command incompatible with file structure')
    SW6982 = (27010, 'Security status not satisfied; Invalid key check value')
    SW6983 = (27011, 'Authentication method blocked')
    SW6984 = (27012, 'Reference data not usable')
    SW6985 = (27013, 'Conditions of use not satisfied')
    SW6986 = (27014, 'Command not allowed (curEF not set)')
    SW6987 = (27015, 'Expected secure messaging DOs missing')
    SW6988 = (27016, 'Incorrect secure messaging DOs')
    SW6A00 = (27136, 'No information given')
    SW6A80 = (27264, 'Incorrect parameters in the command data field; Incorrect parameters in data field; Wrong data')
    SW6A81 = (27265, 'Function not supported e.g. card Life Cycle State is CARD_LOCKED')
    SW6A82 = (27266, 'File or application not found')
    SW6A83 = (27267, 'Record not found')
    SW6A84 = (27268, 'Not enough memory space in the file')
    SW6A85 = (27269, 'Nc inconsistent with tlv structure')
    SW6A86 = (27270, 'Incorrect parameters P1-P2')
    SW6A87 = (27271, 'Nc inconsistent with parameters P1-P2')
    SW6A88 = (27272, 'Referenced data, reference data or DO not found (exact meaning depending on the command)')
    SW6A89 = (27273, 'File already exists')
    SW6A8A = (27274, 'DF name already exists; Unsupported SCP')
    SW6A8B = (27275, 'Invalid signature')
    SW6A8C = (27276, 'Decrypt failed')
    SW6A8F = (27279, 'Invalid length; Unrecognized data')
    SW6A8E = (27278, 'Uninitialized')
    SW6A90 = (27280, 'Internal CMD error; Update failed; Proceed failed')
    SW6D00 = (27904, 'Invalid instruction')
    SW6E00 = (28160, 'Invalid class')
    SW9484 = (38020, "Algorithm not supported (DEPRECATED: Use '6A80' instead.)")
    SW9485 = (38021, "Invalid key check value (DEPRECATED: Use '6982' instead.)")

    @staticmethod
    def __get_missing_value__(value: int):
        sw1 = (value & 65280) >> 8
        sw2 = value & 255
        if sw1 == 97:
            return Int(value, doc='Normal processing. SW2 encodes the number of data bytes still available (see text below)')
        if sw1 == 98:
            if sw2 >= 2 and sw2 <= 128:
                return Int(value, doc="'6202' to '6280' Triggering by the card (see 12.6.2)")
            return Int(value, doc='Warning. State of non-volatile memory is unchanged (further qualification in SW2, see Table 7)')
        if sw1 == 99:
            if sw2 >= 192 and sw2 <= 207:
                return Int(value, doc="Warning. 0x63CX means counter from 0 to 15 encoded by 'X' (exact meaning depends on the command)")
            return Int(value, doc='Warning. State of non-volatile memory may have changed (further qualification in SW2, see Table 7)')
        if sw1 == 100:
            return Int(value, doc='Execution error. State of non-volatile memory is unchanged (further qualification in SW2, see Table 7)')
        if sw1 == 101:
            return Int(value, doc='Execution error. State of non-volatile memory may have changed (further qualification in SW2, see Table 7)')
        if sw1 == 102:
            return Int(value, doc='Execution error. Security-related issues (further qualification in SW2 is RFU)')
        if sw1 == 103:
            return Int(value, doc='Checking error.  Wrong length (further qualification in SW2, see Table 7)')
        if sw1 == 104:
            return Int(value, doc='Checking error. Functions in CLA not supported (further qualification in SW2, see Table 7)')
        if sw1 == 105:
            return Int(value, doc='Checking error. Command not allowed (further qualification in SW2, see Table 7)')
        if sw1 == 106:
            return Int(value, doc='Checking error. Wrong parameters P1-P2 (further qualification in SW2, see Table 7)')
        if sw1 == 107:
            return Int(value, doc='Checking error. Wrong parameters P1-P2')
        if sw1 == 108:
            return Int(value, doc='Checking error. Wrong Le field; SW2 encodes the exact number of available data bytes (see text below)')
        if sw1 == 109:
            return Int(value, doc='Checking error. Instruction code not supported or invalid')
        if sw1 == 110:
            return Int(value, doc='Checking error. Class not supported')
        if sw1 == 111:
            return Int(value, doc='Checking error. No precise diagnosis')
        return Int(value, doc='RFU')

class SecurityLevel(IntFlag):
    NO_SECURE = (0, 'NO SECURE')
    C_MAC = (1, 'C-MAC')
    C_DECRYPTION = (2, 'C-DECRYPTION')
    R_MAC = (16, 'R-MAC')

class SessionContext:
    security_level: SecurityLevel = SecurityLevel.NO_SECURE
    c_mac_size: int = 8
    r_mac_size: int = 8
    last_ins: Instruction = None

    def __init__(self, Gp_KEY_ENC='404142434445464748494A4B4C4D4E4F', Gp_KEY_MAC='404142434445464748494A4B4C4D4E4F', Gp_KEY_DEK='404142434445464748494A4B4C4D4E4F', Gp_SECURED_LEVEL='00', Gp_KEY_Version='00'):
        self.goodix_Initdata = ''
        self.Gp_KEY_ENC = Gp_KEY_ENC
        self.Gp_KEY_MAC = Gp_KEY_MAC
        self.Gp_KEY_DEK = Gp_KEY_DEK
        self.Gp_KEY_Version = Gp_KEY_Version
        self.goodix_ENC_SessionKey = ''
        self.goodix_MAC_SessionKey = ''
        self.goodix_DEK_SessionKey = ''
        self.goodix_RMAC_SessionKey = ''
        self.goodix_PerMac = ''
        self.goodix_PerRMac = ''
        self.Goodix_ScpFlag = ''
        self.Gp_SECURED_LEVEL = Gp_SECURED_LEVEL
        self.EncCounter = ''
        self.KeyType = ''

class APDUSerializationContext(SerializationContext):
    session: SessionContext

    def __init__(self, bytes_size: int=None, array_size: int=None, tlv_value: tlv.TLV=None, session: SessionContext=None) -> None:
        super().__init__(bytes_size, array_size, tlv_value)
        self.session = session

class __PacketFactory:
    __packet_factory: Dict[Instruction, Type[Object]]

    def __init__(self) -> None:
        self.__packet_factory = {}

    def get_cls(self, ins: Instruction) -> Type[Object]:
        cls: Type[Object] = self.__packet_factory.get(ins, None)
        return cls

    def register(self, ins: Instruction):

        def inner(cls):
            self.__packet_factory[ins] = cls
            self.__packet_factory[ins.value] = cls
            return cls
        return inner
RequestPacketFactory = __PacketFactory()
ResponsePacketFactory = __PacketFactory()

class PrivilegesByte1Coding(IntEnum):
    SECURITY_DOMAIN = (128, 'Security Domain')
    DAP_VERIFICATION = (192, 'DAP Verification')
    DELEGATED_MANAGEMENT = (160, 'Delegated Management')
    CARD_LOCK = (16, 'Card Lock')
    CARD_TERMINATE = (8, 'Card Terminate')
    CARD_RESET = (4, 'Card Reset')
    CVM_MANAGEMENT = (2, 'CVM Management')
    MANDATED_DAP_VERIFICATION = (193, 'Mandated DAP Verification')

class PrivilegesByte1(Object):
    security_domain: int = Property('Security Domain', int, flags=128, doc='Security Domain. Privilege Number=0')
    dap_verification: int = Property('DAP Verification', int, flags=192, mask=193, doc='DAP Verification. Privilege Number=1')
    delegated_management: int = Property('Delegated Management', int, flags=160, doc='Delegated Management. Privilege Number=2')
    card_lock: int = Property('Card Lock', int, flags=16, doc='Card Lock. Privilege Number=3')
    card_terminate: int = Property('Card Terminate', int, flags=8, doc='Card Terminate. Privilege Number=4')
    card_reset: int = Property('Card Reset', int, flags=4, doc='Card Reset. Privilege Number=5')
    cvm_management: int = Property('CVM Management', int, flags=2, doc='CVM Management. Privilege Number=6')
    mandated_dap_verification: int = Property('Mandated DAP Verification', int, flags=193, doc='Mandated DAP Verification. Privilege Number=7')

    @property
    def has_security_domain(self):
        return self.security_domain == 128

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.security_domain, stream, ctx, peek=True)
        self.deserialize_property(cls.dap_verification, stream, ctx, peek=True)
        self.deserialize_property(cls.delegated_management, stream, ctx, peek=True)
        self.deserialize_property(cls.card_lock, stream, ctx, peek=True)
        self.deserialize_property(cls.card_terminate, stream, ctx, peek=True)
        self.deserialize_property(cls.card_reset, stream, ctx, peek=True)
        self.deserialize_property(cls.cvm_management, stream, ctx, peek=True)
        self.deserialize_property(cls.mandated_dap_verification, stream, ctx)

class PrivilegesByte2(IntFlag):
    TRUSTED_PATH = (128, 'Trusted Path')
    AUTHORIZED_MANAGEMENT = (64, 'Authorized Management')
    TOKEN_MANAGEMENT = (32, 'Token Management')
    GLOBAL_DELETE = (16, 'Global Delete')
    GLOBAL_LOCK = (8, 'Global Lock')
    GLOBAL_REGISTRY = (4, 'Global Registry')
    FINAL_APPLICATION = (2, 'Final Application')
    GLOBAL_SERVICE = (1, 'Global Service')

class PrivilegesByte3(IntFlag):
    RECEIPT_GENERATION = (128, 'Receipt Generation')
    CIPHERED_LOAD_FILE_DATA_BLOCK = (64, 'Ciphered Load File Data Block')
    CONTACTLESS_ACTIVATION = (32, 'Contactless Activation')
    CONTACTLESS_SELF_ACTIVATION = (16, 'Contactless Self-Activation')

class KeyUsageQualifier1(IntFlag):
    VERIFICATION_DST_CCT_CAT_AND_ENCIPHERMENT_CT = (128, 'Verification (DST, CCT, CAT), Encipherment (CT)')
    COMPUTATION_DST_CCT_CAT_DECIPHERMENT_CT = (64, 'Computation (DST, CCT, CAT), Decipherment (CT)')
    SECURE_MESSAGING_IN_RESPONSE_DATA_FIELDS_CT_CCT = (32, 'Secure messaging in response data fields (CT, CCT)')
    SECURE_MESSAGING_IN_COMMAND_DATA_FIELDS_CT_CCT = (16, 'Secure messaging in command data fields (CT, CCT)')
    CONFIDENTIALITY_CT = (8, 'Confidentiality (CT)')
    CRYPTOGRAPHIC_CHECKSUM_CCT = (4, 'Cryptographic Checksum (CCT)')
    DIGITAL_SIGNATURE_DST = (2, 'Digital Signature (DST)')
    CRYPTOGRAPHIC_AUTHORIZATION_CAT = (1, 'Cryptographic Authorization (CAT)')

class KeyUsageQualifier2(IntFlag):
    VERIFICATION_DST_CCT_CAT_AND_ENCIPHERMENT_CT = (32768, 'Verification (DST, CCT, CAT), Encipherment (CT)')
    COMPUTATION_DST_CCT_CAT_DECIPHERMENT_CT = (16384, 'Computation (DST, CCT, CAT), Decipherment (CT)')
    SECURE_MESSAGING_IN_RESPONSE_DATA_FIELDS_CT_CCT = (8192, 'Secure messaging in response data fields (CT, CCT)')
    SECURE_MESSAGING_IN_COMMAND_DATA_FIELDS_CT_CCT = (4096, 'Secure messaging in command data fields (CT, CCT)')
    CONFIDENTIALITY_CT = (2048, 'Confidentiality (CT)')
    CRYPTOGRAPHIC_CHECKSUM_CCT = (1024, 'Cryptographic Checksum (CCT)')
    DIGITAL_SIGNATURE_DST = (512, 'Digital Signature (DST)')
    CRYPTOGRAPHIC_AUTHORIZATION_CAT = (256, 'Cryptographic Authorization (CAT)')
    KEY_AGREEMENT_KAT = (128, 'Key Agreement (KAT)')

class KeyAccess(IntEnum):
    SECURITY_DOMAIN_AND_APPLICATION = (0, 'The key may be used by the Security Domain and any associated Application')
    SECURITY_DOMAIN = (1, 'The key may be used by the Security Domain')
    APPLICATION = (2, 'The key may be used by the Security Domain')

class Privileges(Object):
    byte1: PrivilegesByte1 = Property(name='Privileges(Byte 1)', cls=PrivilegesByte1, length=1)
    byte2: PrivilegesByte2 = Property(name='Privileges(Byte 2)', cls=PrivilegesByte2, length=1)
    byte3: PrivilegesByte3 = Property(name='Privileges(Byte 3)', cls=PrivilegesByte3, length=1)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.byte1, stream, ctx)
        if ctx.bytes_size > 1:
            self.deserialize_property(cls.byte2, stream, ctx)
        if ctx.bytes_size > 2:
            self.deserialize_property(cls.byte3, stream, ctx)

class CommandChainType(IntEnum):
    LAST_COMMAND_CHAIN = (0, 'The command is the last or only command of a chain')
    NOT_LAST_COMMAND_CHAIN = (1, 'The command is not the last command of a chain')

class ClassByteCoding(Object):
    value: int = 0
    spec: CLASpecType = Property(name='Specification', cls=CLASpecType, lsb=7, msb=7)
    interindustry: CLAInterIndustryType = Property(cls=CLAInterIndustryType, name='Interindustry', lsb=6, msb=6)
    chain_type: CommandChainType = Property(cls=CommandChainType, name='Command Chain', lsb=4, msb=4)
    secure_type_for_first_interindustry: CLASecureTypeForFirstInterIndustry = Property(cls=CLASecureTypeForFirstInterIndustry, name='Secure Type(Interindustry=0)', lsb=2, msb=3)
    secure_type_for_further_interindustry: CLASecureTypeForFurtherInterIndustry = Property(cls=CLASecureTypeForFurtherInterIndustry, name='Secure Type(Interindustry=1)', lsb=5, msb=5)
    logical_channel_number_for_first_interindustry: int = Property(cls=int, name='Logical Channel Number(Interindustry=0)', lsb=0, msb=1, doc='0: Basic Logical Channel\n1-3: Supplementary Logical Channel')
    logical_channel_number_further_interindustry: int = Property(cls=int, name='Logical Channel Number(Interindustry=1)', lsb=0, msb=3, doc='A class byte with bit b7 set to 1 indicates in bits b4 to b1 (values 0000 to 1111) receipt of the command on Supplementary Logical Channel 4 to 19')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = ClassByteCoding
        self.value = stream.peek_int(1)
        self.deserialize_property(cls.spec, stream, ctx, peek=True)
        self.deserialize_property(cls.interindustry, stream, ctx, peek=True)
        self.deserialize_property(cls.chain_type, stream, ctx, peek=True)
        if self.interindustry == CLAInterIndustryType.FIRST:
            self.deserialize_property(cls.secure_type_for_first_interindustry, stream, ctx, peek=True)
            self.deserialize_property(cls.logical_channel_number_for_first_interindustry, stream, ctx)
        elif self.interindustry == CLAInterIndustryType.FURTHER:
            self.deserialize_property(cls.secure_type_for_further_interindustry, stream, ctx, peek=True)
            self.deserialize_property(cls.logical_channel_number_further_interindustry, stream, ctx)
        return self

    @property
    def has_cmac(self):
        if self.secure_type_for_first_interindustry is not None:
            return self.secure_type_for_first_interindustry in (CLASecureTypeForFirstInterIndustry.GLOBAL_PLATFORM, CLASecureTypeForFirstInterIndustry.ISO_IEC_7816_CMAC)
        elif self.secure_type_for_further_interindustry is not None:
            return self.secure_type_for_further_interindustry == CLASecureTypeForFurtherInterIndustry.ISO_IEC_7816_OR_GLOBAL_PLATFORM
        else:
            return False

class APDUResponsePacket(Object):
    ins: Instruction = None
    data_field: bytes = Property('Data Field', bytes, display_name='Data', display_order=65533)
    r_mac: bytes = Property('R-MAC', bytes, display_order=65534)
    status: StatusCode = Property('Status', StatusCode, length=2, display_order=65535)

    def __init__(self) -> None:
        super().__init__()

    def deserialize(self, stream: BytesIO, ctx: SerializationContext):
        cls = APDUResponsePacket
        pos_begin = stream.tell()
        self._offset = pos_begin
        self._raw = stream.read()
        self._length = len(self._raw)
        stream.seek(-2, SEEK_END)
        self.deserialize_property(cls.status, stream, ctx, peek=True)
        stream.truncate(stream.tell())
        data_len = stream.tell() - pos_begin
        if data_len > 0:
            ctx1 = ctx.clone(bytes_size=data_len)
            stream.seek(pos_begin, SEEK_SET)
            self._deserialize(stream, ctx1)
            self.deserialize_property(cls.r_mac, stream, ctx1)
            if not self.r_mac:
                self.r_mac = None

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data_field, stream, ctx)

    @classmethod
    def from_stream(cls, stream: Union[bytes, bytearray, BytesIO], session: SessionContext=None) -> 'APDUResponsePacket':
        stream = BytesIO.create(stream)
        ins = session.last_ins if session else None
        cls = ResponsePacketFactory.get_cls(ins) or cls
        pkt = cls()
        pkt.ins = ins
        pkt.deserialize(stream, APDUSerializationContext(session=session))
        return pkt

class APDURequestPacket(Object):
    cla: ClassByteCoding = Property(name='CLA', cls=ClassByteCoding)
    ins: Instruction = Property(name='INS', cls=Instruction)
    p1: int = Property(name='P1', cls=int)
    p2: int = Property(name='P2', cls=int)
    lc: int = Property(name='Lc', cls=APDULc)
    data: bytes = Property(name='Data Field', cls=bytes, display_name='Data')
    c_mac: bytes = Property(name='C-MAC', cls=bytes, doc='C-MAC for SCP02 or SCP03, 8 or 16 bytes.', display_order=65534)
    le: int = Property(name='Le', cls=int, display_order=65535)

    def __init__(self) -> None:
        super().__init__()

    def deserialize(self, stream: BytesIO, ctx: SerializationContext=None):
        cls = self.__class__
        pos_begin = stream.tell()
        self.deserialize_property(cls.cla, stream, ctx)
        self.deserialize_property(cls.ins, stream, ctx)
        self._deserialize_p1p2(stream, ctx)
        self._deserialize_lc(stream, ctx)
        if self.lc:
            data_len = self.lc
            if self.cla.has_cmac:
                data_len -= ctx.session.c_mac_size
            if data_len < 0:
                raise Exception(f'Bad secure packet without C-MAC')
            if data_len > 0:
                self._deserialize(stream, ctx.clone(bytes_size=data_len))
            self.deserialize_property(cls.c_mac, stream, ctx.clone(bytes_size=ctx.session.c_mac_size))
            if not self.c_mac:
                self.c_mac = None
        self.deserialize_property(cls.le, stream, ctx)
        pos_end = stream.tell()
        stream.seek(pos_begin, SEEK_SET)
        self._offset = pos_begin
        self._length = pos_end - pos_begin
        self._raw = stream.read(self._length)
        return self

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize_lc(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.lc, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        if self.lc:
            self.deserialize_property(cls.data, stream, ctx)

    @classmethod
    def from_stream(cls, stream: Union[str, bytes, BytesIO], session: SessionContext) -> 'APDURequestPacket':
        stream = BytesIO.create(stream)
        ins = Instruction(stream.peek(2)[1])
        cls = RequestPacketFactory.get_cls(ins) or cls
        pkt = cls()
        pkt.deserialize(stream, APDUSerializationContext(session=session))
        return pkt

class PBF(IntEnum):
    LAST_COMMAND = (0, 'Last (or only) command')
    MORE_COMMANDS = (1, 'More commands')

class TLVObject(Object):
    tag: int = Property(name='Tag', cls=int)
    length: int = Property(name='Length', cls=int)
    value: Union[bytes, 'TLVObject', List['TLVObject']] = Property(name='Value')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        if isinstance(ctx.tlv_value, list) and len(ctx.tlv_value) > 1:
            raise Exception('解析的TLV对象应该是单个节点，不能是列表，列表对象应该在父节点处理了再解析')
        tlv_data = ctx.tlv_value[0] if isinstance(ctx.tlv_value, list) else ctx.tlv_value
        self.deserialize_tlv_node(cls.tag, tlv_data.tag)
        self.deserialize_tlv_node(cls.length, tlv_data.length)
        stream.seek(tlv_data.value.offset, SEEK_SET)
        if isinstance(tlv_data.value.value, bytes):
            self.deserialize_property(cls.value, stream, ctx.clone(tlv_value=tlv_data.value.value), cls=bytes)
        elif isinstance(tlv_data.value.value, list):
            self.deserialize_property(cls.value, stream, ctx.clone(tlv_value=tlv_data.value.value[0]), cls=TLVObject, is_list=len(tlv_data.value.value) > 1)
        stream.seek(tlv_data.value.offset + tlv_data.value.length, SEEK_SET)

    def deserialize_tlv_node(self, prop: Property, node: tlv.TLVNode):
        prop_info = prop.property_info(self)
        prop_info.offset = node.offset
        prop_info.size = node.length
        prop_info.value = node.value

class Confirmations(Object):
    receipt_length: int = Property(name='Length', cls=TLVLength, doc='Length of Receipt')
    receipt: bytes = Property(name='Receipt', cls=bytes)
    length_of_confirmation_counter: int = Property(name='Length of Confirmation Counter', cls=int, doc='Length of Confirmation Counter. Mandatory.')
    confirmation_counter: int = Property(name='Confirmation Counter', cls=int, length=2, byteorder=Byteorder.BIG, doc='Confirmation Counter. Mandatory.')
    length_of_card_unique_data: int = Property(name='Length of Card Unique Data', cls=int, doc='Length of Card Unique Data. Mandatory.')
    sd_unique_data: bytes = Property(name='SD Unique Data', cls=bytes)
    length_of_token_identifier: int = Property(name='Length of Token identifier', cls=bytes, doc='Length of Token identifier. Mandatory.')
    token_identifier: bytes = Property(name='Token identifier')
    length_of_token_data_digest: int = Property(name='Length of Token Data digest', cls=bytes, doc='Length of Token Data digest. Optional.')
    token_data_digest: bytes = Property(name='Token Data digest', cls=bytes, doc='Token Data digest. Optional.')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = Confirmations
        self.deserialize_property(cls.receipt_length, stream, ctx)
        if self.receipt_length:
            self.deserialize_property(cls.receipt, stream, ctx.clone(bytes_size=self.receipt_length))
        self.deserialize_property(cls.length_of_confirmation_counter, stream, ctx)
        if self.length_of_confirmation_counter:
            self.deserialize_property(cls.confirmation_counter, stream, ctx=APDUSerializationContext(self.length_of_confirmation_counter))
        self.deserialize_property(cls.length_of_card_unique_data, stream, ctx)
        if self.length_of_card_unique_data:
            self.deserialize_property(cls.sd_unique_data, stream, ctx=APDUSerializationContext(self.length_of_card_unique_data))
        self.deserialize_property(cls.length_of_token_identifier, stream, ctx)
        if self.length_of_token_identifier:
            self.deserialize_property(cls.token_identifier, stream, ctx=APDUSerializationContext(self.length_of_token_identifier))
        self.deserialize_property(cls.length_of_token_data_digest, stream, ctx)
        if self.length_of_token_data_digest:
            self.deserialize_property(cls.token_data_digest, stream, ctx=APDUSerializationContext(self.length_of_token_data_digest))

class DeleteStrategy(IntEnum):
    DELETE_OBJECT = (0, 'Delete object')
    DELETE_ROOT_SECURITY_DOMAIN_AND_ALL_ASSOCIATED_APPLICATIONS = (1, 'Delete a root Security Domain and all associated Applications')
    DELETE_OBJECT_AND_RELATED_OBJECT = (2, 'Delete object and related object')
    DELETE_OBJECT_AND_RELATED_OBJECT__ROOT_SECURITY_DOMAIN_AND_ALL_ASSOCIATED_APPLICATIONS = (3, 'Delete object and related object; Delete a root Security Domain and all associated Applications')

class DeleteP1(Object):
    pbf: PBF = Property(name='PBF', cls=PBF, lsb=7, msb=7)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = DeleteP1
        self.deserialize_property(cls.pbf, stream=stream, ctx=ctx)

class DeleteP2(Object):
    delete_strategy: DeleteStrategy = Property(name='Delete Strategy', cls=DeleteStrategy, lsb=6, msb=7)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = DeleteP2
        self.deserialize_property(cls.delete_strategy, stream=stream, ctx=ctx)

class CRTForDigitalSignature(Object):
    identification_number: bytes = Property(66, cls=bytes, doc='Identification Number of the Security Domain with the Token Verification privilege. Optional.')
    image_number: bytes = Property(69, cls=bytes, doc='Image number of the Security Domain with the Token Verification privilege. Optional.')
    application_provider_identifier: bytes = Property(24352, cls=bytes, doc='Application Provider identifier. Optional.')
    token_id: bytes = Property(147, cls=bytes, doc='Token identifier/number (digital signature counter). Conditional.')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = CRTForDigitalSignature
        self.deserialize_property(cls.identification_number, stream, ctx, True)
        self.deserialize_property(cls.image_number, stream, ctx, True)
        self.deserialize_property(cls.application_provider_identifier, stream, ctx, True)
        self.deserialize_property(cls.token_id, stream, ctx, True)

class DeleteData(Object):
    exe_or_aid: bytes = Property(tlv_tag=79, cls=bytes, doc='Executable Load File or Application AID. Mandatory.')
    crt_for_digital_signature: CRTForDigitalSignature = Property(tlv_tag=182, cls=CRTForDigitalSignature, doc='Control Reference Template for Digital Signature. Conditional')
    delete_token: bytes = Property(tlv_tag=158, cls=bytes, doc='Executable Load File or Application AID. Mandatory.')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = DeleteData
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        pos_end = stream.tell()
        ctx = ctx.clone(tlv_value=tlv_data)
        self.deserialize_property(cls.exe_or_aid, stream, ctx, True)
        self.deserialize_property(cls.crt_for_digital_signature, stream, ctx, True)
        self.deserialize_property(cls.delete_token, stream, ctx, True)
        stream.seek(pos_end, SEEK_SET)

@RequestPacketFactory.register(Instruction.DELETE)
class DeletePacket(APDURequestPacket):
    p1: DeleteP1 = Property(name='P1', cls=DeleteP1, display_order=2)
    p2: DeleteP2 = Property(name='P2', cls=DeleteP2, display_order=3)
    data: DeleteData = Property(name='Data', cls=DeleteData)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = DeletePacket
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = DeletePacket
        self.deserialize_property(cls.data, stream, ctx)

@ResponsePacketFactory.register(Instruction.DELETE)
class DeleteResponsePacket(APDUResponsePacket):
    confirmations_length: int = Property(name='Length of confirmation', cls=int, doc='Length of delete confirmation')
    confirmations: Confirmations = Property(name='Delete Confirmation', cls=Confirmations)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = DeleteResponsePacket
        if ctx.bytes_size > 2:
            self.deserialize_property(cls.confirmations_length, stream, ctx)
            if self.confirmations_length:
                self.deserialize_property(cls.confirmations, stream, APDUSerializationContext(self.confirmations_length))

class GetDataTag(IntEnum):
    IDENTIFICATION_NUMBER = (66, 'Issuer Identification Number (or Security Domain Provider Identification Number)')
    IMAGE_NUMBER = (69, 'Card Image Number (or Security Domain Image Number)')
    CARD_DATA_OR_MANAGEMENT_DATA = (102, 'Card Data (or Security Domain Management Data)')
    KEY_INFORMATION_TEMPLATE = (224, 'Key Information Template')
    CARD_CAPABILITY_INFORMATION = (103, 'Card Capability Information')
    CURRENT_SECURITY_LEVEL = (211, 'Current Security Level')
    LIST_OF_APPLICATIONS = (12032, 'List of Applications associated with the Security Domain, or every application on the card if the Security Domain has Global Registry Privilege')
    EXTENDED_CARD_RESOURCES_INFORMATION = (65313, 'Extended Card Resources Information available for Card Content Management, as defined in [TS 102 226]')
    SECURITY_DOMAIN_MANAGER_URL = (24400, 'Security Domain Manager URL')
    CONFIRMATION_COUNTER = (194, 'Confirmation Counter')
    SEQUENCE_COUNTER_OF_THE_DEFAULT_KEY_VERSION_NUMBER = (193, 'Sequence Counter of the default Key Version Number')
    CERTIFICATE = (32545, 'Certificate')
    DATA_OBJECT_IDENTIFIER_OF_EF_OD = (20529, 'Data object identifier of EF.OD')
    CARD_PRODUCTION_LIFE_CYCLE = (40831, 'Card Production Life Cycle')
    GOODIX_GET_VERSION = (65408, 'Get Version')

@RequestPacketFactory.register(Instruction.GET_DATA_CA)
@RequestPacketFactory.register(Instruction.GET_DATA_CB)
class GetDataPacket(APDURequestPacket):
    p1p2: GetDataTag = Property(name='P1P2', cls=GetDataTag, length=2, display_order=2)
    data: bytes = Property(name='Data', cls=bytes, doc='Tag list(5C00 for 2F00) and/or C-MAC if present.')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = GetDataPacket
        self.deserialize_property(cls.p1p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = GetDataPacket
        if self.lc:
            self.deserialize_property(cls.data, stream, ctx)

class KeyTypeAndLength(Object):
    key_type: KeyType = Property('Key Type', KeyType)
    key_length: int = Property('Key Length', int)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = KeyTypeAndLength
        self.deserialize_property(cls.key_type, stream, ctx)
        self.deserialize_property(cls.key_length, stream, ctx)

class KeyInformation(Object):
    key_identifier: int = Property('Key Identifier', int, doc='Key Identifier value')
    key_version_number: int = Property('Key Version Number', int, doc='Key Version Number value')
    keys: List[KeyTypeAndLength] = Property('Key Type and Key Length', KeyTypeAndLength, is_list=True, doc='Key Type and Key Length Pairs')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = KeyInformation
        self.deserialize_property(cls.key_identifier, stream, ctx)
        self.deserialize_property(cls.key_version_number, stream, ctx)
        self.deserialize_property(cls.keys, stream, ctx.clone(array_size=ctx.bytes_size - 2 >> 1))

class KeyInformationTemplate(Object):
    key_information: List[KeyInformation] = Property(192, KeyInformation, is_list=True, name='Key Information')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = KeyInformationTemplate
        self.deserialize_property(cls.key_information, stream, ctx=ctx)
        if not self.key_information:
            raise Exception('Bad KeyInformation')

class ApplicationTemplate(Object):
    application_aid: List[bytes] = Property(79, bytes, is_list=True, name='Application AID')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = ApplicationTemplate
        self.deserialize_property(cls.application_aid, stream, ctx=ctx)

class ExtendedCardResourcesInformation(Object):
    number_of_installed_application: int = Property(129, int, doc='Number of installed application', byteorder='big')
    free_non_volatile_memory: int = Property(130, int, doc='Free non volatile memory', byteorder='big')
    free_volatile_memory: int = Property(131, int, doc='Free volatile memory', byteorder='big')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = ExtendedCardResourcesInformation
        self.deserialize_property(cls.number_of_installed_application, stream, ctx=ctx)
        self.deserialize_property(cls.free_non_volatile_memory, stream, ctx=ctx)
        self.deserialize_property(cls.free_volatile_memory, stream, ctx=ctx)

class CipherSuitesForSignaturesByte1(IntFlag):
    RSA1024_RSASSAPKCSV15_SHA1 = (1, 'RSA-1024 / RSASSA-PKCS-v1_5 / SHA-1 (see section B.3.1.1)')
    RSA_1024_RSASSAPSS_SHA256 = (2, 'RSA >1024 / RSASSA-PSS / SHA-256 (see section B.3.2.1)')
    SINGLE_DES_PLUS_FINAL_TRIPLE_DES_MAC = (4, '16 byte key / Single DES plus Final Triple DES MAC (see section B.1.2.2)')
    CMAC_USING_AES128 = (8, 'CMAC using AES-128 (see section B.2.2)')
    CMAC_USING_AES192 = (16, 'CMAC using AES-192 (see section B.2.2)')
    CMAC_USING_AES256 = (32, 'CMAC using AES-256 (see section B.2.2)')
    ECDSA_USING_ECC256_AND_SHA256 = (64, 'ECDSA using ECC-256 and SHA-256 (see section B.4.3)')
    ECDSA_USING_ECC384_AND_SHA384 = (128, 'ECDSA using ECC-384 and SHA-384 (see section B.4.3)')

class CipherSuitesForSignaturesByte2(IntFlag):
    ECDSA_USING_ECC512_AND_SHA512 = (1, 'ECDSA using ECC-512 and SHA-512 (see section B.4.3)')
    ECDSA_USING_ECC521_AND_SHA512 = (2, 'ECDSA using ECC-521 and SHA-512 (see section B.4.3)')

class CipherSuitesForSignatures(IntFlag):
    RSA1024_RSASSAPKCSV15_SHA1 = (1, 'RSA-1024 / RSASSA-PKCS-v1_5 / SHA-1 (see section B.3.1.1)')
    RSA_1024_RSASSAPSS_SHA256 = (2, 'RSA >1024 / RSASSA-PSS / SHA-256 (see section B.3.2.1)')
    SINGLE_DES_PLUS_FINAL_TRIPLE_DES_MAC = (4, '16 byte key / Single DES plus Final Triple DES MAC (see section B.1.2.2)')
    CMAC_USING_AES128 = (8, 'CMAC using AES-128 (see section B.2.2)')
    CMAC_USING_AES192 = (16, 'CMAC using AES-192 (see section B.2.2)')
    CMAC_USING_AES256 = (32, 'CMAC using AES-256 (see section B.2.2)')
    ECDSA_USING_ECC256_AND_SHA256 = (64, 'ECDSA using ECC-256 and SHA-256 (see section B.4.3)')
    ECDSA_USING_ECC384_AND_SHA384 = (128, 'ECDSA using ECC-384 and SHA-384 (see section B.4.3)')
    ECDSA_USING_ECC512_AND_SHA512 = (256, 'ECDSA using ECC-512 and SHA-512 (see section B.4.3)')
    ECDSA_USING_ECC521_AND_SHA512 = (512, 'ECDSA using ECC-521 and SHA-512 (see section B.4.3)')

class CipherSuitesForLFDBEncryption(IntFlag):
    TRIPLE_DES_WITH_16_BYTE_KEY = (1, 'Triple DES with 16 byte key length')
    AES128 = (2, 'AES-128')
    AES192 = (4, 'AES-192')
    AES256 = (8, 'AES-256')
    ICV_SUPPORTED_FOR_LFDB_ENCRYPTION = (128, 'ICV supported for LFDB encryption')

class LFDBHAlgorithms(IntEnum):
    SHA1 = (1, 'SHA-1')
    SHA256 = (2, 'SHA-256')
    SHA384 = (3, 'SHA-384')
    SHA512 = (4, 'SHA-512')

class SupportedKeysForSCP03(IntFlag):
    AES128 = (1, 'AES-128')
    AES192 = (2, 'AES-192')
    AES256 = (4, 'AES-256')

class SCPType(IntEnum):
    SCP02 = (2, 'SCP 02')
    SCP03 = (3, 'SCP 03')
    SCP80 = (128, 'SCP 80')
    SCP81 = (129, 'SCP 81')

class SCPInformation(Object):
    scp_type: SCPType = Property(128, SCPType, doc="SCP type ('02', '03', '80', '81') Mandatory")
    supported_options: bytes = Property(129, bytes, doc="List of supported options for that protocol (e.g. '15 55' for SCP02) Mandatory")
    supported_keys_for_scp03: bytes = Property(130, bytes, doc='Supported keys for SCP03 Conditional')
    supported_tls_cipher_suites_for_scp81: bytes = Property(131, bytes, doc='Supported TLS cipher suites for SCP81 Conditional')
    maximum_length_of_pre_shared_key_in_bytes: int = Property(132, int, doc='Maximum length of Pre Shared Key in bytes (unsigned integer) (for SCP81 only) Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.scp_type, stream, ctx)
        self.deserialize_property(cls.supported_options, stream, ctx)
        self.deserialize_property(cls.supported_keys_for_scp03, stream, ctx)
        self.deserialize_property(cls.supported_tls_cipher_suites_for_scp81, stream, ctx)
        self.deserialize_property(cls.maximum_length_of_pre_shared_key_in_bytes, stream, ctx)

class ECCCurveType(IntEnum):
    P256 = (0, 'as specified in [FIPS 186-4]')
    P384 = (1, 'as specified in [FIPS 186-4]')
    P521 = (2, 'as specified in [FIPS 186-4]')
    brainpool_P256_r1 = (3, 'as specified in [RFC 5639]')
    brainpool_P256_t1 = (4, 'as specified in [RFC 5639]')
    brainpool_P384_r1 = (5, 'as specified in [RFC 5639]')
    brainpool_P384_t1 = (6, 'as specified in [RFC 5639]')
    brainpool_P512_r1 = (7, 'as specified in [RFC 5639]')
    brainpool_P512_t1 = (8, 'as specified in [RFC 5639]')

class CardCapabilityInformation(Object):
    scp: List[SCPInformation] = Property(160, SCPInformation, is_list=True, doc='SCP information for SCP(s)')
    privileges_to_ssd: bytes = Property(129, bytes, doc='Privileges that can be assigned to an SSD Conditional')
    privileges_to_app: bytes = Property(130, bytes, doc='Privileges that can be assigned any application Mandatory')
    supported_lfdbh_algorithms: LFDBHAlgorithms = Property(131, LFDBHAlgorithms, doc='Supported LFDBH algorithms Mandatory')
    cipher_suites_for_lfdb_encryption: CipherSuitesForLFDBEncryption = Property(132, CipherSuitesForLFDBEncryption, doc='Cipher suites for LFDB encryption Conditional')
    cipher_suites_supported_for_tokens: CipherSuitesForSignatures = Property(133, CipherSuitesForSignatures, doc='Cipher suites supported for tokens Conditional')
    cipher_suites_supported_for_receipts: CipherSuitesForSignatures = Property(134, CipherSuitesForSignatures, doc='Cipher suites supported for receipts Conditional')
    cipher_suites_supported_for_dap: CipherSuitesForSignatures = Property(135, CipherSuitesForSignatures, doc='Cipher suites supported for DAPs Conditional')
    key_parameter_reference_list: ECCCurveType = Property(135, ECCCurveType, doc='Cipher suites supported for DAPs Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.scp, stream, ctx)
        self.deserialize_property(cls.privileges_to_ssd, stream, ctx)
        self.deserialize_property(cls.privileges_to_app, stream, ctx)
        self.deserialize_property(cls.supported_lfdbh_algorithms, stream, ctx)
        self.deserialize_property(cls.cipher_suites_for_lfdb_encryption, stream, ctx)
        self.deserialize_property(cls.cipher_suites_supported_for_tokens, stream, ctx)
        self.deserialize_property(cls.cipher_suites_supported_for_receipts, stream, ctx)
        self.deserialize_property(cls.cipher_suites_supported_for_dap, stream, ctx)
        self.deserialize_property(cls.key_parameter_reference_list, stream, ctx)

class GoodixAppVersion(Object):
    app_type: bytes = Property('APP Type', bytes, length=2)
    app_version: bytes = Property('APP Version', bytes, length=2)
    release_count: bytes = Property('Release Count', bytes, length=2)
    commit_date: bytes = Property('Commit Date', bytes, length=4)

    def _deserialize(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.app_type, stream, ctx)
        self.deserialize_property(cls.app_version, stream, ctx)
        self.deserialize_property(cls.release_count, stream, ctx)
        self.deserialize_property(cls.commit_date, stream, ctx)

class CardProductionLifeCycle(Object):
    ic_fabricator = Property('IC fabricator¹', int, length=2)
    ic_type = Property('IC type¹', int, length=2)
    operating_system_identifier = Property('Operating system identifier¹', int, length=2)
    operating_system_release_date = Property('Operating system release date²', int, length=2)
    operating_system_release_level = Property('Operating system release level', int, length=2)
    ic_fabrication_date = Property('IC fabrication date²', int, length=2)
    ic_serial_number = Property('IC serial number', int, length=4)
    ic_batch_identifier = Property('IC batch identifier', int, length=2)
    ic_module_fabricator = Property('IC module fabricator¹', int, length=2)
    ic_module_packaging_date = Property('IC module packaging date²', int, length=2)
    icc_manufacturer = Property('ICC manufacturer¹', int, length=2)
    ic_embedding_date = Property('IC embedding date²', int, length=2)
    ic_pre_personalizer = Property('IC pre-personalizer¹', int, length=2)
    ic_pre_personalization_date = Property('IC pre-personalization date²', int, length=2)
    ic_pre_personalization_equipment_identifier = Property('IC pre-personalization equipment identifier', int, length=4)
    ic_personalizer = Property('IC personalizer¹', int, length=2)
    ic_personalization_date = Property('IC personalization date²', int, length=2)
    ic_personalization_equipment_identifier = Property('IC personalization equipment identifier', int, length=4)

    def _deserialize(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.ic_fabricator, stream, ctx)
        self.deserialize_property(cls.ic_type, stream, ctx)
        self.deserialize_property(cls.operating_system_identifier, stream, ctx)
        self.deserialize_property(cls.operating_system_release_date, stream, ctx)
        self.deserialize_property(cls.operating_system_release_level, stream, ctx)
        self.deserialize_property(cls.ic_fabrication_date, stream, ctx)
        self.deserialize_property(cls.ic_serial_number, stream, ctx)
        self.deserialize_property(cls.ic_batch_identifier, stream, ctx)
        self.deserialize_property(cls.ic_module_fabricator, stream, ctx)
        self.deserialize_property(cls.ic_module_packaging_date, stream, ctx)
        self.deserialize_property(cls.icc_manufacturer, stream, ctx)
        self.deserialize_property(cls.ic_embedding_date, stream, ctx)
        self.deserialize_property(cls.ic_pre_personalizer, stream, ctx)
        self.deserialize_property(cls.ic_pre_personalization_date, stream, ctx)
        self.deserialize_property(cls.ic_pre_personalization_equipment_identifier, stream, ctx)
        self.deserialize_property(cls.ic_personalizer, stream, ctx)
        self.deserialize_property(cls.ic_personalization_date, stream, ctx)
        self.deserialize_property(cls.ic_personalization_equipment_identifier, stream, ctx)

@ResponsePacketFactory.register(Instruction.GET_DATA_CA)
@ResponsePacketFactory.register(Instruction.GET_DATA_CB)
class GetDataResponsePacket(APDUResponsePacket):
    identification_number: bytes = Property(name='Identification Number', cls=bytes, tlv_tag=GetDataTag.IDENTIFICATION_NUMBER)
    image_number: bytes = Property(name='Image Number', cls=bytes, tlv_tag=GetDataTag.IMAGE_NUMBER)
    card_data_or_management_data: TLVObject = Property(name='Card Data or Management Data', cls=TLVObject, tlv_tag=GetDataTag.CARD_DATA_OR_MANAGEMENT_DATA)
    card_capability_information: CardCapabilityInformation = Property(name='Card Capability Information', cls=CardCapabilityInformation, tlv_tag=GetDataTag.CARD_CAPABILITY_INFORMATION)
    key_information_template: KeyInformationTemplate = Property(name='Key Information Template', cls=KeyInformationTemplate, tlv_tag=GetDataTag.KEY_INFORMATION_TEMPLATE)
    application_template: List[ApplicationTemplate] = Property(97, ApplicationTemplate, is_list=True, name='Application Template', doc='List of Applications')
    extended_card_resources_information: ExtendedCardResourcesInformation = Property(name='Extended Card Resources Information', cls=ExtendedCardResourcesInformation, tlv_tag=GetDataTag.EXTENDED_CARD_RESOURCES_INFORMATION)
    security_domain_manager_url: bytes = Property(name='Security Domain Manager URL', cls=bytes, tlv_tag=GetDataTag.SECURITY_DOMAIN_MANAGER_URL)
    confirmation_counter: int = Property(name='Confirmation Counter', cls=int, tlv_tag=GetDataTag.CONFIRMATION_COUNTER)
    sequence_counter: int = Property(name='Sequence Counter', cls=int, tlv_tag=GetDataTag.SEQUENCE_COUNTER_OF_THE_DEFAULT_KEY_VERSION_NUMBER)
    certificate: TLVObject = Property(name='Certificate', cls=TLVObject, tlv_tag=GetDataTag.CERTIFICATE)
    data_object_identifier_of_ef_od: bytes = Property(name='Data object identifier of EF.OD', cls=bytes, tlv_tag=GetDataTag.DATA_OBJECT_IDENTIFIER_OF_EF_OD)
    card_production_life_cycle: CardProductionLifeCycle = Property(name='Card Production Life Cycle', cls=CardProductionLifeCycle, tlv_tag=GetDataTag.CARD_PRODUCTION_LIFE_CYCLE)
    unknown_tlv: List[TLVObject] = Property('Unknown TLV', TLVObject, is_list=True)
    app_version: GoodixAppVersion = Property(name='APP Version Information', cls=GoodixAppVersion)
    data: bytes = Property(name='Data', cls=bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = GetDataResponsePacket
        if ctx.bytes_size > 0:
            pos_data = stream.tell()
            tlv_data = tlv.parse(stream, ctx.bytes_size)
            if tlv_data and GetDataTag.contains(tlv_data[0].tag.value):
                ctx1 = ctx.clone(tlv_value=tlv_data)
                self.deserialize_property(cls.identification_number, stream, ctx1)
                self.deserialize_property(cls.image_number, stream, ctx1)
                self.deserialize_property(cls.card_data_or_management_data, stream, ctx1)
                self.deserialize_property(cls.card_capability_information, stream, ctx1)
                self.deserialize_property(cls.key_information_template, stream, ctx1)
                self.deserialize_property(cls.application_template, stream, ctx1)
                self.deserialize_property(cls.extended_card_resources_information, stream, ctx1)
                self.deserialize_property(cls.security_domain_manager_url, stream, ctx1)
                self.deserialize_property(cls.confirmation_counter, stream, ctx1)
                self.deserialize_property(cls.sequence_counter, stream, ctx1)
                self.deserialize_property(cls.certificate, stream, ctx1)
                self.deserialize_property(cls.data_object_identifier_of_ef_od, stream, ctx1)
                self.deserialize_property(cls.card_production_life_cycle, stream, ctx1)
            elif tlv_data:
                self.deserialize_property(cls.unknown_tlv, stream, ctx.clone(tlv_value=tlv_data))
            else:
                stream.seek(pos_data, SEEK_SET)
                if ctx.bytes_size == 10:
                    self.deserialize_property(cls.app_version, stream, ctx)
                else:
                    self.deserialize_property(cls.data, stream, ctx)

class GetStatusP1(IntFlag):
    ISSUER_SECURITY_DOMAIN = (128, 'Issuer Security Domain')
    APPLICATIONS_WITH_SECURITY_DOMAINS = (64, 'Applications, including Security Domains')
    EXECUTABLE_LOAD_FILES = (32, 'Executable Load Files')
    EXECUTABLE_LOAD_FILES_AND_EXECUTABLE_MODULES = (16, 'Executable Load Files and Executable Modules')

class GetStatusP2GetType(IntEnum):
    GET_FIRST_OR_ALL_OCCURRENCE = (0, 'Get first or all occurrence(s)')
    GET_NEXT_OCCURRENCE = (1, 'Get next occurrence(s)')

class GetStatusP2ResponseDataType(IntEnum):
    DEPRECATED = (0, 'Deprecated')
    RESPONSE_DATA_STRUCTURE_E3 = (1, 'Response data structure according to Table 11-36 and Table 11-37')

class GetStatusP2(Object):
    get_type: GetStatusP2GetType = Property(name='Get Type', cls=GetStatusP2GetType, lsb=0, msb=0)
    response_type: GetStatusP2ResponseDataType = Property(name='Response Type', cls=GetStatusP2ResponseDataType, lsb=1, msb=1)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = GetStatusP2
        self.deserialize_property(cls.get_type, stream, ctx, True)
        self.deserialize_property(cls.response_type, stream, ctx)

class FilterCriteria(Object):
    tag_4f: bytes = Property(79, bytes, doc='AID')
    tag_9f70: bytes = Property(40816, bytes, doc='Application Life Cycle State on the first byte as defined in section 11.1. The Contactless Activation State is encoded on the second byte as defined in Table 8-1.')
    tag_c5: bytes = Property(197, bytes, doc='Privileges (byte 1 – byte 2 – byte 3) (see [GPCS] section 11.1.2)')
    tag_cf: bytes = Property(207, bytes, doc='Implicit Selection Parameters (see [GPCS] section 11.1.7)')
    tag_c4: bytes = Property(196, bytes, doc='Application’s Executable Load File AID')
    tag_ce: bytes = Property(206, bytes, doc='Executable Load File Version Number')
    tag_84: bytes = Property(132, bytes, doc='List of Executable Module AID')
    tag_cc: bytes = Property(204, bytes, doc='Associated Security Domain’s AID')
    tag_7f20: bytes = Property(32544, bytes, doc='Display Control Template (see section 3.2)')
    tag_5f50: bytes = Property(24400, bytes, doc='Uniform Resource Locator (see section 3.2)')
    tag_6d: bytes = Property(109, bytes, doc='Application Image Template (see section 3.2)')
    tag_5f45: bytes = Property(24389, bytes, doc='Display Message (see section 3.2)')
    tag_a0: bytes = Property(160, bytes, doc='Application Group Head Application (coded as in Table 3-4)')
    tag_a1: bytes = Property(161, bytes, doc='Application Group Authorization List (coded as in Table 3-5)')
    tag_a2: bytes = Property(162, bytes, doc='CREL Application AID List (coded as in Table 3-7)')
    tag_a3: bytes = Property(163, bytes, doc='Policy Restricted Applications (see section 3.3)')
    tag_a4: bytes = Property(164, bytes, doc='Application Group Members (coded as in Table 3-5) (excluding the Head Application)')
    tag_a5: bytes = Property(165, bytes, doc='Application discretionary data (see section 3.4)')
    tag_86: bytes = Property(134, bytes, doc='Application Family (see section 3.5)')
    tag_87: bytes = Property(135, bytes, doc='Assigned Protocols for implicit selection (see section 6.6)')
    tag_88: bytes = Property(136, bytes, doc='Initial Contactless Activation State (see section 8.3)')
    tag_89: bytes = Property(137, bytes, doc='Contactless Protocol Type State (see section 11.2.4)')
    tag_a9: bytes = Property(169, bytes, doc='Contactless Protocol Parameters Profile (see section 11.2.2)')
    tag_8a: bytes = Property(138, bytes, doc='Recognition Algorithm (see section 6.5)')
    tag_8b: bytes = Property(139, bytes, doc='Continuous Processing (see section 6.4)')
    tag_ac: bytes = Property(172, bytes, doc='Communication Interface Access Parameters (see section 5.2)')
    tag_8d: bytes = Property(141, bytes, doc='Protocol Data Type A (Card Emulation Mode) (see section 4.6)')
    tag_8e: bytes = Property(142, bytes, doc='Protocol Data Type B (Card Emulation Mode) (see section 4.7)')
    tag_8f: bytes = Property(143, bytes, doc='Cumulative Granted Non-Volatile Memory (see Chapter 9)')
    tag_90: bytes = Property(144, bytes, doc='Cumulative Granted Volatile Memory (see Chapter 9)')
    tag_91: bytes = Property(145, bytes, doc='Cumulative Remaining Non-Volatile Memory (see Chapter 9)')
    tag_92: bytes = Property(146, bytes, doc='Cumulative Remaining Volatile Memory (see Chapter 9)')
    tag_93: bytes = Property(147, bytes, doc='Protocol Data Type F (Card Emulation Mode) (see section 4.8)')
    tag_96: bytes = Property(150, bytes, doc='Privacy-Sensitive Indicator (see section 13.1)')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_4f, stream, ctx)
        self.deserialize_property(cls.tag_9f70, stream, ctx)
        self.deserialize_property(cls.tag_c5, stream, ctx)
        self.deserialize_property(cls.tag_cf, stream, ctx)
        self.deserialize_property(cls.tag_c4, stream, ctx)
        self.deserialize_property(cls.tag_ce, stream, ctx)
        self.deserialize_property(cls.tag_84, stream, ctx)
        self.deserialize_property(cls.tag_cc, stream, ctx)
        self.deserialize_property(cls.tag_7f20, stream, ctx)
        self.deserialize_property(cls.tag_5f50, stream, ctx)
        self.deserialize_property(cls.tag_6d, stream, ctx)
        self.deserialize_property(cls.tag_5f45, stream, ctx)
        self.deserialize_property(cls.tag_a0, stream, ctx)
        self.deserialize_property(cls.tag_a1, stream, ctx)
        self.deserialize_property(cls.tag_a2, stream, ctx)
        self.deserialize_property(cls.tag_a3, stream, ctx)
        self.deserialize_property(cls.tag_a4, stream, ctx)
        self.deserialize_property(cls.tag_a5, stream, ctx)
        self.deserialize_property(cls.tag_86, stream, ctx)
        self.deserialize_property(cls.tag_87, stream, ctx)
        self.deserialize_property(cls.tag_88, stream, ctx)
        self.deserialize_property(cls.tag_89, stream, ctx)
        self.deserialize_property(cls.tag_a9, stream, ctx)
        self.deserialize_property(cls.tag_8a, stream, ctx)
        self.deserialize_property(cls.tag_8b, stream, ctx)
        self.deserialize_property(cls.tag_ac, stream, ctx)
        self.deserialize_property(cls.tag_8d, stream, ctx)
        self.deserialize_property(cls.tag_8e, stream, ctx)
        self.deserialize_property(cls.tag_8f, stream, ctx)
        self.deserialize_property(cls.tag_90, stream, ctx)
        self.deserialize_property(cls.tag_91, stream, ctx)
        self.deserialize_property(cls.tag_92, stream, ctx)
        self.deserialize_property(cls.tag_93, stream, ctx)
        self.deserialize_property(cls.tag_96, stream, ctx)

class GetDataSearchCriteria(Object):
    aid: bytes = Property(79, cls=bytes, doc='Application AID')
    tag_list: FilterCriteria = Property(92, FilterCriteria, doc='Tag List')
    other_search_criteria: List[TLVObject] = Property('Other Search Criteria', TLVObject, is_list=True)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        pos_end = stream.tell()
        ctx1 = ctx.clone(tlv_value=tlv_data)
        self.deserialize_property(cls.aid, stream, ctx1)
        self.deserialize_property(cls.tag_list, stream, ctx1)
        if tlv_data:
            self.deserialize_property(cls.other_search_criteria, stream, ctx.clone(tlv_value=tlv_data))
        stream.seek(pos_end, SEEK_SET)

@RequestPacketFactory.register(Instruction.GET_STATUS)
class GetStatusPacket(APDURequestPacket):
    p1: GetStatusP1 = Property(name='P1', cls=GetStatusP1, doc='Reference control parameter P1 is used to select a subset of statuses to be included in the response message.', display_order=2)
    p2: GetStatusP2 = Property(name='P2', cls=GetStatusP2, display_order=3)
    search_criteria: GetDataSearchCriteria = Property(name='Search Criteria', cls=GetDataSearchCriteria, doc='Search criteria (and C-MAC if present).')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = GetStatusPacket
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = GetStatusPacket
        self.deserialize_property(cls.search_criteria, stream, ctx)

class ImplicitSelectionParameter(Object):
    contactless_io: bool = Property('Contactless I/O', bool, lsb=7, msb=7)
    contact_io: bool = Property('Contact I/O', bool, lsb=6, msb=6)
    logical_channel_number: bool = Property('Logical channel number (0 to 19)', bool, lsb=0, msb=4)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = ImplicitSelectionParameter
        self.deserialize_property(cls.contactless_io, stream, ctx, peek=True)
        self.deserialize_property(cls.contact_io, stream, ctx, peek=True)
        self.deserialize_property(cls.logical_channel_number, stream, ctx)

class GlobalPlatformRegistryRelatedData(Object):
    aid: bytes = Property(79, bytes, doc='AID')
    life_cycle_state: int = Property(40816, int, doc='Life Cycle State; see section 11.1.1')
    privileges: Privileges = Property(197, Privileges, doc='Privileges (byte 1 - byte 2 - byte 3); see section 11.1.2')
    implicit_selection_parameters: List[ImplicitSelectionParameter] = Property(207, ImplicitSelectionParameter, is_list=True, doc='Implicit Selection Parameter; see section 11.1.7')
    application_executable_load_file_aid: bytes = Property(196, bytes, doc='Application’s Executable Load File AID')
    executable_load_file_version_number: bytes = Property(206, bytes, doc='Executable Load File Version Number')
    executable_module_aid: List[bytes] = Property(132, bytes, is_list=True, doc='Executable Module AIDs')
    associated_security_domain_aid: bytes = Property(204, bytes, doc='Associated Security Domain’s AID')
    unknown_data: List[TLVObject] = Property('Unknown', TLVObject, is_list=True)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = GlobalPlatformRegistryRelatedData
        self.deserialize_property(cls.aid, stream, ctx)
        self.deserialize_property(cls.aid, stream, ctx)
        self.deserialize_property(cls.life_cycle_state, stream, ctx)
        self.deserialize_property(cls.privileges, stream, ctx)
        self.deserialize_property(cls.implicit_selection_parameters, stream, ctx)
        self.deserialize_property(cls.application_executable_load_file_aid, stream, ctx)
        self.deserialize_property(cls.executable_load_file_version_number, stream, ctx)
        self.deserialize_property(cls.executable_module_aid, stream, ctx)
        self.deserialize_property(cls.associated_security_domain_aid, stream, ctx)
        if ctx.tlv_value:
            self.deserialize_property(cls.unknown_data, stream, ctx.clone(tlv_value=ctx.tlv_value))

@ResponsePacketFactory.register(Instruction.GET_STATUS)
class GetStatusResponsePacket(APDUResponsePacket):
    data: GlobalPlatformRegistryRelatedData = Property(name='GlobalPlatform Application Data', cls=GlobalPlatformRegistryRelatedData, tlv_tag=227)
    unknown_data: List[TLVObject] = Property('Unknown', TLVObject, is_list=True)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = GetStatusResponsePacket
        if ctx.bytes_size > 0:
            tlv_nodes = tlv.parse(stream, ctx.bytes_size)
            if not tlv_nodes:
                raise Exception('Bad TLV in response of GetStatus')
            ctx1 = ctx.clone(tlv_value=tlv_nodes)
            self.deserialize_property(cls.data, stream, ctx1)
            if tlv_nodes:
                self.deserialize_property(cls.unknown_data, stream, ctx.clone(tlv_value=tlv_nodes))

class InstallPurpose(IntFlag):
    FOR_REGISTRY_UPDATE = (64, 'For registry update')
    FOR_PERSONALIZATION = (32, 'For personalization')
    FOR_EXTRADITION = (16, 'For extradition')
    FOR_MAKE_SELECTABLE = (8, 'For make selectable')
    FOR_INSTALL = (4, 'For install')
    FOR_LOAD = (2, 'For load')

class InstallP1(Object):
    pbf: PBF = Property('PBF', PBF, lsb=7, msb=7)
    purpose: InstallPurpose = Property('Install Purpose', InstallPurpose, lsb=0, msb=6)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.pbf, stream, ctx, True)
        self.deserialize_property(cls.purpose, stream, ctx)

class InstallP2(IntEnum):
    NO_INFORMATION = (0, 'indicates that no information is provided.')
    BEGINNING = (1, 'indicates the beginning of the combined Load, Install and Make Selectable process.')
    END = (3, 'indicates the end of the combined Load, Install and Make Selectable process.')

class SystemSpecificParametersOfLoadParameters(Object):
    C6: bytes = Property(198, bytes, doc='Non-volatile code Minimum Memory requirement Optional')
    C7: bytes = Property(199, bytes, doc='Volatile data Minimum Memory requirement Optional')
    C8: bytes = Property(200, bytes, doc='Non-volatile data Minimum Memory requirement Optional')
    CD: int = Property(205, int, doc='File Data Block format id Optional')
    DD: bytes = Property(221, bytes, doc='Load File Data Block Parameters Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.C6, stream, ctx)
        self.deserialize_property(cls.C7, stream, ctx)
        self.deserialize_property(cls.C8, stream, ctx)
        self.deserialize_property(cls.CD, stream, ctx)
        self.deserialize_property(cls.DD, stream, ctx)

class LoadParameters(Object):
    system_specific_parameters: SystemSpecificParametersOfLoadParameters = Property(239, SystemSpecificParametersOfLoadParameters, doc='System Specific Parameters')
    crt_for_digital_signature: CRTForDigitalSignature = Property(182, CRTForDigitalSignature, doc='Control Reference Template for Digital Signature. Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.system_specific_parameters, stream, ctx1)
            self.deserialize_property(cls.crt_for_digital_signature, stream, ctx1)

class InstallForLoad(Object):
    load_file_aid_length: int = Property('Length of Load File AID', int, length=1)
    load_file_aid: bytes = Property('Load File AID', bytes)
    security_domain_aid_length: int = Property('Length of Security Domain AID', int, length=1)
    security_domain_aid: bytes = Property('Security Domain AID', bytes)
    load_file_data_block_hash_length: int = Property('Length of Load File Data Block Hash', int, length=1)
    load_file_data_block_hash: bytes = Property('Load File Data Block Hash', bytes)
    load_parameters_length: TLVLength = Property('Length of Load Parameters Field', TLVLength, length=1)
    load_parameters: LoadParameters = Property('Load Parameters Field', LoadParameters)
    load_token_length: TLVLength = Property('Length of Load Token', TLVLength, length=1)
    load_token: bytes = Property('Load Token', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.load_file_aid_length, stream, ctx)
        if self.load_file_aid_length:
            self.deserialize_property(cls.load_file_aid, stream, ctx.clone(bytes_size=self.load_file_aid_length))
        self.deserialize_property(cls.security_domain_aid_length, stream, ctx)
        if self.security_domain_aid_length:
            self.deserialize_property(cls.security_domain_aid, stream, ctx.clone(bytes_size=self.security_domain_aid_length))
        self.deserialize_property(cls.load_file_data_block_hash_length, stream, ctx)
        if self.load_file_data_block_hash_length:
            self.deserialize_property(cls.load_file_data_block_hash, stream, ctx.clone(bytes_size=self.load_file_data_block_hash_length))
        self.deserialize_property(cls.load_parameters_length, stream, ctx)
        if self.load_parameters_length:
            self.deserialize_property(cls.load_parameters, stream, ctx.clone(bytes_size=self.load_parameters_length))
        self.deserialize_property(cls.load_token_length, stream, ctx)
        if self.load_token_length:
            self.deserialize_property(cls.load_token, stream, ctx.clone(bytes_size=self.load_token_length))

class SystemSpecificParametersOfInstallParameters(Object):
    C7: bytes = Property(199, bytes, doc='Volatile Memory Quota Optional')
    C8: bytes = Property(200, bytes, doc='Non-volatile Memory Quota Optional')
    CB: bytes = Property(203, bytes, doc='Global Service Parameters Optional')
    D7: bytes = Property(215, bytes, doc='Volatile Reserved Memory Optional')
    D8: bytes = Property(216, bytes, doc='Non-volatile Reserved Memory Optional')
    CA: bytes = Property(202, bytes, doc='[TS 102 226] specific parameter Optional')
    CF: bytes = Property(207, bytes, doc='Implicit selection parameter See note below')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.C7, stream, ctx)
        self.deserialize_property(cls.C8, stream, ctx)
        self.deserialize_property(cls.CB, stream, ctx)
        self.deserialize_property(cls.D7, stream, ctx)
        self.deserialize_property(cls.D8, stream, ctx)
        self.deserialize_property(cls.CA, stream, ctx)
        self.deserialize_property(cls.CF, stream, ctx)

class InstallParametersOfInstallForInstall(Object):
    application_specific_parameters: bytes = Property(201, bytes, doc='Application Specific Parameters')
    system_specific_parameters: SystemSpecificParametersOfInstallParameters = Property(239, SystemSpecificParametersOfInstallParameters, doc='System Specific Parameters')
    specific_template: bytes = Property(234, bytes, doc='System Specific Template')
    crt_for_digital_signature: CRTForDigitalSignature = Property(182, CRTForDigitalSignature, doc='Control Reference Template for Digital Signature. Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.application_specific_parameters, stream, ctx1)
            self.deserialize_property(cls.system_specific_parameters, stream, ctx1)
            self.deserialize_property(cls.specific_template, stream, ctx1)
            self.deserialize_property(cls.crt_for_digital_signature, stream, ctx1)

class InstallForInstall(Object):
    executable_load_file_aid_length: int = Property('Length of Executable Load File AID', int, length=1)
    executable_load_file_aid: bytes = Property('Executable Load File AID', bytes)
    executable_module_aid_length: int = Property('Length of Executable Module AID', int, length=1)
    executable_module_aid: bytes = Property('Executable Module AID', bytes)
    application_aid_length: int = Property('Length of Application AID', int, length=1)
    application_aid: bytes = Property('Application AID', bytes)
    privileges_length: int = Property('Length of Privileges', int, length=1)
    privileges: Privileges = Property('Privileges', Privileges)
    install_parameters_length: TLVLength = Property('Length of Install Parameters field', TLVLength)
    install_parameters: bytes = Property('Install Parameters field', bytes)
    install_token_length: TLVLength = Property('Length of Install Token', TLVLength)
    install_token: bytes = Property('Install Token', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.executable_load_file_aid_length, stream, ctx)
        if self.executable_load_file_aid_length:
            self.deserialize_property(cls.executable_load_file_aid, stream, ctx.clone(bytes_size=self.executable_load_file_aid_length))
        self.deserialize_property(cls.executable_module_aid_length, stream, ctx)
        if self.executable_module_aid_length:
            self.deserialize_property(cls.executable_module_aid, stream, ctx.clone(bytes_size=self.executable_module_aid_length))
        self.deserialize_property(cls.application_aid_length, stream, ctx)
        if self.application_aid_length:
            self.deserialize_property(cls.application_aid, stream, ctx.clone(bytes_size=self.application_aid_length))
        self.deserialize_property(cls.privileges_length, stream, ctx)
        if self.privileges_length:
            self.deserialize_property(cls.privileges, stream, ctx.clone(bytes_size=self.privileges_length))
        self.deserialize_property(cls.install_parameters_length, stream, ctx)
        if self.install_parameters_length:
            self.deserialize_property(cls.install_parameters, stream, ctx.clone(bytes_size=self.install_parameters_length))
        self.deserialize_property(cls.install_token_length, stream, ctx)
        if self.install_token_length:
            self.deserialize_property(cls.install_token, stream, ctx.clone(bytes_size=self.install_token_length))

class SystemSpecificParametersOfMakeSelectableParameters(Object):
    CF: bytes = Property(207, bytes, doc='Implicit selection parameter Optional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.CF, stream, ctx)

class MakeSelectableParameters(Object):
    system_specific_parameters: SystemSpecificParametersOfMakeSelectableParameters = Property(239, SystemSpecificParametersOfMakeSelectableParameters, doc='System Specific Parameters')
    crt_for_digital_signature: CRTForDigitalSignature = Property(182, CRTForDigitalSignature, doc='Control Reference Template for Digital Signature. Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.system_specific_parameters, stream, ctx1)
            self.deserialize_property(cls.crt_for_digital_signature, stream, ctx1)

class InstallForMakeSelectable(Object):
    data_length0: int = Property('Length of data0', int, length=1)
    data_length1: int = Property('Length of data1', int, length=1)
    application_aid_length: int = Property('Length of Application AID', int, length=1)
    application_aid: bytes = Property('Application AID', bytes)
    privileges_length: int = Property('Length of Privileges', int, length=1)
    privileges: bytes = Property('Privileges', bytes)
    make_selectable_parameters_length: TLVLength = Property('Length of Make Selectable Parameters field', TLVLength)
    make_selectable_parameters: MakeSelectableParameters = Property('Make Selectable Parameters field', MakeSelectableParameters)
    make_selectable_token_length: TLVLength = Property('Length of Make Selectable Token', TLVLength)
    make_selectable_token: bytes = Property('Make Selectable Token', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data_length0, stream, ctx)
        self.deserialize_property(cls.data_length1, stream, ctx)
        self.deserialize_property(cls.application_aid_length, stream, ctx)
        if self.application_aid_length:
            self.deserialize_property(cls.application_aid, stream, ctx.clone(bytes_size=self.application_aid_length))
        self.deserialize_property(cls.privileges_length, stream, ctx)
        if self.privileges_length:
            self.deserialize_property(cls.privileges, stream, ctx.clone(bytes_size=self.privileges_length))
        self.deserialize_property(cls.make_selectable_parameters_length, stream, ctx)
        if self.make_selectable_parameters_length:
            self.deserialize_property(cls.make_selectable_parameters, stream, ctx.clone(bytes_size=self.make_selectable_parameters_length))
        self.deserialize_property(cls.make_selectable_token_length, stream, ctx)
        if self.make_selectable_token_length:
            self.deserialize_property(cls.make_selectable_token, stream, ctx.clone(bytes_size=self.make_selectable_token_length))

class ExtraditionParameters(Object):
    crt_for_digital_signature: CRTForDigitalSignature = Property(182, CRTForDigitalSignature, doc='Control Reference Template for Digital Signature. Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.crt_for_digital_signature, stream, ctx1)

class InstallForExtradition(Object):
    security_domain_aid_length: int = Property('Length of Security Domain AID', int, length=1)
    security_domain_aid: bytes = Property('Security Domain AID', bytes)
    data_length: int = Property('Length of data', int, length=1)
    application_or_executable_load_file_aid_length: int = Property('Length of Application or Executable Load File AID', int, length=1)
    application_or_executable_load_file_aid: bytes = Property('Application or Executable Load File AID', bytes)
    length: int = Property('Length', int, length=1)
    extradition_parameters_length: TLVLength = Property('Length of Extradition Parameters field', TLVLength)
    extradition_parameters: ExtraditionParameters = Property('Extradition Parameters field', ExtraditionParameters)
    extradition_token_length: TLVLength = Property('Length of Extradition Token', TLVLength)
    extradition_token: bytes = Property('Extradition Token', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.security_domain_aid_length, stream, ctx)
        if self.security_domain_aid_length:
            self.deserialize_property(cls.security_domain_aid, stream, ctx.clone(bytes_size=self.security_domain_aid_length))
        self.deserialize_property(cls.data_length, stream, ctx)
        self.deserialize_property(cls.application_or_executable_load_file_aid_length, stream, ctx)
        if self.application_or_executable_load_file_aid_length:
            self.deserialize_property(cls.application_or_executable_load_file_aid, stream, ctx.clone(bytes_size=self.application_or_executable_load_file_aid_length))
        self.deserialize_property(cls.length, stream, ctx)
        self.deserialize_property(cls.extradition_parameters_length, stream, ctx)
        if self.extradition_parameters_length:
            self.deserialize_property(cls.extradition_parameters, stream, ctx.clone(bytes_size=self.extradition_parameters_length))
        self.deserialize_property(cls.extradition_token_length, stream, ctx)
        if self.extradition_token_length:
            self.deserialize_property(cls.extradition_token, stream, ctx.clone(bytes_size=self.extradition_token_length))

class RestrictParameter(IntFlag):
    REGISTRY_UPDATE = (64, 'Registry Update')
    PERSONALIZATION = (32, 'Personalization')
    EXTRADITION = (16, 'Extradition')
    MAKE_SELECTABLE = (8, 'Make selectable')
    INSTALL = (4, 'Install')
    LOAD = (2, 'Load')
    DELETE = (1, 'Delete')

class ContactlessProtocolParametersProfile(Object):
    data: List[TLVObject] = Property('Parameters', TLVObject, is_list=True)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, ctx)

class RecognitionAlgorithmId(IntEnum):
    STRING_RECOGNITION = (1, 'String recognition')
    BITMAP_RECOGNITION = (2, 'Bitmap recognition')
    ID_RECOGNITION = (3, 'ID recognition')

class AlgorithmParameterForStringRecognition(Object):
    offset: int = Property('Offset', int, length=2)
    pattern: bytes = Property('Pattern', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.offset, stream, ctx)
        self.deserialize_property(cls.pattern, stream, ctx.clone(bytes_size=ctx.bytes_size - 2))

class AlgorithmParameterForBitmapRecognition(Object):
    reference_data: bytes = Property('Reference Data', bytes)
    mask: bytes = Property('mask', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.reference_data, stream, ctx.clone(bytes_size=ctx.bytes_size >> 1))
        self.deserialize_property(cls.mask, stream, ctx.clone(bytes_size=ctx.bytes_size >> 1))

class AlgorithmParameterForIdRecognition(Object):
    offset: int = Property('Offset', int, length=2)
    pattern: bytes = Property('Pattern', bytes, length=8)
    mask: bytes = Property('mask', bytes, length=8)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.offset, stream, ctx)
        self.deserialize_property(cls.pattern, stream, ctx.clone(bytes_size=8))
        self.deserialize_property(cls.mask, stream, ctx.clone(bytes_size=8))

class RecognitionAlgorithm(Object):
    algorithm_identifier: RecognitionAlgorithmId = Property('Algorithm Identifier', RecognitionAlgorithmId, length=1)
    algorithm_parameter: Union[AlgorithmParameterForStringRecognition, AlgorithmParameterForBitmapRecognition, AlgorithmParameterForIdRecognition] = Property('Algorithm Identifier')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.algorithm_identifier, stream, ctx)
        for (id, para_cls) in ((RecognitionAlgorithmId.STRING_RECOGNITION, AlgorithmParameterForStringRecognition), (RecognitionAlgorithmId.BITMAP_RECOGNITION, AlgorithmParameterForBitmapRecognition), (RecognitionAlgorithmId.ID_RECOGNITION, AlgorithmParameterForIdRecognition)):
            if self.algorithm_identifier == id:
                self.deserialize_property(cls.algorithm_parameter, stream, ctx.clone(bytes_size=ctx.bytes_size - 1), cls=para_cls)

class CommunicationInterfaceIdentifier(IntFlag):
    CONTACT_BASED = (128, 'Contact-based', 'Contact-based communication (e.g. ISO/IEC 7816) is supported.')
    PROXIMITY_BASED = (64, 'Proximity-based', 'Proximity-based communication (e.g. ISO/IEC 14443) is supported.')

class CommunicationInterfaceAccessConfiguration(Object):
    tag_80: CommunicationInterfaceIdentifier = Property(128, CommunicationInterfaceIdentifier, doc='Communication Interface Access Restriction Optional')
    tag_81: CommunicationInterfaceIdentifier = Property(129, CommunicationInterfaceIdentifier, doc='Communication Interface Access Default Optional')
    tag_82: CommunicationInterfaceIdentifier = Property(130, CommunicationInterfaceIdentifier, doc='Communication Interface Access per Instance Optional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)

class LVObject(Object):
    length: TLVLength = Property('Length', TLVLength)
    value: bytes = Property('Value', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.length, stream, ctx)
        if self.length:
            self.deserialize_property(cls.value, stream, ctx.clone(bytes_size=self.length))

class ProtocolParameterDataForTypeA(Object):
    tag_80: LVObject = Property(128, LVObject, doc='Unique Identifier values as defined in [102 622]. There is no consistency check with UID size which is coded in ATQA.')
    tag_81: int = Property(129, int, doc='SAK: Preformatted Select AcKnowledge as defined in [14443-3], when the UID is complete')
    tag_82: int = Property(130, int, length=2, doc='ATQA: Coding of the ATQA as defined in [102 622].')
    tag_83: LVObject = Property(131, LVObject, doc='ATS Historical bytes in answer to select as defined in [14443-4].')
    tag_84: int = Property(132, int, doc='FWI, SFGI: Frame waiting time and Start-up frame guard time as defined in [14443-4] for Type A')
    tag_85: int = Property(133, int, doc="CID Support: Support of the Card Identifier field as defined in [14443-4]. '01': ATS indicates “CID Support”. '00': ATS may not indicate “CID Support”")
    tag_86: bytes = Property(134, bytes, length=3, doc='DATA_RATE_MAX: Maximum data rate supported as defined in [102 622]')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)
        self.deserialize_property(cls.tag_83, stream, ctx)
        self.deserialize_property(cls.tag_84, stream, ctx)
        self.deserialize_property(cls.tag_85, stream, ctx)
        self.deserialize_property(cls.tag_86, stream, ctx)

class ProtocolParameterMandatoryMaskForTypeA(Object):
    tag_80: bytes = Property(128, bytes, doc="\nLength Operation Indicator(1 byte):\n    '00': Application doesn’t care about UID length.\n    '0F': Application does care about UID length and the XOR operator (strict equality) shall be used.\n    'FF': Application does care about UID length and the MAX operator shall be used.\nValue Mask(n bytes):\n    Mask for mandatory bits within the UID value".strip())
    tag_81: int = Property(129, int, length=1, doc='Mask for mandatory bits within SAK')
    tag_82: int = Property(130, int, length=2, doc='ATQA: Coding of the ATQA as defined in [102 622].')
    tag_83: bytes = Property(131, bytes, doc="\nLength Operation Indicator:\n    '00': Application doesn’t care about ATS historical bytes length.\n    '0F': Application does care about ATS historical bytes length and the XOR operator (strict equality) shall be used.\n    'FF': Application does care about ATS historical bytes length and the MAX operator shall be used.\nValue Mask:\n    Mask for mandatory historical bit in answer to select as defined in [14443-4].".strip())
    tag_84: int = Property(132, int, length=1, doc="\nOperation Indicator for FWI, SFGI\n    '00': Application doesn’t care about the FWI and SFGI values\n    'F0': Application requests FWI does not exceed the specified value, but does not care about the SFGI value.\n    'FF': Application requests that the values for FWI and SFGI do not exceed their specified values.\n    '0F': Application requests that the value of SFGI does not exceed the specified value and does not care about the value of FWI.".strip())
    tag_85: int = Property(133, int, length=1, doc='Mask for mandatory bits in CID_SUPPORT')
    tag_86: bytes = Property(134, bytes, length=3, doc='"\nOperation Indicator for mandatory bits within DATARATE_MAX.\n    Byte 1: \n        \'00\': Application does not care about the Maximum bit rate in the PCD to PICC direction\n        \'FF\': Application requests that the indicated Maximum bit rate in the PCD to PICC direction is not exceeded\n    Byte 2: \n        \'00\': Application does not care about the Maximum bit rate in the PICC to PCD direction\n        \'FF\': Application requests that the indicated Maximum bit rate in the PICC to PCD direction is not exceeded\n    Byte 3: \n        \'00\': Application does not care about this parameter\n        \'FF\': Application requests that value of Byte 3 of DATARATE_MAX is respected'.strip())

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)
        self.deserialize_property(cls.tag_83, stream, ctx)
        self.deserialize_property(cls.tag_84, stream, ctx)
        self.deserialize_property(cls.tag_85, stream, ctx)
        self.deserialize_property(cls.tag_86, stream, ctx)

class ProtocolParametersForTypeA(Object):
    tag_a0: ProtocolParameterDataForTypeA = Property(160, ProtocolParameterDataForTypeA, doc='Protocol Parameter Data')
    tag_a1: ProtocolParameterMandatoryMaskForTypeA = Property(161, ProtocolParameterMandatoryMaskForTypeA, doc='Protocol Parameter Mandatory Mask')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_a0, stream, ctx)
        self.deserialize_property(cls.tag_a1, stream, ctx)

class ProtocolParameterDataForTypeB(Object):
    tag_80: LVObject = Property(128, LVObject, doc='Pseudo Unique PICC Identifier. Coding is as specified in [102 622]')
    tag_81: int = Property(129, int, doc='AFI: Application Family Identifier as defined in [14443-3].')
    tag_82: bytes = Property(130, bytes, doc='ATQB: Coding of the ATQB as defined in [102 622]')
    tag_83: LVObject = Property(131, LVObject, doc='Application historical bytes in answer to select as defined in [102 622]')
    tag_84: bytes = Property(132, bytes, doc='Maximum data rate supported as defined in [102 622]')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)
        self.deserialize_property(cls.tag_83, stream, ctx)
        self.deserialize_property(cls.tag_84, stream, ctx)
        self.deserialize_property(cls.tag_85, stream, ctx)
        self.deserialize_property(cls.tag_86, stream, ctx)

class ProtocolParameterMandatoryMaskForTypeB(Object):
    tag_80: bytes = Property(128, bytes, doc="\nLength Operation Indicator(1 byte):\n    '00': Application doesn’t care about PUPI length\n    'FF': Application does care about PUPI length and the XOR operator shall be used (strict equality).\nValue Mask(n bytes):\n    Mask for mandatory bits within the PUPI".strip())
    tag_81: int = Property(129, int, length=1, doc='Mask for mandatory bits within the AFI.')
    tag_82: bytes = Property(130, bytes, doc='Mask for mandatory bits in ATQB')
    tag_83: bytes = Property(131, bytes, doc="\nLength Operation Indicator:\n    '00': Application doesn’t care about Higher Layer Response length.\n    'FF': Application does care about Higher Layer Response length and the MAX operator shall be used.\nValue Mask:\n    Mask for mandatory bits in the Higher layer response.".strip())
    tag_84: bytes = Property(132, bytes, length=1, doc="\nOperation Indicator for mandatory bits within DATARATE_MAX.\n    Byte 1: \n        '00': Application does not care about the Maximum bit rate in the PCD to PICC direction\n        'FF': Application requests that the indicated Maximum bit rate in the PCD to PICC direction is not exceeded\n    Byte 2: \n        '00': Application does not care about the Maximum bit rate in the PICC to PCD direction\n        'FF': Application requests that the indicated Maximum bit rate in the PICC to PCD direction is not exceeded\n    Byte 3: \n        '00': Application does not care about this parameter\n        'FF': Application requests that value of Byte 3 of DATARATE_MAX is respected".strip())

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)
        self.deserialize_property(cls.tag_83, stream, ctx)
        self.deserialize_property(cls.tag_84, stream, ctx)

class ProtocolParametersForTypeB(Object):
    tag_a0: ProtocolParameterDataForTypeB = Property(160, ProtocolParameterDataForTypeB, doc='Protocol Parameter Data')
    tag_a1: ProtocolParameterMandatoryMaskForTypeB = Property(161, ProtocolParameterMandatoryMaskForTypeB, doc='Protocol Parameter Mandatory Mask')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_a0, stream, ctx)
        self.deserialize_property(cls.tag_a1, stream, ctx)

class TypeFAntiCollisionParametersEntry(Object):
    tag_80: int = Property(128, int, doc='System Code: The System Code is an application specific code used during anti-collision')
    tag_81: bytes = Property(129, bytes, doc='PICC Identifier: The PICC identifier is used by the reader/writer to identify the “File System” associated with the System Code within a Type F card application.')
    tag_82: bytes = Property(130, bytes, doc='Response Time Descriptor: The Response Time Descriptor is used to calculate the response time for the commands defined in [JIS 6319-4].')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)

class ProtocolParameterDataForTypeF(Object):
    tag_80: int = Property(128, int, doc='Maximum Number of anti-collision parameter entries')
    tag_A0: List[TypeFAntiCollisionParametersEntry] = Property(160, TypeFAntiCollisionParametersEntry, is_list=True, doc='Type F anti-collision parameters entry')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_A0, stream, ctx)

class ProtocolParametersForTypeF(Object):
    tag_a0: ProtocolParameterDataForTypeB = Property(160, ProtocolParameterDataForTypeB, doc='Protocol Parameter Data')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_a0, stream, ctx)

class ContactlessProtocolTypeState(IntEnum):
    DEACTIVATED = (0, 'Contactless Protocol Type A/B/F RF DEACTIVATED')
    ACTIVATED = (1, 'Contactless Protocol Type A/B/F RF ACTIVATED')

class ContactlessProtocolTypeState(Object):
    type_a_state: ContactlessProtocolTypeState = Property('Contactless Protocol Type A RF State', ContactlessProtocolTypeState, lsb=7, msb=7)
    type_b_state: ContactlessProtocolTypeState = Property('Contactless Protocol Type B RF State', ContactlessProtocolTypeState, lsb=6, msb=6)
    type_f_state: ContactlessProtocolTypeState = Property('Contactless Protocol Type F RF State', ContactlessProtocolTypeState, lsb=5, msb=5)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.type_a_state, stream, ctx, peek=True)
        self.deserialize_property(cls.type_b_state, stream, ctx, peek=True)
        self.deserialize_property(cls.type_f_state, stream, ctx)

class ContactlessProtocolParameters(Object):
    tag_80: bytes = Property(128, bytes, doc="List of protocol types assigned for the application: '81': Type A, '82': Type B, '84': Type F")
    tag_81: bytes = Property(129, bytes, doc="Initial Contactless Activation State. \n'00': The OPEN shall not attempt to activate the Application.\n'01': The OPEN shall attempt to activate the Application in the following cases:\n\t1. When the Application transitions to the SELECTABLE state for the first time\n\t2. When the Application is unlocked")
    tag_A2: ContactlessProtocolParametersProfile = Property(162, ContactlessProtocolParametersProfile, doc='Contactless Protocol Parameters Profile (see section 11.2.2) Conditional')
    tag_83: RecognitionAlgorithm = Property(131, RecognitionAlgorithm, doc='Recognition Algorithm (see section 6.5) Optional')
    tag_84: int = Property(132, int, doc="Continuous Processing (see section 6.4) Optional. \nOPEN: 2 bytes. Continuous processing timeout. Unsigned short value: Time in ms (default: 0 ms)\nApplication: 1 btye. \n    '01': Continuous processing is disabled (default if TLV is missing). \n    '02': Continuous processing when this Application is selected on the contactless interface is enabled")
    tag_A5: CommunicationInterfaceAccessConfiguration = Property(165, CommunicationInterfaceAccessConfiguration, doc='Communication Interface Access Parameters (see section 5.2) Optional')
    tag_86: ProtocolParametersForTypeA = Property(134, ProtocolParametersForTypeA, doc='Protocol Data Type A (Card Emulation Mode) (see section 4.6) Conditional')
    tag_87: ProtocolParametersForTypeB = Property(135, ProtocolParametersForTypeB, doc='Protocol Data Type B (Card Emulation Mode) (see section 4.7) Conditional')
    tag_88: ProtocolParameterDataForTypeF = Property(136, ProtocolParameterDataForTypeF, doc='Protocol Data Type F (Card Emulation Mode) (see section 4.8) Conditional')
    tag_89: ContactlessProtocolTypeState = Property(137, ContactlessProtocolTypeState, doc='Contactless Protocol Type State (see section 11.2.4) Optional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_80, stream, ctx)
        self.deserialize_property(cls.tag_81, stream, ctx)
        self.deserialize_property(cls.tag_A2, stream, ctx)
        self.deserialize_property(cls.tag_83, stream, ctx)
        self.deserialize_property(cls.tag_84, stream, ctx)
        self.deserialize_property(cls.tag_A5, stream, ctx)
        self.deserialize_property(cls.tag_86, stream, ctx)
        self.deserialize_property(cls.tag_87, stream, ctx)
        self.deserialize_property(cls.tag_88, stream, ctx)
        self.deserialize_property(cls.tag_89, stream, ctx)

class ImageEncodingFormat(IntEnum):
    JPG = (1, 'JPG')
    JPG2000 = (2, 'JPG-2000')
    GIF = (3, 'GIF')
    PNG8 = (4, 'PNG-8')
    PNG24 = (5, 'PNG-24')
    BMP = (6, 'BMP')

class ApplicationImageTemplateAuthenticationData(Object):
    tag_53: ImageEncodingFormat = Property(83, ImageEncodingFormat)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_53, stream, ctx)

class ApplicationImageTemplate(Object):
    tag_5f44: bytes = Property(24400, bytes, doc='Application Image')
    tag_67: ApplicationImageTemplateAuthenticationData = Property(103, ApplicationImageTemplateAuthenticationData, doc='Authentication Data (optional; if this tag is not present, the Application Image format shall be according to ISO/IEC 10918-1 [10918-1])')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_5f44, stream, ctx)
        self.deserialize_property(cls.tag_67, stream, ctx)

class DisplayMessageFormat(IntEnum):
    JPG = (1, 'ASCII')
    JPG2000 = (2, 'BCD')
    GIF = (3, 'HEX')
    PNG8 = (4, 'UTF-8')

class DisplayMessage(Object):
    tag_format: DisplayMessageFormat = Property('Format', DisplayMessageFormat, doc='Application Image')
    tag_message: bytes = Property('Message', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_format, stream, ctx)
        self.deserialize_property(cls.tag_message, stream, ctx.clone(bytes_size=ctx.bytes_size - 1))

class DisplayControlTemplate(Object):
    tag_5f50: bytes = Property(24400, bytes, doc='Uniform Resource Locator (see ISO/IEC 7816-6 [7816-6]). The purpose of this URL is out of scope of this document.')
    tag_6d: ApplicationImageTemplate = Property(109, ApplicationImageTemplate, doc='Uniform Resource Locator (see ISO/IEC 7816-6 [7816-6]). The purpose of this URL is out of scope of this document.')
    tag_5f45: DisplayMessage = Property(24389, DisplayMessage, doc='Display Message')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_5f50, stream, ctx)
        self.deserialize_property(cls.tag_6d, stream, ctx)
        self.deserialize_property(cls.tag_5f45, stream, ctx)

class UserInteractionParametersHeadApplication(Object):
    tag_4f: bytes = Property(79, bytes, doc='AID of the group’s Head Application to join')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_4f, stream, ctx)

class UserInteractionParametersAIDList(Object):
    tag_4f: List[bytes] = Property(79, bytes, is_list=True, doc='AID of an Application')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_4f, stream, ctx)

class UserInteractionParametersDisplayRequiredIndicator(IntEnum):
    REQUIRED = (0, 'Application requires a display')
    NOT_REQUIRED = (1, 'Application does not require a display')

class UserInteractionParameters(Object):
    tag_7f20: DisplayControlTemplate = Property(32544, DisplayControlTemplate, doc='Display Control Template (see section 3.2) Optional')
    tag_a0: UserInteractionParametersHeadApplication = Property(160, UserInteractionParametersHeadApplication, doc='Head Application (see section 3.7.4) Conditional')
    tag_a1: UserInteractionParametersAIDList = Property(161, UserInteractionParametersAIDList, doc='Add to the Group Authorization List (see section 3.7.5) Conditional')
    tag_a2: UserInteractionParametersAIDList = Property(162, UserInteractionParametersAIDList, doc='Remove from the Group Authorization List (see section 3.7.6) Conditional')
    tag_a3: UserInteractionParametersAIDList = Property(163, UserInteractionParametersAIDList, doc='Add to the CREL List (see section 3.8.3) Optional')
    tag_a4: UserInteractionParametersAIDList = Property(164, UserInteractionParametersAIDList, doc='Remove from the CREL List (see section 3.8.4) Optional')
    tag_a5: UserInteractionParametersAIDList = Property(165, UserInteractionParametersAIDList, doc='Policy Restricted Applications (see section 3.3) Optional')
    tag_a6: bytes = Property(166, bytes, doc='Application discretionary data (see section 3.4) Optional')
    tag_87: int = Property(135, int, doc='Application Family (see section 3.5) Optional')
    tag_88: UserInteractionParametersDisplayRequiredIndicator = Property(136, UserInteractionParametersDisplayRequiredIndicator, doc='Display Required Indicator (see section 3.6) Optional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_7f20, stream, ctx)
        self.deserialize_property(cls.tag_a0, stream, ctx)
        self.deserialize_property(cls.tag_a1, stream, ctx)
        self.deserialize_property(cls.tag_a2, stream, ctx)
        self.deserialize_property(cls.tag_a3, stream, ctx)
        self.deserialize_property(cls.tag_a4, stream, ctx)
        self.deserialize_property(cls.tag_a5, stream, ctx)
        self.deserialize_property(cls.tag_a6, stream, ctx)
        self.deserialize_property(cls.tag_87, stream, ctx)
        self.deserialize_property(cls.tag_88, stream, ctx)

class PrivacySensitiveIndicator(Object):
    NO = (0, 'Application is not Privacy-Sensitive')
    YES = (1, 'Application is Privacy-Sensitive')

class SystemSpecificParametersOfRegistryUpdateParameters(Object):
    tag_cf: bytes = Property(207, bytes, doc='Implicit selection parameter Optional')
    tag_cb: bytes = Property(203, bytes, doc='Global Service Parameters Optional')
    tag_d9: RestrictParameter = Property(217, RestrictParameter, doc='Restrict Parameter (see Table 11-53) Conditional')
    tag_a0: ContactlessProtocolParameters = Property(160, ContactlessProtocolParameters, doc='Contactless Protocol Parameters Optional')
    tag_a1: UserInteractionParameters = Property(161, UserInteractionParameters, doc='User Interaction Parameters Optional')
    tag_b0: bytes = Property(176, bytes, doc='(Assigned to ETSI) Optional')
    tag_82: bytes = Property(130, bytes, doc='Cumulative Granted Volatile Memory (see Chapter 9) Optional')
    tag_83: bytes = Property(131, bytes, doc='Cumulative Granted Non Volatile Memory (see Chapter 9) Optional')
    tag_96: PrivacySensitiveIndicator = Property(150, PrivacySensitiveIndicator, doc='Privacy-Sensitive Indicator (see section 13.1) Optional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_cf, stream, ctx)
        self.deserialize_property(cls.tag_cb, stream, ctx)
        self.deserialize_property(cls.tag_d9, stream, ctx)
        self.deserialize_property(cls.tag_a0, stream, ctx)
        self.deserialize_property(cls.tag_a1, stream, ctx)
        self.deserialize_property(cls.tag_b0, stream, ctx)
        self.deserialize_property(cls.tag_82, stream, ctx)
        self.deserialize_property(cls.tag_83, stream, ctx)
        self.deserialize_property(cls.tag_96, stream, ctx)

class RegistryUpdateParameters(Object):
    system_specific_parameters: SystemSpecificParametersOfRegistryUpdateParameters = Property(239, SystemSpecificParametersOfRegistryUpdateParameters, doc='System Specific Parameters Optional')
    crt_for_digital_signature: CRTForDigitalSignature = Property(182, CRTForDigitalSignature, doc='Control Reference Template for Digital Signature. Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.system_specific_parameters, stream, ctx1)
            self.deserialize_property(cls.crt_for_digital_signature, stream, ctx1)

class InstallForRegistryUpdate(Object):
    security_domain_aid_length: int = Property('Length of Security Domain AID', int, length=1)
    security_domain_aid: bytes = Property('Security Domain AID', bytes)
    data_length: int = Property('Length of data', int, length=1)
    application_aid_length: int = Property('Length of Application AID', int, length=1)
    application_aid: bytes = Property('Application AID', bytes)
    privileges_length: int = Property('Length of Privileges', int, length=1)
    privileges: bytes = Property('Privileges', bytes)
    registry_update_parameters_length: int = Property('Length of Registry Update Parameters', int, length=1)
    registry_update_parameters: RegistryUpdateParameters = Property('Registry Update Parameters', RegistryUpdateParameters)
    registry_update_token_length: int = Property('Length of Registry Update Token', int, length=1)
    registry_update_token: bytes = Property('Registry Update Token', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.security_domain_aid_length, stream, ctx)
        if self.security_domain_aid_length:
            self.deserialize_property(cls.security_domain_aid, stream, ctx.clone(bytes_size=self.security_domain_aid_length))
        self.deserialize_property(cls.data_length, stream, ctx)
        self.deserialize_property(cls.application_aid_length, stream, ctx)
        if self.application_aid_length:
            self.deserialize_property(cls.application_aid, stream, ctx.clone(bytes_size=self.application_aid_length))
        self.deserialize_property(cls.privileges_length, stream, ctx)
        if self.privileges_length:
            self.deserialize_property(cls.privileges, stream, ctx.clone(bytes_size=self.privileges_length))
        self.deserialize_property(cls.registry_update_parameters_length, stream, ctx)
        if self.registry_update_parameters_length:
            self.deserialize_property(cls.registry_update_parameters, stream, ctx.clone(bytes_size=self.registry_update_parameters_length))
        self.deserialize_property(cls.registry_update_token_length, stream, ctx)
        if self.registry_update_token_length:
            self.deserialize_property(cls.registry_update_token, stream, ctx.clone(bytes_size=self.registry_update_token_length))

class InstallForPersonalization(Object):
    data_length0: int = Property('Length of data0', int, length=1)
    data_length1: int = Property('Length of data1', int, length=1)
    application_aid_length: int = Property('Length of Application AID', int, length=1)
    application_aid: bytes = Property('Application AID', bytes)
    data_length2: int = Property('Length of data2', int, length=1)
    data_length3: int = Property('Length of data3', int, length=1)
    data_length4: int = Property('Length of data4', int, length=1)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data_length0, stream, ctx)
        self.deserialize_property(cls.data_length1, stream, ctx)
        self.deserialize_property(cls.application_aid_length, stream, ctx)
        if self.application_aid_length:
            self.deserialize_property(cls.application_aid, stream, ctx.clone(bytes_size=self.application_aid_length))
        self.deserialize_property(cls.data_length2, stream, ctx)
        self.deserialize_property(cls.data_length3, stream, ctx)
        self.deserialize_property(cls.data_length4, stream, ctx)

@RequestPacketFactory.register(Instruction.INSTALL)
class InstallPacket(APDURequestPacket):
    p1: InstallP1 = Property(name='P1', cls=InstallP1, display_order=2)
    p2: InstallP2 = Property(name='P2', cls=InstallP2, display_order=3)
    data: Union[InstallForLoad, InstallForInstall, InstallForMakeSelectable, InstallForExtradition, InstallForRegistryUpdate, InstallForPersonalization] = Property(name='Data', doc='Install data (and C-MAC if present).')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        for (purpose, t) in [(InstallPurpose.FOR_LOAD, InstallForLoad), (InstallPurpose.FOR_INSTALL, InstallForInstall), (InstallPurpose.FOR_MAKE_SELECTABLE, InstallForMakeSelectable), (InstallPurpose.FOR_EXTRADITION, InstallForExtradition), (InstallPurpose.FOR_REGISTRY_UPDATE, InstallForRegistryUpdate), (InstallPurpose.FOR_PERSONALIZATION, InstallForPersonalization)]:
            if purpose in self.p1.purpose:
                self.deserialize_property(cls.data, stream, ctx, cls=t)
                break

@ResponsePacketFactory.register(Instruction.INSTALL)
class InstallResponsePacket(APDUResponsePacket):
    install_confirmation_length: TLVLength = Property('Length of Install Confirmation', TLVLength)
    install_confirmation: Confirmations = Property('Install Confirmation', TLVLength)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.install_confirmation_length, stream, ctx)
        if self.install_confirmation_length:
            self.deserialize_property(cls.install_confirmation, stream, ctx)

class LoadP1(Object):
    pbf: int = Property('PBF', int, lsb=7, msb=7, doc='0: More blocks. 1: Last block')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.pbf, stream, ctx)

class DAPBlockOfLoadFile(Object):
    security_domain_aid: bytes = Property(79, bytes, doc='Security Domain AID')
    load_file_data_block_signature: bytes = Property(195, bytes, doc='Load File Data Block Signature')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.security_domain_aid, stream, ctx)
        self.deserialize_property(cls.load_file_data_block_signature, stream, ctx)

class LoadFile(Object):
    dap_blocks: List[DAPBlockOfLoadFile] = Property(226, DAPBlockOfLoadFile, is_list=True, doc='DAP Block(s)')
    load_file_data_block: bytes = Property(196, bytes, doc='Load File Data Block')
    icv: bytes = Property(211, bytes, doc='ICV')
    ciphered_load_file_data_block: bytes = Property(211, bytes, doc='Ciphered Load File Data Block')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.dap_blocks, stream, ctx1)
            self.deserialize_property(cls.load_file_data_block, stream, ctx1)
            self.deserialize_property(cls.icv, stream, ctx1)
            self.deserialize_property(cls.ciphered_load_file_data_block, stream, ctx1)

@RequestPacketFactory.register(Instruction.LOAD)
class LoadPacket(APDURequestPacket):
    p1: LoadP1 = Property('P1', cls=LoadP1, display_order=2)
    p2: int = Property('P2', cls=int, doc='Block number', display_order=3)
    data: Union[bytes, LoadFile] = Property('Data', doc='Load data (and C-MAC if present).')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tag = stream.peek_int(1)
        pos = stream.tell()
        if tag in (226, 196, 211, 212):
            tlv_data = tlv.parse(stream, ctx.bytes_size)
            tlv_size = sum(map(lambda i: i.size, tlv_data))
            if tlv_data and tlv_size in (ctx.bytes_size, ctx.bytes_size - 8, ctx.bytes_size - 16):
                self.deserialize_property(cls.data, stream, ctx, cls=LoadFile)
                return
        stream.seek(pos, SEEK_SET)
        self.deserialize_property(cls.data, stream, ctx, cls=bytes)

@ResponsePacketFactory.register(Instruction.LOAD)
class LoadResponsePacket(APDUResponsePacket):
    load_confirmation_length: TLVLength = Property('Length of Load Confirmation', TLVLength)
    load_confirmation: Confirmations = Property('Load Confirmation', TLVLength)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.load_confirmation_length, stream, ctx)
        if self.load_confirmation_length:
            self.deserialize_property(cls.load_confirmation, stream, ctx)

@RequestPacketFactory.register(Instruction.MANAGE_CHANNEL)
class ManageChannelPacket(APDURequestPacket):
    p1: int = Property('P1', int, doc="'80' - Close the Supplementary Logical Channel identified in reference control parameter P2.\n'00' - Open the next available Supplementary Logical Channel.", display_order=2)
    p2: int = Property('P2', cls=int, doc='Supplementary Logical Channel', display_order=3)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize_lc(self, stream: BytesIO, ctx: SerializationContext):
        return

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        pass

@ResponsePacketFactory.register(Instruction.MANAGE_CHANNEL)
class ManageChannelResponsePacket(APDUResponsePacket):
    opened_supplementary_logical_channel: int = Property('Supplementary Logical Channel opened', int, length=1)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.opened_supplementary_logical_channel, stream, ctx)

class PutKeyP1(Object):
    pbf: int = Property('PBF', int, lsb=7, msb=7, doc='0: Last (or only) command. 1: More PUT KEY commands')
    key_version_number: int = Property('Key Version Number', int, lsb=0, msb=6)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.pbf, stream, ctx)
        self.deserialize_property(cls.key_version_number, stream, ctx)

class PutKeyP2(Object):
    key_type: int = Property('Key Type', int, lsb=7, msb=7, doc='0: Single key. 1: Multiple keys')
    key_identifier: int = Property('Key Identifier', int, lsb=0, msb=6)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_type, stream, ctx)
        self.deserialize_property(cls.key_identifier, stream, ctx)

class KeyComponent(Object):
    key_type: KeyType = Property('Key Type', KeyType)
    key_component_length: TLVLength = Property('Length of Key Component', TLVLength)
    key_value: bytes = Property('Key Value', bytes, doc='"Length (in bytes) of key component value + key component value" or "key component value"')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_type, stream, ctx)
        if self.key_type == 255:
            stream.seek(-1, SEEK_CUR)
            self.deserialize_property(cls.key_type, stream, ctx.clone(bytes_size=2))
        self.deserialize_property(cls.key_component_length, stream, ctx)
        if self.key_component_length:
            self.deserialize_property(cls.key_value, stream, ctx.clone(bytes_size=self.key_component_length))

class PutKeyData(Object):
    key_version_number: int = Property('Key Version Number', int, length=1)
    keys: List[KeyComponent] = Property('Key Components', KeyComponent, is_list=True)
    key_check_value_length: int = Property('Length of Key Check Value', int)
    key_check_value: bytes = Property('Key Check Value', bytes)
    Key_usage_qualifier_length: int = Property('Length of Key Usage Qualifier', int, length=1)
    Key_usage_qualifier: Union[KeyUsageQualifier1, KeyUsageQualifier2] = Property('Key Usage Qualifier')
    Key_access_length: int = Property('Length of Key Access', int, length=1)
    Key_access: KeyAccess = Property('Key Access', KeyAccess)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_version_number, stream, ctx)
        self.deserialize_property(cls.keys, stream, ctx=ctx.clone(array_has_next=lambda i: stream.peek_int() > 127))
        self.deserialize_property(cls.key_check_value_length, stream, ctx)
        if self.key_check_value_length:
            self.deserialize_property(cls.key_check_value, stream, ctx)
        self.deserialize_property(cls.Key_usage_qualifier_length, stream, ctx)
        if self.Key_usage_qualifier_length == 1:
            self.deserialize_property(cls.Key_usage_qualifier, stream, ctx, cls=KeyUsageQualifier1)
        elif self.Key_usage_qualifier_length == 2:
            self.deserialize_property(cls.Key_usage_qualifier, stream, ctx, cls=KeyUsageQualifier2)
        elif self.Key_usage_qualifier_length:
            self.deserialize_property(cls.Key_usage_qualifier, stream, ctx.clone(bytes_size=self.Key_usage_qualifier_length), cls=bytes)
        self.deserialize_property(cls.Key_access_length, stream, ctx)
        if self.Key_access_length == 1:
            self.deserialize_property(cls.Key_access, stream, ctx)
        elif self.Key_access_length:
            self.deserialize_property(cls.Key_access, stream, ctx.clone(bytes_size=self.Key_access_length), cls=bytes)

@RequestPacketFactory.register(Instruction.PUT_KEY)
class PutKeyPacket(APDURequestPacket):
    p1: PutKeyP1 = Property('P1', PutKeyP1, display_order=2)
    p2: PutKeyP2 = Property('P2', PutKeyP2, display_order=3)
    data: PutKeyData = Property('Data', PutKeyData)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, ctx)

@ResponsePacketFactory.register(Instruction.PUT_KEY)
class PutKeyResponsePacket(APDUResponsePacket):
    key_version_number: int = Property('Key Version Number', int, length=1)
    key_check_value: bytes = Property('Key Check Value', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_version_number, stream, ctx)
        self.deserialize_property(cls.key_check_value, stream, ctx)

class SecureInitializationP1(Object):
    major: int = Property('Major', int, lsb=4, msb=7, doc='Protocol Version')
    minor: int = Property('Minor', int, lsb=0, msb=3, doc='0: Broadcast Mode; 1: Unicast Mode.')

    def _deserialize(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.major, stream, ctx, peek=True)
        self.deserialize_property(cls.minor, stream, ctx)

class EncryptionConfiguration(IntEnum):
    NO_ENCRYPTION = (0, 'No encryption')
    AES_FOR_ENCRYPTION = (1, 'AES for encryption')
    AES_FOR_INTEGRITY = (2, 'AES for integrity')
    SM4_FOR_ENCRYPTION = (3, 'SM4 for encryption')
    SM4_FOR_INTEGRITY = (4, 'SM4 for integrity')

class AuthenticationConfiguration(IntEnum):
    NO_AUTHENTICATION = (0, 'No authentication')
    AES_FOR_AUTHENTICATION = (1, 'AES for authentication')
    SM2_FOR_AUTHENTICATION = (2, 'SM2 for authentication')
    SM9_FOR_AUTHENTICATION = (3, 'SM9 for authentication')
    SM4_FOR_AUTHENTICATION = (4, 'SM4 for authentication')

class SecureInitializationP2(Object):
    value: int = 0
    encryption_configuration: EncryptionConfiguration = Property('Encryption Configuration', EncryptionConfiguration, lsb=0, msb=3)
    authentication_configuration: AuthenticationConfiguration = Property('Authentication Configuration', AuthenticationConfiguration, lsb=4, msb=7)

    def _deserialize(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.value = stream.peek_int(1)
        self.deserialize_property(cls.encryption_configuration, stream, ctx, peek=True)
        self.deserialize_property(cls.authentication_configuration, stream, ctx)

@RequestPacketFactory.register(Instruction.SECURE_INITIALIZATION)
class SecureInitializationPacket(APDURequestPacket):
    p1: SecureInitializationP1 = Property('P1', SecureInitializationP1, display_order=2)
    p2: SecureInitializationP2 = Property('P2', SecureInitializationP2, display_order=3)
    key_id_auth: int = Property('KEY_ID_AUTH', int, length=2)
    key_id_enc: int = Property('KEY_ID_ENC', int, length=2)
    cnt: int = Property('CNT', int, length=2)
    ivr: bytes = Property('IVR', bytes, length=16)
    ct0: bytes = Property('CT₀', bytes, length=64)
    macr: bytes = Property('MAC-R', bytes)
    pk_server_aut_sm2: bytes = Property('PK.SERVER.AUT.SM2', bytes, length=64)
    sign_pk_server: bytes = Property('SIGN.PK.SERVER', bytes, length=64)
    s: bytes = Property('S', bytes, length=64)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_id_auth, stream, ctx)
        self.deserialize_property(cls.key_id_enc, stream, ctx)
        if self.p2.value in 0:
            self.deserialize_property(cls.cnt, stream, ctx)
        if self.p2.value in (1, 2, 3, 4):
            self.deserialize_property(cls.ivr, stream, ctx)
            self.deserialize_property(cls.ct0, stream, ctx)
        if self.p2.value in (16, 64):
            self.deserialize_property(cls.ivr, stream, ctx)
            self.deserialize_property(cls.cnt, stream, ctx)
            self.deserialize_property(cls.macr, stream, ctx)
        if self.p2.value in 32:
            self.deserialize_property(cls.cnt, stream, ctx)
            self.deserialize_property(cls.pk_server_aut_sm2, stream, ctx)
            self.deserialize_property(cls.sign_pk_server, stream, ctx)
            self.deserialize_property(cls.s, stream, ctx)
        if self.p2.value in 48:
            self.deserialize_property(cls.cnt, stream, ctx)
            self.deserialize_property(cls.s, stream, ctx)
        if self.p2.value in (17, 18, 19, 20, 65, 66, 67, 68):
            self.deserialize_property(cls.ivr, stream, ctx)
            self.deserialize_property(cls.ct0, stream, ctx)
            self.deserialize_property(cls.macr, stream, ctx)
        if self.p2.value in (33, 34, 35, 36):
            self.deserialize_property(cls.ivr, stream, ctx)
            self.deserialize_property(cls.ct0, stream, ctx)
            self.deserialize_property(cls.pk_server_aut_sm2, stream, ctx)
            self.deserialize_property(cls.sign_pk_server, stream, ctx)
            self.deserialize_property(cls.s, stream, ctx)
        if self.p2.value in (49, 50, 51, 52):
            self.deserialize_property(cls.ivr, stream, ctx)
            self.deserialize_property(cls.ct0, stream, ctx)
            self.deserialize_property(cls.s, stream, ctx)

@ResponsePacketFactory.register(Instruction.SECURE_INITIALIZATION)
class SecureInitializationResponsePacket(APDUResponsePacket):
    pass

@RequestPacketFactory.register(Instruction.SECURE_PROTOCOL)
class SecureProtocolPacket(APDURequestPacket):
    p1: int = Property('P1', int, display_order=2, doc='0: Broadcast Mode; 1: Unicast Mode.')
    p2: int = Property('P2', int, display_order=3, doc='80: means there is following COMMAND; 00: means there is no following COMMAND.')
    cipher_text: bytes = Property('Cipher Text', bytes)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        if self.p1 == 0:
            self.deserialize_property(cls.cipher_text, stream, ctx.clone(bytes_size=self.lc))
        if self.p1 == 1:
            self.deserialize_property(cls.cipher_text, stream, ctx.clone(bytes_size=self.lc - 16))
            self.deserialize_property(cls.c_mac, stream, ctx.clone(bytes_size=16))

@ResponsePacketFactory.register(Instruction.SECURE_PROTOCOL)
class SecureProtocolResponsePacket(APDUResponsePacket):
    pass

@RequestPacketFactory.register(Instruction.SECURE_UPDATE_KEY)
class SecureUpdateKeyPacket(APDURequestPacket):
    p1: int = Property('P1', int, display_order=2, doc='KEY_VERSION')
    p2: int = Property('P2', int, display_order=3)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

@ResponsePacketFactory.register(Instruction.SECURE_UPDATE_KEY)
class SecureUpdateKeyResponsePacket(APDUResponsePacket):
    pass

@RequestPacketFactory.register(Instruction.SECURE_GET_INFO)
class SecureGetInfoPacket(APDURequestPacket):
    pass

@ResponsePacketFactory.register(Instruction.SECURE_GET_INFO)
class SecureGetInfoResponsePacket(APDUResponsePacket):
    pass

class SelectP1(IntEnum):
    Select_MF_DF_EF = (0, 'Select MF, DF or EF')
    Select_child_DF = (1, 'Select child DF')
    Select_EF_under_the_DF_referenced_by_curDF = (2, 'Select EF under the DF referenced by curDF')
    Select_parent_DF_of_the_DF_referenced_by_curDF = (3, 'Select parent DF of the DF referenced by curDF')
    Select_by_DF_name = (4, 'Select by DF name')
    Select_from_the_MF = (8, 'Select from the MF')
    Select_from_the_DF_referenced_by_curDF = (9, 'Select from the DF referenced by curDF        ')
    Select_a_DO = (16, 'Select a DO in the template referenced by curConstructedDO')
    Select_parent_DO = (19, 'Select parent DO of the constructed DO setting the template referenced by curConstructedDO')

class SelectP2Occurrence(IntEnum):
    FIRST_OR_ONLY_OCCURRENCE = (0, 'First or only occurrence')
    LAST_OCCURRENCE = (1, 'Last occurrence')
    NEXT_OCCURRENCE = (2, 'Next occurrence')
    PREVIOUS_OCCURRENCE = (3, 'Previous occurrence')

class SelectP2ResponseRequirement(IntEnum):
    RETURN_FCI_TEMPLATE = (0, 'Return FCI template, optional use of FCI tag and length')
    RETURN_CP_TEMPLATE = (1, 'Return CP template, mandatory use of CP tag and length')
    RETURN_FMD_TEMPLATE = (2, 'Return FMD template, mandatory use of FMD tag and length. Return the tags belonging to the template set by the selection of a constructed DO as a tag list')
    RETURN_DEPENDS_ON_LE = (3, 'No response data if Le field absent, or proprietary if Le field present')

class SelectP2(Object):
    occurrence: SelectP2Occurrence = Property('File or DO occurrence', SelectP2Occurrence, lsb=0, msb=1)
    response_data_field_requirements = Property('Response data field requirements', SelectP2ResponseRequirement, lsb=2, msb=3)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.occurrence, stream, ctx, True)
        self.deserialize_property(cls.response_data_field_requirements, stream, ctx)

@RequestPacketFactory.register(Instruction.SELECT)
class SelectPacket(APDURequestPacket):
    p1: SelectP1 = Property('P1', SelectP1, display_order=2)
    p2: SelectP2 = Property('P2', SelectP2, display_order=3)
    data: bytes = Property('Data', bytes, doc='AID of Application to be selected')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, ctx)

class OID(Object):
    tag_06: bytes = Property(6, bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_06, stream, ctx)

class SecurityDomainManagementData(Object):
    tag_06: bytes = Property(6, bytes, doc='{globalPlatform 1} OID for Card Recognition Data, also identifies GlobalPlatform as the Tag Allocation Authority Mandatory')
    tag_60: OID = Property(96, OID, doc='{globalPlatform 2 v} OID for Card Management Type and Version Optional')
    tag_63: OID = Property(99, OID, doc='{globalPlatform 3} OID for Card Identification Scheme Optional')
    tag_64: Union[OID, List[OID]] = Property(100, OID, doc='{globalPlatform 4 scp i} OID for Secure Channel Protocol of the Security Domain and its implementation options Optional')
    tag_65: bytes = Property(101, bytes, doc='Card configuration details Optional')
    tag_66: bytes = Property(102, bytes, doc='Card / chip details Optional')
    tag_67: bytes = Property(103, bytes, doc='Security Domain’s Trust Point certificate information Optional')
    tag_68: bytes = Property(104, bytes, doc='Security Domain certificate information Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag_06, stream, ctx)
        self.deserialize_property(cls.tag_60, stream, ctx)
        self.deserialize_property(cls.tag_63, stream, ctx)
        self.deserialize_property(cls.tag_64, stream, ctx)
        self.deserialize_property(cls.tag_65, stream, ctx)
        self.deserialize_property(cls.tag_66, stream, ctx)
        self.deserialize_property(cls.tag_67, stream, ctx)
        self.deserialize_property(cls.tag_68, stream, ctx)

class FCIProprietaryData(Object):
    security_domain_management_data: SecurityDomainManagementData = Property(115, SecurityDomainManagementData, doc='Security Domain Management Data (see section H.3 for detailed coding) Optional')
    application_production_life_cycle_data: bytes = Property(40814, bytes, doc='Application production Life Cycle data Optional')
    maximum_length_of_data_field_in_command_message: int = Property(40805, int, doc='Maximum length of data field in command message Mandatory')
    issuer_discretionary_data: bytes = Property(48908, bytes, doc='Issuer Discretionary Data')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.security_domain_management_data, stream, ctx)
        self.deserialize_property(cls.application_production_life_cycle_data, stream, ctx)
        self.deserialize_property(cls.maximum_length_of_data_field_in_command_message, stream, ctx)
        self.deserialize_property(cls.issuer_discretionary_data, stream, ctx)

class FileControlInformation(Object):
    aid: bytes = Property(132, bytes, doc='Application / file AID, Mandatory')
    proprietary_data: FCIProprietaryData = Property(165, FCIProprietaryData, doc='Application / file AID, Mandatory')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.aid, stream, ctx)
        self.deserialize_property(cls.proprietary_data, stream, ctx)

class InternalInformationForSelect(Object):
    rom_version: bytes = Property('Rom Version', bytes, length=2)
    cos_version: bytes = Property('Cos Version', bytes, length=2)
    patch_version: bytes = Property('Patch Version', bytes, length=2)
    se_root_version: bytes = Property('SE Root Version', bytes, length=2)
    mls_rom_version: bytes = Property('MLS ROM Version', bytes, length=1)
    mls_opt_version: bytes = Property('MLS OPT Version', bytes, length=1)
    mls_ram_version: bytes = Property('MLS RAM Version', bytes, length=4)
    proprietary_data: bytes = Property('Proprietary Data', bytes, doc='Proprietary Data for internal using.')

    def _deserialize(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        data_len = ctx.bytes_size
        if ctx.bytes_size == 81:
            self.deserialize_property(cls.rom_version, stream, ctx)
            self.deserialize_property(cls.cos_version, stream, ctx)
            self.deserialize_property(cls.patch_version, stream, ctx)
            self.deserialize_property(cls.se_root_version, stream, ctx)
            self.deserialize_property(cls.mls_rom_version, stream, ctx)
            self.deserialize_property(cls.mls_opt_version, stream, ctx)
            self.deserialize_property(cls.mls_ram_version, stream, ctx)
            data_len -= 14
        self.deserialize_property(cls.proprietary_data, stream, ctx.clone(bytes_size=data_len))

@ResponsePacketFactory.register(Instruction.SELECT)
class SelectResponsePacket(APDUResponsePacket):
    fci: FileControlInformation = Property(111, FileControlInformation, doc='File Control Information')
    proprietary_data: InternalInformationForSelect = Property('Proprietary Data', InternalInformationForSelect, doc='Proprietary Data for internal using.')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        pos = stream.tell()
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data and tlv_data[0].tag.value == 111:
            ctx1 = ctx.clone(tlv_value=tlv_data)
            self.deserialize_property(cls.fci, stream, ctx=ctx1)
        else:
            stream.seek(pos, SEEK_SET)
            self.deserialize_property(cls.proprietary_data, stream, ctx)

class SetStatusType(IntEnum):
    ISSUER_SECURITY_DOMAIN = (128, 'Indicate Issuer Security Domain')
    APPLICATION_OR_SUPPLEMENTARY_SECURITY_DOMAIN = (64, 'Indicate Application or Supplementary Security Domain')
    SECURITY_DOMAIN_AND_ITS_ASSOCIATED_APPLICATIONS = (96, 'Indicate Security Domain and its associated Applications')

@RequestPacketFactory.register(Instruction.SET_STATUS)
class SetStatusPacket(APDURequestPacket):
    p1: SetStatusType = Property('P1', SetStatusType, length=1, display_order=2)
    p2: Union[ApplicationLifeCycleCoding, SecurityDomainLifeCycleCoding, CardLifeCycleCoding, int] = Property('P2', length=1, display_order=3)
    aid: bytes = Property('AID', bytes, doc="The data field shall contain the AID of the target Application or Security Domain for which a Life Cycle change is requested. The on-card entity receiving the command shall be directly or indirectly associated with this target Application or Security Domain or shall have the relevant privilege. If reference control parameter P1 is '80' the content of the command data field shall be ignored. If the command relates to a Security Domain and all its associated Applications, the data field shall contain the AID of the Security Domain.")

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        if self.p1 == SetStatusType.ISSUER_SECURITY_DOMAIN:
            self.deserialize_property(cls.p2, stream, ctx, cls=CardLifeCycleCoding)
        elif self.p1 == SetStatusType.APPLICATION_OR_SUPPLEMENTARY_SECURITY_DOMAIN:
            self.deserialize_property(cls.p2, stream, ctx, cls=SecurityDomainLifeCycleCoding)
        elif self.p1 == SetStatusType.SECURITY_DOMAIN_AND_ITS_ASSOCIATED_APPLICATIONS:
            self.deserialize_property(cls.p2, stream, ctx, cls=ApplicationLifeCycleCoding)
        else:
            self.deserialize_property(cls.p2, stream, ctx, cls=int)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.aid, stream, ctx)

@ResponsePacketFactory.register(Instruction.SET_STATUS)
class SetStatusResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

class DGITag(IntEnum):
    DGI_00B9 = (185, 'DGI CRT Tag')
    DGI_0010 = (16, 'Key Modulus')
    DGI_0011 = (17, 'RSA Public Key Exponent')
    DGI_8112 = (33042, 'RSA Private Key Exponent')
    DGI_8121 = (33057, 'RSA CRT constant q-1 mod p')
    DGI_8122 = (33058, 'RSA CRT constant d mod (q - 1)')
    DGI_8123 = (33059, 'RSA CRT constant d mod (p - 1)')
    DGI_8124 = (33060, 'RSA CRT constant prime factor q')
    DGI_8125 = (33061, 'RSA CRT constant prime factor p')
    DGI_8113 = (33043, 'Secret Key for Symmetric Scheme')
    DGI_0030 = (48, 'ECC P (field specification) Mandatory')
    DGI_0031 = (49, 'ECC A (first coefficient) Mandatory')
    DGI_0032 = (50, 'ECC B (second coefficient) Mandatory')
    DGI_0033 = (51, 'ECC G (generator) Mandatory')
    DGI_0034 = (52, 'ECC N (order of generator) Mandatory')
    DGI_0035 = (53, 'ECC k (cofactor of order of generator); default value "01" Optional')
    DGI_8137 = (33079, 'ECC d (private key)')

class DGIObject(Object):
    tag: DGITag = Property('Tag', DGITag, length=2)
    length: int = Property('Length', int)
    value: bytes = Property('Value', bytes)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.tag, stream, ctx)
        self.deserialize_property(cls.length, stream, ctx)
        if self.length == 255:
            self.deserialize_property(cls.length, stream, ctx=ctx.clone(bytes_size=2))
        if self.length:
            self.deserialize_value(stream, ctx=ctx.clone(bytes_size=self.length))

    def _deserialize_value(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        if self.length:
            self.deserialize_property(cls.value, stream, ctx=ctx.clone(bytes_size=self.length))

class ControlReferenceTemplate(Object):
    key_usage_qualifier: Union[KeyUsageQualifier1, KeyUsageQualifier2] = Property(149, doc='Key Usage Qualifier values according to section 11.1.9 Mandatory')
    key_access: KeyAccess = Property(150, KeyAccess, doc='Key Access according to section 11.1.10 Optional')
    key_type: KeyType = Property(128, KeyType, doc='Key Type according to section 11.1.8 Mandatory')
    key_length: int = Property(129, int, doc='Key Length, in bytes (unsigned integer value) Mandatory')
    key_identifier: int = Property(130, int, doc='Key Identifier Mandatory')
    key_version_number: int = Property(131, int, doc='Key Version Number Mandatory')
    key_check_value: int = Property(132, int, doc='Key check value Mandatory')
    key_parameter_reference_value: ECCCurveType = Property(133, ECCCurveType, doc='ECC Curve Type')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_usage_qualifier, stream, ctx)
        self.deserialize_property(cls.key_access, stream, ctx)
        self.deserialize_property(cls.key_type, stream, ctx)
        self.deserialize_property(cls.key_length, stream, ctx)
        self.deserialize_property(cls.key_identifier, stream, ctx)
        self.deserialize_property(cls.key_version_number, stream, ctx)
        self.deserialize_property(cls.key_check_value, stream, ctx)

class DataContentForDGI00B9(DGIObject):
    crts: List[ControlReferenceTemplate] = Property(185, ControlReferenceTemplate, is_list=True, doc='Control Reference Template')

    def _deserialize_value(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            self.deserialize_property(cls.crts, stream, ctx=ctx.clone(tlv_value=tlv_data))

class DGIForEncryption(Object):
    dgi_00B9: DataContentForDGI00B9 = Property('Data Content for DGI00B9', DataContentForDGI00B9)
    dgi_keys: List[DGIObject] = Property('Keys', DGIObject, is_list=True)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        if stream.peek_int(2, 'big') != 185:
            raise Exception(f'Bad DGI Tag at {stream.tell()}')
        self.deserialize_property(cls.dgi_00B9, stream, ctx)
        self.deserialize_property(cls.dgi_keys, stream, ctx.clone(array_has_next=lambda i: stream.peek_int(2, 'big') in DGITag))

class StoreDataEncryptionType(IntEnum):
    NO_GENERAL_ENCRYPTION_INFORMATION_OR_NON_ENCRYPTED_DATA = (0, 'No general encryption information or non-encrypted data')
    APPLICATION_DEPENDENT_ENCRYPTION_OF_THE_DATA = (1, 'Application dependent encryption of the data')
    RFU = (2, 'RFU (encryption indicator)')
    ENCRYPTED_DATA = (3, 'Encrypted data')

class StoreDataDataStructureType(IntEnum):
    NO_GENERAL_DATA_STRUCTURE_INFORMATION = (0, 'No general data structure information')
    DGI_FORMAT = (1, 'DGI format of the command data field')
    TLV_FORMAT = (2, 'BER-TLV format of the command data field')
    RFU = (3, 'RFU (data structure information)')

class StoreDataP1(Object):
    pbf: int = Property('PBF', int, lsb=7, msb=7, doc='0: More blocks. 1: Last block.')
    encryption_type: StoreDataEncryptionType = Property('Encryption Type', StoreDataEncryptionType, lsb=5, msb=6)
    data_structure_type: StoreDataDataStructureType = Property('Data Structure Type', StoreDataDataStructureType, lsb=3, msb=4)
    response_type: int = Property('Response Type', StoreDataDataStructureType, lsb=0, msb=0, doc='0: ISO case 3 command (no response data expected); 1: ISO case 4 command (response data may be returned)')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.pbf, stream, ctx, True)
        self.deserialize_property(cls.encryption_type, stream, ctx, True)
        self.deserialize_property(cls.data_structure_type, stream, ctx, True)
        self.deserialize_property(cls.response_type, stream, ctx)

@RequestPacketFactory.register(Instruction.STORE_DATA)
class StoreDataPacket(APDURequestPacket):
    p1: StoreDataP1 = Property('P1', StoreDataP1, length=1, display_order=2)
    p2: int = Property('P2', int, length=1, doc='Block Number', display_order=3)
    data: Union[bytes, DGIForEncryption, List[TLVObject]] = Property('Data', doc='Data structure depends on Data Structure Type of P1.')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        if self.p1.data_structure_type == StoreDataDataStructureType.DGI_FORMAT:
            self.deserialize_property(cls.data, stream, ctx, cls=DGIForEncryption)
        elif self.p1.data_structure_type == StoreDataDataStructureType.TLV_FORMAT:
            pos = stream.tell()
            tlv_data = tlv.parse(stream, ctx.bytes_size)
            if tlv_data:
                stream.seek(pos, SEEK_SET)
                self.deserialize_property(cls.data, stream, ctx.clone(tlv_value=tlv_data), cls=TLVObject, is_list=True)
        else:
            self.deserialize_property(cls.data, stream, ctx, cls=bytes)

@ResponsePacketFactory.register(Instruction.STORE_DATA)
class StoreDataResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@RequestPacketFactory.register(Instruction.INITIALIZE_UPDATE)
class InitializeUpdatePacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc='The Key Version Number defines the Key Version Number within the Security Domain to be used to initiate the Secure Channel Session. If this value is zero, the first available key chosen by the Security Domain will be used.', display_order=2)
    p2: int = Property('P2', int, length=1, doc="The reference control parameter P2 shall always be set to '00'.", display_order=3)
    data: bytes = Property('Data', bytes, doc='Host challenge.')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, ctx)

@ResponsePacketFactory.register(Instruction.INITIALIZE_UPDATE)
class InitializeUpdateResponsePacket(APDUResponsePacket):
    key_diversification_data: bytes = Property('Key diversification data ', bytes, length=10)
    key_information: bytes = Property('Key information', bytes, length=2)
    sequence_counter: bytes = Property('Sequence Counter', bytes, length=2)
    card_challenge: bytes = Property('Card challenge', bytes, length=6)
    card_cryptogram: bytes = Property('Card cryptogram', bytes, length=8)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.key_diversification_data, stream, ctx)
        self.deserialize_property(cls.key_information, stream, ctx)
        self.deserialize_property(cls.sequence_counter, stream, ctx)
        self.deserialize_property(cls.card_challenge, stream, ctx)
        self.deserialize_property(cls.card_cryptogram, stream, ctx)

@RequestPacketFactory.register(Instruction.EXTERNAL_AUTHENTICATE)
class ExternalAuthenticatePacket(APDURequestPacket):
    p1: Union[SecurityLevel, int] = Property('P1', SecurityLevel, length=1, display_order=2)
    p2: int = Property('P2', int, length=1, doc="The reference control parameter P2 shall always be set to '00'.", display_order=3)
    data_for_scp02: bytes = Property('Data(SCP02)', bytes, doc='Host cryptogram and MAC.')
    data_for_scp10: bytes = Property('Data(SCP10)', bytes, doc='The data field of the EXTERNAL AUTHENTICATE command message contains the Off-Card Entity Signature(key transport) or encrypted Off-Card Entity Signature (key agreement) - see section F.1.4.4, Off-Card Entity Authentication, for further details.')

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        cla = self.cla.value
        if cla >= 132 and cla <= 135 or (cla >= 224 and cla <= 239):
            self.deserialize_property(cls.data_for_scp02, stream, ctx)
        if cla >= 0 and cla <= 3 or (cla >= 64 and cla <= 79) or (cla >= 16 and cla <= 19) or (cla >= 80 and cla <= 95):
            self.deserialize_property(cls.data_for_scp10, stream, ctx)

@ResponsePacketFactory.register(Instruction.EXTERNAL_AUTHENTICATE)
class ExternalAuthenticateResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@RequestPacketFactory.register(Instruction.BEGIN_RMAC_SESSION)
class BeginRMACSessionPacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc="When P1 is set to '10' each APDU response message during the R-MAC session includes a R-MAC. When P1 is set to '00' only the END R-MAC SESSION response message will contain a R-MAC", display_order=2)
    p2: int = Property('P2', int, length=1, doc="'01': Begin R-MAC session.", display_order=3)
    data_length: int = Property('Length of Data', int, doc='Length of Data.')
    data: bytes = Property('Data', bytes)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data_length, stream, ctx)
        if self.data_length:
            self.deserialize_property(cls.data, stream, ctx.clone(bytes_size=self.data_length))

@ResponsePacketFactory.register(Instruction.BEGIN_RMAC_SESSION)
class BeginRMACSessionResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@RequestPacketFactory.register(Instruction.END_RMAC_SESSION)
class EndRMACSessionPacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc="Reference control parameter P1 shall always be set to '00'", display_order=2)
    p2: int = Property('P2', int, length=1, doc="'01': Return R-MAC. 03: End R-MAC session & return R-MAC", display_order=3)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@ResponsePacketFactory.register(Instruction.END_RMAC_SESSION)
class EndRMACSessionResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@RequestPacketFactory.register(Instruction.GET_CHALLENGE)
class GetChallengePacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc="Reference control parameter P1 shall always be set to '00'", display_order=2)
    p2: int = Property('P2', int, length=1, doc="'01': Return R-MAC. 03: End R-MAC session & return R-MAC", display_order=3)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@ResponsePacketFactory.register(Instruction.GET_CHALLENGE)
class GetChallengeResponsePacket(APDUResponsePacket):
    data: bytes = Property('Data', bytes, doc='Data returned comprises a card challenge, coded on 8 bytes with the key agreement option and 16 bytes with the key transport option.')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, ctx)

@RequestPacketFactory.register(Instruction.GET_CHALLENGE)
class GetChallengePacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc="Reference control parameter P1 shall always be set to '00'", display_order=2)
    p2: int = Property('P2', int, length=1, doc="'01': Return R-MAC. 03: End R-MAC session & return R-MAC", display_order=3)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@ResponsePacketFactory.register(Instruction.GET_CHALLENGE)
class GetChallengeResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@RequestPacketFactory.register(Instruction.INTERNAL_AUTHENTICATE)
class InternalAuthenticatePacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc="Reference control parameter P1 shall always be set to '00'", display_order=2)
    p2: int = Property('P2', int, length=1, doc="'01': Return R-MAC. 03: End R-MAC session & return R-MAC", display_order=3)
    off_card_entity_challenge: bytes = Property('Off-Card Entity challenge', bytes)
    off_card_entity_id: bytes = Property('Off-Card Entity id', bytes)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        if self.lc:
            pos_cur = stream.tell()
            stream.seek(-8, SEEK_END)
            challenge_begin = stream.tell()
            self.deserialize_property(cls.off_card_entity_id, stream, ctx.clone(bytes_size=8))
            challenge_end = stream.tell()
            stream.seek(pos_cur, SEEK_SET)
            self.deserialize_property(cls.off_card_entity_challenge, stream, ctx.clone(bytes_size=challenge_begin - pos_cur))
            stream.seek(challenge_end, SEEK_SET)

@ResponsePacketFactory.register(Instruction.INTERNAL_AUTHENTICATE)
class InternalAuthenticateResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

class ManageSecurityEnvironmentP1(IntEnum):
    STORE = (242, 'store')
    RESTORE = (243, 'restore')
    RESET = (247, 'reset')
    ERASE = (244, 'erase')
    GET_CRT = (8, 'get crt')
    GET_SE = (0, 'get se')

    @staticmethod
    def __get_missing_value__(value: int):
        doc = []
        if value & 15 == 1:
            if value & 128 == 128:
                doc.append('Verification, encipherment, external authentication and key agreement')
            if value & 64 == 64:
                doc.append('Computation, decipherment, internal authentication and key agreement')
            if value & 32 == 32:
                doc.append('Secure messaging in response data field')
            if value & 16 == 32:
                doc.append('Secure messaging in command data field')
            return Int(value, doc='SET: ' + '; '.join(doc))
        return Int(value, doc='RFU')

class ParameterI(IntEnum):
    KEY_TRANSPORT_SIGNATURE_WITH_MESSAGE_RECOVERY = (0, 'Key Transport + Signature with message recovery')
    KEY_TRANSPORT_SIGNATURE_WITHOUT_MESSAGE_RECOVERY = (2, 'Key Transport + Signature without message recovery')
    KEY_AGREEMENT_SIGNATURE_WITH_MESSAGE_RECOVERY = (1, 'Key Agreement + Signature with message recovery')
    KEY_AGREEMENT_SIGNATURE_WITHOUT_MESSAGE_RECOVERY = (3, 'Key Agreement + Signature without message recovery')

class CryptographicMechanismReference(Object):
    scp_id: int = Property('SCP ID', int)
    parameter_i: ParameterI = Property('Parameter "i"', ParameterI)

class ManageSecurityEnvironmentData(Object):
    cryptographic_mechanism_reference: CryptographicMechanismReference = Property(128, CryptographicMechanismReference, doc='Cryptographic mechanism reference: SCP id + options “i” (= scp || i ) Mandatory')
    public_key_reference: bytes = Property(129, bytes, doc='Public key reference Conditional')
    private_key_reference: bytes = Property(130, bytes, doc='Private key reference Conditional')

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.cryptographic_mechanism_reference, stream, ctx)
        self.deserialize_property(cls.public_key_reference, stream, ctx)
        self.deserialize_property(cls.private_key_reference, stream, ctx)

@RequestPacketFactory.register(Instruction.MANAGE_SECURITY_ENVIRONMENT)
class ManageSecurityEnvironmentPacket(APDURequestPacket):
    p1: ManageSecurityEnvironmentP1 = Property('P1', ManageSecurityEnvironmentP1, length=1, display_order=2)
    p2: int = Property('P2', int, length=1, doc="'A4': Authentication: no certificate verification will be performed by the card; 'B6': Digital signature: certificate verification will be performed by the card", display_order=3)
    data: ManageSecurityEnvironmentData = Property('Off-Card Entity data', ManageSecurityEnvironmentData)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__
        tlv_data = tlv.parse(stream, ctx.bytes_size)
        if tlv_data:
            self.deserialize_property(cls.data, ctx.clone(tlv_value=tlv_data))

@ResponsePacketFactory.register(Instruction.MANAGE_SECURITY_ENVIRONMENT)
class ManageSecurityEnvironmentResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@RequestPacketFactory.register(Instruction.PERFORM_SECURITY_OPERATION)
class PerformSecurityOperationPacket(APDURequestPacket):
    p1: int = Property('P1', int, length=1, doc="[decipher]: '80' Reference Control Parameter P1: clear text object; [verify certificate]: no object in the response", display_order=2)
    p2: int = Property('P2', int, length=1, doc="[decipher]: '84' cryptogram (plain value encoded in BER-TLV) present in the command; [verify certificate]: 'AE': non-self descriptive card verifiable certificate (only the concatenated value fields are certified). 'BE': self-descriptive card verifiable certificate (the TLV data elements are certified)", display_order=3)
    encrypted_data: bytes = Property('Encrypted Data', bytes)
    certificate_data: bytes = Property('Certificate Data', bytes)

    def _deserialize_p1p2(self, stream: BytesIO, ctx: SerializationContext):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream, ctx)
        self.deserialize_property(cls.p2, stream, ctx)

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

@ResponsePacketFactory.register(Instruction.PERFORM_SECURITY_OPERATION)
class PerformSecurityOperationResponsePacket(APDUResponsePacket):

    def _deserialize(self, stream: BytesIO, ctx: APDUSerializationContext):
        cls = self.__class__

def is_apdu_request(stream: BytesIO):
    pos_begin = stream.tell()
    length = stream.length - pos_begin
    if length < 5 or length == 6:
        return False
    try:
        head_length = 5
        head = stream.peek(7)
        ins = head[1]
        lc = head[4]
        if lc == 0 and length >= 7:
            lc = int.from_bytes(head[5:7], 'big')
            if not lc:
                return False
            head_length = 7
        if length != head_length + lc:
            return False
        return Instruction.contains(ins)
    except:
        pass
    return False

def is_apdu_response(stream: BytesIO):
    if stream.length < 2:
        return False
    offset = 0
    head = stream.peek(3)
    if head[0] == 3 and int.from_bytes(head[1:], 'big') == stream.length - 3:
        return False
    if head[0] == 4 and int.from_bytes(head[1:], 'big') == stream.length - 3:
        offset = 3
    if StatusCode.contains(stream.peek_int(2, 'big', -2, SEEK_END)):
        if offset:
            stream.seek(offset, SEEK_CUR)
        return True
    return False

def is_valid_packet(data: Union[str, bytes, BytesIO]) -> bool:
    stream = BytesIO.create(data)
    return is_apdu_request(stream) or is_apdu_response(stream)

def parse_packet(data: Union[str, bytes, BytesIO], session: SessionContext=None) -> Object:
    stream = BytesIO.create(data)
    if is_apdu_request(stream):
        return APDURequestPacket.from_stream(stream, session)
    if is_apdu_response(stream):
        return APDUResponsePacket.from_stream(stream, session)
    return None

def test():
    apdu = [(Instruction.GET_DATA_CA, '84CA5F50089A760342C05FD970', '6A88'), (Instruction.GET_DATA_CA, '84CA00C208989479353AA0F059', 'C20200009000'), (Instruction.GET_DATA_CA, '84CA00C1082D15E7206283FDDB', 'C10200359000'), (Instruction.GET_DATA_CA, '84CA7F21088C6E0BA96DBEB13F', '6A88'), (Instruction.GET_DATA_CA, '84CA5031080DF6C2E82E55DD1E', '6A88')]
    session = SessionContext()
    for (ins, req, rsp) in apdu:
        req_pkt = APDURequestPacket.from_stream(req, session)
        rsp_pkt = APDUResponsePacket.from_stream(rsp, req_pkt.ins, session)
        pass