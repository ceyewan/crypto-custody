import os
import re
from typing import Dict, List, Type, Union
from enum import IntEnum, IntFlag
from zipfile import ZipFile
from ...base.common import BytesIO, int_to_bytes, first
from .apdu import CommandAPDU, Instruction, InstallP1Coding

class ComponentType(IntEnum):
    Header = 1
    Directory = 2
    Applet = 3
    Import = 4
    ConstantPool = 5
    Class = 6
    Method = 7
    StaticField = 8
    ReferenceLocation = 9
    Export = 10
    Descriptor = 11
    Debug = 12
    StaticResources = 13
ComponentFileNames = {ComponentType.Header: 'Header.cap', ComponentType.Directory: 'Directory.cap', ComponentType.Applet: 'Applet.cap', ComponentType.Import: 'Import.cap', ComponentType.ConstantPool: 'ConstantPool.cap', ComponentType.Class: 'Class.cap', ComponentType.Method: 'Method.capx?', ComponentType.StaticField: 'StaticField.cap', ComponentType.ReferenceLocation: 'RefLocation.capx?', ComponentType.Export: 'Export.cap', ComponentType.Descriptor: 'Descriptor.capx?', ComponentType.Debug: 'Debug.capx?', ComponentType.StaticResources: 'StaticResources.capx'}

class CapFileFlags(IntFlag):
    ACC_INT = 1
    ACC_EXPORT = 2
    ACC_APPLET = 4
    ACC_EXTENDED = 8

    def to_str(self):
        return ' | '.join([flag.name for flag in CapFileFlags if self & flag])

class PackageInfo:
    minor_version: int
    major_version: int
    aid: bytes
    name: str

    def read_package_info(self, s: BytesIO):
        self.minor_version = s.read_int(1)
        self.major_version = s.read_int(1)
        self.aid = s.read(s.read_int(1))
        return self

    def read_package_name_info(self, s: BytesIO):
        self.name = s.read(s.read_int(1)).decode('utf8')
        return self

class Component:
    tag: ComponentType
    size: int

    def __init__(self) -> None:
        pass

    def from_bytes(self, s: BytesIO, is_extended: bool):
        self.tag = s.read_int(1)
        self.size = s.read_int(2, 'big')
        return self

class HeaderComponent(Component):
    flags: CapFileFlags
    cap_format_minor_version: int
    cap_format_major_version: int
    cap_minor_version: int
    cap_major_version: int
    cap_aid: bytes
    packages: List[PackageInfo]

    def __init__(self) -> None:
        super().__init__()

    @property
    def is_extended(self) -> bool:
        return CapFileFlags.ACC_EXTENDED in self.flags

    def from_bytes(self, s: BytesIO):
        super().from_bytes(s, None)
        s.read(4)
        self.cap_format_minor_version = s.read_int(1)
        self.cap_format_major_version = s.read_int(1)
        self.flags = CapFileFlags(s.read_int(1))
        self.packages = []
        if self.is_extended:
            self.cap_minor_version = s.read_int(1)
            self.cap_major_version = s.read_int(1)
            self.cap_aid = s.read(s.read_int(1))
            pkg_count = s.read_int(1)
            for _ in range(pkg_count):
                package = PackageInfo()
                package.read_package_info(s)
                self.packages.append(package)
            for package in self.packages:
                package.read_package_name_info(s)
        else:
            package = PackageInfo().read_package_info(s).read_package_name_info(s)
            self.packages.append(package)
            self.cap_aid = package.aid
        return self

class Applet:
    aid: bytes = None
    install_method_component_block_index: int = None
    install_method_offset: int = None

    def from_bytes(self, s: BytesIO, is_extended: bool):
        self.aid = s.read(s.read_byte())
        if is_extended:
            self.install_method_component_block_index = s.read_byte()
        self.install_method_offset = s.read_int(2, 'big')
        return self

class AppletComponent(Component):
    applets: List[Applet] = []

    def __init__(self) -> None:
        super().__init__()

    @property
    def aids(self):
        return [a.aid for a in self.applets]

    def from_bytes(self, s: BytesIO, is_extended: bool):
        super().from_bytes(s, is_extended)
        self.applets = []
        for _ in range(s.read_byte()):
            self.applets.append(Applet().from_bytes(s, is_extended))
        return self
INSTALL_ORDER = [ComponentType.Header, ComponentType.Directory, ComponentType.Import, ComponentType.Applet, ComponentType.Class, ComponentType.Method, ComponentType.StaticField, ComponentType.Export, ComponentType.ConstantPool, ComponentType.ReferenceLocation, ComponentType.StaticResources, ComponentType.Descriptor]
INSTALL_ORDER_DEBUG = INSTALL_ORDER + [ComponentType.Debug]

class CapFile:
    header: HeaderComponent = None
    applet: AppletComponent = None
    __components_path: Dict[ComponentType, str]
    components: Dict[ComponentType, Component]

    def __init__(self, cap_file: str):
        self.__components_path = {}
        self.file = ZipFile(cap_file, 'r')
        self.filename = cap_file
        files = self.file.namelist()
        for (t, pattern) in ComponentFileNames.items():
            file = first(files, lambda f: bool(re.match(pattern, os.path.basename(f), re.I)))
            if file:
                self.__components_path[t] = file
                self.__components_path[t.value] = file
        component_type_map: Dict[ComponentType, Type[Component]] = {ComponentType.Header: HeaderComponent, ComponentType.Applet: AppletComponent}
        self.header = HeaderComponent().from_bytes(BytesIO(self.file.read(self.__components_path[ComponentType.Header])))
        self.components = {ComponentType.Header: self.header}
        for c in INSTALL_ORDER_DEBUG:
            if c != ComponentType.Header and c in self.__components_path:
                self.components[c] = component_type_map.get(c, Component)().from_bytes(BytesIO(self.file.read(self.__components_path[c])), self.header.is_extended)
        self.applet = self.components.get(ComponentType.Applet, None)

    @property
    def is_extended(self) -> bool:
        return self.header.is_extended

    @property
    def cap_aid(self):
        return self.header.cap_aid

    @property
    def package_aids(self):
        return [p.aid for p in self.header.packages] if self.header and self.header.packages else []

    @property
    def applet_aids(self):
        return self.applet.aids if self.applet else []

    def get_component(self, type: ComponentType):
        return self.__components_path

    def to_apdu_s_deprecated(self, payload_size: int=255, include_debug: bool=False) -> List[str]:
        install_order = [ComponentType.Header, ComponentType.Directory, ComponentType.Import, ComponentType.Applet, ComponentType.Class, ComponentType.Method, ComponentType.StaticField, ComponentType.Export, ComponentType.ConstantPool, ComponentType.ReferenceLocation, ComponentType.StaticResources, ComponentType.Descriptor]
        if include_debug:
            install_order.append(ComponentType.Debug)
        payload_size = payload_size if payload_size else 255
        assert isinstance(payload_size, int) and payload_size > 0 and (payload_size < 65536), f'Bad payload_size={payload_size}, require an integer between [1-65535].'
        s = BytesIO()
        for c in install_order:
            if c in self.__components_path:
                s.write(self.file.read(self.__components_path[c]))

        def to_asn1_length(v: int):
            b = int_to_bytes(v)
            if v <= 255:
                return b
            else:
                return bytes([128 + len(b)]) + b
        total_size = to_asn1_length(s.tell())
        s.seek(0)

        def to_payload_length(v: int):
            return int_to_bytes(v, 1 if v < 256 else 3, 'big')

        def build_apdu(header: str, payload: Union[bytes, str]) -> bytearray:
            payload = payload if isinstance(payload, (bytes, bytearray)) else bytearray.fromhex(payload)
            return bytearray.fromhex(header) + to_payload_length(len(payload)) + payload + bytes(1)
        block_id = 0
        apdu = [build_apdu('80E60200', f'{len(self.cap_aid):02X}{self.cap_aid.hex()}00000000')]
        apdu.append(build_apdu(f'80E800{block_id:02X}', bytes([196]) + total_size + s.read(payload_size - 1 - len(total_size))))
        while True:
            block_id += 1
            segment = s.read(payload_size)
            if not segment:
                break
            apdu.append(build_apdu(f'80E800{block_id & 255:02X}', segment))
        apdu[-1] = '80E880' + apdu[-1][6:]
        return apdu

    def to_apdu(self, payload_size: int=255, include_debug: bool=False, include_install_for_load: bool=True) -> List[CommandAPDU]:
        install_order = INSTALL_ORDER_DEBUG if include_debug else INSTALL_ORDER
        payload_size = payload_size if payload_size else 255
        assert isinstance(payload_size, int) and payload_size > 0 and (payload_size < 65536), f'Bad payload_size={payload_size}, require an integer between [1-65535].'
        stream = BytesIO()
        for c in install_order:
            if c in self.__components_path:
                stream.write(self.file.read(self.__components_path[c]))
        data = stream.getvalue()
        stream.truncate(0)
        stream.write_tlv(196, data)
        stream.seek(0)
        apdu = []
        if include_install_for_load:
            apdu.append(CommandAPDU(128, Instruction.INSTALL, InstallP1Coding.FOR_LOAD, 0, bytes([len(self.cap_aid)]) + self.cap_aid + bytes(4)))
        block_id = 0
        while not stream.at_end():
            apdu.append(CommandAPDU(128, Instruction.LOAD, 0, block_id & 255, stream.read(payload_size)))
            block_id += 1
        apdu[-1].p1 = 128
        return apdu

    def to_apdu_s(self, payload_size: int=255, include_debug: bool=False, include_install_for_load: bool=True) -> List[str]:
        return [hex(a.to_bytes()) for a in self.to_apdu(payload_size, include_debug, include_install_for_load)]

def cap_to_apdu(cap_file: str, payload_size: int=255, include_debug: bool=False, include_install_for_load: bool=True) -> List[CommandAPDU]:
    return CapFile(cap_file).to_apdu(payload_size, include_debug, include_install_for_load)

def cap_to_apdu_s(cap_file: str, payload_size: int=255, include_debug: bool=False, include_install_for_load: bool=True) -> List[str]:
    return CapFile(cap_file).to_apdu_s(payload_size, include_debug, include_install_for_load)
__all__ = [ComponentType.__name__, PackageInfo.__name__, Component.__name__, HeaderComponent.__name__, AppletComponent.__name__, CapFile.__name__, cap_to_apdu.__name__, cap_to_apdu_s.__name__]