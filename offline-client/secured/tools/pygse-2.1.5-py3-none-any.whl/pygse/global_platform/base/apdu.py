from abc import abstractmethod
from typing import Dict, List, Literal, Tuple, Type, Union
from ...base.common import IntEnum, IntFlag, BytesIO, Tlv, to_bytes
from ...base.common.object import ListType, Property, IntProperty, Object, TlvProperty

class Instruction(IntEnum):
    DEACTIVATE_FILE = 4
    ERASE_RECORDS = 12
    ERASE_BINARY_0E = 14
    ERASE_BINARY_0F = 15
    PERFORM_SCQL_OPERATION = 16
    PERFORM_TRANSACTION_OPERATION = 18
    PERFORM_USER_OPERATION = 20
    VERIFY_PIN = 32
    VERIFY_21 = 33
    MANAGE_SECURITY_ENVIRONMENT = 34
    CHANGE_REFERENCE_DATA = 36
    DISABLE_VERIFICATION_REQUIREMENT = 38
    ENABLE_VERIFICATION_REQUIREMENT = 40
    PERFORM_SECURITY_OPERATION = 42
    RESET_RETRY_COUNTER = 44
    ACTIVATE_FILE = 68
    GENERATE_ASYMMETRIC_KEY_PAIR = 70
    INITIALIZE_UPDATE = 80
    MANAGE_CHANNEL = 112
    END_RMAC_SESSION = 120
    BEGIN_RMAC_SESSION = 122
    EXTERNAL_AUTHENTICATE = 130
    GET_CHALLENGE = 132
    GENERAL_AUTHENTICATE_86 = 134
    GENERAL_AUTHENTICATE_87 = 135
    INTERNAL_AUTHENTICATE = 136
    SECURE_INITIALIZATION = 160
    SECURE_PROTOCOL = 161
    SECURE_UPDATE_KEY = 162
    SECURE_GET_INFO = 163
    SELECT = 164
    READ_BINARY_B0 = 176
    READ_BINARY_B1 = 177
    READ_RECORDS_B2 = 178
    READ_RECORDS_B3 = 179
    GET_RESPONSE = 192
    ENVELOPE_C2 = 194
    ENVELOPE_C3 = 195
    GET_DATA_CA = (202, "GET_DATA. If CLA = '00' - '0F', '40' - '4F', or '60' - '6F', even or odd instruction code 'CA' or 'CB'.\nIf CLA = '80' - '8F', 'C0' - 'CF', or 'E0' - 'EF', even instruction code 'CA'")
    GET_DATA_CB = (203, "GET_DATA. If CLA = '00' - '0F', '40' - '4F', or '60' - '6F', even or odd instruction code 'CA' or 'CB'.\nIf CLA = '80' - '8F', 'C0' - 'CF', or 'E0' - 'EF', even instruction code 'CA'")
    WRITE_BINARY_D0 = 208
    WRITE_BINARY_D1 = 209
    WRITE_RECORD = 210
    UPDATE_BINARY_D6 = 214
    UPDATE_BINARY_D7 = 215
    PUT_KEY = 216
    PUT_DATA_DA = 218
    PUT_DATA_DB = 219
    UPDATE_RECORD_DC = 220
    UPDATE_RECORD_DD = 221
    CREATE_FILE = 224
    GOODIX_PRIVATE = 225
    STORE_DATA = 226
    DELETE = 228
    INSTALL = 230
    LOAD = 232
    SET_STATUS = 240
    EXIT_ROOT2 = 241
    GET_STATUS = 242

class InstallP1Coding(IntFlag):
    LAST_CMD = 0
    MORE_INSTALL_CMD = 128
    FOR_REGISTRY_UPDATE = 64
    FOR_PERSONALIZATION = 32
    FOR_EXTRADITION = 16
    FOR_MAKE_SELECTABLE = 8
    FOR_INSTALL = 4
    FOR_LOAD = 2

class KeyType(IntEnum):
    DES = (128, 'DES - mode (ECB/CBC) implicitly known')
    PRE_SHARED_KEY = (133, 'Pre-Shared Key for Transport Layer Security')
    AES = (136, 'AES (16, 24, or 32 long keys)')
    SM4 = (137, 'SM4 16 bytes keys')
    HMAC_SHA1 = (144, 'HMAC-SHA1 - length of HMAC is implicitly known')
    HMAC_SHA1_160 = (145, 'HMAC-SHA1-160 - length of HMAC is 160 bits')
    RSA_PUBLIC_KEY_PUBLIC_EXPONENT_E = (160, 'RSA Public Key - public exponent e component (clear text)')
    RSA_PUBLIC_KEY_MODULUS_N_CLEAR_TEXT = (161, 'RSA Public Key - modulus N component (clear text)')
    RSA_PRIVATE_KEY_MODULUS_N = (162, 'RSA Private Key - modulus N component')
    RSA_PRIVATE_KEY_PRIVATE_EXPONENT_D = (163, 'RSA Private Key - private exponent d component')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_P = (164, 'RSA Private Key - Chinese Remainder P component')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_Q = (165, 'RSA Private Key - Chinese Remainder Q component')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_PQ = (166, 'RSA Private Key - Chinese Remainder PQ component (q-1 mod p)')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_DP1 = (167, 'RSA Private Key - Chinese Remainder DP1 component (d mod (p-1))')
    RSA_PRIVATE_KEY_CHINESE_REMAINDER_DQ1 = (168, 'RSA Private Key - Chinese Remainder DQ1 component (d mod (q-1))')
    ECC_PUBLIC_KEY = (176, 'ECC public key')
    ECC_PRIVATE_KEY = (177, 'ECC private key')
    ECC_P = (178, 'ECC field parameter P (field specification)')
    ECC_A = (179, 'ECC field parameter A (first coefficient)')
    ECC_B = (180, 'ECC field parameter B (second coefficient)')
    ECC_G = (181, 'ECC field parameter G (generator)')
    ECC_N = (182, 'ECC field parameter N (order of generator)')
    ECC_K = (183, 'ECC field parameter k (cofactor of order of generator)')
    ECC_KEY_REFERENCE = (240, 'ECC key parameters reference')

    @staticmethod
    def __get_missing_value__(value: int):
        if 0 <= value and value <= 127:
            return (value, 'Reserved for private use')
        if 129 <= value and value <= 132:
            (value, 'Reserved for historical reasons')
        if 134 <= value and value <= 135:
            (value, 'RFU (symmetric algorithms')
        if 137 <= value and value <= 143:
            (value, 'RFU (symmetric algorithms')
        if 146 <= value and value <= 159:
            (value, 'RFU (symmetric algorithms')
        if 169 <= value and value <= 175:
            (value, 'RFU (asymmetric algorithms')
        if 184 <= value and value <= 239:
            (value, 'RFU (asymmetric algorithms')
        if 241 <= value and value <= 254:
            (value, 'RFU (asymmetric algorithms')
        if 65280 <= value and value <= 65535:
            (value, 'Extended format (usage defined for specific APDU commands; e.g. PUT KEY')

class KeyUsageQualifier(IntEnum):
    C_MAC = 20
    R_MAC = 36
    C_MAC_R_MAC = 52
    C_ENC = 24
    R_ENC = 40
    C_ENC_AND_R_ENC = 56
    C_DEK = 72
    R_DEK = 136
    C_DEK_AND_R_DEK = 200
    PK_SD_AUT = 130
    SK_SD_AUT = 66
    Token = 129
    Receipt = 68
    DAP = 132
    PK_SD_AUT_AND_Token = 131
    SK_SD_AUT_AND_Receipt = 67
    PK_SD_AUT_AND_DAP = 134
    PK_SD_AUT_AND_Token_AND_DAP = 135

class ExecutableLoadFileLifeCycleState(IntEnum):
    LOGICALLY_DELETED_WITH_REFERENCES = (0, 'LOGICALLY DELETED WITH REFERENCES')
    LOADED = (1, 'LOADED')

class ApplicationLifeCycleState(IntEnum):
    INSTALLED = (3, 'INSTALLED')
    SELECTABLE = (7, 'SELECTABLE')
    LOCKED = (135, 'LOCKED')

    @staticmethod
    def __get_missing_value__(value: int):
        if value & 131 == 131:
            return (value, 'LOCKED')
        if value & 135 == 7:
            return (value, 'Application Specific State')
        return (value, 'RFU')

class SecurityDomainLifeCycleState(IntEnum):
    INSTALLED = (3, 'INSTALLED')
    SELECTABLE = (7, 'SELECTABLE')
    PERSONALIZED = (15, 'PERSONALIZED')
    LOCKED = (131, 'LOCKED')

    @staticmethod
    def __get_missing_value__(value: int):
        if value & 131 == 131:
            return (value, 'LOCKED')
        return (value, 'RFU')

class CardLifeCycleState(IntEnum):
    OP_READY = (1, 'OP_READY')
    INITIALIZED = (7, 'INITIALIZED')
    SECURED = (15, 'SECURED')
    CARD_LOCKED = (127, 'CARD_LOCKED')
    TERMINATED = (255, 'TERMINATED')

class ContactlessActivationState(IntEnum):
    ACTIVATED = (1, 'ACTIVATED')
    DEACTIVATED = (0, 'DEACTIVATED')
    NON_ACTIVATABLE = (128, 'NON_ACTIVATABLE')

class CLASpecType(IntEnum):
    ISO_IEC_7816 = (0, 'Command defined in ISO/IEC 7816')
    GLOBAL_PLATFORM = (1, 'GlobalPlatform command')

class CLAInterindustryType(IntEnum):
    FIRST = (0, 'First Inter-industry Class Byte Coding')
    FURTHER = (1, 'Further Inter-industry Class Byte Coding')

class CLASecureTypeForFirstInterIndustry(IntEnum):
    NO_SECURE_MESSAGING = (0, 'No secure messaging')
    GLOBAL_PLATFORM = (1, 'Secure messaging - GlobalPlatform proprietary')
    ISO_IEC_7816_NO_CMAC = (2, 'Secure messaging - ISO/IEC 7816 standard, command header not processed (no C-MAC)')
    ISO_IEC_7816_CMAC = (3, 'Secure messaging - ISO/IEC 7816 standard, command header authenticated (C-MAC)')

class CLASecureTypeForFurtherInterIndustry(IntEnum):
    NO_SECURE_MESSAGING = (0, 'No secure messaging')
    ISO_IEC_7816_OR_GLOBAL_PLATFORM = (1, 'Secure messaging - ISO/IEC 7816 or GlobalPlatform proprietary')

class StatusCode(IntEnum):
    SW9000 = (36864, 'The command executed successfully.')
    SW6200 = (25088, 'Logical Channel already closed; No information given.')
    SW6281 = (25217, 'Part of returned data may be corrupted.')
    SW6282 = (25218, 'End of file, record or DO reached before reading Ne bytes, or unsuccessful search..')
    SW6283 = (25219, 'Card Life Cycle State is CARD_LOCKED; Selected file deactivated.')
    SW6284 = (25220, 'File or data control information not formatted according to 7.4.')
    SW6285 = (25221, 'Selected file or DO in termination state.')
    SW6286 = (25222, 'No input data available from a sensor on the card.')
    SW6287 = (25223, 'At least one of the referenced records is not processed for some reason, e.g. record deactivated, security status not satisfied or conditions of use not satisfied.')
    SW6300 = (25344, 'No information given.')
    SW6310 = (25360, 'More data available')
    SW6340 = (25408, 'Unsuccessful comparison.')
    SW6381 = (25473, 'File or DO filled up by the last write.')
    SW6400 = (25600, 'No specific diagnosis; No information given.')
    SW6401 = (25601, 'Immediate response required by the card.')
    SW6402 = (25602, 'to "80" Triggering by the card (see 12.6.2).')
    SW6481 = (25729, 'Logical channel shared access denied.')
    SW6482 = (25730, 'Logical channel opening denied.')
    SW6500 = (25856, 'No information given.')
    SW6581 = (25985, 'Memory failure.')
    SW6600 = (26112, 'No information given, any other value is RFU.')
    SW6700 = (26368, 'Wrong length in Lc; No information given.')
    SW6701 = (26369, 'Command APDU format not compliant with this standard (see 5.1).')
    SW6702 = (26370, 'The value of Lc is not the one expected..')
    SW6800 = (26624, 'No information given.')
    SW6881 = (26753, 'Logical channel not supported.')
    SW6882 = (26754, 'Secure messaging not supported.')
    SW6883 = (26755, 'Last command of the chain expected.')
    SW6884 = (26756, 'Command chaining not supported.')
    SW6900 = (26880, 'No information given.')
    SW6981 = (27009, 'Command incompatible with file structure.')
    SW6982 = (27010, 'Security status not satisfied; Invalid key check value.')
    SW6983 = (27011, 'Authentication method blocked.')
    SW6984 = (27012, 'Reference data not usable.')
    SW6985 = (27013, 'Conditions of use not satisfied.')
    SW6986 = (27014, 'Command not allowed (curEF not set).')
    SW6987 = (27015, 'Expected secure messaging DOs missing.')
    SW6988 = (27016, 'Incorrect secure messaging DOs.')
    SW6A00 = (27136, 'No information given.')
    SW6A80 = (27264, 'Incorrect parameters in the command data field; Incorrect parameters in data field; Wrong data.')
    SW6A81 = (27265, 'Function not supported e.g. card Life Cycle State is CARD_LOCKED.')
    SW6A82 = (27266, 'File or application not found.')
    SW6A83 = (27267, 'Record not found.')
    SW6A84 = (27268, 'Not enough memory space in the file.')
    SW6A85 = (27269, 'Nc inconsistent with tlv structure.')
    SW6A86 = (27270, 'Incorrect parameters P1-P2.')
    SW6A87 = (27271, 'Nc inconsistent with parameters P1-P2.')
    SW6A88 = (27272, 'Referenced data, reference data or DO not found (exact meaning depending on the command).')
    SW6A89 = (27273, 'File already exists.')
    SW6A8A = (27274, 'DF name already exists; Unsupported SCP.')
    SW6A8B = (27275, 'Invalid signature.')
    SW6A8C = (27276, 'Decrypt failed.')
    SW6A8F = (27279, 'Invalid length; Unrecognized data.')
    SW6A8E = (27278, 'Uninitialized.')
    SW6A90 = (27280, 'Internal CMD error; Update failed; Proceed failed.')
    SW6D00 = (27904, 'Invalid instruction.')
    SW6E00 = (28160, 'Invalid class.')
    SW9484 = (38020, "Algorithm not supported (DEPRECATED: Use '6A80' instead.).")
    SW9485 = (38021, "Invalid key check value (DEPRECATED: Use '6982' instead.).")

    @staticmethod
    def __get_missing_value__(value: int):
        sw1 = (value & 65280) >> 8
        sw2 = value & 255
        if sw1 == 97:
            return (value, 'Normal processing. SW2 encodes the number of data bytes still available (see text below)')
        if sw1 == 98:
            if sw2 >= 2 and sw2 <= 128:
                return (value, "'6202' to '6280' Triggering by the card (see 12.6.2)")
            return (value, 'Warning. State of non-volatile memory is unchanged (further qualification in SW2, see Table 7)')
        if sw1 == 99:
            if sw2 >= 192 and sw2 <= 207:
                return (value, "Warning. 0x63CX means counter from 0 to 15 encoded by 'X' (exact meaning depends on the command)")
            return (value, 'Warning. State of non-volatile memory may have changed (further qualification in SW2, see Table 7)')
        if sw1 == 100:
            return (value, 'Execution error. State of non-volatile memory is unchanged (further qualification in SW2, see Table 7)')
        if sw1 == 101:
            return (value, 'Execution error. State of non-volatile memory may have changed (further qualification in SW2, see Table 7)')
        if sw1 == 102:
            return (value, 'Execution error. Security-related issues (further qualification in SW2 is RFU)')
        if sw1 == 103:
            return (value, 'Checking error.  Wrong length (further qualification in SW2, see Table 7)')
        if sw1 == 104:
            return (value, 'Checking error. Functions in CLA not supported (further qualification in SW2, see Table 7)')
        if sw1 == 105:
            return (value, 'Checking error. Command not allowed (further qualification in SW2, see Table 7)')
        if sw1 == 106:
            return (value, 'Checking error. Wrong parameters P1-P2 (further qualification in SW2, see Table 7)')
        if sw1 == 107:
            return (value, 'Checking error. Wrong parameters P1-P2')
        if sw1 == 108:
            return (value, 'Checking error. Wrong Le field; SW2 encodes the exact number of available data bytes (see text below)')
        if sw1 == 109:
            return (value, 'Checking error. Instruction code not supported or invalid')
        if sw1 == 110:
            return (value, 'Checking error. Class not supported')
        if sw1 == 111:
            return (value, 'Checking error. No precise diagnosis')
        return (value, 'RFU')

    @property
    def sw1(self) -> int:
        return self.value >> 8

    @property
    def sw2(self) -> int:
        return self.value & 255

    def __str__(self):
        return f'{self.value:02X}' if not self.__doc__ else f'{self.value:02X}, {self.__doc__}'

class SecurityLevel(IntFlag):
    NO_SECURE = (0, 'NO SECURE')
    C_MAC = (1, 'C-MAC')
    C_DECRYPTION = (2, 'C-DECRYPTION')
    R_MAC = (16, 'R-MAC')

class PrivilegesByte1(IntFlag):
    SECURITY_DOMAIN = (128, 'Security Domain')
    DAP_VERIFICATION = (192, 'DAP Verification')
    DELEGATED_MANAGEMENT = (160, 'Delegated Management')
    CARD_LOCK = (16, 'Card Lock')
    CARD_TERMINATE = (8, 'Card Terminate')
    CARD_RESET = (4, 'Card Reset')
    CVM_MANAGEMENT = (2, 'CVM Management')
    MANDATED_DAP_VERIFICATION = (193, 'Mandated DAP Verification')

class PrivilegesByte2(IntFlag):
    TRUSTED_PATH = (128, 'Trusted Path')
    AUTHORIZED_MANAGEMENT = (64, 'Authorized Management')
    TOKEN_MANAGEMENT = (32, 'Token Management')
    GLOBAL_DELETE = (16, 'Global Delete')
    GLOBAL_LOCK = (8, 'Global Lock')
    GLOBAL_REGISTRY = (4, 'Global Registry')
    FINAL_APPLICATION = (2, 'Final Application')
    GLOBAL_SERVICE = (1, 'Global Service')

class PrivilegesByte3(IntFlag):
    RECEIPT_GENERATION = (128, 'Receipt Generation')
    CIPHERED_LOAD_FILE_DATA_BLOCK = (64, 'Ciphered Load File Data Block')
    CONTACTLESS_ACTIVATION = (32, 'Contactless Activation')
    CONTACTLESS_SELF_ACTIVATION = (16, 'Contactless Self-Activation')

class KeyUsageQualifier1(IntFlag):
    VERIFICATION_DST_CCT_CAT_AND_ENCIPHERMENT_CT = (128, 'Verification (DST, CCT, CAT), Encipherment (CT)')
    COMPUTATION_DST_CCT_CAT_DECIPHERMENT_CT = (64, 'Computation (DST, CCT, CAT), Decipherment (CT)')
    SECURE_MESSAGING_IN_RESPONSE_DATA_FIELDS_CT_CCT = (32, 'Secure messaging in response data fields (CT, CCT)')
    SECURE_MESSAGING_IN_COMMAND_DATA_FIELDS_CT_CCT = (16, 'Secure messaging in command data fields (CT, CCT)')
    CONFIDENTIALITY_CT = (8, 'Confidentiality (CT)')
    CRYPTOGRAPHIC_CHECKSUM_CCT = (4, 'Cryptographic Checksum (CCT)')
    DIGITAL_SIGNATURE_DST = (2, 'Digital Signature (DST)')
    CRYPTOGRAPHIC_AUTHORIZATION_CAT = (1, 'Cryptographic Authorization (CAT)')

class KeyUsageQualifier2(IntFlag):
    VERIFICATION_DST_CCT_CAT_AND_ENCIPHERMENT_CT = (32768, 'Verification (DST, CCT, CAT), Encipherment (CT)')
    COMPUTATION_DST_CCT_CAT_DECIPHERMENT_CT = (16384, 'Computation (DST, CCT, CAT), Decipherment (CT)')
    SECURE_MESSAGING_IN_RESPONSE_DATA_FIELDS_CT_CCT = (8192, 'Secure messaging in response data fields (CT, CCT)')
    SECURE_MESSAGING_IN_COMMAND_DATA_FIELDS_CT_CCT = (4096, 'Secure messaging in command data fields (CT, CCT)')
    CONFIDENTIALITY_CT = (2048, 'Confidentiality (CT)')
    CRYPTOGRAPHIC_CHECKSUM_CCT = (1024, 'Cryptographic Checksum (CCT)')
    DIGITAL_SIGNATURE_DST = (512, 'Digital Signature (DST)')
    CRYPTOGRAPHIC_AUTHORIZATION_CAT = (256, 'Cryptographic Authorization (CAT)')
    KEY_AGREEMENT_KAT = (128, 'Key Agreement (KAT)')

class KeyAccess(IntEnum):
    SECURITY_DOMAIN_AND_APPLICATION = (0, 'The key may be used by the Security Domain and any associated Application')
    SECURITY_DOMAIN = (1, 'The key may be used by the Security Domain')
    APPLICATION = (2, 'The key may be used by the Security Domain')

class CommandChainType(IntEnum):
    LAST_COMMAND_CHAIN = (0, 'The command is the last or only command of a chain')
    NOT_LAST_COMMAND_CHAIN = (1, 'The command is not the last command of a chain')

class FirstInterindustryClassByteCoding(Object):
    value: int = 0
    spec: CLASpecType = IntProperty(title='Specification', cls=CLASpecType, bit_field=7)
    interindustry: CLAInterindustryType = IntProperty(cls=CLAInterindustryType, title='Interindustry', bit_field=6)
    chain_type: CommandChainType = IntProperty(cls=CommandChainType, title='Command Chain', bit_field=4)
    secure_type_for_first_interindustry: CLASecureTypeForFirstInterIndustry = IntProperty(cls=CLASecureTypeForFirstInterIndustry, title='Secure Type(Interindustry=0)', bit_field=(2, 3))
    logical_channel_number_for_first_interindustry: int = IntProperty(cls=int, title='Logical Channel Number(Interindustry=0)', bit_field=(0, 1), doc='0: Basic Logical Channel\n1-3: Supplementary Logical Channel')
    secure_type_for_further_interindustry: CLASecureTypeForFurtherInterIndustry = IntProperty(cls=CLASecureTypeForFurtherInterIndustry, title='Secure Type(Interindustry=1)', bit_field=5)
    logical_channel_number_further_interindustry: int = IntProperty(cls=int, title='Logical Channel Number(Interindustry=1)', bit_field=(0, 3), doc='A class byte with bit b7 set to 1 indicates in bits b4 to b1 (values 0000 to 1111) receipt of the command on Supplementary Logical Channel 4 to 19')

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.value = stream.peek_int(1)
        self.deserialize_property(cls.spec, stream, ctx, peek=True)
        self.deserialize_property(cls.interindustry, stream, ctx, peek=True)
        self.deserialize_property(cls.chain_type, stream, ctx, peek=True)
        if self.interindustry == CLAInterindustryType.FIRST:
            self.deserialize_property(cls.secure_type_for_first_interindustry, stream, ctx, peek=True)
            self.deserialize_property(cls.logical_channel_number_for_first_interindustry, stream, ctx)
        elif self.interindustry == CLAInterindustryType.FURTHER:
            self.deserialize_property(cls.secure_type_for_further_interindustry, stream, ctx, peek=True)
            self.deserialize_property(cls.logical_channel_number_further_interindustry, stream, ctx)
        return self

    @property
    def has_cmac(self):
        if self.secure_type_for_first_interindustry is not None:
            return self.secure_type_for_first_interindustry in (CLASecureTypeForFirstInterIndustry.GLOBAL_PLATFORM, CLASecureTypeForFirstInterIndustry.ISO_IEC_7816_CMAC)
        elif self.secure_type_for_further_interindustry is not None:
            return self.secure_type_for_further_interindustry == CLASecureTypeForFurtherInterIndustry.ISO_IEC_7816_OR_GLOBAL_PLATFORM
        else:
            return False

class FurtherInterindustryClassByteCoding:
    value: int = 0

class CommandAPDU(Object):
    cla: int = IntProperty('CLA')
    ins: Instruction = IntProperty('INS', Instruction)
    p1: int = IntProperty('P1')
    p2: int = IntProperty('P2')
    lc: int = IntProperty('Lc')
    data: bytes = Property('Data')
    le: int = IntProperty('Le')

    def __init__(self, cla: int=None, ins: Instruction=0, p1: int=0, p2: int=0, data: bytes=None, logic_channel_number: int=0) -> None:
        super().__init__()
        cla = cla or 0
        if ins in (Instruction.DELETE, Instruction.GET_DATA_CB, Instruction.GET_STATUS, Instruction.INSTALL, Instruction.LOAD, Instruction.PUT_KEY, Instruction.SET_STATUS, Instruction.STORE_DATA, Instruction.INITIALIZE_UPDATE, Instruction.EXTERNAL_AUTHENTICATE, Instruction.BEGIN_RMAC_SESSION, Instruction.END_RMAC_SESSION):
            cla |= 128
        self.cla = cla
        self.ins = ins
        self.p1 = p1
        self.p2 = p2
        if isinstance(data, str) or data == None:
            data = to_bytes(data) or bytes()
        if data and isinstance(data, (bytes, bytearray)):
            self.lc = len(data)
        else:
            self.lc = 0
        self.data = data
        if logic_channel_number:
            self.logic_channel_number = logic_channel_number

    @property
    def spec_type(self) -> CLASpecType:
        return CLASpecType(self.cla >> 7)

    @spec_type.setter
    def spec_type(self, t: Union[CLASpecType, Literal[0, 1]]):
        self.cla = self.cla | int(t) << 7

    @property
    def interindustry_type(self) -> CLAInterindustryType:
        return CLAInterindustryType(self.cla >> 6 & 1)

    @interindustry_type.setter
    def interindustry_type(self, value: Union[CLAInterindustryType, Literal[0, 1]]):
        if value != 0 and value != 1:
            raise Exception(f'Bad Interindustry Type value!')
        self.cla = self.cla & 191 | int(value) << 6

    @property
    def logic_channel_number(self) -> int:
        if self.interindustry_type == CLAInterindustryType.FIRST:
            return self.cla & 3
        if self.interindustry_type == CLAInterindustryType.FURTHER:
            return 4 + (self.cla & 15)

    @logic_channel_number.setter
    def logic_channel_number(self, value: int) -> CLAInterindustryType:
        if self.interindustry_type == CLAInterindustryType.FIRST:
            if value not in [0, 1, 2, 3]:
                raise Exception(f'Bad Logic Channel Number: {value}, must be [0-3] for {self.interindustry_type}!')
            self.cla = (self.cla & 252) + value
        if self.interindustry_type == CLAInterindustryType.FURTHER:
            if value < 4 or value > 19:
                raise Exception(f'Bad Logic Channel Number: {value}, must be [4-19] for {self.interindustry_type}!')
            self.cla = (self.cla & 240) + (value - 4)

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.cla, stream)
        self.deserialize_property(cls.ins, stream)
        self.deserialize_property(cls.p1, stream)
        self.deserialize_property(cls.p2, stream)
        self.lc = stream.read_byte()
        if stream.at_end():
            self.le = self.lc
            self.lc = None
        else:
            if self.lc == 0:
                if stream.length - stream.tell() == 1:
                    self.le = stream.read_byte()
                elif stream.length - stream.tell() > 1:
                    self.lc = stream.read_int(2, 'big')
                else:
                    raise Exception(f'Bad apdu with Lc=0!')
            if self.lc:
                self.deserialize_data(stream)
            else:
                self.data = bytes()
        if not stream.at_end():
            self.le = stream.read_byte()
        return self

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, size=self.lc)

    def serialize(self, stream: BytesIO):
        return self.__do_serialize(stream)

    def __do_serialize(self, stream: BytesIO, no_le: bool=False):
        cls = self.__class__
        self.serialize_property(cls.cla, stream)
        self.serialize_property(cls.ins, stream)
        self.serialize_property(cls.p1, stream)
        self.serialize_property(cls.p2, stream)
        length_pos = stream.tell()
        stream.write_byte(0)
        self.serialize_data(stream)
        payload_length = stream.tell() - length_pos - 1
        if payload_length <= 255:
            stream.adjust_wrote_length(length_pos)
        elif payload_length <= 65535:
            stream.insert(length_pos, bytes(2))
            stream.adjust_wrote_length(length_pos, length_size=3, byteorder='big')
        else:
            raise Exception(f'Bad data size > 0xFFFF!')
        if no_le:
            return
        if self.ins == Instruction.MANAGE_CHANNEL:
            if self.p1 == 0:
                stream.write_byte(1)
        elif self.ins in (Instruction.SELECT, Instruction.GET_DATA_CA, Instruction.GET_DATA_CB):
            if payload_length > 0:
                stream.write_byte(self.le or 0)
        elif self.ins not in (Instruction.SET_STATUS, Instruction.STORE_DATA, Instruction.EXTERNAL_AUTHENTICATE, Instruction.BEGIN_RMAC_SESSION, Instruction.VERIFY_PIN, Instruction.PERFORM_TRANSACTION_OPERATION):
            if self.lc == None and payload_length == 0 and (self.le != None):
                stream.seek(-1, 1)
                stream.write_byte(self.le)
            elif self.le != None:
                stream.write_byte(self.le or 0)
        elif self.le != None:
            stream.write_byte(self.le)

    def serialize_data(self, stream: BytesIO):
        if self.data:
            stream.write(self.data)

    def to_bytes(self, no_le: bool=False) -> bytes:
        stream = BytesIO()
        self.__do_serialize(stream, no_le)
        return stream.getvalue()

    def __repr__(self) -> str:
        lc = self.lc or (len(self.data) if self.data else 0)
        return f"CLA={self.cla:02X}, INS={self.ins}, P1={self.p1:02X}, P2={self.p2:02X}, Lc={(f'{lc:02X}' if lc <= 255 else f'{lc:04X}')}({lc}), Data={hex(self.data)}"

    def clone(self):
        obj = self.__class__()
        for k in self.__dict__.keys():
            setattr(obj, k, getattr(self, k, None))
        return obj

class ResponseAPDU(Object):
    raw: bytes
    data: bytes = Property('Data')
    status_code: StatusCode = IntProperty('Status Code', cls=StatusCode, size=2, byteorder='big')

    def __init__(self, init: bytes=None) -> None:
        if init:
            self.deserialize(BytesIO(init))

    @property
    def status_ok(self):
        return self.status_code == 36864

    @property
    def sw1(self):
        return (self.status_code & 65280) >> 8

    @property
    def sw2(self):
        return self.status_code & 255

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.raw = stream.getvalue()
        stream.seek(-2, 2)
        self.deserialize_property(cls.status_code, stream)
        stream.truncate(stream.length - 2)
        if stream.length:
            stream.seek(0, 0)
            self.deserialize_property(cls.data, stream, size=stream.length, cls=bytes)
            stream.seek(0, 0)
            self.deserialize_data(stream)

    @abstractmethod
    def deserialize_data(self, stream: BytesIO):
        pass

    def serialize(self, stream: BytesIO):
        cls = self.__class__
        self.serialize_property(cls.data)
        self.serialize_property(cls.status_code)

    def __buffer__(self):
        return (self.data or bytes()) + bytes([self.status_code.sw1, self.status_code.sw2])

    def __str__(self) -> str:
        return f'{hex(self.__buffer__())}, Status: {self.status_code.__doc__}'

    def __repr__(self) -> str:
        return f'<{self.__class__} Status={self.status_code}, Data({(len(self.data) if self.data else 0)})={hex(self.data)}>'

class CommandPacketFactory:
    registered_types: Dict[Instruction, Type[CommandAPDU]]

    def __init__(self) -> None:
        self.registered_types = {}

    def get_cls(self, ins: Instruction) -> Type[CommandAPDU]:
        return self.registered_types.get(ins, CommandAPDU)

    def register(self, ins: Instruction, cls):
        self.registered_types[ins] = cls
        self.registered_types[ins.value] = cls
        return cls

    def from_bytes(self, packet: Union[bytes, str]):
        packet = to_bytes(packet)
        cls = self.get_cls(packet[1])
        return cls().deserialize(BytesIO(to_bytes(packet)))
RegisteredCommandPackets = CommandPacketFactory()

def register_command_packet(ins: Instruction):

    def inner(cls):
        RegisteredCommandPackets.register(ins, cls)
        return cls
    return inner

class CosType(IntEnum):
    LJS = 165
    ROOT2 = 90

class CosVersion(Object):
    generation: Literal[1, 2] = 0

    def __init__(self, init: bytes=None) -> None:
        if init:
            self.deserialize(BytesIO(init))

    @staticmethod
    def new(data: bytes) -> Union['CosVersionGen1', 'CosVersionGen2']:
        if data and data[2] == 3 and (data[3] >= 0):
            return CosVersionGen2(data)
        return CosVersionGen1(data)

class CosVersionGen1(CosVersion):
    ic_fw_version: int = IntProperty('IC FW Version', size=2, byteorder='big')
    cos_rom_major_version: int = IntProperty('COS ROM Major Version')
    cos_rom_minor_version: int = IntProperty('COS ROM Minor Version')
    patch_major_version: int = IntProperty('Patch Major Version')
    patch_minor_version: int = IntProperty('Patch Minor Version')
    se_root_major_version: int = IntProperty('SE Root Minor Version')
    se_root_minor_version: int = IntProperty('SE Root Minor Version')
    mls_rom_version: int = IntProperty('MLS ROM Version')
    mls_opt_version: int = IntProperty('MLS OPT Version')
    mls_ram_version: int = IntProperty('MLS RAM Version', size=4, byteorder='big')
    cos_type: CosType = IntProperty('COS Type', CosType)
    key_version: int = IntProperty('Key Version')
    reversed0: bytes
    cid: int = IntProperty('CID')
    crc: int = IntProperty('CRC', size=4, byteorder='big')

    def __init__(self, init: bytes=None) -> None:
        super().__init__(init)
        self.generation = 1

    @property
    def versions(self):
        return (self.ic_fw_version, self.cos_rom_major_version, self.cos_rom_minor_version, self.patch_major_version, self.patch_minor_version)

    @property
    def versions_str(self):
        return f'FW: {self.ic_fw_version:04X}, COS={self.cos_rom_major_version:02X}.{self.cos_rom_minor_version:02X}.{self.patch_major_version:02X}.{self.patch_minor_version:02X}, T={int(self.cos_type):02X}, CID=0x{self.cid:02X}, KV=0x{self.key_version:02X}, CRC=0x{self.crc:08X}'

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.ic_fw_version, stream)
        self.deserialize_property(cls.cos_rom_major_version, stream)
        self.deserialize_property(cls.cos_rom_minor_version, stream)
        self.deserialize_property(cls.patch_major_version, stream)
        self.deserialize_property(cls.patch_minor_version, stream)
        self.deserialize_property(cls.se_root_major_version, stream)
        self.deserialize_property(cls.se_root_minor_version, stream)
        self.deserialize_property(cls.mls_rom_version, stream)
        self.deserialize_property(cls.mls_opt_version, stream)
        self.deserialize_property(cls.mls_ram_version, stream)
        self.deserialize_property(cls.cos_type, stream)
        self.deserialize_property(cls.key_version, stream)
        stream.seek(53, 1)
        self.deserialize_property(cls.cid, stream)
        self.deserialize_property(cls.crc, stream)

class CosVersionGen2(CosVersion):
    ic_fw_version: int = IntProperty('IC FW Version', size=2, byteorder='big')
    cos_rom_version: int = IntProperty('COS ROM Version')
    patch_major_version: int = IntProperty('Patch Major Version')
    patch_minor_version: int = IntProperty('Patch Minor Version', size=2, byteorder='big')
    reserved0: bytes
    cos_type: CosType = IntProperty('COS Type', CosType)
    key_version: int = IntProperty('Key Version')
    reversed1: bytes
    config2_id: int = IntProperty('Config2 Id')
    cid: int = IntProperty('CID')
    crc: int = IntProperty('CRC', size=4, byteorder='big')

    def __init__(self, init: bytes=None) -> None:
        super().__init__(init)
        self.generation = 2

    @property
    def versions(self):
        return (self.ic_fw_version, self.cos_rom_version, self.patch_major_version, self.patch_minor_version)

    @property
    def versions_str(self):
        return f'FW: {self.ic_fw_version:04X}, COS={self.cos_rom_version:02X}.{self.patch_major_version:02X}.{self.patch_minor_version:04X}, T={int(self.cos_type):02X}, CID=0x{self.cid:02X}, KV=0x{self.key_version:02X}, CFG2=0x{self.config2_id:02X}, CRC=0x{self.crc:08X}'

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.ic_fw_version, stream)
        self.deserialize_property(cls.cos_rom_version, stream)
        self.deserialize_property(cls.patch_major_version, stream)
        self.deserialize_property(cls.patch_minor_version, stream)
        stream.seek(8, 1)
        self.deserialize_property(cls.cos_type, stream)
        self.deserialize_property(cls.key_version, stream)
        stream.seek(52, 1)
        self.deserialize_property(cls.config2_id, stream)
        self.deserialize_property(cls.cid, stream)
        self.deserialize_property(cls.crc, stream)

class GetDataTag(IntEnum):
    IDENTIFICATION_NUMBER = (66, 'Issuer Identification Number (or Security Domain Provider Identification Number)')
    IMAGE_NUMBER = (69, 'Card Image Number (or Security Domain Image Number)')
    CARD_DATA_OR_MANAGEMENT_DATA = (102, 'Card Data (or Security Domain Management Data)')
    KEY_INFORMATION_TEMPLATE = (224, 'Key Information Template')
    CARD_CAPABILITY_INFORMATION = (103, 'Card Capability Information')
    CURRENT_SECURITY_LEVEL = (211, 'Current Security Level')
    LIST_OF_APPLICATIONS = (12032, 'List of Applications associated with the Security Domain, or every application on the card if the Security Domain has Global Registry Privilege')
    EXTENDED_CARD_RESOURCES_INFORMATION = (65313, 'Extended Card Resources Information available for Card Content Management, as defined in [TS 102 226]')
    SECURITY_DOMAIN_MANAGER_URL = (24400, 'Security Domain Manager URL')
    CONFIRMATION_COUNTER = (194, 'Confirmation Counter')
    SEQUENCE_COUNTER_OF_THE_DEFAULT_KEY_VERSION_NUMBER = (193, 'Sequence Counter of the default Key Version Number')
    CERTIFICATE = (32545, 'Certificate')
    DATA_OBJECT_IDENTIFIER_OF_EF_OD = (20529, 'Data object identifier of EF.OD')
    CARD_PRODUCTION_LIFE_CYCLE = (40831, 'Card Production Life Cycle')
    PROTOCOL_CONFIGURATION_LIST = (49009, 'Protocol Configuration List')
    GOODIX_GET_VERSION = (65408, 'Get Version')

class CipherSuitesForSignaturesByte1(IntFlag):
    RSA1024_RSASSAPKCSV15_SHA1 = (1, 'RSA-1024 / RSASSA-PKCS-v1_5 / SHA-1 (see section B.3.1.1)')
    RSA_1024_RSASSAPSS_SHA256 = (2, 'RSA >1024 / RSASSA-PSS / SHA-256 (see section B.3.2.1)')
    SINGLE_DES_PLUS_FINAL_TRIPLE_DES_MAC = (4, '16 byte key / Single DES plus Final Triple DES MAC (see section B.1.2.2)')
    CMAC_USING_AES128 = (8, 'CMAC using AES-128 (see section B.2.2)')
    CMAC_USING_AES192 = (16, 'CMAC using AES-192 (see section B.2.2)')
    CMAC_USING_AES256 = (32, 'CMAC using AES-256 (see section B.2.2)')
    ECDSA_USING_ECC256_AND_SHA256 = (64, 'ECDSA using ECC-256 and SHA-256 (see section B.4.3)')
    ECDSA_USING_ECC384_AND_SHA384 = (128, 'ECDSA using ECC-384 and SHA-384 (see section B.4.3)')

class CipherSuitesForSignaturesByte2(IntFlag):
    ECDSA_USING_ECC512_AND_SHA512 = (1, 'ECDSA using ECC-512 and SHA-512 (see section B.4.3)')
    ECDSA_USING_ECC521_AND_SHA512 = (2, 'ECDSA using ECC-521 and SHA-512 (see section B.4.3)')

class CipherSuitesForSignatures(IntFlag):
    RSA1024_RSASSAPKCSV15_SHA1 = (1, 'RSA-1024 / RSASSA-PKCS-v1_5 / SHA-1 (see section B.3.1.1)')
    RSA_1024_RSASSAPSS_SHA256 = (2, 'RSA >1024 / RSASSA-PSS / SHA-256 (see section B.3.2.1)')
    SINGLE_DES_PLUS_FINAL_TRIPLE_DES_MAC = (4, '16 byte key / Single DES plus Final Triple DES MAC (see section B.1.2.2)')
    CMAC_USING_AES128 = (8, 'CMAC using AES-128 (see section B.2.2)')
    CMAC_USING_AES192 = (16, 'CMAC using AES-192 (see section B.2.2)')
    CMAC_USING_AES256 = (32, 'CMAC using AES-256 (see section B.2.2)')
    ECDSA_USING_ECC256_AND_SHA256 = (64, 'ECDSA using ECC-256 and SHA-256 (see section B.4.3)')
    ECDSA_USING_ECC384_AND_SHA384 = (128, 'ECDSA using ECC-384 and SHA-384 (see section B.4.3)')
    ECDSA_USING_ECC512_AND_SHA512 = (256, 'ECDSA using ECC-512 and SHA-512 (see section B.4.3)')
    ECDSA_USING_ECC521_AND_SHA512 = (512, 'ECDSA using ECC-521 and SHA-512 (see section B.4.3)')

class CipherSuitesForLFDBEncryption(IntFlag):
    TRIPLE_DES_WITH_16_BYTE_KEY = (1, 'Triple DES with 16 byte key length')
    AES128 = (2, 'AES-128')
    AES192 = (4, 'AES-192')
    AES256 = (8, 'AES-256')
    ICV_SUPPORTED_FOR_LFDB_ENCRYPTION = (128, 'ICV supported for LFDB encryption')

class LFDBHAlgorithms(IntEnum):
    SHA1 = (1, 'SHA-1')
    SHA256 = (2, 'SHA-256')
    SHA384 = (3, 'SHA-384')
    SHA512 = (4, 'SHA-512')

class SupportedKeysForSCP03(IntFlag):
    AES128 = (1, 'AES-128')
    AES192 = (2, 'AES-192')
    AES256 = (4, 'AES-256')

class ScpId(IntEnum):
    SCP00 = 0
    SCP02 = 2
    SCP03 = 3
    SCP04 = 4
    SCP10 = 16
    SCP11 = 17
    SCP80 = 128
    SCP81 = 129

class SCPInformation(Object):
    scp_type: ScpId = Property(128, ScpId, doc="SCP type ('02', '03', '80', '81') Mandatory")
    supported_options: bytes = Property(129, bytes, doc="List of supported options for that protocol (e.g. '15 55' for SCP02) Mandatory")
    supported_keys_for_scp03: bytes = Property(130, bytes, doc='Supported keys for SCP03 Conditional')
    supported_tls_cipher_suites_for_scp81: bytes = Property(131, bytes, doc='Supported TLS cipher suites for SCP81 Conditional')
    maximum_length_of_pre_shared_key_in_bytes: int = Property(132, int, doc='Maximum length of Pre Shared Key in bytes (unsigned integer) (for SCP81 only) Conditional')

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.scp_type, stream)
        self.deserialize_property(cls.supported_options, stream)
        self.deserialize_property(cls.supported_keys_for_scp03, stream)
        self.deserialize_property(cls.supported_tls_cipher_suites_for_scp81, stream)
        self.deserialize_property(cls.maximum_length_of_pre_shared_key_in_bytes, stream)

class ECCCurveType(IntEnum):
    P256 = (0, 'as specified in [FIPS 186-4]')
    P384 = (1, 'as specified in [FIPS 186-4]')
    P521 = (2, 'as specified in [FIPS 186-4]')
    brainpool_P256_r1 = (3, 'as specified in [RFC 5639]')
    brainpool_P256_t1 = (4, 'as specified in [RFC 5639]')
    brainpool_P384_r1 = (5, 'as specified in [RFC 5639]')
    brainpool_P384_t1 = (6, 'as specified in [RFC 5639]')
    brainpool_P512_r1 = (7, 'as specified in [RFC 5639]')
    brainpool_P512_t1 = (8, 'as specified in [RFC 5639]')

class CardCapabilityInformation(Object):
    scp: List[SCPInformation] = Property(160, SCPInformation, is_list=True, doc='SCP information for SCP(s)')
    privileges_to_ssd: bytes = Property(129, bytes, doc='Privileges that can be assigned to an SSD Conditional')
    privileges_to_app: bytes = Property(130, bytes, doc='Privileges that can be assigned any application Mandatory')
    supported_lfdbh_algorithms: LFDBHAlgorithms = Property(131, LFDBHAlgorithms, doc='Supported LFDBH algorithms Mandatory')
    cipher_suites_for_lfdb_encryption: CipherSuitesForLFDBEncryption = Property(132, CipherSuitesForLFDBEncryption, doc='Cipher suites for LFDB encryption Conditional')
    cipher_suites_supported_for_tokens: CipherSuitesForSignatures = Property(133, CipherSuitesForSignatures, doc='Cipher suites supported for tokens Conditional')
    cipher_suites_supported_for_receipts: CipherSuitesForSignatures = Property(134, CipherSuitesForSignatures, doc='Cipher suites supported for receipts Conditional')
    cipher_suites_supported_for_dap: CipherSuitesForSignatures = Property(135, CipherSuitesForSignatures, doc='Cipher suites supported for DAPs Conditional')
    key_parameter_reference_list: List[ECCCurveType] = Property(136, ECCCurveType, doc='Key Parameter Reference List')

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.scp, stream, ctx)
        self.deserialize_property(cls.privileges_to_ssd, stream, ctx)
        self.deserialize_property(cls.privileges_to_app, stream, ctx)
        self.deserialize_property(cls.supported_lfdbh_algorithms, stream, ctx)
        self.deserialize_property(cls.cipher_suites_for_lfdb_encryption, stream, ctx)
        self.deserialize_property(cls.cipher_suites_supported_for_tokens, stream, ctx)
        self.deserialize_property(cls.cipher_suites_supported_for_receipts, stream, ctx)
        self.deserialize_property(cls.cipher_suites_supported_for_dap, stream, ctx)
        self.deserialize_property(cls.key_parameter_reference_list, stream, ctx)

class GoodixPreinstalledAppletVersionInformation(Object):
    applet_type: int = IntProperty('Applet Type', size=2, byteorder='big')
    applet_version: int = IntProperty('Applet Version', size=2, byteorder='big')
    release_count: int = IntProperty('Release Count', size=2, byteorder='big')
    commit_date: bytes = Property('Commit Date', size=4)

    def __init__(self, init: Union[str, bytes]=None) -> None:
        super().__init__()
        if init:
            self.deserialize(BytesIO(init))

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.applet_type, stream)
        self.deserialize_property(cls.applet_version, stream)
        self.deserialize_property(cls.release_count, stream)
        self.deserialize_property(cls.commit_date, stream)

class ICType(IntEnum):
    GEN1 = 1
    GEN2 = 2

class CardProductionLifeCycle(Object):
    ic_fabricator: int = IntProperty('IC fabricator¹', size=2, byteorder='big')
    ic_type: ICType = IntProperty('IC type¹', ICType, size=2, byteorder='big', doc='0001: GEN1. 0002: GEN2')
    operating_system_identifier: int = IntProperty('Operating system identifier¹', size=2, byteorder='big')
    operating_system_release_date: int = IntProperty('Operating system release date²', size=2, byteorder='big')
    operating_system_release_level: int = IntProperty('Operating system release level', size=2, byteorder='big')
    ic_fabrication_date: int = IntProperty('IC fabrication date²', size=2, byteorder='big')
    ic_serial_number: int = IntProperty('IC serial number', size=4, byteorder='big')
    ic_batch_identifier: int = IntProperty('IC batch identifier', size=2, byteorder='big')
    ic_module_fabricator: int = IntProperty('IC module fabricator¹', size=2, byteorder='big')
    ic_module_packaging_date: int = IntProperty('IC module packaging date²', size=2, byteorder='big')
    icc_manufacturer: int = IntProperty('ICC manufacturer¹', size=2, byteorder='big')
    ic_embedding_date: int = IntProperty('IC embedding date²', size=2, byteorder='big')
    ic_pre_personalizer: int = IntProperty('IC pre-personalizer¹', size=2, byteorder='big')
    ic_pre_personalization_date: int = IntProperty('IC pre-personalization date²', size=2, byteorder='big')
    ic_pre_personalization_equipment_identifier: int = IntProperty('IC pre-personalization equipment identifier', size=4, byteorder='big')
    ic_personalizer: int = IntProperty('IC personalizer¹', size=2, byteorder='big')
    ic_personalization_date: int = IntProperty('IC personalization date²', size=2, byteorder='big')
    ic_personalization_equipment_identifier: int = IntProperty('IC personalization equipment identifier', size=4, byteorder='big')
    chip_id: bytes

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.ic_fabricator, stream)
        self.chip_id = stream.peek(16)
        self.deserialize_property(cls.ic_type, stream)
        self.deserialize_property(cls.operating_system_identifier, stream)
        self.deserialize_property(cls.operating_system_release_date, stream)
        self.deserialize_property(cls.operating_system_release_level, stream)
        self.deserialize_property(cls.ic_fabrication_date, stream)
        self.deserialize_property(cls.ic_serial_number, stream)
        self.deserialize_property(cls.ic_batch_identifier, stream)
        self.deserialize_property(cls.ic_module_fabricator, stream)
        self.deserialize_property(cls.ic_module_packaging_date, stream)
        self.deserialize_property(cls.icc_manufacturer, stream)
        self.deserialize_property(cls.ic_embedding_date, stream)
        self.deserialize_property(cls.ic_pre_personalizer, stream)
        self.deserialize_property(cls.ic_pre_personalization_date, stream)
        self.deserialize_property(cls.ic_pre_personalization_equipment_identifier, stream)
        self.deserialize_property(cls.ic_personalizer, stream)
        self.deserialize_property(cls.ic_personalization_date, stream)
        self.deserialize_property(cls.ic_personalization_equipment_identifier, stream)
        return self

    @property
    def is_testing_chip(self):
        return self.ic_personalization_equipment_identifier and self.ic_personalization_equipment_identifier & 65535 == 65314

class GetDataResponsePacket(ResponseAPDU):
    card_capability_information: CardCapabilityInformation = TlvProperty(GetDataTag.CARD_CAPABILITY_INFORMATION, 'Card Capability Information', CardCapabilityInformation)

    def __init__(self, init: bytes=None) -> None:
        super().__init__(init)

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        self.tlv_nodes = tlv.parse(stream, recursive=False)

class GetStatusP1(IntEnum):
    ISSUER_SECURITY_DOMAIN = 128
    APPLICATIONS_WITH_SECURITY_DOMAINS = 64
    EXECUTABLE_LOAD_FILES = 32
    EXECUTABLE_LOAD_FILES_AND_EXECUTABLE_MODULES = 16

class GetStatusP2(IntFlag):
    GET_FIRST_OR_ALL_OCCURRENCE = 0
    GET_NEXT_OCCURRENCE = 1
    RESPONSE_DATA_STRUCTURE_TLV_E3 = 2

class GetDataSearchCriteria(Object):
    aid: bytes = TlvProperty(79, cls=bytes, doc='Application AID')
    tag_list: Tlv = TlvProperty(92, cls=Tlv, doc='Tag List')

    def __init__(self, aid: bytes=None) -> None:
        super().__init__()
        self.aid = aid

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        tlv = Tlv.try_parse(stream, True)
        if not tlv:
            raise Exception('Bad SearchCriteria')
        TlvProperty.set_tlv(cls.aid, self, Tlv.find_one(tlv, 79))
        TlvProperty.set_tlv(cls.tag_list, self, Tlv.find_one(tlv, 92))

    def serialize(self, stream: BytesIO):
        if self.aid != None:
            stream.write_tlv(79, self.aid)
        if self.tag_list:
            self.tag_list.serialize(stream)

@register_command_packet(Instruction.GET_STATUS)
class GetStatusCommand(CommandAPDU):
    p1: GetStatusP1 = IntProperty('P1', cls=GetStatusP1, doc='Reference control parameter P1 is used to select a subset of statuses to be included in the response message.', order=2)
    p2: GetStatusP2 = IntProperty('P2', cls=GetStatusP2, order=3)
    data: GetDataSearchCriteria = Property('Search Criteria', cls=GetDataSearchCriteria, doc='Search criteria (and C-MAC if present).')

    def __init__(self, cla: int=128, p1: Union[GetStatusP1, int]=96, p2: Union[GetStatusP2, int]=2, aid: bytes=None, logic_channel_number: int=0) -> None:
        super().__init__(cla, Instruction.GET_STATUS, p1, p2, logic_channel_number)
        self.p1 = GetStatusP1(p1)
        self.p2 = GetStatusP2(p2)
        self.data = GetDataSearchCriteria(aid)

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.p1 = GetStatusP1(self.p1)
        self.p2 = GetStatusP1(self.p2)
        self.deserialize_property(cls.data, stream)

    def serialize_data(self, stream: BytesIO):
        self.data.serialize(stream)

class GlobalPlatformRegistryRelatedData(Object):
    aid: bytes = TlvProperty(79, bytes, doc='AID')
    life_cycle_state: bytes = TlvProperty(40816, bytes, doc='Life Cycle State; see section 11.1.1')
    privileges: bytes = TlvProperty(197, bytes, doc='Privileges (byte 1 - byte 2 - byte 3); see section 11.1.2')
    implicit_selection_parameters: List[int] = TlvProperty(207, ListType(int), doc='Implicit Selection Parameter; see section 11.1.7')
    application_executable_load_file_aid: bytes = TlvProperty(196, bytes, doc='Application’s Executable Load File AID')
    executable_load_file_version_number: bytes = TlvProperty(206, bytes, doc='Executable Load File Version Number')
    executable_module_aid: List[bytes] = TlvProperty(132, ListType(bytes), doc='Executable Module AIDs')
    associated_security_domain_aid: bytes = TlvProperty(204, bytes, doc='Associated Security Domain’s AID')

    def deserialize_from_tlv(self, stream: BytesIO, tlv: Tlv):
        cls = self.__class__
        tlv_nodes = Tlv.try_parse(stream, False, tlv.value_size)
        self.deserialize_tlv_property(cls.aid, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.life_cycle_state, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.privileges, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.implicit_selection_parameters, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.application_executable_load_file_aid, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.executable_load_file_version_number, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.executable_module_aid, stream, tlv_nodes)
        self.deserialize_tlv_property(cls.associated_security_domain_aid, stream, tlv_nodes)

    def __str__(self):
        cls = self.__class__
        values = [(p.title, p.__get__(self)) for p in [cls.aid, cls.life_cycle_state, cls.privileges, cls.implicit_selection_parameters, cls.application_executable_load_file_aid, cls.executable_load_file_version_number, cls.executable_module_aid, cls.associated_security_domain_aid]]
        name_len = max([len(i[0]) for i in values])
        return '\n'.join([f'{i[0].ljust(name_len)}: {i[1]}' for i in values if i[1]])

class GetStatusResponse(ResponseAPDU):
    data: List[GlobalPlatformRegistryRelatedData] = TlvProperty(227, ListType(GlobalPlatformRegistryRelatedData), doc='GlobalPlatform Application Data (TLV) or GlobalPlatform Executable Load File Data (TLV)')

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        tlv = Tlv.try_parse(stream, False)
        self.deserialize_tlv_property(cls.data, stream, tlv)

class KeyComponent(Object):
    key_type: KeyType = IntProperty('Key Type', KeyType)
    key_value_length: int = IntProperty('Length of Key Component', byteorder='big')
    key_value: bytes = Property('Key Value', bytes, doc='"Length (in bytes) of key component value + key component value" or "key component value"')
    key_check_value_length: int = IntProperty('Length of Key Check Value', int)
    key_check_value: bytes = Property('Key Check Value', bytes)

    def __init__(self, key_type: KeyType=None, key_value: bytes=None, key_check_value: bytes=None) -> None:
        super().__init__()
        self.key_type = key_type
        self.key_value = key_value
        self.key_check_value = key_check_value

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.key_type, stream, 2 if stream.peek_int() == 255 else 1)
        size = stream.peek_int(1)
        if size > 128:
            stream.seek(1)
            size = stream.read_int(size & 127, 'big')
        self.deserialize_property(cls.key_value_length, stream, size)
        if self.key_value_length:
            self.deserialize_property(cls.key_value, stream, size=self.key_value_length)
        self.deserialize_property(cls.key_check_value_length, stream, size)
        if self.key_check_value_length:
            self.deserialize_property(cls.key_check_value, stream, size=self.key_check_value)

    def serialize(self, stream: BytesIO):
        cls = self.__class__
        self.serialize_property(cls.key_type, stream)
        if self.key_value:
            self.key_value_length = len(self.key_value)
            if self.key_value_length <= 128:
                self.serialize_property(cls.key_value_length, stream)
            else:
                length = to_bytes(self.key_value_length)
                stream.write_byte(128 + len(length))
                stream.write(length)
            self.serialize_property(cls.key_value, stream)
        else:
            stream.write_byte(0)
        if self.key_check_value:
            self.key_check_value_length = len(self.key_check_value)
            self.serialize_property(cls.key_check_value_length, stream)
            self.serialize_property(cls.key_check_value, stream)
        else:
            stream.write_int(0)

class PutKeyData(Object):
    key_version_number: int = IntProperty('Key Version Number')
    keys: List[KeyComponent] = Property('Key Components', ListType(KeyComponent))
    Key_usage_qualifier_length: int = IntProperty('Length of Key Usage Qualifier')
    Key_usage_qualifier1: KeyUsageQualifier1 = Property('Key Usage Qualifier Byte1', KeyUsageQualifier1)
    Key_usage_qualifier2: KeyUsageQualifier2 = Property('Key Usage Qualifier Byte2', KeyUsageQualifier2)
    Key_access_length: int = IntProperty('Length of Key Access')
    key_access: List[KeyAccess] = Property('Key Access', ListType(KeyAccess))

    def __init__(self, key_version_number: int=0, keys: List[KeyComponent]=None) -> None:
        super().__init__()
        self.key_version_number = key_version_number
        self.keys = keys

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.key_version_number, stream)
        while stream.peek_int() >= 128:
            self.deserialize_property(cls.keys, stream)
        self.deserialize_property(cls.Key_usage_qualifier_length, stream)
        if self.Key_usage_qualifier_length == 0:
            pass
        elif self.Key_usage_qualifier_length == 1:
            self.deserialize_property(cls.Key_usage_qualifier1, stream)
        else:
            self.deserialize_property(cls.Key_usage_qualifier1, stream)
            self.deserialize_property(cls.Key_usage_qualifier2, stream)
            stream.seek(self.Key_usage_qualifier_length - 2)
        self.deserialize_property(cls.Key_access_length, stream)
        if self.Key_access_length:
            self.deserialize_property(cls.key_access, size=self.Key_access_length)

    def serialize(self, stream: BytesIO):
        cls = self.__class__
        self.serialize_property(cls.key_version_number, stream)
        if self.keys:
            for k in self.keys:
                k.serialize(stream)
        if self.Key_usage_qualifier1 == None and self.Key_usage_qualifier2 == None:
            if self.Key_usage_qualifier_length != None:
                stream.write_int(0)
        elif self.Key_usage_qualifier1 != None and self.Key_usage_qualifier2 == None:
            stream.write_int(1)
            self.serialize_property(cls.Key_usage_qualifier1, stream)
        elif self.Key_usage_qualifier1 != None and self.Key_usage_qualifier2 != None:
            stream.write_int(2)
            self.serialize_property(cls.Key_usage_qualifier1, stream)
            self.serialize_property(cls.Key_usage_qualifier2, stream)
        if self.key_access:
            self.Key_access_length = len(self.key_access)
            self.serialize_property(cls.Key_access_length, stream)
            for k in self.key_access:
                stream.write_int(int(k))

@register_command_packet(Instruction.PUT_KEY)
class PutKeyCommand(CommandAPDU):
    data: PutKeyData = Property('Data', PutKeyData)

    def __init__(self, cla: int=128, p1: int=0, p2: int=129, data: bytes=None, logic_channel_number: int=0) -> None:
        super().__init__(cla, Instruction.PUT_KEY, p1, p2, data, logic_channel_number)

    @property
    def more_put_key_cmd(self) -> bool:
        return self.p1 & 128 == 128

    @more_put_key_cmd.setter
    def more_put_key_cmd(self, v: bool):
        if v:
            self.p1 |= 128
        else:
            self.p1 &= 127

    @property
    def key_version_number(self) -> int:
        return self.p1 & 127

    @key_version_number.setter
    def key_version_number(self, v: int):
        self.p1 = self.p1 & 128 | v & 127

    @property
    def multiple_keys(self) -> bool:
        return self.p2 & 128 == 128

    @multiple_keys.setter
    def multiple_keys(self, v: bool):
        if v:
            self.p2 |= 128
        else:
            self.p2 &= 127

    @property
    def key_identifier(self) -> int:
        return self.p2 & 127

    @key_identifier.setter
    def key_identifier(self, v: int):
        self.p2 = self.p2 & 128 | v & 127

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.data, stream)

    def serialize(self, stream: BytesIO):
        self.multiple_keys = len(self.data.keys) > 1
        return super().serialize(stream)

    def serialize_data(self, stream: BytesIO):
        self.data.serialize(stream)

class PutKeyResponsePacket(ResponseAPDU):
    key_version_number: int = IntProperty('Key Version Number')
    key_check_value: bytes = Property('Key Check Value', bytes)

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        if self.status_ok:
            self.deserialize_property(cls.key_version_number, stream)
            self.deserialize_property(cls.key_check_value, stream, size=stream.length - 1)

class DataGroupingIdentifier(IntEnum):
    DGI_00B9 = (185, 'DGI CRT Tag')
    DGI_0010 = (16, 'Key Modulus')
    DGI_0011 = (17, 'RSA Public Key Exponent')
    DGI_8112 = (33042, 'RSA Private Key Exponent')
    DGI_8113 = (33043, 'Secret Key for Symmetric Scheme')
    DGI_8121 = (33057, 'RSA CRT constant q-1 mod p')
    DGI_8122 = (33058, 'RSA CRT constant d mod (q - 1)')
    DGI_8123 = (33059, 'RSA CRT constant d mod (p - 1)')
    DGI_8124 = (33060, 'RSA CRT constant prime factor q')
    DGI_8125 = (33061, 'RSA CRT constant prime factor p')
    DGI_0030 = (48, 'ECC P (field specification) Mandatory')
    DGI_0031 = (49, 'ECC A (first coefficient) Mandatory')
    DGI_0032 = (50, 'ECC B (second coefficient) Mandatory')
    DGI_0033 = (51, 'ECC G (generator) Mandatory')
    DGI_0034 = (52, 'ECC N (order of generator) Mandatory')
    DGI_0035 = (53, 'ECC k (cofactor of order of generator); default value "01" Optional')
    DGI_8137 = (33079, 'ECC d (private key)')

class DGIObject(Object):
    dgi: DataGroupingIdentifier = IntProperty('DGI', DataGroupingIdentifier, size=2, byteorder='big')
    length: int = Property('Length', int)
    value: bytes = Property('Value', bytes)

    def __init__(self) -> None:
        super().__init__()

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.tag, stream)
        self.deserialize_property(cls.length, stream)
        if self.length == 255:
            self.deserialize_property(cls.length, stream)
        if self.length:
            self.deserialize_value(stream)

    def _deserialize_value(self, stream: BytesIO):
        cls = self.__class__
        if self.length:
            self.deserialize_property(cls.value, stream)

class KeyControlReferenceTemplate(Object):
    key_usage_qualifier: Union[KeyUsageQualifier1, KeyUsageQualifier2] = Property('0x95', doc='Key Usage Qualifier values according to section 11.1.9 Mandatory')
    key_access: KeyAccess = Property('0x96', KeyAccess, doc='Key Access according to section 11.1.10 Optional')
    key_type: KeyType = Property('0x80', KeyType, doc='Key Type according to section 11.1.8 Mandatory')
    key_length: int = Property('0x81', int, doc='Key Length, in bytes (unsigned integer value) Mandatory')
    key_identifier: int = Property('0x82', int, doc='Key Identifier Mandatory')
    key_version_number: int = Property('0x83', int, doc='Key Version Number Mandatory')
    key_check_value: int = Property('0x84', int, doc='Key check value Mandatory')
    key_parameter_reference_value: ECCCurveType = Property('0x85', ECCCurveType, doc='ECC Curve Type')

    def __init__(self, key_usage_qualifier: Union[KeyUsageQualifier1, KeyUsageQualifier2]=None, key_access: KeyAccess=None, key_type: KeyType=None, key_length: int=None, key_identifier: int=None, key_version_number: int=None, key_check_value: int=None, key_parameter_reference_value: ECCCurveType=None) -> None:
        super().__init__()
        self.key_usage_qualifier = key_usage_qualifier
        self.key_access = key_access
        self.key_type = key_type
        self.key_length = key_length
        self.key_identifier = key_identifier
        self.key_version_number = key_version_number
        self.key_check_value = key_check_value
        self.key_parameter_reference_value = key_parameter_reference_value

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        tag_map = {149: cls.key_usage_qualifier, 150: cls.key_access, 128: cls.key_type, 129: cls.key_length, 130: cls.key_identifier, 131: cls.key_version_number, 132: cls.key_check_value, 133: cls.key_parameter_reference_value}
        while tag_map:
            tag = stream.read_tlv_tag()
            if tag not in tag_map:
                raise Exception(f'Bad Control Reference Template Tag 0x{tag:02X} at {stream.tell()}.')
            length = stream.read_tlv_length()
            self.deserialize_property(tag_map.pop(tag), stream, length)

    def serialize(self, stream: BytesIO):
        cls = self.__class__
        if self.key_usage_qualifier != None:
            stream.write_tlv(149, int(self.key_usage_qualifier))
        if self.key_access != None:
            stream.write_tlv(150, self.key_access)
        if self.key_type != None:
            stream.write_tlv(128, self.key_type)
        if self.key_length != None:
            stream.write_tlv(129, self.key_length)
        if self.key_identifier != None:
            stream.write_tlv(130, self.key_identifier)
        if self.key_version_number != None:
            stream.write_tlv(131, self.key_version_number)
        if self.key_check_value != None:
            stream.write_tlv(132, self.key_check_value)
        if self.key_parameter_reference_value != None:
            stream.write_tlv(133, self.key_parameter_reference_value)

class DgiKeyLoading(Object):
    kcrts: List[KeyControlReferenceTemplate] = Property('CRTs', KeyControlReferenceTemplate, doc='Control Reference Template(Tag=0xB9)')
    key_or_parameters: List[Tuple[DataGroupingIdentifier, bytes]] = Property('Keys', DGIObject, doc='Keys or key parameters for CRTs, DGI TLV')

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        if stream.read_dgi_tag() != DataGroupingIdentifier.DGI_00B9:
            raise Exception(f'Bad DGI at {stream.tell()}')
        stream.read_dgi_length()
        self.deserialize_property(cls.kcrts, stream)
        self.deserialize_property(cls.dgi_keys, stream)

    def serialize(self, stream: BytesIO):
        cls = self.__class__
        temp_stream = BytesIO()
        for crt in self.kcrts:
            temp_stream.write_tlv(185, crt.to_bytes())
        stream.write_dgi(185, temp_stream.getvalue())
        for (dgi, value) in self.key_or_parameters:
            stream.write_dgi(dgi.value, value)

class StoreDataEncryptionType(IntEnum):
    NO_ENCRYPTION = (0, 'No general encryption information or non-encrypted data')
    APP_DEPENDENT_ENCRYPTION = (1, 'Application dependent encryption of the data')
    RFU = (2, 'RFU (encryption indicator)')
    ENCRYPTED_DATA = (3, 'Encrypted data')

class StoreDataDataStructureType(IntEnum):
    NO_FORMAT = (0, 'No general data structure information')
    DGI_FORMAT = (1, 'DGI format of the command data field')
    TLV_FORMAT = (2, 'BER-TLV format of the command data field')
    RFU = (3, 'RFU (data structure information)')

class StoreDataP1(Object):
    pbf: int = Property('PBF', int, lsb=7, msb=7, doc='0: More blocks. 1: Last block.')
    encryption_type: StoreDataEncryptionType = Property('Encryption Type', StoreDataEncryptionType, lsb=5, msb=6)
    data_structure_type: StoreDataDataStructureType = Property('Data Structure Type', StoreDataDataStructureType, lsb=3, msb=4)
    response_type: int = Property('Response Type', int, lsb=0, msb=0, doc='0: ISO case 3 command (no response data expected); 1: ISO case 4 command (response data may be returned)')

    def __init__(self, pbf: Literal[0, 1]=0, encryption_type: StoreDataEncryptionType=StoreDataEncryptionType.RFU, data_structure_type: StoreDataDataStructureType=StoreDataDataStructureType.RFU, response_type: Literal[0, 1]=0) -> None:
        super().__init__()
        self.pbf = pbf
        self.encryption_type = encryption_type
        self.data_structure_type = data_structure_type
        self.response_type = response_type

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.pbf, stream, True)
        self.deserialize_property(cls.encryption_type, stream, True)
        self.deserialize_property(cls.data_structure_type, stream, True)
        self.deserialize_property(cls.response_type, stream)

    def serialize(self, stream: BytesIO):
        p1 = (self.pbf << 7) + (self.encryption_type << 5) + (self.data_structure_type << 3) + self.response_type
        stream.write_byte(p1)

    def __int__(self):
        return self.pbf << 7 & 128 | int(self.encryption_type) << 5 & 96 | int(self.data_structure_type) << 3 & 24 | self.response_type & 1

@register_command_packet(Instruction.STORE_DATA)
class StoreDataCommand(CommandAPDU):
    p1: StoreDataP1 = Property('P1', StoreDataP1, size=1, order=2)
    p2: int = IntProperty('P2', int, size=1, doc='Block Number', order=3)
    data: Union[bytes, DgiKeyLoading] = Property('Data', doc='Data structure depends on Data Structure Type of P1.')

    def __init__(self, cla: int=0, p1: StoreDataP1=None, p2: int=0, data: bytes=None, logic_channel_number: int=0) -> None:
        super().__init__(cla, Instruction.STORE_DATA, 0, p2, data, logic_channel_number)
        self.p1 = p1 or StoreDataP1()

    def _deserialize_p1p2(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream)
        self.deserialize_property(cls.p2, stream)

    def _deserialize(self, stream: BytesIO):
        cls = self.__class__
        if self.p1.data_structure_type == StoreDataDataStructureType.DGI_FORMAT:
            self.deserialize_property(cls.data, stream, cls=DgiKeyLoading)
        elif self.p1.data_structure_type == StoreDataDataStructureType.TLV_FORMAT:
            self.deserialize_property(cls.data, stream, cls=bytes)
        else:
            self.deserialize_property(cls.data, stream, cls=bytes)

    def serialize(self, stream: BytesIO):
        self.multiple_keys = len(self.data.keys) > 1
        return super().serialize(stream)

    def serialize_data(self, stream: BytesIO):
        if isinstance(self.data, bytes):
            stream.write(self.data)
        elif isinstance(self.data, DgiKeyLoading):
            self.data.serialize(stream)

    @staticmethod
    def new_store_symmetric_keys_cmd(kcrts: List[KeyControlReferenceTemplate], keys: List[bytes]) -> List['StoreDataCommand']:
        key_loading = DgiKeyLoading()
        key_loading.kcrts = kcrts
        key_loading.key_or_parameters = [(DataGroupingIdentifier.DGI_8113, key) for key in keys]
        data = key_loading.to_bytes()
        commands: List[StoreDataCommand] = []
        segments = [data[i:i + 247] for i in range(0, len(data), 247)]
        for (i, segment) in enumerate(segments):
            commands.append(StoreDataCommand(p1=StoreDataP1(0, StoreDataEncryptionType.NO_ENCRYPTION, StoreDataDataStructureType.DGI_FORMAT), p2=i & 255, data=segment))
        commands[-1].p1.pbf = 1
        return commands

    @staticmethod
    def new_store_symmetric_protocol_identifiers_cmd(protocol_identifiers: List[int]=[1, 2]) -> 'StoreDataCommand':
        return StoreDataCommand(p1=StoreDataP1(1, StoreDataEncryptionType.NO_ENCRYPTION, StoreDataDataStructureType.DGI_FORMAT), data=bytes.fromhex('BF71') + bytes([len(protocol_identifiers), *protocol_identifiers]))

class StoreDataResponsePacket(ResponseAPDU):

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__

class AuthenticationDataScp04(Object):
    protocol_identifier: int = IntProperty('Protocol Identifier')
    host_challenge: bytes = Property('Host Challenge', bytes, doc='Host challenge for SCP04.')

    def __init__(self, host_challenge: bytes=None, protocol_identifier: int=2) -> None:
        super().__init__()
        self.protocol_identifier = protocol_identifier
        self.host_challenge = host_challenge

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_tlv(stream, {128: cls.protocol_identifier, 138: cls.host_challenge})

    def serialize(self, stream: BytesIO):
        cls = self.__class__
        if self.protocol_identifier != None:
            stream.write_tlv(128, self.protocol_identifier)
        if self.host_challenge:
            stream.write_tlv(138, self.host_challenge)

@register_command_packet(Instruction.INITIALIZE_UPDATE)
class InitializeUpdateCommand(CommandAPDU):
    p1: int = IntProperty('P1')
    p2: int = IntProperty('P2')
    data: Union[bytes, AuthenticationDataScp04] = Property('Data', doc='Host challenge for SCP02/03, PID and Host challenge for SCP04.')

    def __init__(self, cla: int=128, p1: int=0, p2: int=0, data: bytes=None, logic_channel_number: int=0) -> None:
        super().__init__(cla, Instruction.INITIALIZE_UPDATE, p1, p2, data, logic_channel_number)

    def _deserialize_p1p2(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.p1, stream)
        self.deserialize_property(cls.p2, stream)

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.data, stream, cls=AuthenticationDataScp04 if self.p2 == 255 else bytes)

    def serialize_data(self, stream: BytesIO):
        cls = self.__class__
        self.serialize_property(cls.data, stream)

class InitializeUpdateResponseSCP02(Object):
    key_diversification_data: bytes = Property('Key Diversification Data', bytes, size=10)
    key_version_number: int = IntProperty('Key Version Number')
    scp_id: ScpId = IntProperty('Secure Channel Protocol Identifier', ScpId)
    sequence_counter: bytes = Property('Sequence Counter', bytes, size=2)
    card_challenge: bytes = Property('Card challenge', bytes, size=6)
    card_cryptogram: bytes = Property('Card cryptogram', bytes, size=8)

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.key_diversification_data, stream)
        self.deserialize_property(cls.key_version_number, stream)
        self.deserialize_property(cls.scp_id, stream)
        self.deserialize_property(cls.sequence_counter, stream)
        self.deserialize_property(cls.card_challenge, stream)
        self.deserialize_property(cls.card_cryptogram, stream)

class Scp03SecurityMode(IntEnum):
    S8 = 0
    S16 = 1

class InitializeUpdateResponseSCP03(Object):
    key_diversification_data: bytes = Property('Key Diversification Data', bytes, size=10)
    key_version_number: int = IntProperty('Key Version Number')
    scp_id: ScpId = IntProperty('Secure Channel Protocol Identifier', ScpId)
    scp_i: int = IntProperty('Secure Channel Protocol i')
    card_challenge: bytes = Property('Card challenge', bytes, size=8)
    card_cryptogram: bytes = Property('Card cryptogram', bytes, size=8)
    sequence_counter: bytes = Property('Sequence Counter', bytes, size=3)

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        self.deserialize_property(cls.key_diversification_data, stream)
        self.deserialize_property(cls.key_version_number, stream)
        self.deserialize_property(cls.scp_id, stream)
        self.deserialize_property(cls.scp_i, stream)
        self.deserialize_property(cls.card_challenge, stream)
        self.deserialize_property(cls.card_cryptogram, stream)
        if not stream.at_end():
            self.deserialize_property(cls.sequence_counter, stream)

    @property
    def security_mode(self):
        return Scp03SecurityMode.S16 if self.scp_i & 1 == 1 else Scp03SecurityMode.S8

class InitializeUpdateResponseSCP04(Object):
    key_diversification_data: bytes = Property('Key Diversification Data', bytes)
    key_information: bytes = Property('Key Information ', bytes, size=4)
    sequence_counter: bytes = Property('Sequence Counter', bytes, size=3)
    card_challenge: bytes = Property('Card challenge', bytes, size=8)
    card_cryptogram: bytes = Property('Card cryptogram', bytes, size=8)
    scp_id: ScpId = IntProperty('Secure Channel Protocol Identifier', ScpId)
    protocol_identifier: int = IntProperty('Protocol Identifier')
    scp_i: int = IntProperty('Secure Channel Protocol i')
    key_version_number: int = IntProperty('Key Version Number')

    def deserialize(self, stream: BytesIO):
        cls = self.__class__
        if 160 != stream.read_tlv_tag():
            raise Exception(f'INITIALIZE UPDATE Response Message MUST be start with 0xA0 Tag')
        size = stream.read_tlv_length()
        self.deserialize_tlv(stream, {144: cls.key_diversification_data, 145: cls.key_information, 146: cls.sequence_counter, 139: cls.card_challenge, 140: cls.card_cryptogram}, size_limit=size)
        self.scp_id = self.key_information[0]
        self.protocol_identifier = self.key_information[1]
        self.scp_i = self.key_information[2]
        self.key_version_number = self.key_information[3]

class InitializeUpdateResponsePacket(ResponseAPDU):
    data: Union[InitializeUpdateResponseSCP02, InitializeUpdateResponseSCP03, InitializeUpdateResponseSCP04] = Property('Data')

    def deserialize_data(self, stream: BytesIO):
        cls = self.__class__
        data_cls = bytes
        if stream.length == 28:
            data_cls = InitializeUpdateResponseSCP02
        elif stream.length == 29 or stream.length == 32:
            data_cls = InitializeUpdateResponseSCP03
        elif stream.peek_int() == 160 and stream.length > 32:
            data_cls = InitializeUpdateResponseSCP04
        self.deserialize_property(cls.data, stream, cls=data_cls)