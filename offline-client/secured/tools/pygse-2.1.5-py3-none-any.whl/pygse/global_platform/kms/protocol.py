from datetime import datetime
import json
import logging
from typing import Any, Dict, List, Literal, Tuple, Type, TypeVar, Union
from ...base.common import to_bytes, IntEnum, JsonEncodableObject, join_url, post
from ..base.apdu import KeyType
from ..base.key import AesSessionKeySet, DesSessionKeySet, Key, KeySet, KeySetAlgorithm, DesKeySet, AesKeySet, Sm4KeySet, Sm4SessionKeySet

class StatusCode(int):
    OK = 200
    E404 = 404
    E500 = 500

class Request(JsonEncodableObject):

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

class Response(JsonEncodableObject):
    status: StatusCode
    error: str
    data: Any

    def __init__(self, data: Any=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.data = data
        self.status = StatusCode(status)
        self.error = error

class ErrorResponse(JsonEncodableObject):
    status: Union[int, StatusCode]
    error: str
    data: Any

    def __init__(self, error: Any=None, status: Union[int, StatusCode]=StatusCode.E500, **kwargs) -> None:
        super().__init__(kwargs)
        self.status = status
        self.error = str(error)

class GetKeySetRequest(Request):
    chip_id: bytes = None
    security_domain: bytes = None
    key_version_number: int = None
    algorithm: KeySetAlgorithm = None

    def __init__(self, chip_id: Union[str, bytes]=None, security_domain: Union[str, bytes]=None, key_version_number: int=None, algorithm: KeySetAlgorithm=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.chip_id = to_bytes(chip_id)
        self.security_domain = to_bytes(security_domain)
        self.key_version_number = key_version_number
        self.algorithm = algorithm

class IKey(JsonEncodableObject):
    id: bytes = None
    key_set_id: bytes = None
    key_identifier: int = None
    key_type: int = None
    key_usage_qualifier: int = None
    key_access: int = None
    key_value: bytes = None
    key_check_value: bytes = None
    key_length: int = None
    update_time: datetime = None
    create_time: datetime = None

class IKeySet(JsonEncodableObject):

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        if self.keys:
            self.keys = [IKey(**k) if isinstance(k, dict) else k for k in self.keys or []]
    id: bytes = None
    chip_id: bytes = None
    security_domain: bytes = None
    key_version_number: int = None
    algorithm: KeySetAlgorithm = None
    update_time: datetime = None
    create_time: datetime = None
    keys: List[IKey] = None

class GetKeySetResponse(Response):
    data: IKeySet = None

    def __init__(self, data: Union[Dict, IKeySet]=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if isinstance(data, dict):
            self.data = IKeySet(**data)

class NewKeySetRequest(Request):
    chip_id: bytes = None
    security_domain: bytes = None
    algorithm: KeySetAlgorithm = None
    key_version_number: int = None
    key_length: int = None
    key_enc: bytes = None
    key_mac: bytes = None
    key_dek: bytes = None

    def __init__(self, chip_id: Union[str, bytes]=None, security_domain: Union[str, bytes]=None, key_version_number: int=None, algorithm: KeySetAlgorithm=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.chip_id = to_bytes(chip_id)
        self.security_domain = to_bytes(security_domain)
        self.key_version_number = key_version_number
        self.algorithm = algorithm
        self.key_length = key_length
        self.key_enc = to_bytes(key_enc)
        self.key_mac = to_bytes(key_mac)
        self.key_dek = to_bytes(key_dek)

class NewKeySetResponse(Response):
    data: IKeySet = None

    def __init__(self, data: Union[Dict, IKeySet]=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if isinstance(data, dict):
            self.data = IKeySet(**data)

class SaveKeySetRequest(Request):
    key_set_id: Union[bytes, IKeySet] = None
    override: bool = False

    def __init__(self, key_set_id: Union[str, bytes], override: bool=False, **kwargs) -> None:
        super().__init__(**kwargs)
        self.key_set_id = to_bytes(key_set_id)
        self.override = override

class SaveKeySetResponse(Response):
    data: IKeySet = None

    def __init__(self, data: Union[Dict, IKeySet]=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if isinstance(data, dict):
            self.data = IKeySet(**data)

class DeleteKeySetRequest(Request):
    chip_id: bytes
    key_version_number: int
    security_domain: bytes
    key_set_id: bytes

    def __init__(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes]=None, key_version_number: int=None, key_set_id: Union[str, bytes]=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.chip_id = to_bytes(chip_id)
        self.security_domain = to_bytes(security_domain)
        self.key_version_number = int(key_version_number)
        self.key_set_id = to_bytes(key_set_id)

class DeleteKeySetResponse(Response):

    def __init__(self, data: int=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(None, status, error, **kwargs)

class DeriveSessionKeysRequest(Request):
    key_set_id: Union[str, bytes] = None
    sequence_counter: Union[str, bytes] = (None,)
    host_challenge: Union[str, bytes] = (None,)
    card_challenge: Union[str, bytes] = (None,)
    protocol_identifier: int = (2,)
    supported_protocol_configuration_list: List[int] = ([2],)

    def __init__(self, key_set_id: Union[str, bytes]=None, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2], **kwargs) -> None:
        super().__init__(**kwargs)
        self.key_set_id = to_bytes(key_set_id)
        self.key_set_id = to_bytes(key_set_id)
        self.sequence_counter = to_bytes(sequence_counter)
        self.host_challenge = to_bytes(host_challenge)
        self.card_challenge = to_bytes(card_challenge)
        self.protocol_identifier = protocol_identifier
        self.supported_protocol_configuration_list = supported_protocol_configuration_list

class DeriveSessionKeysResponse(Response):
    data: IKeySet = None

    def __init__(self, data: Union[Dict, IKeySet]=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if isinstance(data, dict):
            self.data = IKeySet(**data)

class EncryptKeySetRequest(Request):
    session_key_set_id: bytes = None
    key_set_id: bytes = None

    def __init__(self, session_key_set_id: Union[str, bytes]=None, key_set_id: Union[str, bytes]=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.session_key_set_id = to_bytes(session_key_set_id)
        self.key_set_id = to_bytes(key_set_id)

class EncryptKeySetResponse(Response):
    data: IKeySet = None

    def __init__(self, data: Union[Dict, IKeySet], status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if isinstance(data, dict):
            self.data = IKeySet(**data)

class EncryptKeySetAesRequest(Request):
    dek_id: bytes = None
    key_set_id: bytes = None

    def __init__(self, dek_id: Union[str, bytes]=None, key_set_id: Union[str, bytes]=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.dek_id = to_bytes(dek_id)
        self.key_set_id = to_bytes(key_set_id)

class EncryptKeySetAesResponse(Response):
    data: List[Tuple[KeyType, bytes, bytes]] = None

    def __init__(self, data: List[Tuple[KeyType, bytes, bytes]]=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if self.data:
            self.data = [(KeyType(kt), to_bytes(cipher), to_bytes(mac)) for (kt, cipher, mac) in self.data]

class EncryptKeySetDesRequest(Request):
    dek: bytes = None
    key_set_id: bytes = None

    def __init__(self, dek: Union[str, bytes]=None, key_set_id: Union[str, bytes]=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.dek = to_bytes(dek)
        self.key_set_id = to_bytes(key_set_id)

class EncryptKeySetDesResponse(Response):
    data: List[Tuple[KeyType, bytes, bytes]] = None

    def __init__(self, data: List[Tuple[KeyType, bytes, bytes]]=None, status: Union[int, StatusCode]=StatusCode.OK, error: str=None, **kwargs) -> None:
        super().__init__(data, status, error, **kwargs)
        if self.data:
            self.data = [(KeyType(kt), to_bytes(cipher), to_bytes(mac)) for (kt, cipher, mac) in self.data]

def to_api_key(key: Key, include_key_value: bool=None) -> IKey:
    obj = IKey()
    obj.__dict__.update({k: v for (k, v) in key.__dict__.items() if k in IKey.__dict__})
    if not include_key_value:
        obj.key_value = None
        obj.key_check_value = None
    return obj

def to_kms_key(key: IKey) -> Key:
    obj = Key()
    obj.__dict__.update(key.__dict__)
    if key.id:
        obj.id = to_bytes(obj.id)
    if key.key_set_id:
        obj.key_set_id = to_bytes(obj.key_set_id)
    if key.key_value:
        obj.key_value = to_bytes(obj.key_value)
    if key.key_check_value:
        obj.key_check_value = to_bytes(obj.key_check_value)
    return obj

def to_kms_key_set(key_set: IKeySet, cls=None) -> KeySet:
    if not cls:
        if key_set.algorithm == KeySetAlgorithm.DES:
            obj = DesKeySet()
        elif key_set.algorithm == KeySetAlgorithm.AES:
            obj = AesKeySet()
        elif key_set.algorithm == KeySetAlgorithm.SM4:
            obj = Sm4KeySet()
        else:
            obj = KeySet()
    else:
        obj = cls()
    obj.__dict__.update(key_set.__dict__)
    obj.keys = {k.key_identifier: to_kms_key(k) for k in key_set.keys}
    return obj

def to_api_key_set(key_set: KeySet, include_key_value: bool=None) -> IKeySet:
    obj = IKeySet()
    obj.__dict__.update({k: v for (k, v) in key_set.__dict__.items() if k in IKeySet.__dict__})
    obj.keys = [to_api_key(k, include_key_value) for k in key_set.keys.values()]
    return obj

class KmsApiType:
    GET_KEY_SET = 'get-key-set'
    NEW_KEY_SET = 'new-key-set'
    SAVE_KEY_SET = 'save-key-set'
    DELETE_KEY_SET = 'delete-key-set'
    DERIVE_SESSION_KEYS = 'derive-session-keys'
    REPLACE_KEY_SET = 'replace-key-set'
    ENCRYPT_KEY_SET = 'encrypt_key_set'
    ENCRYPT_KEY_SET_AES = 'encrypt_key_set_aes'
    ENCRYPT_KEY_SET_DES = 'encrypt_key_set_des'
    ENCRYPT = 'encrypt'
    DECRYPT = 'decrypt'

    def __str__(self):
        return self.value
T_REQ = TypeVar('T_REQ', bound=Request)
T_RSP = TypeVar('T_RSP', bound=Response)

class KmsClient:

    def __init__(self, kms_address: str) -> None:
        super().__init__()
        self.kms_address = kms_address
        self.kms_api_path = 'kms/api'
        self.logger = logging.getLogger(self.__class__.__name__)

    async def __request(self, api: KmsApiType, data: T_REQ, rsp_cls: Type[T_RSP], silent: bool=False) -> T_RSP:
        url = join_url(self.kms_address, self.kms_api_path, api)
        json_data = json.dumps(data)
        self.logger.debug(f'POST {url}, data={json_data}')
        response = await post(url, json_data)
        self.logger.debug(f'RSP: {response.body}')
        if response.code != 200:
            err = f'{url} failed! StatusCode={response.status_code}, error={response.body}'
            raise Exception(err)
        rsp = rsp_cls(**json.loads(response.body))
        if rsp.status != StatusCode.OK:
            err = f'{url} failed! status={rsp.status}, error={rsp.error}'
            if not silent:
                raise Exception(err)
            else:
                self.logger.error(err)
        return rsp

    async def get_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: KeySetAlgorithm=None) -> KeySet:
        req = GetKeySetRequest(chip_id, security_domain, key_version_number, algorithm)
        rsp = await self.__request(KmsApiType.GET_KEY_SET, req, GetKeySetResponse)
        return to_kms_key_set(rsp.data)

    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: KeySetAlgorithm=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        req = NewKeySetRequest(chip_id, security_domain, key_version_number, algorithm, key_length, key_enc, key_mac, key_dek)
        rsp = await self.__request(KmsApiType.NEW_KEY_SET, req, NewKeySetResponse)
        return to_kms_key_set(rsp.data)

    async def save_key_set(self, key_set_id: Union[str, bytes], override: bool=False) -> IKeySet:
        req = SaveKeySetRequest(key_set_id, override)
        rsp = await self.__request(KmsApiType.SAVE_KEY_SET, req, SaveKeySetResponse)
        return to_kms_key_set(rsp.data)

    async def delete_key_set_by_kvn(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int) -> int:
        req = DeleteKeySetRequest(chip_id, security_domain, key_version_number)
        rsp = await self.__request(KmsApiType.DELETE_KEY_SET, req, DeleteKeySetResponse, True)
        return rsp.status

    async def derive_session_keys(self, key_set_id: Union[str, bytes], *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]:
        req = DeriveSessionKeysRequest(key_set_id, sequence_counter=sequence_counter, host_challenge=host_challenge, card_challenge=card_challenge, protocol_identifier=protocol_identifier, supported_protocol_configuration_list=supported_protocol_configuration_list)
        rsp = await self.__request(KmsApiType.DERIVE_SESSION_KEYS, req, DeriveSessionKeysResponse)
        if rsp.data:
            if rsp.data.algorithm == KeySetAlgorithm.DES:
                return to_kms_key_set(rsp.data, DesSessionKeySet)
            if rsp.data.algorithm == KeySetAlgorithm.AES:
                return to_kms_key_set(rsp.data, AesSessionKeySet)
            if rsp.data.algorithm == KeySetAlgorithm.SM4:
                return to_kms_key_set(rsp.data, Sm4SessionKeySet)
        raise Exception(f'Can not derive session keys!')

    async def encrypt_key_set(self, session_key_set_id: Union[str, bytes], key_set_id: Union[str, bytes]) -> KeySet:
        req = EncryptKeySetRequest(session_key_set_id, key_set_id)
        rsp = await self.__request(KmsApiType.ENCRYPT_KEY_SET, req, EncryptKeySetResponse)
        if rsp.data:
            return to_kms_key_set(rsp.data)
        raise Exception(f'Can not encrypt key set!')

    async def encrypt_key_set_aes(self, dek_id: Union[str, bytes], key_set_id: Union[str, bytes]) -> List[Tuple[KeyType, bytes, bytes]]:
        req = EncryptKeySetAesRequest(dek_id, key_set_id)
        rsp = await self.__request(KmsApiType.ENCRYPT_KEY_SET_AES, req, EncryptKeySetAesResponse)
        return rsp.data

    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set_id: Union[str, bytes]) -> List[Tuple[KeyType, bytes, bytes]]:
        req = EncryptKeySetDesRequest(dek, key_set_id)
        rsp = await self.__request(KmsApiType.ENCRYPT_KEY_SET_DES, req, EncryptKeySetDesResponse)
        return rsp.data
__all__ = [StatusCode.__name__, Request.__name__, Response.__name__, ErrorResponse.__name__, GetKeySetRequest.__name__, GetKeySetResponse.__name__, NewKeySetRequest.__name__, NewKeySetResponse.__name__, SaveKeySetRequest.__name__, SaveKeySetResponse.__name__, DeleteKeySetRequest.__name__, DeleteKeySetResponse.__name__, DeriveSessionKeysRequest.__name__, DeriveSessionKeysResponse.__name__, EncryptKeySetRequest.__name__, EncryptKeySetResponse.__name__, EncryptKeySetAesRequest.__name__, EncryptKeySetAesResponse.__name__, EncryptKeySetDesRequest.__name__, EncryptKeySetDesResponse.__name__, KmsApiType.__name__, KmsClient.__name__, to_api_key.__name__, to_api_key_set.__name__]