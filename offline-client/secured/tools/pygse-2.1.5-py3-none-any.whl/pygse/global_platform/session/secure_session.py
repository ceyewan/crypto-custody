import logging
from asyncio import sleep
from dataclasses import dataclass, field
from time import time
from typing import Type, TypeVar
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import *
from ...base.common import to_bytes, Tlv
from ...components.kms.common import IKmsService
from ..base.apdu import *
from ..base.cap_file import *
from ..base.exception import *
from ..base.key import *
from ..base.security_device import *
from ..scp import *
T_RSP = TypeVar('T_RSP', bound=ResponseAPDU)

def _input_app_aid(file_aid: bytes, module_aid: bytes) -> bytes:
    while True:
        aid = input('\n'.join([f'即将安装可执行模块为可选择应用:', f'  文件AID：{hex(file_aid)}', f'  模块AID：{hex(module_aid)}', f'请输入5-16字节Hex字符串作为应用AID，如果想直接使用可执行模块的AID作为应用AID，请直接按Enter({hex(module_aid)}): '])).strip()
        if not aid:
            return module_aid
        try:
            aid = to_bytes(aid)
            if len(aid) >= 5 and len(aid) <= 16:
                return aid
        except:
            logging.error(f'无效的AID，请重新输入！')
            pass

@dataclass
class SecureSessionOptions:
    sd: Union[bytes, str] = field(default=None)
    aid: Union[bytes, str] = field(default=None)
    key_version_number: int = field(default=0)
    secure_level: SecureLevel = field(default=SecureLevel.C_MAC)

class SecureSession:
    options: SecureSessionOptions
    sd_key_set: KeySet = None
    secure_channel: ISecureChannel = None

    def __init__(self, device: SecurityDevice, kms_service: IKmsService, options: SecureSessionOptions=None) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.device = device
        self.kms_service = kms_service
        self.options = options or SecureSessionOptions()

    @property
    def scp_id(self):
        return self.secure_channel.scp_id if self.secure_channel else None

    async def select(self, aid: Union[bytes, str]=None, p1: int=4, p2: Literal[0, 2]=0):
        aid = to_bytes(aid)
        rsp = await self.device.select(aid, p1, p2)
        if self.secure_channel and self.secure_channel.scp_id != ScpId.SCP00:
            self.logger.info(f'The current secure channel {self.secure_channel.scp_id.name} will closed by the SELECT instruction.')
            self.secure_channel = None
        if rsp.status_ok:
            self.options.aid = aid
            self.logger.info(f"Device was selected with AID={(hex(aid) if aid else '(Default ISD)')}.")
        else:
            raise GPException(rsp.status_code, f'Can not select AID=({hex(self.options.aid)}).')
        return rsp

    async def create_secure_channel(self):
        if self.secure_channel:
            return
        key_version_number = self.options.key_version_number or 0
        if key_version_number < 0:
            rsp = await self.device.select(self.options.aid)
            if not rsp.status_ok:
                raise GPException(rsp.status_code, f'Can not select AID({hex(self.options.aid)}).')
            self.secure_channel = Scp00SecurityChannel(self.options.aid)
            return
        if key_version_number > 0:
            self.sd_key_set = await self.kms_service.init_key_set(self.device.chip_id, security_domain=self.options.sd, key_version_number=key_version_number)
        initialize_update_data = host_challenge = get_random_bytes(16 if self.sd_key_set and self.sd_key_set.algorithm == KeySetAlgorithm.SM4 else 8)
        p2 = 0
        scp04_supported_protocol_configuration_list = None
        if self.sd_key_set and self.sd_key_set.algorithm == KeySetAlgorithm.SM4:
            rsp = await self.device.select(self.options.sd)
            if not rsp.status_ok:
                raise GPException(rsp.status_code, f'Can not select AID({hex(self.options.aid)}).')
            data = await self.get_data(191, 113)
            if data:
                scp04_supported_protocol_configuration_list = list(data)
            else:
                self.logger.warning(f'Can not get Protocol Configuration List, try using SM4([0x02])')
                scp04_supported_protocol_configuration_list = [2]
            p2 = 255
            initialize_update_data = AuthenticationDataScp04(host_challenge)
        if self.options.aid != self.options.sd:
            rsp = await self.device.select(self.options.aid)
            if not rsp.status_ok:
                raise GPException(rsp.status_code, f'Can not select AID({hex(self.options.aid)}).')
        req = InitializeUpdateCommand(p1=key_version_number, p2=p2, data=initialize_update_data)
        start_time = time()
        rsp = await self.device.transmit(req, InitializeUpdateResponsePacket)
        if rsp.status_code == StatusCode.SW6985:
            msg = '\n设备返回错误码6985，意味着某组密钥可能已经因为认证失败次数过多而被锁定。要解决这个问题，需要执行以下步骤：\n    1. 确认被锁定的密钥的版本号。可以通过--kvn参数显示指定密钥版本号，根据是否返回6985来确定。\n    2. 使用del-key命令删除被锁定的密钥集。\n    3. 最后，使用put-key命令，通过另外一组可用的密钥建立安全通道，添加一组对应算法的新密钥集，新密钥集的版本号和密钥值可以和被删除的重复。\n例如：\n    1. 如果pygse ls --kvn=20返回6985，则意味着0x20的的密钥集已经无法使用。\n    2. 使用pygse del-key --kvn=30 0x20，通过SCP30删除0x20密钥集。\n    3. 再使用put-key添加一组新密钥：pygse put-key --kvn=30 --kvn-new=20 --key-alg-new=DES --key-enc-new=... --key-mac-new=... --key-dek-new=...\n'.strip()
            self.logger.warning(msg)
        end_time = time()
        if end_time - start_time >= 30:
            self.logger.warning(f'INITIALIZE UPDATE耗时过长，SE可能已经进入保护模式，请使用正确的密钥建立安全通道以解决此问题。')
        if not rsp.status_ok:
            raise GPException(rsp.status_code, 'INITIALIZE_UPDATE Failed')
        self.logger.info(f'Creating secure channel using SCP{int(rsp.data.scp_id):02X} with KVN=0x{rsp.data.key_version_number:02X}.')
        if not self.sd_key_set:
            self.sd_key_set = await self.kms_service.init_key_set(self.device.chip_id, security_domain=self.options.sd, scp_id=rsp.data.scp_id, key_version_number=rsp.data.key_version_number)
        if isinstance(rsp.data, InitializeUpdateResponseSCP02):
            session_key_set: DesSessionKeySet = await self.kms_service.derive_session_keys(self.sd_key_set, sequence_counter=rsp.data.sequence_counter)
            host_data = rsp.data.sequence_counter + rsp.data.card_challenge + host_challenge + bytes.fromhex('8000000000000000')
            host_cryptogram = scp02_mac_3des(session_key_set.enc.key_value, host_data)
            self.secure_channel = Scp02SecurityChannel(self.options.aid, session_key_set, self.options.secure_level)
            req = CommandAPDU(cla=132, ins=Instruction.EXTERNAL_AUTHENTICATE, p1=SecureLevel.C_MAC, p2=0, data=host_cryptogram)
            rsp = await self.transmit(req)
            if not rsp.status_ok:
                self.secure_channel = None
                raise GPException(rsp.status_code, 'EXTERNAL_AUTHENTICATE failed! Please double-check the KEY-ENC, KEY-MAC, and KEY-DEK values in the SCP02 key set to ensure they are correctly configured.')
        elif isinstance(rsp.data, InitializeUpdateResponseSCP03):
            auth_context = host_challenge + rsp.data.card_challenge
            session_key_set: AesSessionKeySet = await self.kms_service.derive_session_keys(self.sd_key_set, host_challenge=host_challenge, card_challenge=rsp.data.card_challenge)
            card_verify_cryptogram = scp03_kdf(session_key_set.mac.key_value, Scp03DerivationConstants.CARD_CRYPTOGRAM, auth_context, len(rsp.data.card_cryptogram))
            if card_verify_cryptogram != rsp.data.card_cryptogram:
                raise GPException(rsp.status_code, 'Verification of the card cryptogram failed using the current session key set. Please double-check the KEY-ENC, KEY-MAC, and KEY-DEK values in the SCP03 key set to ensure they are correctly configured.')
            host_cryptogram = scp03_kdf(session_key_set.mac.key_value, Scp03DerivationConstants.HOST_CRYPTOGRAM, auth_context, len(rsp.data.card_cryptogram))
            self.secure_channel = Scp03SecurityChannel(self.options.aid, session_key_set, self.options.secure_level, rsp.data.security_mode)
            req = CommandAPDU(cla=132, ins=Instruction.EXTERNAL_AUTHENTICATE, p1=SecureLevel.C_MAC, p2=0, data=host_cryptogram)
            rsp = await self.transmit(req)
            if not rsp.status_ok:
                self.secure_channel = None
                raise GPException(rsp.status_code, 'EXTERNAL_AUTHENTICATE failed!')
        elif isinstance(rsp.data, InitializeUpdateResponseSCP04):
            auth_context = host_challenge + rsp.data.card_challenge
            session_key_set: AesSessionKeySet = await self.kms_service.derive_session_keys(self.sd_key_set, host_challenge=host_challenge, card_challenge=rsp.data.card_challenge, supported_protocol_configuration_list=scp04_supported_protocol_configuration_list)
            card_verify_cryptogram = scp04_kdf(session_key_set.mac.key_value, Scp04DerivationConstants.CARD_CRYPTOGRAM, auth_context)
            if card_verify_cryptogram != rsp.data.card_cryptogram:
                raise GPException(rsp.status_code, 'Verification of the card cryptogram failed using the current session key set. Please double-check the KEY-ENC, KEY-MAC, and KEY-DEK values in the SCP04 key set to ensure they are correctly configured.')
            host_cryptogram = scp04_kdf(session_key_set.mac.key_value, Scp04DerivationConstants.HOST_CRYPTOGRAM, auth_context)
            self.secure_channel = Scp04SecurityChannel(self.options.aid, session_key_set, self.options.secure_level)
            req = CommandAPDU(cla=132, ins=Instruction.EXTERNAL_AUTHENTICATE, p1=SecureLevel.C_MAC, p2=0, data=Tlv.build(141, host_cryptogram, True))
            rsp = await self.transmit(req)
            if not rsp.status_ok:
                self.secure_channel = None
                raise GPException(rsp.status_code, 'EXTERNAL_AUTHENTICATE failed!')

    async def transmit(self, apdu: Union[CommandAPDU, str, bytes], rsp_cls: Type[T_RSP]=ResponseAPDU) -> T_RSP:
        if isinstance(apdu, (str, bytes)):
            req = CommandAPDU().deserialize(BytesIO(apdu))
        else:
            req = apdu
        if req.ins == Instruction.SELECT:
            return await self.select(req.data, p1=req.p1, p2=req.p2)
        if self.secure_channel:
            req = self.secure_channel.encrypt(req)
        rsp = await self.device.transmit(req)
        if self.secure_channel:
            rsp = self.secure_channel.decrypt(rsp)
        return rsp_cls(rsp.raw) if rsp_cls != ResponseAPDU else rsp

    async def install_for_load(self, file_aid: Union[bytes, str], sd_aid: Union[bytes, str]=None, data_block_hash: Union[bytes, str]=None, load_parameters: Union[bytes, str]=None, load_token: Union[bytes, str]=None):
        await self.create_secure_channel()
        data = BytesIO()
        data.write_lv(file_aid)
        data.write_lv(sd_aid)
        data.write_lv(data_block_hash)
        data.write_lv(load_parameters)
        data.write_lv(load_token)
        req = CommandAPDU(ins=Instruction.INSTALL, p1=InstallP1Coding.FOR_LOAD, p2=0, data=data.getvalue())
        rsp = await self.transmit(req)
        GPException.check(rsp, 'Install for load failed')

    async def load_cap(self, cap_file: Union[CapFile, str], include_debug: bool=False, payload_size: int=None):
        payload_size = payload_size or 255
        max_payload_size = 255 if payload_size <= 255 else 65535
        if self.secure_channel:
            payload_size = min(payload_size, max_payload_size - self.secure_channel.cmac_length)
        cap_file = cap_file if isinstance(cap_file, CapFile) else CapFile(cap_file)
        apdu_list: List[CommandAPDU] = cap_file.to_apdu(payload_size, include_debug, include_install_for_load=False)
        for apdu in apdu_list:
            rsp = await self.transmit(apdu)
            GPException.check(rsp, 'Load failed!')
        self.logger.info(f"Successfully loaded {cap_file.filename} to {hex(self.options.sd) or 'default ISD'}.")

    async def load_apdu_script(self, file_path: str):
        apdus = []
        with open(file_path, 'r') as f:
            for line in f.readlines():
                loadblock = ''.join(line.split())
                if len(loadblock) != 0 and (loadblock.find('80E4') != -1 or loadblock.find('80e4') != -1 or loadblock.find('80E800') != -1 or (loadblock.find('80e800') != -1) or (loadblock.find('80E880') != -1) or (loadblock.find('80e880') != -1)):
                    apdus.append(loadblock)
        for apdu in apdus:
            rsp = await self.transmit(bytes.fromhex(apdu))
            GPException.check(rsp, 'Load failed')

    async def install_make_selectable(self, file_aid: Union[bytes, str], executable_module_aid: Union[bytes, str], application_aid: Union[bytes, str]=None, privileges: Union[bytes, str, int]=0, install_parameters: Union[bytes, str]=51456, install_token: Union[bytes, str]=None):
        data = BytesIO()
        data.write_lv(file_aid)
        data.write_lv(executable_module_aid)
        data.write_lv(application_aid or executable_module_aid)
        data.write_lv(privileges or 0)
        data.write_lv(install_parameters or 51456)
        data.write_lv(install_token)
        req = CommandAPDU(ins=Instruction.INSTALL, p1=InstallP1Coding.FOR_INSTALL | InstallP1Coding.FOR_MAKE_SELECTABLE, p2=0, data=data.getvalue())
        rsp = await self.transmit(req)
        GPException.check(rsp, 'Install for INSTALL and MAKE_SELECTABLE failed!')

    async def install_cap(self, cap_files: Union[str, CapFile, List[Union[str, CapFile]]], for_make_selectable: bool=False, load_parameters: Union[bytes, str]=None, install_parameters: Union[bytes, str]=None, install_privileges: Union[bytes, str, int]=0, app_aid: bytes=None, include_debug: bool=False, payload_size: int=None) -> None:
        await self.create_secure_channel()
        cap_files = cap_files if isinstance(cap_files, list) else [cap_files]
        for cap_file in cap_files:
            file = cap_file if isinstance(cap_file, CapFile) else CapFile(cap_file)
            code = await self.delete_aid(file.cap_aid)
            if code not in (StatusCode.SW9000, StatusCode.SW6A82, StatusCode.SW6A86, StatusCode.SW6A88):
                raise GPException(code, f'Can not delete {hex(file.cap_aid)}.')
            await self.install_for_load(file.cap_aid, load_parameters=load_parameters)
            await self.load_cap(file, include_debug, payload_size)
            if for_make_selectable:
                for module_aid in file.applet_aids:
                    if len(file.applet_aids) == 1 and app_aid:
                        input_app_aid = module_aid if app_aid in ('.', b'.') else app_aid
                    else:
                        input_app_aid = _input_app_aid(file.cap_aid, module_aid)
                    await self.install_make_selectable(file.cap_aid, module_aid, input_app_aid, install_privileges, install_parameters)
                    self.logger.info(f'已安装可执行(MAKE SELECTABLE)应用。文件AID：{hex(file.cap_aid)}，模块AID：{hex(module_aid)}，应用AID：{hex(input_app_aid)}')
                self.logger.info(f"Successfully installed {file.filename} to {hex(self.options.sd) or 'default ISD'}.")
            await sleep(0.1)

    async def delete_aid(self, aid: Union[str, bytes], is_delete_related: bool=True) -> StatusCode:
        await self.create_secure_channel()
        aid = to_bytes(aid)
        data = bytes([79, len(aid)]) + aid
        if is_delete_related:
            p2 = 128
        else:
            p2 = 0
        req = CommandAPDU(ins=Instruction.DELETE, p1=0, p2=p2, data=data)
        rsp = await self.transmit(req)
        if rsp.status_code == StatusCode.SW9000:
            self.logger.info(f'Successfully deleted：{hex(aid)}')
        elif rsp.status_code == StatusCode.SW6A88:
            self.logger.warning(f'AID={hex(aid)} does not exits!')
        elif rsp.status_code == StatusCode.SW6A86:
            self.logger.info(f'Delete {hex(aid)} failed! SW={str(rsp.status_code)}. Using -r option to delete file. Omit -r option to delete installed app.')
        elif rsp.status_code == StatusCode.SW6985:
            self.logger.info(f'Delete {hex(aid)} failed! SW={str(rsp.status_code)}. This file with AID={hex(aid)} maybe used by another applet, you must delete the applet(s) first.')
        else:
            self.logger.info(f'Delete {hex(aid)} failed! SW={str(rsp.status_code)}.')
        return rsp.status_code

    async def delete_key(self, key_version_number: int=None, key_identifier: int=None):
        data = bytearray()
        if key_version_number != None:
            data.extend([210, 1, key_version_number])
        elif key_identifier != None:
            data.extend([208, 1, key_identifier])
        else:
            raise Exception('At least one of the key word argument of key_version_number and key_identifier must be given!')
        await self.create_secure_channel()
        req = CommandAPDU(ins=Instruction.DELETE, p1=0, p2=128, data=bytes(data))
        rsp = await self.transmit(req)
        kvn = f'0x{key_version_number:02X}' if key_version_number != None else 'None'
        kid = f'0x{key_identifier:02X}' if key_identifier != None else 'None'
        if rsp.status_ok:
            self.logger.info(f'Successfully deleted key(s) from device where KeyVersionNumber={kvn} and KeyIdentifier={kid}!')
        elif rsp.status_code == StatusCode.SW6A88:
            self.logger.warning(f'Delete key(s) failed because the key(s) with KeyVersionNumber={kvn} and KeyIdentifier={kid} does not exist on the device!')
        else:
            self.logger.error(f'Failed to key(s) with KeyVersionNumber={kvn} and KeyIdentifier={kid}! code={rsp.status_code}.')
        return rsp.status_code

    async def put_key_set(self, key_set: KeySet, replace: bool=False):
        await self.create_secure_channel()
        if key_set.key_version_number < 1 or key_set.key_version_number > 127:
            raise Exception('The key version number should in in the range of [0x01 ~ 0x7F].')
        encrypted_key_set = await self.kms_service.encrypt_key_set(self.secure_channel.session_key_set, key_set)
        if key_set.algorithm in (KeySetAlgorithm.AES, KeySetAlgorithm.DES):
            cmd = PutKeyCommand()
            cmd.key_identifier = min(key_set.keys.keys())
            if replace:
                cmd.key_version_number = key_set.key_version_number
            cmd.data = PutKeyData(key_set.key_version_number, [KeyComponent(k.key_type, k.key_value, k.key_check_value) for k in encrypted_key_set.keys.values()])
            resp = await self.transmit(cmd, PutKeyResponsePacket)
            if resp.status_code == StatusCode.SW6A88 and replace:
                self.logger.info(f'Can not put a new key set with --replace option, retry without --replace option.')
                cmd.key_version_number = 0
                resp = await self.transmit(cmd, PutKeyResponsePacket)
            if not resp.status_ok:
                msg = 'Put Key Failed!'
                if not replace and resp.status_code == 27264:
                    msg += ' Please retry with -r or --replace option for replacing an existing key set.'
                raise GPException(resp.status_code, msg)
        elif key_set.algorithm in (KeySetAlgorithm.SM4,):
            if replace:
                await self.delete_key(key_set.key_version_number)
            kcrts = [KeyControlReferenceTemplate(key_usage_qualifier=key.key_usage_qualifier, key_access=key.key_access, key_type=key.key_type, key_length=key.key_length, key_identifier=key.key_identifier, key_version_number=key_set.key_version_number, key_check_value=key.key_check_value) for key in encrypted_key_set.keys.values()]
            cmds = StoreDataCommand.new_store_symmetric_keys_cmd(kcrts, [k.key_value for k in encrypted_key_set.keys.values()])
            for cmd in cmds:
                resp = await self.transmit(cmd, ResponseAPDU)
                if not resp.status_ok:
                    raise GPException(resp.status_code, 'Put Key Failed!')

    async def get_key_set(self) -> List[KeySet]:
        await self.create_secure_channel()
        req = CommandAPDU(ins=Instruction.GET_DATA_CA, p1=0, p2=224)
        resp = await self.transmit(req)
        if not resp.status_ok and resp.status_code != 27272:
            raise GPException(resp.status_code, 'Get Key Failed')
        ket_sets: Dict[int, KeySet] = {}
        tlv_e0 = Tlv.find_one(Tlv.parse(resp.data), 224)
        for c0_tlv in tlv_e0.find_nodes(192):
            key_identifier: int = c0_tlv.value[0]
            key_version_number = c0_tlv.value[1]
            key_type = c0_tlv.value[2]
            key_len = c0_tlv.value[3]
            key_set = ket_sets.get(key_version_number, None)
            if not key_set:
                key_set = KeySet(self.device.chip_id, self.options.aid, key_version_number)
                if key_type == KeyType.AES:
                    key_set.algorithm = KeySetAlgorithm.AES
                elif key_type == KeyType.DES:
                    key_set.algorithm = KeySetAlgorithm.DES
                elif key_type == KeyType.SM4:
                    key_set.algorithm = KeySetAlgorithm.SM4
                elif key_type in (176, 177, 178, 179, 180, 181, 182, 183, 240):
                    key_set.algorithm = KeySetAlgorithm.ECC
                elif key_type in (160, 161, 162, 163, 164, 165, 166, 167, 168):
                    key_set.algorithm = KeySetAlgorithm.RSA
                elif key_type in (144, 145):
                    key_set.algorithm = KeySetAlgorithm.HMAC
                else:
                    self.logger.warning(f'Unknown KeyType=x0{key_type:02X}')
                ket_sets.setdefault(key_version_number, key_set)
            k = key_set.add_key(key_identifier, None, KeyType(key_type))
            k.key_length = key_len
        return list(ket_sets.values())

    async def get_status(self, p1: GetStatusP1=GetStatusP1.APPLICATIONS_WITH_SECURITY_DOMAINS, aid: bytes=None) -> List[GlobalPlatformRegistryRelatedData]:
        await self.create_secure_channel()
        ret: List[GlobalPlatformRegistryRelatedData] = []
        has_more = True
        p2 = GetStatusP2.RESPONSE_DATA_STRUCTURE_TLV_E3
        while has_more:
            req = GetStatusCommand(p1=p1, p2=p2, aid=aid or bytes())
            rsp = await self.transmit(req)
            if rsp.status_ok:
                rsp = GetStatusResponse(rsp.raw)
                ret.extend(rsp.data)
                has_more = False
            elif rsp.status_code == 25360:
                rsp = GetStatusResponse(rsp.raw)
                ret.extend(rsp.data)
                has_more = True
                p2 = GetStatusP2.RESPONSE_DATA_STRUCTURE_TLV_E3 | GetStatusP2.GET_NEXT_OCCURRENCE
            elif rsp.status_code == 27272:
                has_more = False
            else:
                raise GPException(rsp.status_code, 'GET STATUS Failed!')
        return ret

    async def enter_scp_protection_mode(self, key_version_number: int=0):
        rsp = await self.device.select(self.options.aid)
        if not rsp.status_ok:
            raise Exception(f'Can not select ISD({hex(self.options.aid)}). Status={rsp.status_code}')
        key_set = await self.kms_service.new_key_set(self.device.chip_id, None, key_version_number, KeySetAlgorithm.DES)
        while True:
            host_challenge = get_random_bytes(8)
            req = InitializeUpdateCommand(p1=key_version_number, data=host_challenge)
            response = await self.device.transmit(req, InitializeUpdateResponsePacket)

    async def get_data(self, p1: int, p2: int, data: bytes=None):
        rsp_data = bytearray()
        req = CommandAPDU(ins=Instruction.GET_DATA_CA, p1=p1, p2=p2)
        rsp = await self.transmit(req)
        if rsp.status_ok:
            return rsp.data
        elif rsp.sw1 == 97:
            rsp_data.extend(rsp.data)
            while True:
                req = CommandAPDU(ins=Instruction.GET_RESPONSE)
                rsp = await self.transmit(req)
                if rsp.status_ok:
                    rsp_data.extend(rsp.data)
                    return bytes(rsp_data)
                elif rsp.sw1 == 97:
                    rsp_data.extend(rsp.data)
                    continue
                else:
                    raise GPException(rsp.status_code, 'Get more data failed!')
        else:
            raise GPException(rsp.status_code, 'Get data failed!')
__all__ = [SecureSessionOptions.__name__, SecureSession.__name__]