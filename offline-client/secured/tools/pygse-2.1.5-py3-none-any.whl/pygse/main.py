import logging
from .app import CliApplication

def main(*args: str):
    try:
        app = CliApplication()
        return app.run(*args)
    except (SystemExit, KeyboardInterrupt):
        pass
    except Exception as ex:
        logging.error(ex)
__all__ = [main.__name__]