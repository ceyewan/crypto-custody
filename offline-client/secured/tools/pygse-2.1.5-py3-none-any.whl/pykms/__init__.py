import builtins
from .main import main
from .__version__ import *
version = version
product = 'PyKMS'
vendor = 'Shenzhen Goodix Technology Co., Ltd.'
builtins.product = product
builtins.__product__ = product
builtins.__package_version__ = version
builtins.__build__ = build
builtins.__commit__ = commit