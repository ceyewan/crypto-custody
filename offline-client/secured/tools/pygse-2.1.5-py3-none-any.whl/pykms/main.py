import logging
from .app import CliApplication

def main(*args: str):
    try:
        app = CliApplication()
        app.run(*args)
    except (SystemExit, KeyboardInterrupt):
        pass
    except Exception as ex:
        logging.error(ex)