from ...base.common import IInstanceService, ServiceParam
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser
ACTION_ID = 'web'

@register_cmd(ACTION_ID, 'Run PyKMS as HTTP Service.')
class WebCommandArguments(SubCommandArguments):
    port: int = 0

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--port', type=int, default=0, help='Listening Port.')

@action(ACTION_ID)
class DownloadAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: WebCommandArguments, *args, **kwargs):
        from ...web import run_web
        await run_web(self.instance_service, arg.port)
__all__ = []