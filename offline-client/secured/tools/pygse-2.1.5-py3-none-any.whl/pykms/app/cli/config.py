from typing import List, Literal, Union
from ...base.common import IInstanceService, ServiceParam, print_table, some
from ...components.configuration.common import IConfigurationService, CommonConfigurationKeys
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser
ACTION_ID = 'config'

@register_cmd('config', 'Set or list configurations.')
class ConfigureCommandArguments(SubCommandArguments):
    sub_cmd: Literal['set', 'unset', 'ls']
    key: Union[str, List[str]]
    value: str

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        sub = parser.add_subparsers(dest='sub_cmd')
        set = sub.add_parser('set', help='set configuration. e.g. config set key value')
        set.add_argument('key', help='Configuration key.')
        set.add_argument('value', help='Value of key.')
        unset = sub.add_parser('unset', help='unset configurations. e.g. config unset key')
        unset.add_argument('key', nargs='+', help='Configuration keys.')
        list = sub.add_parser('ls', help='list configurations. e.g. config list key')
        list.add_argument('key', nargs='*', help='仅输出包键名称包含此内容的配置项。默认全部输出。')

@action(ACTION_ID)
class ConfigureAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ConfigureCommandArguments, *args, **kwargs):
        config_service = self.instance_service.get(IConfigurationService)
        if arg.sub_cmd == 'set':
            config_service.set_config(arg.key, arg.value)
            print('提示：使用命令 "pykms config ls [KEY]" 查看配置项。')
        if arg.sub_cmd == 'unset':
            keys = arg.key if isinstance(arg.key, list) else [arg.key]
            for key in keys:
                config_service.set_config(key, None)
        if arg.sub_cmd == 'ls':
            header = ['配置键值', '类型', '说明', '设置值', '默认值']
            data = [[item.key, item.type, item.description, item.format(config_service.get_config(item)), item.format(item.default_value)] for item in sorted(config_service.registered_configs.values(), key=lambda i: i.order)]
            for r in data:
                if r[-1] == r[-2]:
                    r[-2] = ''
            keys = arg.key if isinstance(arg.key, list) else [arg.key]
            if keys:
                data = [row for row in data if some(keys, lambda k: k in row[0])]
            if not data:
                print(f'没有找到包含“{arg.key}”的配置项！')
            else:
                print_table(header, data)
                print('提示：使用命令 "pykms config set [KEY] [VALUE]" 进行配置。')
                print(f'例如，配置Goodix通用料下载服务地址：pykms config set {CommonConfigurationKeys.GOODIX_KMS_ADDRESS.key} https://kmsonline.goodix.com')
__all__ = []