from ...base.common import same, IInstanceService, ServiceParam
from ...components.key_management.common import IKeyManagementService
from ...components.action.common import action, IAction
from ...global_platform.base import KeySetAlgorithm
from ...global_platform.base.constants import GseConstants
from .cli_args import parse_cid, parse_isd, parse_key_set_type, parse_key_version, register_cmd, question, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'rm-key'

@register_cmd(ACTION_ID, 'Remove keys from KMS database.')
class RemoveKeyCommandArguments(SubCommandArguments):
    cid: bytes
    sd: bytes
    kvn: int
    alg: KeySetAlgorithm
    silent: bool

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--cid', type=parse_cid, required=True, help='CHIP ID. Using “pygse info” to get the chip id.')
        parser.add_argument('--sd', type=parse_isd, help='Specify the security domain of key set to delete. Default is unlimited.')
        parser.add_argument('--kvn', type=parse_key_version, help='Specify the key version number of key set to delete.')
        parser.add_argument('--alg', type=parse_key_set_type, metavar='AES|DES', help='Specify the algorithm type of key set to delete. For example, DES to delete all SCP02 key sets and AES  to delete all SCP03 key sets.')
        parser.add_argument('-y', dest='silent', action='store_true', help='Delete without confirmation.')

@action(ACTION_ID)
class RemoveKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: RemoveKeyCommandArguments, *args, **kwargs):
        if not arg.silent:
            if question('请谨慎使用删除密钥功能。是否继续?') != 'y':
                print('操作已取消。')
                return 0
            if not arg.sd and (not arg.kvn) and (not arg.alg):
                if question('即将删除此芯片的全部密钥。是否继续?') != 'y':
                    print('操作已取消。')
                    return 0
        kms_service = self.instance_service.get(IKeyManagementService)
        count = await kms_service.delete_key_set(arg.cid, arg.sd, arg.kvn, arg.alg)
        print(f'已删除{count}个密钥集！')
__all__ = []