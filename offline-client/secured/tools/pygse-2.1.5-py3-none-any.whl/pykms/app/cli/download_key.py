from typing import List
from ...base.common import IInstanceService, ServiceParam
from ...components.key_management.common import IKeyManagementService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser
ACTION_ID = 'download-key'

@register_cmd(ACTION_ID, '从GOODIX KMS下载通用料芯片初始密钥。')
class DownloadKeyCommandArguments(SubCommandArguments):
    cid: List[str] = None
    out: str = None

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--out', type=str, help='Save the downloaded initial keys data to a JSON file instead of database.')
        parser.add_argument('cid', nargs='+', metavar='CHIP_ID1 CHIP_ID2...', help='The chip IDs that need to download the keys. Using the file input redirection symbol(<) to input a large list of chid IDs.')

@action(ACTION_ID)
class DownloadKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: DownloadKeyCommandArguments, *args, **kwargs):
        kms_service = self.instance_service.get(IKeyManagementService)
        if arg.out:
            await kms_service.download_keys_from_goodix_kms_to_file(arg.cid, arg.out)
        else:
            await kms_service.download_keys_from_goodix_kms(arg.cid)
__all__ = []