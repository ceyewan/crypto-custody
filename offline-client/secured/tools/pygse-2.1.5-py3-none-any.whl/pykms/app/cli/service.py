import logging
import os
import subprocess
import sys
from typing import Literal
from ...base.common import IInstanceService, ServiceParam
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser, Namespace

class IServiceTool:

    def install(self, port: int=7010):
        pass

    def uninstall(self):
        pass

    def start(self):
        pass

    def stop(self):
        pass

class LinuxServiceTool(IServiceTool):
    service_name = 'pykms.service'
    service_file = f'/etc/systemd/system/pykms.service'

    def install(self, port: int=7010):
        tips = '\n'.join([f"     Start service: 'pykms service start' or 'systemctl start {self.service_name}'.", f"      Stop service: 'pykms service stop'  or 'systemctl stop  {self.service_name}'.", f" Uninstall service: 'pykms service uninstall'."])
        if os.path.exists(self.service_file):
            logging.error('Service already installed!')
            print(tips)
            return
        with open(self.service_file, 'w', encoding='utf8') as f:
            f.write(f"""\n[Unit]\nDescription=PyKMS Service\n\n[Service]\nExecStart={sys.executable} -m pykms web --port={port or 7010}\nRestart=always\nEnvironment="PYTHONPATH={os.path.normpath(os.path.join(__file__, '../../../../'))}"\n\n[Install]\nWantedBy=multi-user.target\n    """.strip())
        os.system('systemctl daemon-reload')
        os.system(f'systemctl enable {self.service_name}')
        logging.info(f'Service installed to {self.service_file}!')
        print(tips)

    def uninstall(self):
        if not os.path.exists(self.service_file):
            logging.error('Service not installed!')
            return
        self.stop()
        os.unlink(self.service_file)
        os.system('systemctl daemon-reload')
        logging.info(f'Service removed from {self.service_file}!')

    def start(self):
        if os.system(f'systemctl start {self.service_name}') == 0:
            logging.info(f'Service started!')

    def stop(self):
        if os.system(f'systemctl stop {self.service_name}') == 0:
            logging.info(f'Service stopped!')
ACTION_ID = 'service'

@register_cmd(ACTION_ID, 'Service tool for pykms web.')
class ServiceCommandArguments(SubCommandArguments):
    sub_cmd: Literal['install', 'uninstall', 'start', 'restart', 'stop']
    port: int

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        sub = parser.add_subparsers(dest='sub_cmd', required=True)
        install = sub.add_parser('install', help='Install pykms web service to systemd.')
        install.add_argument('--port', type=int, help='Port for pykms web service.')
        uninstall = sub.add_parser('uninstall', help='Uninstall pykms web service from systemd.')
        start = sub.add_parser('start', help='Start pykms web service.')
        restart = sub.add_parser('restart', help='Stop pykms web service.')
        stop = sub.add_parser('stop', help='Stop pykms web service.')

@action(ACTION_ID)
class ServiceAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ServiceCommandArguments, *args, **kwargs):
        service_tool: IServiceTool = None
        if sys.platform == 'linux':
            if os.geteuid() != 0:
                argv = sys.argv if 'pykms' in sys.executable else ['-m', 'pykms', *sys.argv[1:]]
                subprocess.check_call(['sudo', '-E', sys.executable, *argv])
                return
            service_tool = LinuxServiceTool()
        else:
            logging.error(f'服务工具暂时只支持Linux')
            return
        if arg.sub_cmd == 'install':
            service_tool.install(arg.port)
        elif arg.sub_cmd == 'uninstall':
            service_tool.uninstall()
        elif arg.sub_cmd == 'start':
            service_tool.start()
        elif arg.sub_cmd == 'stop':
            service_tool.stop()
        elif arg.sub_cmd == 'restart':
            service_tool.stop()
            service_tool.start()
__all__ = []