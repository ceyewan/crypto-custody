import os
import sys
from ...base.common import IInstanceService, ServiceParam
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser
ACTION_ID = 'help'

@register_cmd(ACTION_ID, 'Things to help you.')
class HelpCommandArguments(SubCommandArguments):

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        pass

@action(ACTION_ID)
class HelpAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: HelpCommandArguments):
        user_manual = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../PyKMS用户手册.pdf'))
        self.open(user_manual)

    def open(self, file: str):
        if not os.path.exists(file):
            print(f'{file} does not exits!')
            return
        print(f'Open {file} ...')
        try:
            if sys.platform == 'win32':
                os.startfile(file)
            else:
                import subprocess
                subprocess.Popen(['xdg-open', file])
        except:
            print(f'Can not open {file}. Please open it manually.')
__all__ = []