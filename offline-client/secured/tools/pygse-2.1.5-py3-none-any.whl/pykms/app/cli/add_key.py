from typing import List, Literal
from ...base.common import same, IInstanceService, ServiceParam, to_bytes
from ...components.key_management.common import IKeyManagementService
from ...components.action.common import action, IAction
from ...global_platform.base import KeyType, KeySet, AesKeyId, DesKeyId, KeySetAlgorithm, Sm4KeyId
from .cli_args import parse_cid, parse_isd, question, parse_key_version, register_cmd, parse_key_set_type, SubCommandArguments, ArgumentParser, Namespace
ACTION_ID = 'add-key'

@register_cmd(ACTION_ID, 'Add keys to KMS database.')
class AddKeyCommandArguments(SubCommandArguments):
    cid: bytes
    sd: bytes
    kvn: int
    alg: KeySetAlgorithm
    enc: bytes
    mac: bytes
    dek: bytes
    override: bool = None

    def __init__(self, init: Namespace) -> None:
        super().__init__(init)
        if not same([len(self.enc), len(self.mac), len(self.dek)]):
            raise Exception(f'3个密钥长度不一致')
        if len(self.enc) not in (8, 16, 32):
            raise Exception(f'密钥长度必须是8、16、32字节。')

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('--cid', type=parse_cid, required=True, help='CHIP ID. Using “pygse info” to get the chip id.')
        parser.add_argument('--sd', type=parse_isd, help='Security Domain of this Key Set. Default is the configuration value of "se.default-isd".')
        parser.add_argument('--kvn', type=parse_key_version, required=True, help='The key version number')
        parser.add_argument('--alg', type=parse_key_set_type, required=True, metavar='AES|DES', help='The key set algorithm type for the key set, for example, DES for SCP02 key set and AES for SCP03 key set.')
        parser.add_argument('--enc', type=to_bytes, required=True, help='The KEY-ENC for secure channel authentication & encryption')
        parser.add_argument('--mac', type=to_bytes, required=True, help='The KEY-MAC for secure channel verification & generation')
        parser.add_argument('--dek', type=to_bytes, required=True, help='The KEY-DEK for sensitive data encryption and decryption')
        parser.add_argument('-o', '--override', dest='override', action='store_true', help='Overwrite the exists Key Set。')

@action(ACTION_ID)
class AddKeyAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: AddKeyCommandArguments, *args, **kwargs):
        kms_service = self.instance_service.get(IKeyManagementService)
        exists = await kms_service.get_key_set(arg.cid, arg.sd, arg.kvn, arg.alg, False)
        if exists and (not arg.override):
            if question(f'已存在KVN=0x{arg.kvn:02X}, ALG={arg.alg}的密钥集，是否覆盖？') != 'y':
                print('操作已取消。')
                return 0
            arg.override = True
        new_ket_set = await kms_service.new_key_set(arg.cid, arg.sd, arg.kvn, arg.alg)
        if new_ket_set.algorithm == KeySetAlgorithm.DES:
            new_ket_set.add_key(DesKeyId.KEY_ENC, arg.enc)
            new_ket_set.add_key(DesKeyId.KEY_MAC, arg.mac)
            new_ket_set.add_key(DesKeyId.KEY_DEK, arg.dek)
        elif new_ket_set.algorithm == KeySetAlgorithm.AES:
            new_ket_set.add_key(AesKeyId.KEY_ENC, arg.enc)
            new_ket_set.add_key(AesKeyId.KEY_MAC, arg.mac)
            new_ket_set.add_key(AesKeyId.KEY_DEK, arg.dek)
        elif new_ket_set.algorithm == KeySetAlgorithm.SM4:
            new_ket_set.add_key(Sm4KeyId.KEY_ENC, arg.enc)
            new_ket_set.add_key(Sm4KeyId.KEY_MAC, arg.mac)
            new_ket_set.add_key(Sm4KeyId.KEY_DEK, arg.dek)
        else:
            raise Exception(f'Unsupported algorithm={new_ket_set.algorithm}')
        await kms_service.save_key_set(new_ket_set, arg.override)
        print(f'密钥已添加！')
__all__ = []