from typing import List
from ...base.common import IInstanceService, ServiceParam
from ...components.key_management.common import IKeyManagementService
from ...components.action.common import action, IAction
from .cli_args import register_cmd, SubCommandArguments, ArgumentParser
ACTION_ID = 'report-chip'

@register_cmd(ACTION_ID, '向Goodix KMS上报已经下载密钥的芯片。注意！！上报后将无法再次下载密钥，请在上报前妥善保管芯片密钥！')
class ReportChipToGoodixKmsCommandArguments(SubCommandArguments):
    cid: List[str] = None

    @staticmethod
    def add_arguments(parser: ArgumentParser):
        parser.add_argument('cid', nargs='+', metavar='CHIP_ID1 CHIP_ID2 ...', help='The chip IDs that need to report to Goodix KMS. Using the file input redirection symbol(<) to input a large list of chid IDs. Note that once the chip ID is reported to Goodix KMS, the initial keys CAN NOT be download again.')

@action(ACTION_ID)
class ReportChipToGoodixKmsAction(IAction):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)) -> None:
        super().__init__()
        self.instance_service = instance_service

    async def run(self, arg: ReportChipToGoodixKmsCommandArguments, *args, **kwargs):
        kms_service = self.instance_service.get(IKeyManagementService)
        await kms_service.report_chips_to_goodix_kms(arg.cid)
__all__ = []