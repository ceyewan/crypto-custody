import logging
from ..components.action.common import IActionService
from ..base.common import InstanceService, Application
from ..components import register_all_services
from .cli import parse_arguments

class CliApplication(Application):

    def __init__(self) -> None:
        super().__init__(self.__main)

    async def __main(self, *argv: str):
        arg = parse_arguments(*argv)
        if arg.log_level:
            logging.root.setLevel(arg.log_level)
        if arg.log_file:
            logging.root.addHandler(logging.FileHandler(arg.log_file, 'w'))
        register_all_services()
        self.instance_service = InstanceService()
        action_service = self.instance_service.get(IActionService)
        await action_service.run_until_complete(arg.cmd, arg)