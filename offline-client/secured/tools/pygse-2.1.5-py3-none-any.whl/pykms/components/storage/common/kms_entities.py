from datetime import datetime
from typing import List
from ....base.common.sqlite_entity import Entity, DataTable, table, identity, uuid, integer, blob, date_time, boolean, ForeignKey, navigation_property, add_foreign_key

@table('key')
class Key:
    id: bytes = uuid(primary_key=True)
    key_set_id: bytes = uuid(index='ASC')
    key_identifier: int = integer(not_null=False)
    key_type: int = integer(not_null=False)
    key_usage_qualifier: int = integer(default_value=0)
    key_access: int = integer(default_value=0)
    key_value: bytes = blob(not_null=False)
    key_length: int = integer(not_null=False)
    update_time: datetime = date_time(auto_update=True)
    create_time: datetime = date_time()
    key_set: 'KeySet' = navigation_property()

@table('key_history')
class KeyHistory(Key):
    id: bytes = uuid(primary_key=True)
    chip_id: bytes = uuid(index='ASC')
    security_domain: bytes = uuid()
    key_version_number: int = integer(not_null=False)
    key_identifier: int = integer(not_null=False)
    key_type: int = integer(not_null=False)
    key_usage_qualifier: int = integer(default_value=0)
    key_access: int = integer(default_value=0)
    key_value: bytes = blob(not_null=False)
    key_length: int = integer()
    update_time: datetime = date_time(auto_update=True)
    create_time: datetime = date_time()

@table('key_set')
class KeySet:
    id: bytes = uuid(primary_key=True)
    chip_id: bytes = uuid(index='ASC')
    security_domain: bytes = uuid()
    key_version_number: int = integer(not_null=True)
    algorithm: int = integer(not_null=True)
    update_time: datetime = date_time(auto_update=True)
    create_time: datetime = date_time()
    chip: 'Chip' = navigation_property()
    keys: List[Key] = navigation_property()

    def to_history(self) -> List[KeyHistory]:
        his = []
        for k in self.keys:
            h = KeyHistory()
            h.__dict__.update(k.__dict__)
            h.__dict__.update(self.__dict__)
            h.id = None
            his.append(h)
        return his

    def __str__(self):
        return f'id={hex(self.id)}, chip_id={hex(self.chip_id)}, sd={hex(self.security_domain)}, kvn={hex(self.key_version_number)}, alg={self.algorithm}'

@table('chip')
class Chip:
    id: bytes = uuid(primary_key=True)
    update_time: datetime = date_time(auto_update=True)
    create_time: datetime = date_time()
    key_sets: List[KeySet] = navigation_property()
add_foreign_key(KeySet, KeySet.chip_id, KeySet.chip, Chip, Chip.id, Chip.key_sets)
add_foreign_key(Key, Key.key_set_id, Key.key_set, KeySet, KeySet.id, KeySet.keys)

class KmsStorageEntity(Entity):
    chips: DataTable[Chip]
    key_sets: DataTable[KeySet]
    keys: DataTable[Key]
    keys_history: DataTable[KeyHistory]

    def __init__(self, file: str, enable_foreign_keys: bool=True):
        super().__init__(file, enable_foreign_keys)
        self.chips = self.register_table(Chip)
        self.key_sets = self.register_table(KeySet)
        self.keys = self.register_table(Key)
        self.keys_history = self.register_table(KeyHistory)
        self.create_tables()
        self.connection.executescript("\nCREATE VIEW IF NOT EXISTS all_chip_keys AS\n    SELECT hex(chip_id) AS CID,\n           hex(security_domain) AS SD,\n           printf('%02X', key_version_number) AS KVN,\n           algorithm AS ALG,\n           [key].key_identifier AS KID,\n           printf('%02X', [key].key_type) AS KeyType,\n           hex([key].key_value) AS [Key],\n           create_time,\n           update_time\n      FROM key_set\n           LEFT JOIN\n           [key] ON [key].key_set_id = key_set.id;\n")
__all__ = [Chip.__name__, Key.__name__, KeyHistory.__name__, KeySet.__name__, KmsStorageEntity.__name__]