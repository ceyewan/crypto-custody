from abc import abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Union
from .kms_entities import KeySet, Key

class IKmsStorageService:

    @abstractmethod
    async def get_key_set(self, chip_id: Union[str, bytes]=None, security_domain: Union[str, bytes]=None, algorithm: int=None, key_version_number: int=None, skip: int=None, take: int=None, update_time_begin: datetime=None, update_time_end: datetime=None) -> List[KeySet]:
        pass

    @abstractmethod
    async def get_key_set_by_id(self, key_set_id: Union[str, bytes]) -> KeySet:
        pass

    @abstractmethod
    async def get_key_by_id(self, key_id: Union[str, bytes]) -> Key:
        pass

    @abstractmethod
    async def add_key_set(self, key_set: KeySet, override: bool=False) -> KeySet:
        pass

    @abstractmethod
    async def update_key_set(self, key_set: KeySet) -> bool:
        pass

    @abstractmethod
    async def delete_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: int=None) -> int:
        pass

    @abstractmethod
    async def delete_key_set_by_id(self, key_set_id: Union[str, bytes]) -> bool:
        pass
__all__ = [IKmsStorageService.__name__]