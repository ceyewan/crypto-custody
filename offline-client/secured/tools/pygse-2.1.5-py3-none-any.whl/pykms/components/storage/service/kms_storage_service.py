from datetime import datetime, timedelta
import logging
import os
from typing import Any, Dict, List, TypeVar, Union
from ....base.common import to_bytes, service, ServiceParam, first
from ...configuration.common import CommonConfigurationKeys, IConfigurationService
from ..common import IKmsStorageService, Chip, KeySet, Key, KeyHistory, KmsStorageEntity

def to_int(chip_id: Union[int, str, bytes, bytearray]) -> int:
    if isinstance(chip_id, int):
        return chip_id
    return int.from_bytes(to_bytes(chip_id), 'big')

@service(IKmsStorageService)
class KmsStorageService(IKmsStorageService):
    storage: KmsStorageEntity = None

    def __init__(self, configuration_service: IConfigurationService=ServiceParam(IConfigurationService)) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.configuration_service = configuration_service
        self.history_data_keep_days: int = configuration_service.get_config(CommonConfigurationKeys.STORAGE_HISTORY_DATA_KEEP_DAYS)
        configuration_service.register_on_changed(CommonConfigurationKeys.STORAGE_DB.key, self.__on_storage_file_changed)
        self.__on_storage_file_changed(configuration_service.get_config(CommonConfigurationKeys.STORAGE_DB.key))

    def __on_storage_file_changed(self, new_storage: str):
        file = new_storage or os.path.join(self.configuration_service.app_data_dir, 'pykms.db')
        if not self.storage or file != self.storage.file:
            self.logger.info(f'Using db: {file}')
            self.storage = KmsStorageEntity(file)

    def __get_key_set(self, chip_id: Union[int, str, bytes, bytearray]=None, security_domain: Union[int, str, bytes, bytearray]=None, key_version_number: Union[int, List[int]]=None, algorithm: int=None, skip: int=None, take: int=None, update_time_begin: datetime=None, update_time_end: datetime=None, key_set_id: Union[int, str, bytes, bytearray]=None) -> List[KeySet]:
        where = []
        para = []
        if chip_id:
            where.append(f'{KeySet.chip_id} = ?')
            para.append(to_bytes(chip_id))
        if security_domain:
            where.append(f'{KeySet.security_domain} = ?')
            para.append(to_bytes(security_domain))
        if key_version_number:
            lst = key_version_number if isinstance(key_version_number, list) else [key_version_number]
            where.append(f"{KeySet.key_version_number} IN ({', '.join('?' * len(lst))})")
            para.extend(lst)
        if algorithm != None:
            where.append(f'{KeySet.algorithm} = ?')
            para.append(algorithm)
        if update_time_begin:
            where.append(f'{KeySet.update_time} >= ?')
            para.append(update_time_begin)
        if update_time_end:
            where.append(f'{KeySet.update_time} <= ?')
            para.append(update_time_end)
        if key_set_id:
            where.append(f'{KeySet.id} = ?')
            para.append(to_bytes(key_set_id))
        key_sets = self.storage.key_sets.select(' AND '.join(where), para, f'{KeySet.key_version_number}, {KeySet.update_time}', skip, take, 'FIRST')
        return key_sets

    async def get_key_set_by_id(self, key_set_id: Union[str, bytes]) -> KeySet:
        return first(self.__get_key_set(key_set_id=key_set_id))

    async def get_key_by_id(self, key_id: Union[str, bytes]) -> Key:
        return self.storage.keys.select_by_id(to_bytes(key_id))

    async def get_key_set(self, chip_id: Union[str, bytes]=None, security_domain: Union[str, bytes]=None, key_version_number: int=None, algorithm: int=None, skip: int=None, take: int=None, update_time_begin: datetime=None, update_time_end: datetime=None) -> List[KeySet]:
        return self.__get_key_set(chip_id, security_domain, key_version_number, algorithm, skip, take, update_time_begin, update_time_end)

    async def add_key_set(self, key_set: KeySet, override: bool=False) -> KeySet:
        if not key_set or not key_set.keys:
            return None
        for k in key_set.keys:
            k.key_set_id = key_set.id
        exists = first(self.__get_key_set(key_set.chip_id, key_set.security_domain, key_set.key_version_number, take=1))
        with self.storage.transaction():
            if exists:
                if not override:
                    self.logger.error(f'Can not add existing key set: {key_set}!')
                    return None
                else:
                    self.logger.warning(f'Overriding existing key set: {key_set}!')
                self.storage.key_sets.delete(exists)
                self.storage.keys_history.insert(exists.to_history())
            elif not self.storage.chips.exists(key_set.chip_id):
                chip = Chip()
                chip.id = key_set.chip_id
                self.storage.chips.insert(chip)
            self.storage.key_sets.insert(key_set)
            self.storage.keys.insert(key_set.keys)
        return await self.get_key_set_by_id(key_set.id)

    async def delete_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: int=None) -> int:
        exists = await self.get_key_set(chip_id, security_domain, key_version_number, algorithm)
        with self.storage.transaction():
            for item in exists:
                self.storage.keys_history.insert(item.to_history())
                self.storage.key_sets.delete(item)
            self.delete_old_history()
        return len(exists)

    async def delete_key_set_by_id(self, key_set_id: Union[str, bytes]) -> bool:
        if not key_set_id:
            return False
        exist = await self.get_key_set_by_id(to_bytes(key_set_id))
        if not exist:
            return False
        with self.storage.transaction():
            self.storage.keys_history.insert(exist.to_history())
            self.storage.key_sets.delete(exist)
            self.delete_old_history()
            return True

    async def update_key_set(self, key_set: KeySet):
        exist = self.__get_key_set(key_set.chip_id, key_set.security_domain, key_set.key_version_number)
        if not exist:
            return
        with self.storage.transaction():
            self.storage.key_sets.update(key_set)
            self.storage.keys.update(key_set.keys)
    _last_delete_old_history_date: datetime = None

    def delete_old_history(self):
        if self.history_data_keep_days <= 0:
            return
        if self._last_delete_old_history_date and datetime.now() + timedelta(-30) < self._last_delete_old_history_date:
            return
        count = self.storage.keys_history.delete_many(f'{KeyHistory.create_time} < ?', [datetime.now() + timedelta(-self.history_data_keep_days)])
        self.logger.info(f'Deleted {count} expired history data')
        self._last_delete_old_history_date = datetime.now()
__all__ = [KmsStorageService.__name__]