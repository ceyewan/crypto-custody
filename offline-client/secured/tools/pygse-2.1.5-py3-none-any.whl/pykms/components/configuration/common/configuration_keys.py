from .configuration_service import ConfigurationDescriptor, register_config

class CommonConfigurationKeys:
    GOODIX_KMS_ADDRESS = ConfigurationDescriptor('goodix-kms.address', 'str', 'Goodix KMS服务URL地址', 'https://kmsonline.goodix.com', 100)
    GOODIX_KMS_CUSTOMER_ID = ConfigurationDescriptor('goodix-kms.customer-id', 'str', '用于Goodix KMS服务的客户ID', None, 101)
    GOODIX_KMS_KEK = ConfigurationDescriptor('goodix-kms.kek', 'str', '用于Goodix KMS服务的加密密钥', None, 102)
    GOODIX_KMS_SERVER_N = ConfigurationDescriptor('goodix-kms.server-n', 'str', '用于Goodix KMS服务的公钥', None, 103)
    GOODIX_KMS_CLIENT_N = ConfigurationDescriptor('goodix-kms.client-n', 'str', '用于Goodix KMS服务的客户端公钥', None, 104)
    GOODIX_KMS_CLIENT_D = ConfigurationDescriptor('goodix-kms.client-d', 'str', '用于Goodix KMS服务的客户端私钥', None, 105)
    GOODIX_KMS_ENCRYPT_CID = ConfigurationDescriptor('goodix-kms.encrypt-cid', 'bool', '用于Goodix KMS服务通信时是否加密芯片ID', True, 106)
    GOODIX_KMS_AUTO_DOWNLOAD_KEYS = ConfigurationDescriptor('goodix-kms.auto-download', 'bool', '当在本地数据库未找到密钥时，是否自动从GOODIX KMS服务下载密钥。', True, 107)
    SE_DEFAULT_ISD = ConfigurationDescriptor('se.default-isd', 'bytes', '默认发行者安全域。创建密钥集合时，默认使用此安全域。', 'A000000151000000', 200)
    STORAGE_DB = ConfigurationDescriptor('storage.db', 'str', '存储芯片密钥的数据库文件路径。\n默认:\n  windows: ~/AppData/Roaming/PyKMS/pykms.db\n  Linux: ~/.goodix/PyKMS/pykms.db\n请妥善保管和备份此数据文件，遗失密钥将导致无法与SE进行安全通信。', None, 300)
    STORAGE_HISTORY_DATA_KEEP_DAYS = ConfigurationDescriptor('storage.history-data-keep-days', 'int', '芯片密钥的历史数据的保存天数。超过此天数的历史数据将被删除。如果配置为非正数，将不会删除历史数据。', 365, 301)
    WEB_HTTP_PORT = ConfigurationDescriptor('web.http-port', 'int', '运行Web服务时使用的端口号。默认使用随机端口号。', None, 400)

    @staticmethod
    def register_all():
        for item in CommonConfigurationKeys.__dict__.values():
            if isinstance(item, ConfigurationDescriptor):
                register_config(item)
CommonConfigurationKeys.register_all()
__all__ = [CommonConfigurationKeys.__name__]