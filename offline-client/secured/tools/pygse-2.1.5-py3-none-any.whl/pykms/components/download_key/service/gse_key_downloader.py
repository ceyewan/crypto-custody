import json
import logging
from base64 import b64encode, b64decode
from typing import Any, Dict, List, Type, TypeVar, Union, Literal, Tuple
from urllib.parse import urljoin
from itertools import chain
from ....global_platform.base import AesKeySet, DesKeySet, KeySet, KeySetAlgorithm, DesKeyId, AesKeyId
from ....base.crypto.rsa import RasPkcsVerifier
from ....base.common import to_bytes, IntEnum, post
from ....base.crypto.aes import AesEcbCipher, aes_ecb_cmac
from ....base.crypto.rsa import *

def dumps(obj):
    return json.dumps(obj, separators=(',', ':'), sort_keys=True, bytes_format='str').strip('"')

class ErrorCode(IntEnum):
    E200 = 200
    E503 = 503
    E513 = 513
    E523 = 523
    E504 = 504
    E506 = 506
    E407 = 407
    E408 = 408

class JsonableObject:

    def __init__(self, init: Dict=None) -> None:
        if init:
            self.__dict__.update(init)

    def __json__(self):
        d = self.__dict__
        return {k: d[k] for k in sorted(d.keys()) if not k.startswith('_') and d[k] != None}

    def json(self, exclude: List[str]=['sign']):
        exclude = exclude or []
        obj = self.__json__()
        for ex in exclude:
            if ex in obj:
                del obj[ex]
        return obj

    def to_sign(self) -> bytes:
        kv = [(k, v if isinstance(v, str) else dumps(v)) for (k, v) in self.json().items()]
        return '&'.join([f'{k}={v}' for (k, v) in kv]).encode('utf-8')

class KmsRequest(JsonableObject):
    uuid: str = None

    def __init__(self, customerNo: str, uuid: str=None) -> None:
        super().__init__()
        self.customerNo = customerNo
        self.uuid = uuid

    def sign_data(self, signer: RasPkcsSigner):
        self.sign = b64encode(signer.sign(self.to_sign())).decode('utf-8')

class KmsResponse:
    code: int = None
    message: str = None
    uuid: str = None
    sign: bytes = None
    data: JsonableObject = None

    def __init__(self, init: Dict[str, Any]=None) -> None:
        if init:
            self.__dict__.update(init)
        if isinstance(self.sign, str):
            self.sign = b64decode(self.sign)

    def verify(self, signer: RasPkcsVerifier) -> bool:
        return signer.verify(self.data.to_sign(), self.sign)
TREQ = TypeVar('TREQ', bound=KmsRequest)
TRSP = TypeVar('TRSP', bound=KmsResponse)

class ApplyVerifyRequest(KmsRequest):

    def __init__(self, customerNo: str=None, uuid: str=None, modeType: int=1) -> None:
        super().__init__(customerNo, uuid)
        self.modeType = modeType

class ApplyVerifyResult(JsonableObject):
    random1: bytes
    random2: bytes

    def __init__(self, init: Dict=None) -> None:
        super().__init__(init)
        self.random1 = to_bytes(self.random1)
        self.random2 = to_bytes(self.random2)

class ApplyVerifyResponse(KmsResponse):
    data: ApplyVerifyResult

    def __init__(self, init: Dict[str, Any]=None) -> None:
        super().__init__(init)
        self.data = ApplyVerifyResult(self.data)

class AuthenticationRequest(KmsRequest):

    def __init__(self, customerNo: str=None, uuid: str=None, encryptedChallengeCode: str=None) -> None:
        super().__init__(customerNo, uuid)
        self.encChallengeCode = encryptedChallengeCode

class CplcItem(JsonableObject):
    index: int
    cplc: bytes

    def __init__(self, index: int, cplc: Union[str, bytes], **kwargs) -> None:
        super().__init__(kwargs)
        self.index = index
        self.cplc = to_bytes(cplc)

class GetCplcDataRequest(KmsRequest):
    isEncrypted: Literal[0, 1] = None

    def __init__(self, customerNo: str=None, uuid: str=None, cplcs: List[bytes]=None) -> None:
        super().__init__(customerNo, uuid)
        self._cplcs = [CplcItem(i, c) for (i, c) in enumerate(cplcs)]
        self.totalNum = len(cplcs)
        self.cplcs = dumps(self._cplcs)

    def encrypt_cplc(self, cipher: AesEcbCipher):
        if self.isEncrypted:
            return
        for item in self._cplcs:
            item.cplc = cipher.encrypt(item.cplc)
        self.isEncrypted = 1
        self.cplcs = dumps(self._cplcs)

    def calc_mac(self, key: bytes):
        self.mac = aes_ecb_cmac(key, to_bytes(f'{self.customerNo:0<8}{self.totalNum:08X}') + b''.join([c.cplc for c in self._cplcs])).hex().upper()

class KeyInfo(CplcItem):
    encKey02: bytes = None
    macKey02: bytes = None
    dekKey02: bytes = None
    encKey03: bytes = None
    macKey03: bytes = None
    dekKey03: bytes = None

    def __init__(self, index: int, cplc: Union[str, bytes], **kwargs) -> None:
        super().__init__(index, cplc, **kwargs)
        self.encKey02 = to_bytes(self.encKey02)
        self.macKey02 = to_bytes(self.macKey02)
        self.dekKey02 = to_bytes(self.dekKey02)
        self.encKey03 = to_bytes(self.encKey03)
        self.macKey03 = to_bytes(self.macKey03)
        self.dekKey03 = to_bytes(self.dekKey03)

    def decrypt_keys(self, cipher: AesEcbCipher) -> bool:
        (self.encKey02, ok) = self.__decrypt(cipher, self.encKey02)
        if not ok:
            return False
        (self.macKey02, ok) = self.__decrypt(cipher, self.macKey02)
        if not ok:
            return False
        (self.dekKey02, ok) = self.__decrypt(cipher, self.dekKey02)
        if not ok:
            return False
        (self.encKey03, ok) = self.__decrypt(cipher, self.encKey03)
        if not ok:
            return False
        (self.macKey03, ok) = self.__decrypt(cipher, self.macKey03)
        if not ok:
            return False
        (self.dekKey03, ok) = self.__decrypt(cipher, self.dekKey03)
        if not ok:
            return False
        return True

    def __decrypt(self, cipher: AesEcbCipher, data: bytes):
        if not data:
            return (data, True)
        plain = cipher.decrypt(data[:-4])
        if AesEcbCipher.enc(bytes(16), plain)[:4] == data[-4:]:
            return (plain, True)
        return (data, False)

    def to_kms_key_set(self) -> List[KeySet]:
        des = DesKeySet(self.cplc, None, 33)
        des.add_key(DesKeyId.KEY_ENC, self.encKey02)
        des.add_key(DesKeyId.KEY_MAC, self.macKey02)
        des.add_key(DesKeyId.KEY_DEK, self.dekKey02)
        aes = AesKeySet(self.cplc, None, 48)
        aes.add_key(AesKeyId.KEY_ENC, self.encKey03)
        aes.add_key(AesKeyId.KEY_MAC, self.macKey03)
        aes.add_key(AesKeyId.KEY_DEK, self.dekKey03)
        return [des, aes]

class GetCplcResult(JsonableObject):
    totalNum: int = None
    errorNum: int = None
    errorOutputs: List[CplcItem] = None
    errorFormats: List[CplcItem] = None
    keys: List[KeyInfo] = None
    rMac: bytes = None

    def __init__(self, init: Dict) -> None:
        super().__init__(init)
        self.errorFormats = [CplcItem(**item) for item in self.errorFormats or []]
        self.errorOutputs = [CplcItem(**item) for item in self.errorOutputs or []]
        self.keys = [KeyInfo(**item) for item in self.keys or []]
        self.rMac = to_bytes(self.rMac) or None

class GetCplcDataResponse(KmsResponse):
    data: GetCplcResult

    def __init__(self, init: Dict[str, Any]=None) -> None:
        super().__init__(init)
        if self.data:
            self.data = GetCplcResult(self.data)

    def decrypt_cplc(self, cipher: AesEcbCipher):
        if self.data.errorFormats:
            for item in self.data.errorFormats:
                item.cplc = cipher.decrypt(item.cplc)
        if self.data.errorOutputs:
            for item in self.data.errorOutputs:
                item.cplc = cipher.decrypt(item.cplc)
        if self.data.keys:
            for item in self.data.keys:
                item.cplc = cipher.decrypt(item.cplc)

    def decrypt_keys(self, cipher: AesEcbCipher) -> bool:
        for item in self.data.keys:
            if not item.decrypt_keys(cipher):
                raise Exception(f'解密密钥失败！{item}')
        return True

    def verify_rmac(self, rmac_key: bytes) -> bool:
        if not self.data.rMac:
            return True
        data = b''.join([(self.data.totalNum * 6).to_bytes(4, 'big'), *[b''.join([k.encKey02, k.macKey02, k.dekKey02, k.encKey03, k.macKey03, k.dekKey03]) for k in self.data.keys]])
        rmac = aes_ecb_cmac(rmac_key, data, len(self.data.rMac))
        return rmac == self.data.rMac

class ReportCplcDataRequest(GetCplcDataRequest):

    def __init__(self, customerNo: str=None, uuid: str=None, cplcs: List[bytes]=None) -> None:
        super().__init__(customerNo, uuid, cplcs)

class ReportCplcResult(JsonableObject):
    totalNum: int
    errorNum: int
    errorCplcs: List[CplcItem]

    def __init__(self, init: Dict) -> None:
        super().__init__(init)
        self.errorCplcs = [CplcItem(**item) for item in self.errorCplcs or []]

class ReportCplcDataResponse(KmsResponse):
    data: ReportCplcResult

    def __init__(self, init: Dict[str, Any]=None) -> None:
        super().__init__(init)
        if self.data:
            self.data = ReportCplcResult(self.data)

    def decript_cplc(self, cipher: AesEcbCipher):
        if self.data.errorCplcs:
            for item in self.data.errorCplcs:
                item.cplc = cipher.decrypt(item.cplc)

class GseKeysDownloader:
    kms_server: str
    customer_id: str
    uuid: str = None
    encrypt_cplc: bool
    kek: str
    encrypt_key: bytes
    mac_key: bytes
    rmac_key: bytes
    message_encryption: AesEcbCipher

    def __init__(self, kms_server: str, customer_id: str, kek: Union[str, bytes], server_n: Union[str, bytes], client_n: Union[str, bytes], client_d: Union[str, bytes], encrypt_cplc: bool=True) -> None:
        assert kms_server, f'kms_server参数是必须的！'
        assert kek, f'kek参数是必须的！'
        assert server_n, f'server_n参数是必须的！'
        assert client_n, f'client_n参数是必须的！'
        assert client_d, f'client_d参数是必须的！'
        self.kms_server = kms_server
        self.customer_id = customer_id
        self.kek = to_bytes(kek)
        self.encrypt_cplc = encrypt_cplc
        self.signer = RasPkcsSigner(client_n, client_d)
        self.verifier = RasPkcsVerifier(server_n)
        self.logger = logging.getLogger(GseKeysDownloader.__name__)

    async def download(self, chip_ids: List[Union[int, str, bytes]]) -> List[KeySet]:
        if not chip_ids:
            return
        cplcs_b = [to_bytes(i) for i in chip_ids]
        await self.__auth()
        ok_keys = await self.__request_keys(cplcs_b)
        return list(chain.from_iterable([k.to_kms_key_set() for k in ok_keys]))

    async def report(self, chip_ids: List[Union[int, str, bytes]]) -> List[bytes]:
        if not chip_ids:
            return
        cplcs_b = [to_bytes(i) for i in chip_ids]
        await self.__auth()
        return await self.__report_keys(cplcs_b)

    async def __request(self, path: str, data: TREQ, rsp_cls: Type[TRSP]) -> TRSP:
        url = urljoin(self.kms_server, path)
        data.sign_data(self.signer)
        json_data = dumps(data)
        self.logger.debug(f'POST {url}, data={json_data}')
        response = await post(url, json_data)
        self.logger.debug(f'RSP: {response.body}')
        if response.code != 200:
            err = f'{url} failed! code={response.code}, reason={response.reason}'
            self.logger.error(err)
            raise Exception(err)
        rsp = rsp_cls(json.loads(response.body))
        if rsp.code != 200:
            err = f'{url} failed! code={rsp.code}, message={rsp.message}'
            self.logger.error(err)
            if not rsp.data:
                raise Exception(err)
        if rsp.data and rsp.sign and (not rsp.verify(self.verifier)):
            err = f'f"{url} 验签失败！data={rsp.data.to_sign().hex()}, sign={rsp.sign.hex()}'
            self.logger.error(err)
            raise Exception(err)
        return rsp

    async def __auth(self):
        if self.uuid:
            return
        self.logger.info(f'认证客户{self.customer_id}...')
        rsp = await self.__request('external/v1/applyVerify', ApplyVerifyRequest(self.customer_id), ApplyVerifyResponse)
        if rsp.code != 200:
            raise Exception(f'ApplyVerify failed! code={rsp.code}, message={rsp.message}')
        encryptedChallengeCode = self.__init_session_keys(rsp.data.random1, rsp.data.random2)
        rsp = await self.__request('external/v1/authentication', AuthenticationRequest(self.customer_id, rsp.uuid, encryptedChallengeCode.hex().upper()), KmsResponse)
        if rsp.code != 200:
            raise Exception(f'Authentication failed! code={rsp.code}, message={rsp.message}')
        self.uuid = rsp.uuid
        self.logger.info(f'客户{self.customer_id}认证成功！')

    def __init_session_keys(self, random1: bytes, random2: bytes):
        random10 = random1[:-1]
        ecb = AesEcbCipher(self.kek)
        self.encrypt_key = ecb.encrypt(random10 + bytes([1]))
        self.mac_key = ecb.encrypt(random10 + bytes([2]))
        self.rmac_key = ecb.encrypt(random10 + bytes([3]))
        self.message_encryption = AesEcbCipher(self.encrypt_key)
        encryptedChallengeCode = self.message_encryption.encrypt(random2)
        return encryptedChallengeCode

    async def __request_keys(self, cplc: List[bytes]):
        error_formats: List[CplcItem] = []
        error_outputs: List[CplcItem] = []
        ok_outputs: List[KeyInfo] = []
        total = len(cplc)
        progress = 0
        for i in range(0, len(cplc), 1000):
            req = GetCplcDataRequest(self.customer_id, self.uuid, cplc[i:i + 1000])
            progress += len(req._cplcs)
            if self.encrypt_cplc:
                req.encrypt_cplc(self.message_encryption)
            req.calc_mac(self.mac_key)
            self.logger.info(f'正在获取密钥{progress}/{total}...')
            rsp = await self.__request('external/v1/getCplcData', req, GetCplcDataResponse)
            if rsp.code != 200 and (not rsp.data):
                raise Exception(f'GetCplcData failed! code={rsp.code}, message={rsp.message}')
            assert rsp.verify_rmac(self.rmac_key), f'R-MAC 验证失败！'
            if self.encrypt_cplc:
                rsp.decrypt_cplc(self.message_encryption)
            rsp.decrypt_keys(self.message_encryption)
            for item in rsp.data.errorFormats:
                item.index += i
                error_formats.append(item)
            for item in rsp.data.errorOutputs:
                item.index += i
                error_outputs.append(item)
            for item in rsp.data.keys:
                item.index += i
                ok_outputs.append(item)
        has_error = bool(error_formats or error_outputs)
        if error_formats:
            self.logger.error(f'请求格式错误的CPLC({len(error_formats)})：\n{json.dumps(error_formats, indent=2)}')
        if error_outputs:
            self.logger.error(f'输出异常的CPLC({len(error_outputs)})：\n{json.dumps(error_outputs, indent=2)}')
        self.logger.info(f'成功获取{len(ok_outputs)}/{len(cplc)}个芯片的密钥!')
        return ok_outputs

    async def __report_keys(self, cplc: List[bytes]):
        error_outputs: List[bytes] = []
        ok_outputs: List[bytes] = []
        total = len(cplc)
        progress = 0
        for i in range(0, len(cplc), 1000):
            cplc_chunk = cplc[i:i + 1000]
            req = ReportCplcDataRequest(self.customer_id, self.uuid, cplc[i:i + 1000])
            progress += len(req._cplcs)
            if self.encrypt_cplc:
                req.encrypt_cplc(self.message_encryption)
            req.calc_mac(self.mac_key)
            self.logger.info(f'正在上报{progress}/{total}...')
            rsp = await self.__request('external/v1/reportResult', req, ReportCplcDataResponse)
            if rsp.code != 200 and (not rsp.data):
                raise Exception(f'ReportResult failed! code={rsp.code}, message={rsp.message}')
            if self.encrypt_cplc:
                rsp.decript_cplc(self.message_encryption)
            for item in rsp.data.errorCplcs:
                item.index += i
                error_outputs.append(item.cplc)
                cplc_chunk.remove(item.cplc)
            ok_outputs.extend(cplc_chunk)
        has_error = bool(error_outputs)
        if error_outputs:
            self.logger.error(f'上报失败的CPLC({len(error_outputs)})：\n{json.dumps(error_outputs, indent=2)}')
        self.logger.info(f'上报成功{len(ok_outputs)}/{len(cplc)}个CPLC!已成功上报的芯片的密钥将无法再次下载！')
        return ok_outputs
__all__ = [GseKeysDownloader.__name__]