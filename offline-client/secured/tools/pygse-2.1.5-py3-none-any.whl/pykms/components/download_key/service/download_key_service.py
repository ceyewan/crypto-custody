import logging
from typing import List, Union
from ....base.common import service, ServiceParam
from ...storage.common import KeySet
from ...configuration.common import IConfigurationService, CommonConfigurationKeys
from ..common import IDownloadKeyService
from .gse_key_downloader import GseKeysDownloader

@service(IDownloadKeyService)
class DownloadKeyService(IDownloadKeyService):

    def __init__(self, configuration_service: IConfigurationService=ServiceParam(IConfigurationService)) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.configuration_service = configuration_service

    async def download(self, chip_ids: List[Union[int, str, bytes]]) -> List[KeySet]:
        try:
            downloader = GseKeysDownloader(self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_ADDRESS), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_CUSTOMER_ID), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_KEK), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_SERVER_N), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_CLIENT_N), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_CLIENT_D), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_ENCRYPT_CID))
            key_sets = await downloader.download(chip_ids)
            for ks in key_sets:
                ks.security_domain = self.configuration_service.get_config(CommonConfigurationKeys.SE_DEFAULT_ISD)
            return key_sets
        except:
            self.logger.error(f'Failed to fetch chip key from {downloader.kms_server}!')
            raise

    async def report(self, chip_ids: List[Union[int, str, bytes]]) -> List[bytes]:
        try:
            downloader = GseKeysDownloader(self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_ADDRESS.key), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_CUSTOMER_ID.key), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_KEK.key), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_SERVER_N.key), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_CLIENT_N.key), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_CLIENT_D.key), self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_ENCRYPT_CID.key))
            return await downloader.report(chip_ids)
        except:
            self.logger.error(f'Failed to report chip key to {downloader.kms_server}!')
            raise
__all__ = [DownloadKeyService.__name__]