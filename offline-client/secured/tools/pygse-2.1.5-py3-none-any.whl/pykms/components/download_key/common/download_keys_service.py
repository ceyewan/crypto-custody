from abc import abstractmethod
from typing import List, Union
from ....global_platform.base.key import KeySet

class IDownloadKeyService:

    @abstractmethod
    async def download(self, chip_ids: List[Union[int, str, bytes]]) -> List[KeySet]:
        pass

    @abstractmethod
    async def report(self, chip_ids: List[Union[int, str, bytes]]) -> List[bytes]:
        pass
__all__ = [IDownloadKeyService.__name__]