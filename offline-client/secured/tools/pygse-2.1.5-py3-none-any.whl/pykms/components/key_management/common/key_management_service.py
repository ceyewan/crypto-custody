from abc import abstractmethod
from typing import Any, Dict, List, Literal, Tuple, Union, overload
from ....global_platform.base import KeyType, KeySetAlgorithm, KeySet, AesKeySet, AesSessionKeySet, DesKeySet, DesSessionKeySet, Sm4KeySet, Sm4SessionKeySet

class IKeyManagementService:

    @abstractmethod
    async def get_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: Union[KeySetAlgorithm, int]=None, fetch_online: bool=None) -> KeySet:
        pass

    @abstractmethod
    async def get_key_set_by_id(self, key_set_id: Union[str, bytes]) -> KeySet:
        pass

    @abstractmethod
    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: Union[KeySetAlgorithm, int]=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        pass

    async def save_key_set(self, key_set: Union[str, bytes, KeySet], override: bool=False) -> KeySet:
        pass

    @abstractmethod
    async def delete_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_set_version: int=None, key_set_alg: KeySetAlgorithm=None) -> int:
        pass

    async def delete_key_set_by_id(self, key_set_id: Union[str, bytes]=None) -> int:
        pass

    @overload
    async def derive_session_keys(self, key_set: DesKeySet, *, sequence_counter: Union[str, bytes]) -> DesSessionKeySet:
        pass

    @overload
    async def derive_session_keys(self, key_set: AesKeySet, *, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes]) -> AesSessionKeySet:
        pass

    @overload
    async def derive_session_keys(self, key_set: Sm4KeySet, *, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Sm4SessionKeySet:
        pass

    @abstractmethod
    async def derive_session_keys(self, key_set: Union[KeySet, DesKeySet, AesKeySet, Sm4KeySet], *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]:
        pass

    async def download_keys_from_goodix_kms(self, chip_ids: List[Union[str, bytes]]) -> List[KeySet]:
        pass

    async def download_keys_from_goodix_kms_to_file(self, chip_ids: List[Union[str, bytes]], file: str):
        pass

    async def report_chips_to_goodix_kms(self, chip_ids: List[Union[str, bytes]]):
        pass

    @abstractmethod
    async def encrypt_key_set(self, session_key_set_id: Union[str, bytes], key_set_id: Union[str, bytes]) -> KeySet:
        pass

    @abstractmethod
    async def encrypt_key_set_aes(self, dek_id: Union[str, bytes], key_set_id: Union[str, bytes]) -> List[Tuple[KeyType, bytes, bytes]]:
        pass

    @abstractmethod
    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set_id: Union[str, bytes]) -> List[Tuple[KeyType, bytes, bytes]]:
        pass
__all__ = [IKeyManagementService.__name__]