import json
import logging
import os
from typing import Dict, List, Literal, Tuple, TypeVar, Union
from os import urandom
from datetime import datetime, timedelta
from itertools import chain
from ....base.common import to_bytes, service, first, same, ServiceParam
from ....base.crypto import des3_cbc_encrypt, aes_cbc_encrypt, sm4_cbc_encrypt
from ....global_platform.base import KeyType, KeySetAlgorithm, Key, KeySet, AesKeyId, DesKeyId, calc_key_check_value, Sm4KeyId, AesSessionKeySet, DesKeySet, DesSessionKeySet, Sm4KeySet, Sm4SessionKeySet
from ....global_platform.scp import scp02_derive_session_keys, scp03_derive_session_keys, scp04_derive_session_keys
from ....global_platform.kms.protocol import to_api_key_set
from ...configuration.common import IConfigurationService, CommonConfigurationKeys
from ...download_key.common import IDownloadKeyService
from ...storage.common import IKmsStorageService, Key as EntityKey, KeySet as EntityKeySet
from ..common import IKeyManagementService
T = TypeVar('T')

def to_entity_key(key: Key) -> EntityKey:
    obj = EntityKey()
    obj.__dict__.update(key.__dict__)
    return obj

def to_kms_key(key: EntityKey) -> Key:
    obj = Key()
    obj.__dict__.update(key.__dict__)
    return obj

def to_entity_key_set(key_set: KeySet) -> EntityKeySet:
    obj = EntityKeySet()
    obj.__dict__.update(key_set.__dict__)
    obj.keys = [to_entity_key(k) for k in key_set.keys.values()]
    for k in obj.keys:
        k.key_set_id = obj.id
    return obj

def to_kms_key_set(key_set: EntityKeySet) -> KeySet:
    obj = KeySet()
    obj.__dict__.update(key_set.__dict__)
    obj.keys = {k.key_identifier: to_kms_key(k) for k in key_set.keys}
    for k in obj.keys.values():
        k.key_set_id = obj.id
    return obj

@service(IKeyManagementService)
class KeyManagementService(IKeyManagementService):
    new_key_set_cache: Dict[bytes, KeySet]
    session_key_set_cache: Dict[bytes, Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]]

    def __init__(self, configuration_service: IConfigurationService=ServiceParam(IConfigurationService), download_key_service: IDownloadKeyService=ServiceParam(IDownloadKeyService), kms_storage_service: IKmsStorageService=ServiceParam(IKmsStorageService)) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.new_key_set_cache = {}
        self.session_key_set_cache = {}
        self.configuration_service = configuration_service
        self.download_key_service = download_key_service
        self.kms_storage_service = kms_storage_service

    async def get_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, algorithm: Union[KeySetAlgorithm, int]=None, fetch_online: bool=None) -> KeySet:
        security_domain = to_bytes(security_domain)
        key_sets = await self.kms_storage_service.get_key_set(chip_id, security_domain, key_version_number, algorithm)
        if key_sets:
            key_set = key_sets.pop()
            return to_kms_key_set(key_set)
        elif algorithm in (KeySetAlgorithm.AES, KeySetAlgorithm.DES) and key_version_number in (33, 48):
            if fetch_online == None:
                if self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_AUTO_DOWNLOAD_KEYS):
                    fetch_online = True
                    for item in [CommonConfigurationKeys.GOODIX_KMS_ADDRESS, CommonConfigurationKeys.GOODIX_KMS_CUSTOMER_ID, CommonConfigurationKeys.GOODIX_KMS_KEK, CommonConfigurationKeys.GOODIX_KMS_SERVER_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_D]:
                        if not self.configuration_service.get_config(item):
                            self.logger.warning(f'未配置{item.key}, 无法自动从Goodix KMS下载初始密钥。')
                            fetch_online = False
            if fetch_online:
                key_sets = await self.download_keys_from_goodix_kms([chip_id])
                if security_domain:
                    key_sets = [k for k in key_sets if k.security_domain == security_domain]
                if algorithm:
                    key_sets = [k for k in key_sets if k.algorithm == algorithm]
                if key_version_number:
                    key_sets = [k for k in key_sets if k.key_version_number == key_version_number]
                return first(key_sets)
        return None

    async def get_key_set_by_id(self, key_set_id: Union[str, bytes]) -> KeySet:
        key_set_id = to_bytes(key_set_id)
        if key_set_id in self.new_key_set_cache:
            return self.new_key_set_cache.get(key_set_id)
        key_set = await self.kms_storage_service.get_key_set_by_id(key_set_id)
        if key_set:
            return to_kms_key_set(key_set)
        return None

    async def get_key_by_id(self, key_id: Union[str, bytes]) -> Key:
        key_id = to_bytes(key_id)
        key = await self.kms_storage_service.get_key_by_id(key_id)
        if key:
            return to_kms_key(key)
        else:
            return first(chain.from_iterable((ks.keys.values() for ks in self.new_key_set_cache.values())), lambda k: k.id == key_id)

    async def new_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes]=None, key_version_number: int=None, algorithm: Union[KeySetAlgorithm, int]=None, key_length: int=None, key_enc: Union[str, bytes]=None, key_mac: Union[str, bytes]=None, key_dek: Union[str, bytes]=None) -> KeySet:
        security_domain = to_bytes(security_domain or self.configuration_service.get_config(CommonConfigurationKeys.SE_DEFAULT_ISD))
        algorithm = KeySetAlgorithm(algorithm)
        assert key_version_number == None or (key_version_number >= 0 and key_version_number <= 255), f'Bad Ker Version Number {key_version_number}'
        if not key_version_number or key_version_number == 255:
            key_sets = await self.kms_storage_service.get_key_set(chip_id, security_domain, algorithm=algorithm) or []
            if key_sets:
                key_version_number = key_sets.pop().key_version_number + 1
            elif KeySetAlgorithm.DES == algorithm:
                key_version_number = 33
            elif KeySetAlgorithm.AES == algorithm:
                key_version_number = 48
            else:
                raise Exception(f'Not supported algorithm {algorithm}!')
        key_set = KeySet(chip_id, security_domain, key_version_number, algorithm)
        if key_length:
            if key_enc and len(key_enc) != key_length:
                raise Exception(f'The key_length={key_length} but len(key_enc)={len(key_enc)}.')
            if key_mac and len(key_mac) != key_length:
                raise Exception(f'The key_length={key_length} but len(key_mac)={len(key_mac)}.')
            if key_dek and len(key_dek) != key_length:
                raise Exception(f'The key_length={key_length} but len(key_dek)={len(key_dek)}.')
        else:
            lengths: List[int] = list(filter(lambda i: i, [len(key_enc) if key_enc else None, len(key_mac) if key_mac else None, len(key_dek) if key_dek else None]))
            if lengths:
                if not same(lengths):
                    raise Exception(f'The (len(key_enc), len(key_mac), len(key_dek)) are not the same.')
                key_length = lengths[0]
        if KeySetAlgorithm.AES == algorithm:
            key_length = key_length or 16
            assert key_length in (8, 16, 32), f'Invalid key_length={key_length}'
            key_set.add_key(AesKeyId.KEY_ENC, key_enc or urandom(key_length))
            key_set.add_key(AesKeyId.KEY_MAC, key_mac or urandom(key_length))
            key_set.add_key(AesKeyId.KEY_DEK, key_dek or urandom(key_length))
        elif KeySetAlgorithm.DES == algorithm:
            key_length = key_length or 16
            assert key_length in (8, 16, 32), f'Invalid key_length={key_length}'
            key_set.add_key(DesKeyId.KEY_ENC, key_enc or urandom(key_length))
            key_set.add_key(DesKeyId.KEY_MAC, key_mac or urandom(key_length))
            key_set.add_key(DesKeyId.KEY_DEK, key_dek or urandom(key_length))
        elif KeySetAlgorithm.SM4 == algorithm:
            key_length = key_length or 16
            assert key_length in (8, 16, 32), f'Invalid key_length={key_length}'
            key_set.add_key(Sm4KeyId.KEY_ENC, key_enc or urandom(key_length))
            key_set.add_key(Sm4KeyId.KEY_MAC, key_mac or urandom(key_length))
            key_set.add_key(Sm4KeyId.KEY_DEK, key_dek or urandom(key_length))
        else:
            raise Exception(f'Not supported algorithm {algorithm}!')
        self.new_key_set_cache[key_set.id] = key_set
        self._clean_key_set_cache()
        return key_set

    def _clean_key_set_cache(self):
        expire = datetime.now() + timedelta(days=-1)
        expired = [k for k in self.new_key_set_cache.values() if k.create_time < expire]
        for to_del in expired:
            del self.new_key_set_cache[to_del.id]
        expired = [k for k in self.session_key_set_cache.values() if k.create_time < expire]
        for to_del in expired:
            del self.session_key_set_cache[to_del.id]

    async def save_key_set(self, key_set: Union[str, bytes, KeySet], override: bool=False) -> KeySet:
        cache: KeySet = None
        if not isinstance(key_set, KeySet):
            key_set = to_bytes(key_set)
            cache = self.new_key_set_cache.get(key_set, None)
            if not cache:
                raise Exception(f'Can not find Key Set by ID={hex(key_set)}')
            key_set = cache
        added = await self.kms_storage_service.add_key_set(to_entity_key_set(key_set), override)
        if added.id in self.new_key_set_cache:
            del self.new_key_set_cache[added.id]
        return to_kms_key_set(added)

    async def delete_key_set(self, chip_id: Union[str, bytes], security_domain: Union[str, bytes], key_version_number: int=None, key_set_alg: KeySetAlgorithm=None) -> int:
        return await self.kms_storage_service.delete_key_set(chip_id, security_domain, key_version_number, key_set_alg)

    async def delete_key_set_by_id(self, key_set_id: Union[str, bytes]=None) -> int:
        return await self.kms_storage_service.delete_key_set_by_id(key_set_id)

    async def derive_session_keys(self, key_set_id: Union[str, bytes], *, sequence_counter: Union[str, bytes]=None, host_challenge: Union[str, bytes]=None, card_challenge: Union[str, bytes]=None, protocol_identifier: int=2, supported_protocol_configuration_list: List[int]=[2]) -> Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet]:
        key_set = await self.get_key_set_by_id(key_set_id)
        if not key_set or not key_set.keys:
            self.logger.error(f'No key set found for {hex(key_set_id)} in storage.')
            return None
        if key_set.algorithm == KeySetAlgorithm.DES:
            if len(key_set.keys) != 3:
                self.logger.warning(f'Bad key count for {hex(key_set_id)}, want 3, got {len(key_set.keys)}!')
            (enc, mac, dek) = [k.key_value for k in key_set.keys.values()]
            if not enc or not mac or (not dek):
                self.logger.error(f'Bad key value for {hex(key_set_id)} in storage. enc={hex(enc)}, mac={hex(mac)}, dek={hex(dek)}')
            session_key_set = scp02_derive_session_keys(key_set, sequence_counter)
        elif key_set.algorithm == KeySetAlgorithm.AES:
            if len(key_set.keys) != 3:
                self.logger.warning(f'Bad key count for {hex(key_set_id)}, want 3, got {len(key_set.keys)}!')
            (enc, mac, dek) = [k.key_value for k in key_set.keys.values()]
            if not enc or not mac or (not dek):
                self.logger.error(f'Bad key value for {hex(key_set_id)} in storage. enc={hex(enc)}, mac={hex(mac)}, dek={hex(dek)}')
            session_key_set = scp03_derive_session_keys(key_set, host_challenge, card_challenge)
        elif key_set.algorithm == KeySetAlgorithm.SM4:
            if len(key_set.keys) != 3:
                self.logger.warning(f'Bad key count for {hex(key_set_id)}, want 3, got {len(key_set.keys)}!')
            (enc, mac, dek) = [k.key_value for k in key_set.keys.values()]
            if not enc or not mac or (not dek):
                self.logger.error(f'Bad key value for {hex(key_set_id)} in storage. enc={hex(enc)}, mac={hex(mac)}, dek={hex(dek)}')
            session_key_set = scp04_derive_session_keys(key_set, host_challenge, card_challenge, protocol_identifier, supported_protocol_configuration_list)
        else:
            return None
        self.session_key_set_cache[session_key_set.id] = session_key_set
        self._clean_key_set_cache()
        return session_key_set

    async def derive_session_keys_scp02(self, chip_id: Union[str, bytes], key_version_number: int, sequence_counter: Union[str, bytes], security_domain: Union[str, bytes]=None) -> Dict[Literal['dek', 'enc', 'cmac', 'rmac'], bytes]:
        keys = await self.kms_storage_service.get_key_set(chip_id, security_domain, key_version_number)
        if not keys:
            self.logger.info(f'No SCP02 keys for {chip_id} in storage.')
            return (None, None, None)
        if len(keys) != 3:
            self.logger.warning(f'Not enough SCP02 keys for {chip_id}')
        keys.sort(key=lambda k: k.key_identifier)
        (enc, mac, dek, *_) = [k.key_value for k in keys] + [None, None, None]
        if not enc or not mac or (not dek):
            self.logger.error(f'Bad SCP02 keys for {chip_id} in storage. enc={enc}, mac={mac}, dek={dek}')
        return scp02_derive_session_keys(enc, mac, dek, sequence_counter)

    async def derive_session_keys_scp03(self, chip_id: Union[str, bytes], key_version_number: int, host_challenge: Union[str, bytes], card_challenge: Union[str, bytes], key_length: Literal[16, 24, 32]=None, security_domain: Union[str, bytes]=None) -> Dict[Literal['enc', 'mac', 'rmac'], bytes]:
        keys = await self.kms_storage_service.get_key_set(chip_id, security_domain, key_version_number)
        if not keys:
            return (None, None, None)
        if len(keys) != 3:
            self.logger.warning(f'Not enough SCP03 keys for {chip_id}')
        keys.sort(key=lambda k: k.key_identifier)
        (enc, mac, dek, *_) = [k.key_value for k in keys] + [None, None, None]
        if not enc or not mac or (not dek):
            self.logger.error(f'Bad SCP03 keys for {chip_id} in storage. enc={enc}, mac={mac}, dek={dek}')
        return scp03_derive_session_keys(enc, mac, host_challenge, card_challenge, key_length)

    async def download_keys_from_goodix_kms(self, chip_ids: List[Union[str, bytes]]) -> List[KeySet]:
        key_sets = await self.download_key_service.download(chip_ids)
        added: List[KeySet] = []
        for ks in key_sets:
            saved = await self.kms_storage_service.add_key_set(to_entity_key_set(ks), False)
            if saved:
                added.append(saved)
        return [to_kms_key_set(ks) for ks in added if ks]

    async def download_keys_from_goodix_kms_to_file(self, chip_ids: List[Union[str, bytes]], file: str):
        config_ok = True
        for item in [CommonConfigurationKeys.GOODIX_KMS_ADDRESS, CommonConfigurationKeys.GOODIX_KMS_CUSTOMER_ID, CommonConfigurationKeys.GOODIX_KMS_KEK, CommonConfigurationKeys.GOODIX_KMS_SERVER_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_D]:
            if not self.configuration_service.get_config(item):
                self.logger.error(f'未配置{item.key}, 无法从Goodix KMS下载初始密钥。')
                config_ok = False
        if not config_ok:
            return
        file = os.path.realpath(file)
        os.makedirs(os.path.dirname(file), exist_ok=True)
        with open(file, 'w', encoding='utf8') as fs:
            key_sets = await self.download_key_service.download(chip_ids)
            to_save = [to_api_key_set(ks) for ks in key_sets]
            for ks in to_save:
                ks.id = None
                for k in ks.keys:
                    k.id = None
                    k.key_set_id = None
            fs.write(json.dumps(to_save, indent=2))
        self.logger.info(f'已将下载的密钥集保存至"{file}"。')

    async def report_chips_to_goodix_kms(self, chip_ids: List[Union[str, bytes]]):
        config_ok = True
        for item in [CommonConfigurationKeys.GOODIX_KMS_ADDRESS, CommonConfigurationKeys.GOODIX_KMS_CUSTOMER_ID, CommonConfigurationKeys.GOODIX_KMS_KEK, CommonConfigurationKeys.GOODIX_KMS_SERVER_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_D]:
            if not self.configuration_service.get_config(item):
                self.logger.error(f'未配置{item.key}, 无法上报至Goodix KMS。')
                config_ok = False
        if not config_ok or not chip_ids:
            return
        await self.download_key_service.report(chip_ids)
        self.logger.info(f'已将芯片上报至"{self.configuration_service.get_config(CommonConfigurationKeys.GOODIX_KMS_ADDRESS)}"。已经上报的芯片将无法下载密钥。')

    async def encrypt_key_set(self, session_key_set_id: Union[str, bytes], key_set_id: Union[str, bytes]) -> KeySet:
        session_key_set: DesSessionKeySet | AesSessionKeySet | Sm4SessionKeySet = self.session_key_set_cache.get(session_key_set_id, None)
        if not session_key_set:
            raise Exception(f'Cannot find session key set by key_set_id={hex(key_set_id)}')
        key_set = await self.get_key_set_by_id(key_set_id)
        if not key_set:
            raise Exception(f'Cannot find key set by key_set_id={hex(key_set_id)}')
        dek = session_key_set.dek.key_value
        encrypted = key_set.clone()
        if session_key_set.algorithm == KeySetAlgorithm.DES:
            for key in encrypted.keys.values():
                key.key_check_value = calc_key_check_value(key)
                key.key_value = des3_cbc_encrypt(dek, key.key_value)
        elif session_key_set.algorithm == KeySetAlgorithm.AES:
            for key in encrypted.keys.values():
                key.key_check_value = calc_key_check_value(key)
                key.key_value = aes_cbc_encrypt(dek, key.key_value)
        elif session_key_set.algorithm == KeySetAlgorithm.SM4:
            for key in encrypted.keys.values():
                key.key_check_value = calc_key_check_value(key)
                key.key_value = sm4_cbc_encrypt(dek, key.key_value)
        else:
            raise Exception(f'encrypt_key_set currently does not support session_key_set.algorithm={session_key_set.algorithm}')
        return encrypted

    async def encrypt_key_set_aes(self, dek_id: Union[str, bytes], key_set_id: Union[str, bytes]) -> List[Tuple[KeyType, bytes, bytes]]:
        dek = await self.get_key_by_id(dek_id)
        if not dek:
            raise Exception(f'Cannot find KEY-DEK by id={hex(dek_id)}')
        key_set = await self.get_key_set_by_id(key_set_id)
        if not key_set:
            raise Exception(f'Cannot find KEY-INPUT by key_set_id={hex(key_set_id)}')
        return [(key.key_type, aes_cbc_encrypt(dek.key_value, key.key_value, iv=bytes(16)), calc_key_check_value(key)) for key in sorted(key_set.keys.values(), key=lambda k: k.key_identifier)]

    async def encrypt_key_set_des(self, dek: Union[str, bytes], key_set_id: Union[str, bytes]) -> List[Tuple[KeyType, bytes, bytes]]:
        dek = to_bytes(dek)
        key_set = await self.get_key_set_by_id(key_set_id)
        if not key_set:
            raise Exception(f'Cannot find KEY-INPUT by key_set_id={hex(key_set_id)}')
        return [(key.key_type, des3_cbc_encrypt(dek, key.key_value), calc_key_check_value(key)) for key in sorted(key_set.keys.values(), key=lambda k: k.key_identifier)]
__all__ = [KeyManagementService.__name__]