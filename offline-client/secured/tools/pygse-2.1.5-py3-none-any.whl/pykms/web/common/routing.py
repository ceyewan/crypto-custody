import glob
import importlib
import inspect
import os
from types import ModuleType
from typing import Any, Dict, List, Optional, Tuple
from .base_request_handler import BaseRequestHandler

def route(path: str, kwargs: Optional[Dict[str, Any]]=None, name: Optional[str]=None):

    def inner(cls):
        cls.__route__ = (path, cls, kwargs or {}, name)
        return cls
    return inner

def scan_handlers(root_module: ModuleType):
    root_path = root_module.__path__[0]
    root_package = root_module.__package__
    handler_files: List[str] = glob.glob(os.path.join(root_path, '**/*_handler.py'), recursive=True)
    handlers: List[Tuple] = []
    for handler_file in handler_files:
        p: str = os.path.relpath(os.path.splitext(handler_file)[0], root_path)
        module_name = p.replace(os.path.sep, '.')
        module = importlib.import_module(f'{root_package}.{module_name}')
        for (name, obj) in inspect.getmembers(module):
            if inspect.isclass(obj) and issubclass(obj, BaseRequestHandler) and (obj != BaseRequestHandler):
                if hasattr(obj, '__route__'):
                    handlers.append(getattr(obj, '__route__'))
    return handlers
__all__ = [route.__name__, scan_handlers.__name__]