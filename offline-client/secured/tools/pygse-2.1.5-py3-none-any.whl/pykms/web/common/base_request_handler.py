import json
import logging
import tornado.web
from typing import Any, Dict, Union
from ...base.common.instance_service import IInstanceService

class BaseRequestHandler(tornado.web.RequestHandler):
    instanceService: IInstanceService

    async def prepare(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def initialize(self, *args, instanceService: IInstanceService, **kwargs) -> None:
        self.instanceService = instanceService
        return super().initialize(*args, **kwargs)

class BaseRestHandler(BaseRequestHandler):

    def get_body_json(self) -> Dict[str, Any]:
        return json.loads(self.request.body)

    def send_error(self, status_code: int=500, error: Any=None, **kwargs: Any) -> None:
        try:
            self.write(dict(status=status_code, error=str(error)))
        except Exception as ex:
            self.logger.error(ex)
        if not self._finished:
            self.finish()

    def write(self, data: Union[str, bytes, dict, object]) -> None:
        if isinstance(data, (bytes, str, dict)):
            return super().write(data)
        else:
            data = json.dumps(data)
            self.set_header('Content-Type', 'application/json; charset=UTF-8')
            return super().write(data)
__all__ = [BaseRequestHandler.__name__, BaseRestHandler.__name__]