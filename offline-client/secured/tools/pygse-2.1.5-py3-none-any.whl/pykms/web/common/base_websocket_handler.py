import json
import logging
import tornado.web
from tornado.websocket import WebSocketHandler
from typing import Any, Dict
from ...base.common.instance_service import IInstanceService
from .base_request_handler import BaseRequestHandler

class BaseWebSocketHandler(WebSocketHandler):
    instanceService: IInstanceService

    async def prepare(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def initialize(self, *args, instanceService: IInstanceService, **kwargs) -> None:
        self.instanceService = instanceService
        return super().initialize(*args, **kwargs)

    def on_message(self, message):
        super().on_message()
        try:
            data = json.loads(message)
            cmd = data.get('cmd')
            if cmd == 'command1':
                response_data = {'cmd': 'command1_response', 'data': 'Data from command1'}
            elif cmd == 'command2':
                response_data = {'cmd': 'command2_response', 'data': 'Data from command2'}
            else:
                response_data = {'cmd': 'unknown_command', 'data': 'Unknown command'}
            response_message = json.dumps(response_data)
            self.write_message(response_message)
        except json.JSONDecodeError:
            print('Invalid JSON format received')

    def on_close(self):
        print('WebSocket connection closed')

    def send_error(self, status_code: int=500, error: Any=None, **kwargs: Any) -> None:
        try:
            self.write(dict(status=status_code, error=str(error)))
        except Exception as ex:
            self.logger.error(ex)
        if not self._finished:
            self.finish()
import tornado.websocket
import tornado.web
import tornado.ioloop
import json
import asyncio

class WebSocketHandler(tornado.websocket.WebSocketHandler):

    def open(self):
        print('WebSocket connection opened')
        self.counter = 1
        self.requests = {}

    async def send_message(self, message):
        future = asyncio.Future()
        message['future'] = future
        self.write_message(json.dumps(message))
        await future
        return future.result()

    def on_message(self, message):
        message_data = json.loads(message)
        if message_data['cmd'] == 'request':
            request_id = message_data['id']
            response_message = {'id': request_id, 'request_id': request_id, 'cmd': 'response', 'data': 'Response data for request with id {}'.format(request_id)}
            self.write_message(json.dumps(response_message))
            print('Sent response message for request with id {}'.format(request_id))
        elif message_data['cmd'] == 'ack':
            request_id = message_data['request_id']
            if request_id in self.requests:
                print('Received ack for request with id {}'.format(request_id))
                request_data = self.requests[request_id]
                future = request_data['future']
                future.set_result(message_data['data'])
                del self.requests[request_id]

    async def send_next_message(self):
        if self.counter in self.requests:
            request_data = self.requests[self.counter]
            await self.send_message(request_data)
            print('Sent request with id {}'.format(self.counter))
        self.counter += 1

    async def send_message_periodically(self):
        while True:
            await asyncio.sleep(5)
            request_id = self.counter
            request_message = {'id': request_id, 'cmd': 'request'}
            self.requests[request_id] = request_message
            await self.send_next_message()

    def on_close(self):
        print('WebSocket connection closed')

def make_app():
    return tornado.web.Application([('/ws', WebSocketHandler)])
if __name__ == '__main__':
    app = make_app()
    app.listen(8888)
    asyncio.get_event_loop().create_task(WebSocketHandler().send_message_periodically())
    tornado.ioloop.IOLoop.current().start()
__all__ = [BaseWebSocketHandler.__name__]