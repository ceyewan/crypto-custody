import logging
import os
from socket import AddressFamily
import socket
import tornado
import tornado.web
import tornado.httputil
from ..components.configuration.common import IConfigurationService, CommonConfigurationKeys
from ..base.common import IInstanceService, ServiceParam
from .common import scan_handlers
from . import handlers

class WebApplication(tornado.web.Application):

    def __init__(self, instance_service: IInstanceService=ServiceParam(IInstanceService)):
        settings = dict(template_path=os.path.join(os.path.dirname(__file__), 'templates'), static_path=os.path.join(os.path.dirname(__file__), 'static'), cookie_secret=os.urandom(32), login_url='/auth/login')
        super().__init__(**settings)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.instance_service = instance_service
        all_handlers = scan_handlers(handlers)
        for handler in all_handlers:
            handler[2]['instanceService'] = instance_service
        self.wildcard_router.add_rules(all_handlers)
        config_service = instance_service.get(IConfigurationService)
        if config_service.get_config(CommonConfigurationKeys.GOODIX_KMS_AUTO_DOWNLOAD_KEYS):
            for item in [CommonConfigurationKeys.GOODIX_KMS_ADDRESS, CommonConfigurationKeys.GOODIX_KMS_CUSTOMER_ID, CommonConfigurationKeys.GOODIX_KMS_KEK, CommonConfigurationKeys.GOODIX_KMS_SERVER_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_N, CommonConfigurationKeys.GOODIX_KMS_CLIENT_D]:
                if not config_service.get_config(item):
                    self.logger.warning(f'未配置{item.key}, 将无法自动从Goodix KMS下载初始密钥。')

    def listen(self, port: int, address: str=None, *, family: AddressFamily=socket.AF_UNSPEC, backlog: int=tornado.netutil._DEFAULT_BACKLOG, flags: int=None, reuse_port: bool=False, **kwargs) -> tornado.web.HTTPServer:
        self.server = super().listen(port, address, family=family, backlog=backlog, flags=flags, reuse_port=reuse_port, **kwargs)
        for listen in self.binding_address:
            port = listen[1]
            self.logger.info(f'PyKMS Server started on {listen}')
        addresses = f'  pygse config set kms.server http://{address or socket.gethostbyname(socket.gethostname())}:{port}'
        print(f'To use this KMS service for PyGSE, configure your PyGSE using flowing commands:\n1. Set KMS Server:\n{addresses}\n2. Enable Remote Mode:\n  pygse config set kms.enable-remote true')
        return self.server

    @property
    def binding_address(self):
        return [s.getsockname() for s in self.server._sockets.values()]

async def run_web(instance_service: IInstanceService, port: int=None):
    config_service = instance_service.get(IConfigurationService)
    port = port or config_service.get_config(CommonConfigurationKeys.WEB_HTTP_PORT) or 0
    app = instance_service.instance(WebApplication)
    app.listen(port)
    shutdown_event = tornado.locks.Event()
    await shutdown_event.wait()
__all__ = [WebApplication.__name__, run_web.__name__]