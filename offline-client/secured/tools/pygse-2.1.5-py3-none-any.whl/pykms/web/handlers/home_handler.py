from ..common.base_request_handler import BaseRequestHandler

class HomeHandler(BaseRequestHandler):

    async def get(self):
        self.render('home.html', entries='entries')