import inspect
from typing import Any, Callable, Coroutine, Dict, Tuple, Type, Union
from ....global_platform.base import DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet
from ....global_platform.kms.protocol import *
from ....components.key_management.common import IKeyManagementService
from ...common import route, BaseRestHandler

def handler(api: KmsApiType, req_cls):

    def inner(method):
        method.api = api
        method.req_cls = req_cls
        return method
    return inner

def scan_handlers(cls: Type[Any]) -> Dict[str, Tuple[Type[Request], Callable[['KmsApiHandler', Request], Coroutine[None, None, Response]]]]:
    return {func[1].api: (func[1].req_cls, func[1]) for func in inspect.getmembers(cls, predicate=inspect.isfunction) if func[1].__qualname__.startswith(cls.__name__) and hasattr(func[1], 'api')}

@route('/kms/api/(?P<api>[^/]+)')
class KmsApiHandler(BaseRestHandler):
    handlers: Dict[str, Tuple[Type[Request], Callable[['KmsApiHandler', Request], Coroutine[None, None, Response]]]] = {}

    async def prepare(self):
        await super().prepare()
        self.kms_service = self.instanceService.get(IKeyManagementService)
        self.handlers = scan_handlers(self.__class__)
        pass

    async def post(self, api: str):
        api = api.lower()
        try:
            if api not in self.handlers:
                raise Exception(f'Unsupported API: {api}')
            (req_cls, handler) = self.handlers.get(api)
            rsp = await handler(self, req_cls(**self.get_body_json()))
            self.write(rsp)
        except Exception as ex:
            self.logger.exception(ex)
            self.send_error(500, ex)

    @handler(KmsApiType.GET_KEY_SET, GetKeySetRequest)
    async def get_key_set(self, req: GetKeySetRequest):
        try:
            key_set = await self.kms_service.get_key_set(req.chip_id, req.security_domain, req.key_version_number, req.algorithm)
            if key_set:
                return GetKeySetResponse(to_api_key_set(key_set))
            else:
                raise Exception(f'Can not find Key Set with chip_id={hex(req.chip_id)}, sd={hex(req.security_domain)}, kvn={hex(req.key_version_number)}, alg={req.algorithm}')
        except Exception as ex:
            self.logger.error(ex)
            raise ex

    @handler(KmsApiType.NEW_KEY_SET, NewKeySetRequest)
    async def new_key_set(self, req: NewKeySetRequest):
        try:
            key_set = await self.kms_service.new_key_set(req.chip_id, req.security_domain, req.key_version_number, req.algorithm, req.key_length, req.key_enc, req.key_mac, req.key_dek)
            if key_set:
                return NewKeySetResponse(to_api_key_set(key_set))
            else:
                raise Exception(f'Can not create Key Set with chip_id={hex(req.chip_id)}, sd={hex(req.security_domain)}, kvn={hex(req.key_version_number)}, alg={req.algorithm}, len={req.key_length}')
        except Exception as ex:
            self.logger.error(ex)
            raise ex

    @handler(KmsApiType.SAVE_KEY_SET, SaveKeySetRequest)
    async def save_key_set(self, req: SaveKeySetRequest):
        try:
            key_set = await self.kms_service.save_key_set(req.key_set_id, req.override)
            return SaveKeySetResponse(to_api_key_set(key_set))
        except Exception as ex:
            self.logger.error(f'Failed to save chip key set! key_set={hex(req.key_set)}')
            raise ex

    @handler(KmsApiType.DELETE_KEY_SET, DeleteKeySetRequest)
    async def delete_key_set(self, req: DeleteKeySetRequest):
        try:
            if req.key_set_id:
                code = await self.kms_service.delete_key_set_by_id(req.key_set_id)
            elif req.key_version_number:
                code = await self.kms_service.delete_key_set(req.chip_id, req.security_domain, req.key_version_number)
            else:
                raise Exception(f'Parameter Error!')
            if code >= 0:
                return DeleteKeySetResponse(code)
            else:
                return DeleteKeySetResponse(None, code)
        except Exception as ex:
            self.logger.error(f'Failed to save chip key set! key_set={hex(req.key_set)}')
            return DeleteKeySetResponse(StatusCode.E500, str(ex))

    @handler(KmsApiType.DERIVE_SESSION_KEYS, DeriveSessionKeysRequest)
    async def derive_session_keys(self, req: DeriveSessionKeysRequest):
        try:
            key_set: Union[DesSessionKeySet, AesSessionKeySet, Sm4SessionKeySet] = await self.kms_service.derive_session_keys(**req.__dict__)
            if isinstance(key_set, (AesSessionKeySet, Sm4SessionKeySet)):
                dek = key_set.dek.key_value
                key_set.dek.key_value = None
                ks = to_api_key_set(key_set, True)
                key_set.dek.key_value = dek
            else:
                ks = to_api_key_set(key_set, True)
            return DeriveSessionKeysResponse(ks)
        except Exception as ex:
            self.logger.error(f'Failed to save chip key set! key_set_id={hex(req.key_set_id)}, context={hex(req.context)}')
            raise ex

    @handler(KmsApiType.ENCRYPT_KEY_SET, EncryptKeySetRequest)
    async def encrypt_key_set(self, req: EncryptKeySetRequest):
        try:
            key_set = await self.kms_service.encrypt_key_set(req.session_key_set_id, req.key_set_id)
            return EncryptKeySetResponse(to_api_key_set(key_set, True))
        except Exception as ex:
            self.logger.error(f'Failed to encrypt key set! session_key_set_id={hex(req.session_key_set_id)}, key_set_id={hex(req.key_set_id)}')
            raise ex

    @handler(KmsApiType.ENCRYPT_KEY_SET_AES, EncryptKeySetAesRequest)
    async def encrypt_key_set_aes(self, req: EncryptKeySetAesRequest) -> Tuple[bytes, bytes]:
        try:
            keys = await self.kms_service.encrypt_key_set_aes(req.dek_id, req.key_set_id)
            return EncryptKeySetAesResponse(keys)
        except Exception as ex:
            self.logger.error(f'Failed to encrypt key set! dek_id={hex(req.dek_id)}, key_set_id={hex(req.key_set_id)}')
            raise ex

    @handler(KmsApiType.ENCRYPT_KEY_SET_DES, EncryptKeySetDesRequest)
    async def encrypt_key_set_des(self, req: EncryptKeySetDesRequest) -> Tuple[bytes, bytes]:
        try:
            keys = await self.kms_service.encrypt_key_set_des(req.dek, req.key_set_id)
            return EncryptKeySetDesResponse(keys)
        except Exception as ex:
            self.logger.error(f'Failed to encrypt key set! s-dek={hex(req.dek)}, key_set_id={hex(req.key_set_id)}')
            raise ex