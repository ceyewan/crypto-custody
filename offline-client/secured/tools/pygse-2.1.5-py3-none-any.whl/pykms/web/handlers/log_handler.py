from ..common.base_request_handler import BaseRequestHandler

class KmsHandler(BaseRequestHandler):

    async def get(self):
        self.render('home.html', entries='entries')