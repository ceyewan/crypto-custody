import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtAsyncio import run
from .ui.main_window import MainWindow

def main(*argv: str):
    app = QApplication(argv or sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(run())
__all__ = [main.__name__]