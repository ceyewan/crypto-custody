import asyncio
import logging
import os
import sys
from functools import wraps
from typing import Dict, List, Tuple, Union
from PySide6.QtCore import Signal, QObject, QTimer, QSize, QEvent
from PySide6.QtWidgets import QMainWindow, QMessageBox, QLabel, QWidget
from PySide6.QtGui import QIcon, QAction
from pygse import to_bytes
from ..components.pqc_service import PqcService
from ..components.pqc_protocol import PqcAlgorithm
from .main_window_ui import Ui_MainWindow
__dir__ = os.path.dirname(os.path.realpath(__file__))
__pkg_dir__ = os.path.dirname(__dir__)

def async_slot(func):

    @wraps(func)
    def wrapper(self, *args):
        return asyncio.ensure_future(func(self, *args))
    return wrapper

class LogEmitter(QObject):
    on_log = Signal(int, str)

class LogHandler(logging.Handler):

    def __init__(self):
        super().__init__()
        self.log_emitter = LogEmitter()

    def emit(self, record: logging.LogRecord):
        msg = self.format(record)
        self.log_emitter.on_log.emit(record.levelno, msg)

    @property
    def on_log(self):
        return self.log_emitter.on_log

class MainWindow(QMainWindow, Ui_MainWindow):
    log_handler: LogHandler
    cached_key_pair: Dict[PqcAlgorithm, Tuple[str, str]]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        icon = QIcon()
        icon.addFile(os.path.join(__pkg_dir__, 'resources', 'icon.svg'), QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.setWindowIcon(icon)
        self.lbPublicKeyLength = QLabel('公钥：0 ')
        self.lbPublicKeyLength.setToolTip('公钥字节长度')
        self.lbPublicKeyLength.setStyleSheet('color: normal;')
        self.lbPrivateKeyLength = QLabel('私钥：0 ')
        self.lbPrivateKeyLength.setToolTip('私钥字节长度')
        self.lbPrivateKeyLength.setStyleSheet('color: normal;')
        self.statusbar.addPermanentWidget(self.lbPublicKeyLength)
        self.statusbar.addPermanentWidget(self.lbPrivateKeyLength)
        self.cached_key_pair = {}
        self.rbDilithium2.setVisible(False)
        self.rbDilithium3.setVisible(False)
        self.rbDilithium5.setVisible(False)
        self.log_handler = LogHandler()
        self.log_handler.on_log.connect(self.on_log)
        logging.root.name = ''
        logging.root.addHandler(self.log_handler)
        self.set_log_level(logging.INFO)
        self.pqc_service = PqcService()
        QTimer.singleShot(0, self.refresh_device_list)
    can_close = False

    def closeEvent(self, event: QEvent):
        if self.can_close:
            return super().closeEvent(event)
        else:
            event.ignore()

            async def do_close():
                try:
                    await self.pqc_service.close_device()
                except:
                    pass
                finally:
                    self.can_close = True
                self.close()
            asyncio.create_task(do_close())

    def set_log_level(self, level: int):
        logging.root.setLevel(level)
        self.actionLogLevelDebug.setChecked(level == logging.DEBUG)
        self.actionLogLevelInfo.setChecked(level == logging.INFO)
        self.actionLogLevelWarning.setChecked(level == logging.WARNING)
        self.actionLogLevelError.setChecked(level == logging.ERROR)

    def set_log_level_debug(self, *args):
        self.set_log_level(logging.DEBUG)

    def set_log_level_info(self, *args):
        self.set_log_level(logging.INFO)

    def set_log_level_warning(self, *args):
        self.set_log_level(logging.WARNING)

    def set_log_level_error(self, *args):
        self.set_log_level(logging.ERROR)

    def show_user_manual(self, *args):
        pdf_path = f"{os.path.join(__pkg_dir__, 'resources', 'Goodix后量子加密工具用户手册.pdf')}"
        try:
            if sys.platform == 'win32':
                os.startfile(pdf_path)
            else:
                import subprocess
                subprocess.Popen(['xdg-open', real_path], stdout=subprocess.DEVNULL)
        except:
            import webbrowser
            webbrowser.open(f"file:///{pdf_path.replace(os.sep, '/')}")

    def about(self, *args):
        QMessageBox.about(self, '关于', f'This is a Post-Quantum Cryptographic Tool for Goodix SE.\nVersion {__package_version__}')

    def hide_log(self, *args):
        self.gbLog.hide()

    def show_log(self, *args):
        self.gbLog.show()

    def clear_log(self):
        self.txtLog.clear()

    def show_log_context_menu(self, pos):
        menu = self.txtLog.createStandardContextMenu()
        menu.addSeparator()
        menu.addAction(self.actionClearLog)
        menu.exec(self.txtLog.mapToGlobal(pos))

    def set_busy(self, busy: bool):
        enable = not busy
        controls: List[Union[QAction, QWidget]] = [self.rbCapsuleContainer, self.rbSignContainer, self.cbDeviceList, self.btRefreshDeviceList, self.btSignSetKey, self.btSignGetKey, self.btSignGenerateKey, self.btSign, self.btSignVerify, self.btCapsuleSetKey, self.btCapsuleGetKey, self.btCapsuleGenerateKey, self.btEncapShareSecretKey, self.btDecapShareSecretKeyCipher, self.actionInstallPqcApplet, self.actionDeletePqcApplet]
        for item in controls:
            item.setEnabled(enable)

    @async_slot
    async def refresh_device_list(self, *args):
        asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
        self.devices = self.pqc_service.get_pqc_device_list()
        self.cbDeviceList.clear()
        self.cbDeviceList.addItems([d.name for d in self.devices])
        logging.info('Device list updated.')

    @property
    def sign_alg(self) -> PqcAlgorithm:
        if self.rbMlDsa44.isChecked():
            return PqcAlgorithm.ML_DSA_44
        elif self.rbMlDsa65.isChecked():
            return PqcAlgorithm.ML_DSA_65
        elif self.rbMlDsa87.isChecked():
            return PqcAlgorithm.ML_DSA_87
        else:
            raise ValueError('No algorithm selected.')

    @async_slot
    async def sign_algorithm_changed(self, *args):
        if self.sign_alg in self.cached_key_pair:
            (public_key, private_key) = self.cached_key_pair[self.sign_alg]
            self.txtSignPublicKey.setPlainText(public_key)
            self.txtSignPrivateKey.setPlainText(private_key)
        else:
            self.txtSignPublicKey.clear()
            self.txtSignPrivateKey.clear()

    @async_slot
    async def sign_generate_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            (public_key, private_key) = await self.pqc_service.generate_key(self.sign_alg)
            self.txtSignPublicKey.setPlainText(hex(public_key))
            self.txtSignPrivateKey.setPlainText(hex(private_key))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def sign_set_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            public_key = to_bytes(self.txtSignPublicKey.toPlainText())
            private_key = to_bytes(self.txtSignPrivateKey.toPlainText())
            await self.pqc_service.set_key(self.sign_alg, public_key, private_key)
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def sign_get_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            (public_key, private_key) = await self.pqc_service.get_key(self.sign_alg)
            self.txtSignPublicKey.setPlainText(hex(public_key))
            self.txtSignPrivateKey.setPlainText(hex(private_key))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def sign(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            signature = await self.pqc_service.sign(self.sign_alg, self.txtSignPlain.toPlainText(), self.txtSignContext.toPlainText())
            self.txtSignature.setPlainText(hex(signature))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def sign_verify(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            await self.pqc_service.verify(self.sign_alg, self.txtSignature.toPlainText(), self.txtSignPlain.toPlainText(), self.txtSignContext.toPlainText())
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def sign_public_key_changed(self):
        try:
            to_bytes(self.txtSignPublicKey.toPlainText())
            self.txtSignPublicKey.setStyleSheet('')
        except Exception as ex:
            self.txtSignPublicKey.setStyleSheet('QPlainTextEdit{border: 1px solid red;}')
        self.cached_key_pair[self.sign_alg] = (self.txtSignPublicKey.toPlainText(), self.txtSignPrivateKey.toPlainText())
        await self.update_key_status_tip()

    @async_slot
    async def sign_private_key_changed(self):
        try:
            to_bytes(self.txtSignPrivateKey.toPlainText())
            self.txtSignPrivateKey.setStyleSheet('')
        except Exception as ex:
            self.txtSignPrivateKey.setStyleSheet('QPlainTextEdit{border: 1px solid red;}')
        self.cached_key_pair[self.sign_alg] = (self.txtSignPublicKey.toPlainText(), self.txtSignPrivateKey.toPlainText())
        await self.update_key_status_tip()

    @property
    def capsule_alg(self) -> PqcAlgorithm:
        if self.rbMlKem512.isChecked():
            return PqcAlgorithm.ML_KEM_512
        elif self.rbMlKem768.isChecked():
            return PqcAlgorithm.ML_KEM_768
        elif self.rbMlKem1024.isChecked():
            return PqcAlgorithm.ML_KEM_1024
        else:
            raise ValueError('No algorithm selected.')

    @async_slot
    async def capsule_algorithm_changed(self, *args):
        if self.capsule_alg in self.cached_key_pair:
            (public_key, private_key) = self.cached_key_pair[self.capsule_alg]
            self.txtCapsulePublicKey.setPlainText(public_key)
            self.txtCapsulePrivateKey.setPlainText(private_key)
        else:
            self.txtCapsulePublicKey.clear()
            self.txtCapsulePrivateKey.clear()

    @async_slot
    async def capsule_generate_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            (public_key, private_key) = await self.pqc_service.generate_key(self.capsule_alg)
            self.txtCapsulePublicKey.setPlainText(hex(public_key))
            self.txtCapsulePrivateKey.setPlainText(hex(private_key))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def capsule_get_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            (public_key, private_key) = await self.pqc_service.get_key(self.capsule_alg)
            self.cached_key_pair[self.capsule_alg] = (public_key, private_key)
            self.txtCapsulePublicKey.setPlainText(hex(public_key))
            self.txtCapsulePrivateKey.setPlainText(hex(private_key))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def capsule_set_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            public_key = to_bytes(self.txtCapsulePublicKey.toPlainText())
            private_key = to_bytes(self.txtCapsulePrivateKey.toPlainText())
            await self.pqc_service.set_key(self.capsule_alg, public_key, private_key)
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def encapsulate_share_secret_key(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            (share_secret_key, cipher) = await self.pqc_service.encapsulate(self.capsule_alg)
            self.txtCapsuleSharedSecretKey.setPlainText(hex(share_secret_key))
            self.txtCapsuleCipherText.setPlainText(hex(cipher))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def decapsulate_share_secret_key_cipher(self, *args):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()])
            share_secret_key = await self.pqc_service.decapsulate(self.capsule_alg, self.txtCapsuleCipherText.toPlainText())
            self.txtCapsuleSharedSecretKey.setPlainText(hex(share_secret_key))
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def capsule_public_key_changed(self):
        try:
            to_bytes(self.txtCapsulePublicKey.toPlainText())
            self.txtCapsulePublicKey.setStyleSheet('')
        except Exception as ex:
            self.txtCapsulePublicKey.setStyleSheet('QPlainTextEdit{border: 1px solid red;}')
        self.cached_key_pair[self.capsule_alg] = (self.txtCapsulePublicKey.toPlainText(), self.txtCapsulePrivateKey.toPlainText())
        await self.update_key_status_tip()

    @async_slot
    async def capsule_private_key_changed(self):
        try:
            to_bytes(self.txtCapsulePrivateKey.toPlainText())
            self.txtCapsulePrivateKey.setStyleSheet('')
        except Exception as ex:
            self.txtCapsulePrivateKey.setStyleSheet('QPlainTextEdit{border: 1px solid red;}')
        self.cached_key_pair[self.capsule_alg] = (self.txtCapsulePublicKey.toPlainText(), self.txtCapsulePrivateKey.toPlainText())
        await self.update_key_status_tip()

    @async_slot
    async def update_key_status_tip(self, *args):
        if self.tabWidget.currentIndex() == 0:
            pub_key = self.txtSignPublicKey.toPlainText()
            pri_key = self.txtSignPrivateKey.toPlainText()
        else:
            pub_key = self.txtCapsulePublicKey.toPlainText()
            pri_key = self.txtCapsulePrivateKey.toPlainText()
        pub_key_len = 0
        try:
            pub_key_len = len(to_bytes(pub_key))
            self.lbPublicKeyLength.setStyleSheet('color: normal;')
        except:
            pub_key_len = '输入错误'
            self.lbPublicKeyLength.setStyleSheet('color: red;')
        self.lbPublicKeyLength.setText(f'公钥：{pub_key_len} ')
        pri_key_len = 0
        try:
            pri_key_len = len(to_bytes(pri_key))
            self.lbPrivateKeyLength.setStyleSheet('color: normal;')
        except:
            pri_key_len = '输入错误'
            self.lbPrivateKeyLength.setStyleSheet('color: red;')
        self.lbPrivateKeyLength.setText(f'私钥：{pri_key_len} ')

    @async_slot
    async def install_applet(self):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()], bytes())
            await self.pqc_service.install_applet()
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def delete_applet(self):
        self.set_busy(True)
        try:
            await self.pqc_service.use_device(self.devices[self.cbDeviceList.currentIndex()], bytes())
            await self.pqc_service.delete_applet()
        except Exception as ex:
            logging.error(ex)
        finally:
            self.set_busy(False)

    @async_slot
    async def on_log(self, level: int, msg: str, *args):
        self.txtLog.appendPlainText(msg)
        if level >= logging.ERROR:
            self.statusbar.setStyleSheet('color: red;')
        elif self.statusbar.styleSheet():
            self.statusbar.setStyleSheet('')
        self.statusbar.showMessage(msg[msg.find(']: ') + 3:])