from enum import IntEnum
from typing import Literal
from pygse import CommandAPDU, ResponseAPDU
PQC_APP_AID = bytes.fromhex('A00000484447534E3131100010240001')

class PqcAlgorithm(IntEnum):
    ML_KEM_512 = 83
    ML_KEM_768 = 84
    ML_KEM_1024 = 85
    ML_DSA_44 = 86
    ML_DSA_65 = 87
    ML_DSA_87 = 88

class PqcKeySize(IntEnum):
    ML_KEM_512_PUBLIC_KEY = 800
    ML_KEM_768_PUBLIC_KEY = 1184
    ML_KEM_1024_PUBLIC_KEY = 1568
    ML_KEM_512_PRIVATE_KEY = 1632
    ML_KEM_768_PRIVATE_KEY = 2400
    ML_KEM_1024_PRIVATE_KEY = 3168
    ML_DSA_44_PUBLIC_KEY = 1312
    ML_DSA_65_PUBLIC_KEY = 1952
    ML_DSA_87_PUBLIC_KEY = 2592
    ML_DSA_44_PRIVATE_KEY = 2560
    ML_DSA_65_PRIVATE_KEY = 4032
    ML_DSA_87_PRIVATE_KEY = 4896

class PqcAction(IntEnum):
    GenerateKey = 0
    SetPublicKey = 1
    SetPrivateKey = 2
    GetPublicKey = 3
    GetPrivateKey = 4
    EncapsulateShareSecretKey = 7
    DecapsulateShareSecretKey = 8
    Sign = 7
    Verify = 8

def check_key(algorithm: PqcAlgorithm, action: PqcAction, key: bytes):
    if algorithm == PqcAlgorithm.ML_KEM_512:
        if action in [PqcAction.SetPublicKey, PqcAction.GetPublicKey]:
            assert len(key) == PqcKeySize.ML_KEM_512_PUBLIC_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_KEM_512_PUBLIC_KEY}'
        elif action in [PqcAction.SetPrivateKey, PqcAction.GetPrivateKey]:
            assert len(key) == PqcKeySize.ML_KEM_512_PRIVATE_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_KEM_512_PRIVATE_KEY}'
    elif algorithm == PqcAlgorithm.ML_KEM_768:
        if action in [PqcAction.SetPublicKey, PqcAction.GetPublicKey]:
            assert len(key) == PqcKeySize.ML_KEM_768_PUBLIC_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_KEM_768_PUBLIC_KEY}'
        elif action in [PqcAction.SetPrivateKey, PqcAction.GetPrivateKey]:
            assert len(key) == PqcKeySize.ML_KEM_768_PRIVATE_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_KEM_768_PRIVATE_KEY}'
    elif algorithm == PqcAlgorithm.ML_KEM_1024:
        if action in [PqcAction.SetPublicKey, PqcAction.GetPublicKey]:
            assert len(key) == PqcKeySize.ML_KEM_1024_PUBLIC_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_KEM_1024_PUBLIC_KEY}'
        elif action in [PqcAction.SetPrivateKey, PqcAction.GetPrivateKey]:
            assert len(key) == PqcKeySize.ML_KEM_1024_PRIVATE_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_KEM_1024_PRIVATE_KEY}'
    elif algorithm == PqcAlgorithm.ML_DSA_44:
        if action in [PqcAction.SetPublicKey, PqcAction.GetPublicKey]:
            assert len(key) == PqcKeySize.ML_DSA_44_PUBLIC_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_DSA_44_PUBLIC_KEY}'
        elif action in [PqcAction.SetPrivateKey, PqcAction.GetPrivateKey]:
            assert len(key) == PqcKeySize.ML_DSA_44_PRIVATE_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_DSA_44_PRIVATE_KEY}'
    elif algorithm == PqcAlgorithm.ML_DSA_65:
        if action in [PqcAction.SetPublicKey, PqcAction.GetPublicKey]:
            assert len(key) == PqcKeySize.ML_DSA_65_PUBLIC_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_DSA_65_PUBLIC_KEY}'
        elif action in [PqcAction.SetPrivateKey, PqcAction.GetPrivateKey]:
            assert len(key) == PqcKeySize.ML_DSA_65_PRIVATE_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_DSA_65_PRIVATE_KEY}'
    elif algorithm == PqcAlgorithm.ML_DSA_87:
        if action in [PqcAction.SetPublicKey, PqcAction.GetPublicKey]:
            assert len(key) == PqcKeySize.ML_DSA_87_PUBLIC_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_DSA_87_PUBLIC_KEY}'
        elif action in [PqcAction.SetPrivateKey, PqcAction.GetPrivateKey]:
            assert len(key) == PqcKeySize.ML_DSA_87_PRIVATE_KEY, f'无效的密钥长度: {len(key)}, 期望: {PqcKeySize.ML_DSA_87_PRIVATE_KEY}'

class PqcGenerateKeyCommand(CommandAPDU):
    p1: PqcAlgorithm
    p2: Literal[0]

    def __init__(self, p1: PqcAlgorithm=0):
        super().__init__(128, 174, p1)

class PqcSetKeyCommand(CommandAPDU):
    p1: PqcAlgorithm
    p2: Literal[PqcAction.SetPublicKey, PqcAction.SetPrivateKey]

    def __init__(self, p1: PqcAlgorithm=0, p2: Literal[PqcAction.SetPublicKey, PqcAction.SetPrivateKey]=PqcAction.SetPublicKey, key: bytes=None):
        super().__init__(128, 174, p1, p2, key)

    @property
    def key(self):
        return self.data

    @key.setter
    def key(self, value: bytes):
        self.data = value

class PqcGetKeyCommand(CommandAPDU):
    p1: PqcAlgorithm
    p2: Literal[PqcAction.GetPublicKey, PqcAction.GetPrivateKey]

    def __init__(self, p1: PqcAlgorithm=0, p2: Literal[PqcAction.GetPublicKey, PqcAction.GetPrivateKey]=PqcAction.GetPublicKey):
        super().__init__(128, 174, p1, p2)

class PqcSignCommand(CommandAPDU):
    p1: Literal[PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87]
    p2: PqcAction.Sign
    plain: bytes = None
    context: bytes = None

    def __init__(self, p1: Literal[PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87]=PqcAlgorithm.ML_DSA_44, plain: bytes=None, context: bytes=None):
        super().__init__(128, 174, p1, PqcAction.Sign)
        self.plain = plain or bytes()
        self.context = context or bytes()

    def serialize_data(self, stream):
        stream.write_int(len(self.plain), 2, 'big')
        stream.write(self.plain)
        stream.write_int(len(self.context), 1)
        stream.write(self.context)

    def deserialize_data(self, stream):
        self.plain = stream.read(stream.read_int(2, 'big'))
        self.context = stream.read(stream.read_int(1))

class PqcVerifyCommand(CommandAPDU):
    p1: Literal[PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87]
    p2: PqcAction.Verify
    signature: bytes = None
    plain: bytes = None
    context: bytes = None

    def __init__(self, p1: Literal[PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87]=PqcAlgorithm.ML_DSA_44, signature: bytes=None, plain: bytes=None, context: bytes=None):
        super().__init__(128, 174, p1, PqcAction.Verify)
        self.signature = signature or bytes()
        self.plain = plain or bytes()
        self.context = context or bytes()

    def serialize_data(self, stream):
        stream.write_int(len(self.signature), 2, 'big')
        stream.write(self.signature)
        stream.write_int(len(self.plain), 2, 'big')
        stream.write(self.plain)
        stream.write_int(len(self.context), 1)
        stream.write(self.context)

    def deserialize_data(self, stream):
        self.signature = stream.read(stream.read_int(2, 'big'))
        self.plain = stream.read(stream.read_int(2, 'big'))
        self.context = stream.read(stream.read_int(1))

class PqcEncapsulateCommand(CommandAPDU):
    p1: Literal[PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024]
    p2: PqcAction.EncapsulateShareSecretKey

    def __init__(self, p1: Literal[PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024]=PqcAlgorithm.ML_KEM_512):
        super().__init__(128, 174, p1, PqcAction.EncapsulateShareSecretKey)

class PqcDecapsulateCommand(CommandAPDU):
    p1: Literal[PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024]
    p2: PqcAction.EncapsulateShareSecretKey

    def __init__(self, p1: Literal[PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024]=PqcAlgorithm.ML_KEM_512, cipher: bytes=None):
        super().__init__(128, 174, p1, PqcAction.DecapsulateShareSecretKey, cipher)

    @property
    def cipher(self):
        return self.data

    @cipher.setter
    def cipher(self, value: bytes):
        self.data = value