from typing import Dict, Literal, Tuple, Union
from pygse import IVirtualSe, CommandAPDU, ResponseAPDU, StatusCode, to_bytes, BytesIO, Instruction
from dilithium_py.ml_dsa import ML_DSA_44, ML_DSA_65, ML_DSA_87
from kyber_py.ml_kem import ML_KEM_512, ML_KEM_768, ML_KEM_1024
from .pqc_protocol import PqcAlgorithm, PqcAction, PqcGenerateKeyCommand, PqcGetKeyCommand, PqcSetKeyCommand, PqcSignCommand, PqcVerifyCommand, PqcEncapsulateCommand, PqcDecapsulateCommand, check_key
STATUS_OK = to_bytes(StatusCode.SW9000.value)
STATUS_NOT_FOUND = to_bytes(StatusCode.SW6A83.value)

class VirtualPqcDevice(IVirtualSe):
    cached_key_pair: Dict[PqcAlgorithm, Tuple[bytes, bytes]]

    def __init__(self, uri_or_info):
        super().__init__(uri_or_info)
        self.cached_key_pair = {}

    def process_command(self, cmd: bytes):
        ins = cmd[1]
        if ins == Instruction.SELECT:
            self.cached_key_pair.clear()
            return STATUS_OK
        elif ins == 174:
            return self.process_pqc_command(cmd)
        return bytes.fromhex('9000')

    def process_pqc_command(self, cmd: bytes):
        alg = PqcAlgorithm(cmd[2])
        action = PqcAction(cmd[3])
        if alg in (PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87):
            if alg == PqcAlgorithm.ML_DSA_44:
                signer = ML_DSA_44
            elif alg == PqcAlgorithm.ML_DSA_65:
                signer = ML_DSA_65
            elif alg == PqcAlgorithm.ML_DSA_87:
                signer = ML_DSA_87
            else:
                return STATUS_NOT_FOUND
            if action == PqcAction.GenerateKey:
                (public_key, private_key) = signer.keygen()
                self.cached_key_pair[alg] = (public_key, private_key)
                return STATUS_OK
            elif action == PqcAction.GetPublicKey:
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                return public_key + STATUS_OK if public_key else STATUS_NOT_FOUND
            elif action == PqcAction.GetPrivateKey:
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                return private_key + STATUS_OK if private_key else STATUS_NOT_FOUND
            elif action == PqcAction.SetPublicKey:
                pkt = PqcSetKeyCommand().deserialize(BytesIO(cmd))
                check_key(alg, PqcAction.SetPublicKey, pkt.key)
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                self.cached_key_pair[alg] = (pkt.key, private_key)
                return STATUS_OK
            elif action == PqcAction.SetPrivateKey:
                pkt = PqcSetKeyCommand().deserialize(BytesIO(cmd))
                check_key(alg, PqcAction.SetPrivateKey, pkt.key)
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                self.cached_key_pair[alg] = (public_key, pkt.key)
                return STATUS_OK
            elif action == PqcAction.Sign:
                pkt = PqcSignCommand().deserialize(BytesIO(cmd))
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                if not private_key:
                    return STATUS_NOT_FOUND
                cypher = signer.sign(private_key, pkt.plain, pkt.context)
                return cypher + STATUS_OK
            elif action == PqcAction.Verify:
                pkt = PqcVerifyCommand().deserialize(BytesIO(cmd))
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                if not public_key:
                    return STATUS_NOT_FOUND
                ok = signer.verify(public_key, pkt.plain, pkt.signature, pkt.context)
                return STATUS_OK if ok else STATUS_NOT_FOUND
        elif alg in (PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024):
            if alg == PqcAlgorithm.ML_KEM_512:
                ml_kem = ML_KEM_512
            elif alg == PqcAlgorithm.ML_KEM_768:
                ml_kem = ML_KEM_768
            elif alg == PqcAlgorithm.ML_KEM_1024:
                ml_kem = ML_KEM_1024
            else:
                return STATUS_NOT_FOUND
            if action == PqcAction.GenerateKey:
                (public_key, private_key) = ml_kem.keygen()
                self.cached_key_pair[alg] = (public_key, private_key)
                return STATUS_OK
            elif action == PqcAction.GetPublicKey:
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                return public_key + STATUS_OK if public_key else STATUS_NOT_FOUND
            elif action == PqcAction.GetPrivateKey:
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                return private_key + STATUS_OK if private_key else STATUS_NOT_FOUND
            elif action == PqcAction.SetPublicKey:
                pkt = PqcSetKeyCommand().deserialize(BytesIO(cmd))
                check_key(alg, PqcAction.SetPublicKey, pkt.key)
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                self.cached_key_pair[alg] = (pkt.key, private_key)
                return STATUS_OK
            elif action == PqcAction.SetPrivateKey:
                pkt = PqcSetKeyCommand().deserialize(BytesIO(cmd))
                check_key(alg, PqcAction.SetPrivateKey, pkt.key)
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                self.cached_key_pair[alg] = (public_key, pkt.key)
                return STATUS_OK
            elif action == PqcAction.EncapsulateShareSecretKey:
                pkt = PqcEncapsulateCommand().deserialize(BytesIO(cmd))
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                if not public_key:
                    return STATUS_NOT_FOUND
                (secret_key, cypher) = ml_kem.encaps(public_key)
                return secret_key + cypher + STATUS_OK
            elif action == PqcAction.DecapsulateShareSecretKey:
                pkt = PqcDecapsulateCommand().deserialize(BytesIO(cmd))
                (public_key, private_key) = self.cached_key_pair.get(alg, (None, None))
                if not private_key:
                    return STATUS_NOT_FOUND
                secret_key = ml_kem.decaps(private_key, pkt.cipher)
                return secret_key + STATUS_OK