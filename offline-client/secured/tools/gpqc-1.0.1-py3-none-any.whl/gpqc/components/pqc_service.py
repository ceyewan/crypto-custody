import logging
import os
from typing import Literal, Tuple, Union
from pygse import PyGseServiceFactory, list_devices, DeviceInfo, DeviceType, SecurityDevice, to_bytes, CapFile
from .pqc_protocol import PqcAlgorithm, PqcAction, PqcGenerateKeyCommand, PqcGetKeyCommand, PqcSetKeyCommand, PqcSignCommand, PqcVerifyCommand, PqcEncapsulateCommand, PqcDecapsulateCommand, check_key, PQC_APP_AID
from .pqc_virtual_device import VirtualPqcDevice
SIMULATOR_IN_ECSTARRY = DeviceInfo.new_socket('127.0.0.1:7788', 'Ecstarry中的模拟器(localhost:7788)')
VIRTUAL_SE = DeviceInfo.new_custom('virtual_se', '虚拟设备(纯软实现)')
__dir__ = os.path.dirname(os.path.realpath(__file__))
__pkg_dir__ = os.path.dirname(__dir__)

def safe_bytes(data: Union[str, bytes]) -> bytes:
    try:
        return to_bytes(data)
    except:
        pass
    return data.encode('utf-8')

class PqcService:
    current_device: SecurityDevice = None
    current_aid: bytes = None
    cap_lib_path: str
    cap_lib: CapFile = None
    cap_app_path: str
    cap_app: CapFile = None

    def __init__(self):
        self.serviceFactory = PyGseServiceFactory()
        self.device_service = self.serviceFactory.device_service
        self.device_service.register_device(VIRTUAL_SE.type, VirtualPqcDevice)
        self.cap_lib_path = os.path.join(__pkg_dir__, 'resources', 'cap', 'crypto.cap')
        self.cap_app_path = os.path.join(__pkg_dir__, 'resources', 'cap', 'pqcalgtestapplet.cap')

    def get_pqc_device_list(self):
        devices = [*filter(lambda d: d.type == DeviceType.CCID, list_devices()), SIMULATOR_IN_ECSTARRY, VIRTUAL_SE]
        return devices

    async def use_device(self, device: DeviceInfo, select_app_aid: bool=PQC_APP_AID):
        if self.current_device:
            if self.current_device.device.closed or self.current_device.device.dev_info.name != device.name:
                await self.device_service.close(device)
                self.current_aid = None
        self.current_device = await self.device_service.open(device)
        if select_app_aid is not None and self.current_aid != select_app_aid:
            rsp = await self.current_device.select(select_app_aid)
            if not rsp.status_ok:
                msg = f'Select PQC applet failed! code=0x{rsp.status_code}'
                if rsp.status_code == 27266:
                    msg += ' 应用可能未安装，请使用菜单“工具→安装PQC应用”安装PQC加密应用到设备后再试。'
                raise Exception(msg)
            self.current_aid = select_app_aid
        return self.current_device

    async def close_device(self):
        await self.device_service.close_all()

    async def generate_key(self, algorithm: PqcAlgorithm) -> Tuple[bytes, bytes]:
        rsp = await self.current_device.transmit(PqcGenerateKeyCommand(algorithm))
        if not rsp.status_ok:
            raise Exception(f'Generate key failed! code=0x{rsp.status_code}')
        logging.info(f'Generated {algorithm.name} key pair!')
        return await self.get_key(algorithm)

    async def get_key(self, algorithm: PqcAlgorithm) -> Tuple[bytes, bytes]:
        rsp = await self.current_device.transmit(PqcGetKeyCommand(algorithm, PqcAction.GetPublicKey))
        if not rsp.status_ok:
            raise Exception(f'Get public key failed! code=0x{rsp.status_code}')
        public_key = rsp.data
        rsp = await self.current_device.transmit(PqcGetKeyCommand(algorithm, PqcAction.GetPrivateKey))
        if not rsp.status_ok:
            raise Exception(f'Get private key failed! code=0x{rsp.status_code}')
        private_key = rsp.data
        logging.info(f'Read {algorithm.name} key pair! public key size: {len(public_key)}, private key size: {len(private_key)}')
        return (public_key, private_key)

    async def set_key(self, algorithm: PqcAlgorithm, public_key: Union[str, bytes], private_key: Union[str, bytes]) -> Tuple[bytes, bytes]:
        check_key(algorithm, PqcAction.SetPublicKey, public_key)
        check_key(algorithm, PqcAction.SetPrivateKey, private_key)
        rsp = await self.current_device.transmit(PqcSetKeyCommand(algorithm, PqcAction.SetPublicKey, public_key))
        if not rsp.status_ok:
            raise Exception(f'Set public key failed! code=0x{rsp.status_code}')
        rsp = await self.current_device.transmit(PqcSetKeyCommand(algorithm, PqcAction.SetPrivateKey, private_key))
        if not rsp.status_ok:
            raise Exception(f'Set private key failed! code=0x{rsp.status_code}')
        logging.info(f'Updated {algorithm.name} key pair! public key size: {len(public_key)}, private key size: {len(private_key)}')
        return rsp.status_ok

    async def sign(self, algorithm: PqcAlgorithm, plain: Union[str, bytes], context: Union[str, bytes]) -> bytes:
        if algorithm not in (PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87):
            raise Exception('Unsupported algorithm')
        plain = safe_bytes(plain)
        if len(plain) > 65535:
            raise Exception('Too long plain text!')
        context = safe_bytes(context)
        if len(context) > 255:
            raise Exception('Too long context!')
        logging.info(f'Sign:\nplain={hex(plain)}\ncontext={hex(context)}')
        rsp = await self.current_device.transmit(PqcSignCommand(algorithm, plain, context))
        if not rsp.status_ok:
            raise Exception(f'Sign failed! code=0x{rsp.status_code} 请确认公钥和私钥是否已写入设备。如果切换了设备或者算法则需要重新写入密钥。')
        logging.info(f'Signature={hex(rsp.data)}. Size of Signature={len(rsp.data)}')
        return rsp.data

    async def verify(self, algorithm: PqcAlgorithm, signature: Union[str, bytes], plain: Union[str, bytes], context: Union[str, bytes]) -> bool:
        if algorithm not in (PqcAlgorithm.ML_DSA_44, PqcAlgorithm.ML_DSA_65, PqcAlgorithm.ML_DSA_87):
            raise Exception('Unsupported algorithm')
        signature = safe_bytes(signature)
        if len(signature) > 65535:
            raise Exception('Too long signature text!')
        if not signature:
            raise Exception('Empty signature text!')
        plain = safe_bytes(plain)
        if len(plain) > 65535:
            raise Exception('Too long plain text!')
        context = safe_bytes(context)
        if len(context) > 255:
            raise Exception('Too long context!')
        logging.info(f'Verify:\nsignature={hex(signature)}\nplain={hex(plain)}\ncontext={hex(context)}')
        rsp = await self.current_device.transmit(PqcVerifyCommand(algorithm, signature, plain, context))
        if not rsp.status_ok:
            raise Exception(f'Verify failed! code=0x{rsp.status_code} 请确认公钥和私钥是否已写入设备。如果切换了设备或者算法则需要重新写入密钥。')
        logging.info(f'Verify passed!')
        return True

    async def encapsulate(self, algorithm: PqcAlgorithm) -> Tuple[bytes, bytes]:
        if algorithm not in (PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024):
            raise Exception('Unsupported algorithm')
        logging.info(f'Encapsulating share secret key using algorithm={algorithm.name}...')
        rsp = await self.current_device.transmit(PqcEncapsulateCommand(algorithm))
        if not rsp.status_ok:
            raise Exception(f'Encapsulate failed! code=0x{rsp.status_code} 请确认公钥和私钥是否已写入设备。如果切换了设备或者算法则需要重新写入密钥。')
        share_secret_key = rsp.data[:32]
        cypher_text = rsp.data[32:]
        logging.info(f'Encapsulated share secret key using algorithm={algorithm.name}.\nShare secret key={hex(share_secret_key)}\nCypher text={hex(cypher_text)}')
        return (share_secret_key, cypher_text)

    async def decapsulate(self, algorithm: PqcAlgorithm, cipher: Union[str, bytes]) -> Tuple[bytes, bytes]:
        if algorithm not in (PqcAlgorithm.ML_KEM_512, PqcAlgorithm.ML_KEM_768, PqcAlgorithm.ML_KEM_1024):
            raise Exception('Unsupported algorithm')
        cipher = safe_bytes(cipher)
        if len(cipher) > 65535:
            raise Exception('Too long cipher text!')
        if not cipher:
            raise Exception('Empty cipher text!')
        logging.info(f'Decapsulating share secret key using algorithm={algorithm.name}...')
        rsp = await self.current_device.transmit(PqcDecapsulateCommand(algorithm, cipher))
        if not rsp.status_ok:
            raise Exception(f'Encapsulate failed! code=0x{rsp.status_code} 请确认公钥和私钥是否已写入设备。如果切换了设备或者算法则需要重新写入密钥。')
        logging.info(f'Decapsulated share secret key using algorithm={algorithm.name}.\nShare secret key={hex(rsp.data)}')
        return rsp.data

    def load_cap(self):
        if not self.cap_lib:
            self.cap_lib = CapFile(self.cap_lib_path)
        if not self.cap_app:
            self.cap_app = CapFile(self.cap_app_path)
        return (self.cap_lib, self.cap_app)

    async def delete_applet(self):
        if self.current_device.device.dev_info.type.value == 'virtual_se':
            raise Exception('虚拟设备不支持删除!')
        (lib, app) = self.load_cap()
        session = await self.serviceFactory.session_service.create(self.current_device)
        await session.select()
        await session.delete_aid(app.cap_aid)
        await session.delete_aid(lib.cap_aid)

    async def install_applet(self):
        if self.current_device.device.dev_info.type.value == 'virtual_se':
            raise Exception('虚拟设备不支持安装!')
        (lib, app) = self.load_cap()
        session = await self.serviceFactory.session_service.create(self.current_device)
        await session.select()
        await session.delete_aid(app.cap_aid)
        await session.delete_aid(lib.cap_aid)
        await session.install_cap(lib, False)
        await session.install_cap(app, True, app_aid='.')