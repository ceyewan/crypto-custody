import builtins
from .main import *
from .__version__ import *
version = version
product = 'gpqc'
vendor = 'Shenzhen Goodix Technology Co., Ltd.'
builtins.vendor = vendor
builtins.product = product
builtins.__product__ = product
builtins.__package_version__ = version
builtins.__build__ = build
builtins.__commit__ = commit